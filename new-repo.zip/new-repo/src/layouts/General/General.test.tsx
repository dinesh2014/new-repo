import React from 'react';
import { render } from '@testing-library/react';
import General from './General';
import NavBar from '../../components/NavBar/NavBar';
import Claire from '../../components/Claire';

// Mock the NavBar and Claire components
jest.mock('../../components/NavBar/NavBar', () => () => <div>NavBar</div>);
jest.mock('../../components/Claire', () => () => <div>Claire</div>);

describe('General', () => {
  it('should render the General layout component with children', () => {
    const { getByText } = render(
      <General>
        <div>Child Component</div>
      </General>
    );
    expect(getByText('Child Component')).toBeInTheDocument();
  });

  it('should render the NavBar and Claire components', () => {
    const { getByText } = render(<General />);
    expect(getByText('NavBar')).toBeInTheDocument();
    expect(getByText('Claire')).toBeInTheDocument();
  });

  it('should apply the loading class when isLoading is true', () => {
    const { container } = render(<General isLoading={true} />);
    expect(container.firstChild).toHaveClass('animate-pulse');
  });

  it('should not apply the loading class when isLoading is false', () => {
    const { container } = render(<General isLoading={false} />);
    expect(container.firstChild).not.toHaveClass('animate-pulse');
  });
});