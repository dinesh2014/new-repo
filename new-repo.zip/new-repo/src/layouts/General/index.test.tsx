import General from './General';
import DefaultExport from './indext';

describe('indext.tsx', () => {
  it('should re-export General as default', () => {
    expect(DefaultExport).toBe(General);
  });
});