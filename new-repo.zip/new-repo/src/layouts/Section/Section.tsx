/**
 * Props for the Section component.
 */
interface SectionProps {
  id?: string;
  bordered?: boolean;
  paddingX?: number;
  paddingY?: number;
  header?: React.ReactNode;
  children?: React.ReactNode;
}

/**
 * Represents a section component.
 *
 * @component
 * @param {SectionProps} props - The component props.
 * @param {string} props.id - The ID of the section.
 * @param {boolean} [props.bordered=false] - Whether the section should have a border.
 * @param {number} [props.paddingX=0] - The horizontal padding of the section.
 * @param {number} [props.paddingY=0] - The vertical padding of the section.
 * @param {ReactNode} props.header - The header content of the section.
 * @param {ReactNode} props.children - The content of the section.
 * @returns {JSX.Element} The rendered section component.
 */
const Section = ({
  id,
  bordered = false,
  paddingX = 0,
  paddingY = 0,
  header,
  children,
}: SectionProps) => {
  const baseClasses = "";
  const paddingClasses = `px-${paddingX} py-${paddingY}`;
  const borderClasses = bordered
    ? "bg-white rounded-md border-1 border-gray-200"
    : "";

  return (
    <div
      id={id}
      className={`${baseClasses} ${paddingClasses} ${borderClasses}`}
    >
      {header}
      {children}
    </div>
  );
};

export default Section;
