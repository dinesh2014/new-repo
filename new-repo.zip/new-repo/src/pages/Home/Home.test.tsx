// Home.test.tsx
import { render, screen } from '@testing-library/react';
import { useQuery } from '@tanstack/react-query';
import Home from './Home';

// Mock the useQuery hook
jest.mock('@tanstack/react-query', () => ({
  useQuery: jest.fn(),
}));

// Mock the components used in Home
jest.mock('../../components/SideBar/SideBar', () => () => <div>Mocked SideBar</div>);
jest.mock('../../components/SideNav', () => () => <div>Mocked SideNav</div>);
jest.mock('../../layouts/General/General', () => ({ children }) => <div>{children}</div>);
jest.mock('../../components/SearchField', () => () => <div>Mocked SearchField</div>);
jest.mock('@nextui-org/react', () => ({
  Snippet: ({ children }) => <div>{children}</div>,
}));

describe('Home', () => {
  it('renders loading state', () => {
    (useQuery as jest.Mock).mockReturnValue({
      data: null,
      isSuccess: false,
      isLoading: true,
    });

    render(<Home />);

    expect(screen.getByText('Loading auxiliary claims list...')).toBeInTheDocument();
  });

  it('renders claims when data is available', () => {
    const mockData = ['Claim 1', 'Claim 2', 'Claim 3'];
    (useQuery as jest.Mock).mockReturnValue({
      data: mockData,
      isSuccess: true,
      isLoading: false,
    });

    render(<Home />);

    expect(screen.getByText('Available claims number')).toBeInTheDocument();
    mockData.forEach((claim) => {
      expect(screen.getByText(claim)).toBeInTheDocument();
    });
  });

  it('renders unique claims', () => {
    const mockData = ['Claim 1', 'Claim 1', 'Claim 2'];
    (useQuery as jest.Mock).mockReturnValue({
      data: mockData,
      isSuccess: true,
      isLoading: false,
    });

    render(<Home />);

    expect(screen.getByText('Available claims number')).toBeInTheDocument();
    expect(screen.getAllByText('Claim 1').length).toBe(1);
    expect(screen.getByText('Claim 2')).toBeInTheDocument();
  });
});