import Home from './Home';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export Home as default', () => {
    expect(DefaultExport).toBe(Home);
  });
});