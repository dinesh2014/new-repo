import { pagesList } from './PagesList';

describe('PagesList', () => {
  it('should have a "Claim details" page with correct properties', () => {
    const claimDetailsPage = pagesList.find(page => page.label === "Claim details");

    expect(claimDetailsPage).toBeDefined();
    expect(claimDetailsPage).toEqual({
      label: "Claim details",
      href: "/claim-details",
      component: "ClaimDetails",
      exact: true,
    });
  });
});