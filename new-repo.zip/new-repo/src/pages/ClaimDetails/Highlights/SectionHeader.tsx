import { FaFlag } from "react-icons/fa6";
import clsx from "clsx";

/**
 * Props for the SectionHeader component.
 */
interface SectionHeaderProps {
  title: string;
  customerComplaints?: number;
  technicianFound?: number;
}

/**
 * Renders a section header with optional flags for customer complaints and technician found.
 *
 * @component
 * @param {SectionHeaderProps} props - The component props.
 * @param {string} props.title - The title of the section.
 * @param {number} props.customerComplaints - The number of customer complaints (optional).
 * @param {number} props.technicianFound - The number of technicians found (optional).
 * @returns {JSX.Element} The rendered SectionHeader component.
 */
const SectionHeader = ({
  title,
  customerComplaints,
  technicianFound,
}: SectionHeaderProps) => {
  return (
    <div className="flex flex-row justify-between gap-4 pb-4 px-2">
      <div className="font-semibold text-sm uppercase">{title}</div>
      <div className="flex flex-row items-center gap-6 pe-6">
        <div className="flex flex-row items-center gap-2">
          <FaFlag
            size={12}
            className={clsx(
              customerComplaints && customerComplaints === 1
                ? "text-red-500"
                : "text-gray-400",
            )}
          />
          <div className="text-xs font-semibold text-gsfs-blue-800 capitalize">
            Customer Complaints
          </div>
        </div>
        <div className="flex flex-row items-center gap-2">
          <FaFlag
            size={12}
            className={clsx(
              technicianFound && technicianFound === 1
                ? "text-red-500"
                : "text-gray-400",
            )}
          />
          <div className="text-xs font-semibold text-gsfs-blue-800 capitalize">
            Technician Found
          </div>
        </div>
      </div>
    </div>
  );
};

export default SectionHeader;
