import Section from "../../../layouts/Section";
import HighlightCard from "../../../components/HighlightCard/HighlightCard";
import SectionHeader from "./SectionHeader";
import { ClaimDetailsProps } from "../../../api/core/get-claim-details";

/**
 * Props for the Highlights component.
 */
interface HighlightsProps {
  fullData?: ClaimDetailsProps;
  isLoading?: boolean;
}

/**
 * Returns an array of unique elements from the input array, keeping only the last occurrence of each element.
 *
 * @param data - The input array.
 * @param key - A function that returns the key used to determine uniqueness of elements.
 * @returns An array of unique elements, keeping only the last occurrence of each element.
 */
function uniqByKeepLast(data: any[], key: (x: any) => any) {
  return [...new Map(data.map((x) => [key(x), x])).values()];
}

/**
 * Renders the highlights section of the claim details page.
 *
 * @component
 * @param {HighlightsProps} props - The component props.
 * @param {object} props.fullData - The full data of the claim.
 * @param {boolean} [props.isLoading=false] - Indicates whether the component is in a loading state.
 * @returns {JSX.Element} The rendered highlights section.
 */
const Highlights = ({ fullData, isLoading = false }: HighlightsProps) => {
  const highlights = [
    {
      id: 1,
      product_type: fullData?.claim?.iproduct_type_id,
      title: "Coverage",
      checks: fullData?.claim?.coverage_highlight_checks,
      secondaryCards: undefined,
    },
    {
      id: 2,
      product_type: fullData?.claim?.iproduct_type_id,
      title: "Dealer",
      checks: fullData?.claim?.dealer_highlight_checks,
      secondaryCards: undefined,
    },
    {
      id: 3,
      product_type: fullData?.claim?.iproduct_type_id,
      title: "Customer",
      checks: fullData?.claim?.customer_highlight_checks,
      secondaryCards: undefined,
    },
    {
      id: 4,
      product_type: fullData?.claim?.iproduct_type_id,
      title: "Cost",
      checks: fullData?.claim?.cost_highlight_checks,
      secondaryCards: [
        {
          title: "Parts",
          data: uniqByKeepLast(fullData?.cost_parts || [], (x) => x?.spart_no),
        },
        {
          title: fullData?.claim?.iproduct_type_id == 8 ? "M&B Labor" : "Labor",
          data: uniqByKeepLast(
            fullData?.cost_labor || [],
            (x) => x?.sloss_code,
          ),
        },
      ],
    },
    {
      id: 5,
      product_type: fullData?.claim?.iproduct_type_id,
      title: "Breakdown",
      checks: fullData?.claim?.breakdown_highlight_checks,
      secondaryCards: [
        {
          title: "Loss Description",
          data: uniqByKeepLast(
            fullData?.breakdown_loss_codes || [],
            (x) => x?.sloss_code,
          ),
        },
        {
          title: "Parts (w/ Loss Description)",
          data: uniqByKeepLast(
            fullData?.breakdown_parts || [],
            (x) => x?.spart_no,
          ),
        },
      ],
    },
  ];

  return (
    <Section
      id="highlights"
      header={
        <SectionHeader
          title="Highlights"
          customerComplaints={fullData?.claim?.customer_comp}
          technicianFound={fullData?.claim?.tech_found}
        />
      }
    >
      {isLoading ? (
        <Section
          id="loading-box"
          bordered
          paddingX={6}
          paddingY={4}
        >
          <div className="animate-pulse">Loading...</div>
        </Section>
      ) : (
        <div className="grid grid-cols-2 divide-x divide-gray-300">
          <div className="col-span-1 pe-3">
            {/* Cards for the first column */}
            {highlights.map((h, index) => {
              if (index % 2 === 0) {
                if (
                  (h.checks?.passed && h.checks?.passed.length > 0) ||
                  (h.checks?.failed && h.checks.failed.length > 0)
                ) {
                  return (
                    <div
                      key={`${h.title}-${index}`}
                      className="mb-8"
                    >
                      <HighlightCard
                        title={h.title}
                        checks={h.checks}
                      />
                      {h.secondaryCards && (
                        <ul className="flex flex-col relative gap-4 pt-4 ml-3 border-l-2 border-gsfs-sky-900">
                          {h.secondaryCards?.map((item) => (
                            <li
                              key={item.title}
                              className="relative gap-3 flex flex-row items-center"
                            >
                              <div className="w-4 h-4 rounded-full border-4 border-gsfs-sky-900 -ml-[9px] bg-white" />
                              <HighlightCard
                                highlight={h.title}
                                section={item.title}
                                product_type={fullData?.claim?.iproduct_type_id}
                                title={item.title}
                                secondary
                                secondaryInfo={item.data}
                              />
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  );
                }
              } else {
                return null;
              }
            })}
          </div>

          <div className="col-span-1 ps-3">
            {/* Cards for the second column */}
            {highlights.map((h, index) => {
              if (index % 2 !== 0) {
                if (
                  (h.checks?.passed && h.checks?.passed.length > 0) ||
                  (h.checks?.failed && h.checks.failed.length > 0)
                ) {
                  return (
                    <div
                      key={`${h.title}-${index}`}
                      className="mb-8"
                    >
                      <HighlightCard
                        title={h.title}
                        checks={h.checks}
                      />
                      {h.secondaryCards && (
                        <ul className="flex flex-col relative gap-4 pt-4 ml-3 border-l-2 border-gsfs-sky-900">
                          {h.secondaryCards?.map((item) => (
                            <li
                              key={item.title}
                              className="relative gap-3 flex flex-row items-center"
                            >
                              <div className="w-4 h-4 rounded-full border-4 border-gsfs-sky-900 -ml-[9px] bg-white" />
                              <HighlightCard
                                highlight={h.title}
                                section={item.title}
                                product_type={fullData?.claim?.iproduct_type_id}
                                title={item.title}
                                secondary
                                secondaryInfo={item.data}
                              />
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  );
                }
              } else {
                return null;
              }
            })}
          </div>
        </div>
      )}
    </Section>
  );
};

export default Highlights;
