// SectionHeader.test.tsx
import React from 'react';
import { render, screen } from '@testing-library/react';
import SectionHeader from './SectionHeader';
import { FaFlag } from 'react-icons/fa6';

describe('SectionHeader Component', () => {
  it('should render the title', () => {
    render(<SectionHeader title="Test Title" />);
    expect(screen.getByText('Test Title')).toBeInTheDocument();
  });

  it('should render customer complaints flag with correct color', () => {
    render(<SectionHeader title="Test Title" customerComplaints={1} />);
    const flagIcon = screen.getAllByRole('img')[0]; // Assuming the first flag is for customer complaints
    expect(flagIcon).toHaveClass('text-red-500');
    expect(screen.getByText('Customer Complaints')).toBeInTheDocument();
  });

  it('should render technician found flag with correct color', () => {
    render(<SectionHeader title="Test Title" technicianFound={1} />);
    const flagIcon = screen.getAllByRole('img')[1]; // Assuming the second flag is for technician found
    expect(flagIcon).toHaveClass('text-red-500');
    expect(screen.getByText('Technician Found')).toBeInTheDocument();
  });

  it('should render flags with gray color when counts are not 1', () => {
    render(<SectionHeader title="Test Title" customerComplaints={0} technicianFound={0} />);
    const flagIcons = screen.getAllByRole('img');
    flagIcons.forEach(flagIcon => {
      expect(flagIcon).toHaveClass('text-gray-400');
    });
  });

  it('should render flags with gray color when counts are undefined', () => {
    render(<SectionHeader title="Test Title" />);
    const flagIcons = screen.getAllByRole('img');
    flagIcons.forEach(flagIcon => {
      expect(flagIcon).toHaveClass('text-gray-400');
    });
  });
});