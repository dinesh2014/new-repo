test('renders no data message when fullData is empty', () => {
    const emptyData: ClaimDetailsProps = {
      claim: {
        iproduct_type_id: 1,
        coverage_highlight_checks: { passed: [], failed: [] },
        dealer_highlight_checks: { passed: [], failed: [] },
        customer_highlight_checks: { passed: [], failed: [] },
        cost_highlight_checks: { passed: [], failed: [] },
        breakdown_highlight_checks: { passed: [], failed: [] },
        customer_comp: '',
        tech_found: '',
      },
      cost_parts: [],
      cost_labor: [],
      breakdown_loss_codes: [],
      breakdown_parts: [],
    };
  
    render(<Highlights fullData={emptyData} isLoading={false} />);
    expect(screen.getByText('No data available')).toBeInTheDocument();
  });