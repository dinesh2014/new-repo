import React from 'react';
import { render, screen } from '@testing-library/react';
import Reminders from './Reminders';
import { ClaimReminderProps } from '../../../api/core/get-claim-details';

// Mock components used in Reminders
jest.mock('../../../layouts/Section', () => ({ children, id, paddingX }) => (
  <div id={id} style={{ padding: `${paddingX}rem` }}>
    {children}
  </div>
));

jest.mock('../../../components/CustomDivider', () => ({ vertical, color }) => (
  <div style={{ borderLeft: vertical ? `2px solid ${color}` : 'none' }} />
));

jest.mock('./ReminderTag', () => ({ text }) => <div>{text}</div>);

describe('Reminders', () => {
  const mockReminders: ClaimReminderProps[] = [
    { id: 1, texts: ['Reminder 1', 'Reminder 2'] },
    { id: 2, texts: ['Reminder 3'] },
  ];

  it('renders loading state', () => {
    render(<Reminders isLoading={true} />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('renders reminders section with reminders', () => {
    render(<Reminders reminders={mockReminders} />);
    expect(screen.getByText('Reminders')).toBeInTheDocument();
    expect(screen.getByText('Reminder 1')).toBeInTheDocument();
    expect(screen.getByText('Reminder 2')).toBeInTheDocument();
    expect(screen.getByText('Reminder 3')).toBeInTheDocument();
  });

  it('renders reminders section with no reminders', () => {
    render(<Reminders reminders={[]} />);
    expect(screen.queryByText('Reminders')).not.toBeInTheDocument();
  });

  it('renders reminders section with duplicate texts filtered out', () => {
    const duplicateReminders: ClaimReminderProps[] = [
      { id: 1, texts: ['Reminder 1', 'Reminder 2'] },
      { id: 2, texts: ['Reminder 1', 'Reminder 3'] },
    ];
    render(<Reminders reminders={duplicateReminders} />);
    expect(screen.getByText('Reminders')).toBeInTheDocument();
    expect(screen.getByText('Reminder 1')).toBeInTheDocument();
    expect(screen.getByText('Reminder 2')).toBeInTheDocument();
    expect(screen.getByText('Reminder 3')).toBeInTheDocument();
    expect(screen.queryAllByText('Reminder 1').length).toBe(1);
  });
});