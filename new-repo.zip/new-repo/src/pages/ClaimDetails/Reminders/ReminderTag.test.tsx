import React from 'react';
import { render, screen } from '@testing-library/react';
import ReminderTag from './ReminderTag';
import { FaCircleExclamation } from "react-icons/fa6";

describe('ReminderTag', () => {
  it('renders the reminder tag with the correct text', () => {
    const text = 'Test Reminder';
    render(<ReminderTag text={text} />);
    expect(screen.getByText(text)).toBeInTheDocument();
  });
