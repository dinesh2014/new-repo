// Financial.test.tsx
import React from 'react';
import { render, screen } from '@testing-library/react';
import Financial from './Financial';
import { ClaimProps } from '../../../api/core/get-claim-details';

describe('Financial Component', () => {
  const mockClaim: ClaimProps = {
    claim_per_msrp: '0.5',
    contract_prev_claim_payout: '1000',
    iproduct_type_id: 4,
    creq_total: '500',
    cvehicle_purchase_price: '10000',
    cmsrp: '12000',
    remaining_limit: '2000',
  };

  it('should render loading state', () => {
    render(<Financial isLoading={true} />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('should render financial details correctly', () => {
    render(<Financial claim={mockClaim} isLoading={false} />);
    
    expect(screen.getByText('Claims Paid to Date on Contract')).toBeInTheDocument();
    expect(screen.getByText('50.0% of sale price')).toBeInTheDocument();
    expect(screen.getByText('$1,000')).toBeInTheDocument();

    expect(screen.getByText('Current Claims')).toBeInTheDocument();
    expect(screen.getByText('*Parts and labor costs only')).toBeInTheDocument();
    expect(screen.getByText('5.0% of sale price')).toBeInTheDocument();
    expect(screen.getByText('$500')).toBeInTheDocument();

    expect(screen.getByText('Sale Price')).toBeInTheDocument();
    expect(screen.getByText('$10,000')).toBeInTheDocument();

    expect(screen.getByText('Remaining Limit')).toBeInTheDocument();
    expect(screen.getByText('$2,000')).toBeInTheDocument();
  });

  it('should handle invalid claim values', () => {
    const invalidClaim: ClaimProps = {
      claim_per_msrp: '0',
      contract_prev_claim_payout: null,
      iproduct_type_id: 8,
      creq_total: '0',
      cvehicle_purchase_price: '0',
      cmsrp: '0',
      remaining_limit: null,
    };

    render(<Financial claim={invalidClaim} isLoading={false} />);

    expect(screen.getByText('Claims Paid to Date on Contract')).toBeInTheDocument();
    expect(screen.getByText('')).toBeInTheDocument();
    expect(screen.getByText('$0')).toBeInTheDocument();

    expect(screen.getByText('Current Claims')).toBeInTheDocument();
    expect(screen.getByText('*Tire, Wheel and M&B labor costs only')).toBeInTheDocument();
    expect(screen.getByText('')).toBeInTheDocument();
    expect(screen.getByText('$0')).toBeInTheDocument();

    expect(screen.getByText('Sale Price')).toBeInTheDocument();
    expect(screen.getByText('Potential 2nd day sale')).toBeInTheDocument();
    expect(screen.getByText('$0')).toBeInTheDocument();

    expect(screen.getByText('Remaining Limit')).toBeInTheDocument();
    expect(screen.getByText('N/A')).toBeInTheDocument();
  });
});