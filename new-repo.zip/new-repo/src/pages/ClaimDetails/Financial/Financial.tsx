import LabeledInfo from "../../../components/LabeledInfo";
import Section from "../../../layouts/Section";
import CustomDivider from "../../../components/CustomDivider";
import { ClaimProps } from "../../../api/core/get-claim-details";

/**
 * Represents the props for the Financial component.
 */
interface FinancialProps {
  claim?: ClaimProps;
  isLoading?: boolean;
}

/**
 * Financial component displays the financial details of a claim.
 * @component
 * @param {FinancialProps} props - The component props.
 * @param {ClaimProps} props.claim - The claim object containing financial information.
 * @param {boolean} [props.isLoading=false] - Indicates whether the component is in a loading state.
 * @returns {JSX.Element} The rendered Financial component.
 */
const Financial = ({ claim, isLoading = false }: FinancialProps) => {
  const formatCurrency = (value: string, decimals: number = 2) => {
    const formatter = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
    return formatter.format(Number(value));
  };

  const isInvalidValue = (value: string | undefined | null | number) => {
    return !value || value === "0";
  };

  const purchasePrice = (purchasePrice:any , cmsrp:any) => {
    let displayPrice = "";
    if (purchasePrice) {
      displayPrice = formatCurrency(String(purchasePrice), 0);
    } else if (cmsrp) {
      displayPrice = formatCurrency(String(cmsrp), 0);
    }
    return displayPrice;
  };

  const financialDetails = [
    {
      leftTitle: "Claims Paid to Date on Contract",
      label: (() => {
        if (isInvalidValue(claim?.claim_per_msrp)) {
          return "";
        } else {
          const percentage = Number(claim?.claim_per_msrp) * 100;
          return `${percentage.toFixed(1)}% of sale price`;
        }
      })(),
      value: claim?.contract_prev_claim_payout
        ? formatCurrency(String(claim.contract_prev_claim_payout), 0)
        : "",
    },

    {
      leftTitle: "Current Claims",
      secondaryTitle: (() => {
        if (claim?.iproduct_type_id == 4) {
          return "*Parts and labor costs only";
        }
        if (claim?.iproduct_type_id == 8) {
          return "*Tire, Wheel and M&B labor costs only";
        }
        return "";
      })(),
      label: (() => {
        if (
          isInvalidValue(claim?.creq_total) ||
          isInvalidValue(claim?.cvehicle_purchase_price)
        ) {
          return "";
        } else {
          const percentage =
            (Number(claim?.creq_total) /
              Number(claim?.cvehicle_purchase_price)) *
            100;
          return `${percentage.toFixed(1)}% of sale price`;
        }
      })(),
      value: claim?.creq_total
        ? formatCurrency(String(claim?.creq_total), 0)
        : "$0",
    },
    {
      leftTitle: "Sale Price",
      label: [0, "0", "unknown", null, undefined].includes(claim?.cvehicle_purchase_price)
        && [0, "0", "unknown", null, undefined].includes(claim?.cmsrp)
        ? "Potential 2nd day sale"
        : "",
      value: purchasePrice(claim?.cvehicle_purchase_price,claim?.cmsrp),
    },
    {
      leftTitle: "Remaining Limit",
      label: "",
      value: claim?.remaining_limit
        ? formatCurrency(String(claim?.remaining_limit), 0)
        : "",
    },
  ];

  return (
    <Section
      id="financial-info"
      bordered
      paddingX={6}
      paddingY={4}
    >
      {isLoading ? (
        <div className="animate-pulse">Loading...</div>
      ) : (
        <div className="flex flex-col gap-6">
          <div className="flex flex-row gap-4">
            {financialDetails?.map((item, index) => (
              <div
                key={`${item.leftTitle}-${item?.secondaryTitle}-${index}`}
                className="flex flex-row p-4 gap-3"
              >
                <div className="text-balance text-lg text-right font-bold leading-none grow self-center">
                  <div>{item.leftTitle}</div>
                  <div className="text-xs font-light text-gray-500">
                    {item?.secondaryTitle}
                  </div>
                </div>
                {item.leftTitle != "Remaining Limit" ? (
                  <>
                    <CustomDivider vertical />
                    <LabeledInfo
                      label={item?.label}
                      labelSize="md"
                      value={item.value}
                      valueSize="2xl"
                      isReversed
                      nullReplacement={
                        [
                          "Claims Paid to Date on Contract",
                          "Current Claims",
                        ].includes(item.leftTitle)
                          ? "$0"
                          : "N/A"
                      }
                    />
                  </>
                ) : (
                  <div className="flex flex-col justify-center leading-none bg-gray-50 rounded-xl">
                    {item?.label && (
                      <div className="font-thin text-md text-nowrap leading-snug">
                        {item?.label}
                      </div>
                    )}
                    <div className="font-light px-3 py-4 text-2xl text-nowrap text-gray-500 leading-snug">
                      {item?.value && item?.value !== "null" || item?.value !== "unknown"
                        ? item?.value
                        : "N/A"}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </Section>
  );
};

export default Financial;
