import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import General from "../../layouts/General/General";
import Review from "./Review";
import Reminders from "./Reminders";
import Customer from "./Customer";
import Financial from "./Financial";
import Highlights from "./Highlights";
import History from "./History";
import Feedback from "./Feedback";

import { getClaimDetails } from "../../api/core/get-claim-details";
import { failureStatuses } from "../../utils/constants";
import { AxiosError } from "axios";

/**
 * Renders the Claim Details page.
 * @returns JSX.Element
 */
const ClaimDetails = () => {
  const { claimNumber } = useParams<{ claimNumber: string }>();
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["claim", claimNumber],
    queryFn: () => getClaimDetails(claimNumber ?? ""),
  });

  const jobStatusTitle = data?.claim?.overall_recommendation
    ?.toString()
    ?.split(" - ")[0]
    ?.toLowerCase();

  const isFailureJobStatus = failureStatuses?.some(
    (status) => status === jobStatusTitle?.toLowerCase(),
  );

  return (
    <>
      <ToastContainer
        theme="colored"
        position="bottom-left"
        autoClose={2500}
        hideProgressBar={false}
        closeOnClick
        rtl={false}
        pauseOnHover
      />
      <General isLoading={isLoading}>
        <main className="flex flex-col gap-6" aria-label="Claim Details">
          <Review
            data={data}
            error={error as AxiosError}
            isError={isError}
            isLoading={isLoading}
            aria-label="Review Section"
            isFailureJobStatus={isFailureJobStatus}
          />
          {!isFailureJobStatus && (
            <>
              <Reminders
                reminders={data?.reminders}
                isLoading={isLoading}
                aria-label="Reminders Section"
              />
              <Customer
                claim={data?.claim}
                isLoading={isLoading}
                aria-label="Customer Section"
              />
              <Financial
                claim={data?.claim}
                isLoading={isLoading}
                aria-label="Financial Section"
              />
              <Highlights
                fullData={data}
                isLoading={isLoading}
                aria-label="Highlights Section"
              />
              <History
                history={data?.claim_history}
                isLoading={isLoading}
                aria-label="History Section"
              />
              <aside
                className="w-100 h-full border-1 border-gray-200 rounded-md p-6 bg-white self-center"
                aria-label="Feedback Section"
              >
                <div className="flex flex-col justify-center items-center">
                  <div className="text-md font-bold uppercase pb-3">
                    Give feedback
                  </div>
                  <Feedback
                    claimNumber={claimNumber ?? ""}
                    placement="bottom feedback buttons"
                    iproduct_type_id={data?.claim?.iproduct_type_id || 0}
                  />
                </div>
              </aside>
            </>
          )}
        </main>
      </General>
    </>
  );
};

export default ClaimDetails;
