import React from 'react';
import { render, screen } from '@testing-library/react';
import SectionHeader from './SectionHeader';

describe('SectionHeader', () => {
  it('renders the section header with the given title', () => {
    const title = 'Test Title';
    render(<SectionHeader title={title} />);
    
    const headerElement = screen.getByText(title);
    expect(headerElement).toBeInTheDocument();
    expect(headerElement).toHaveClass('font-semibold text-sm uppercase');
  });
});