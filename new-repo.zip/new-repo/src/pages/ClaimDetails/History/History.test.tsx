import React from 'react';
import { render, screen } from '@testing-library/react';
import History from './History';
import { ClaimHistoryProps } from '../../../api/core/get-claim-details';

// Mock components used in History
jest.mock('../../../components/BaseCard', () => ({ children, title, additionalHeader }) => (
  <div>
    <div>{title}</div>
    <div>{additionalHeader}</div>
    <div>{children}</div>
  </div>
));

jest.mock('../../../layouts/Section', () => ({ children, header }) => (
  <div>
    <div>{header}</div>
    <div>{children}</div>
  </div>
));

jest.mock('./SectionHeader', () => ({ title }) => <div>{title}</div>);
jest.mock('./Table', () => ({ history }) => <div>Table with {history.length} items</div>);

describe('History', () => {
  const mockHistory: ClaimHistoryProps[] = [
    { id: 1, date: '2021-01-01', description: 'Claim 1' },
    { id: 2, date: '2021-01-02', description: 'Claim 2' },
  ];

  it('renders loading state', () => {
    render(<History isLoading={true} />);
    expect(screen.getByText('Loading table...')).toBeInTheDocument();
  });

  it('renders history section with claims', () => {
    render(<History history={mockHistory} />);
    expect(screen.getByText('History')).toBeInTheDocument();
    expect(screen.getByText('Claims History')).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
    expect(screen.getByText('Table with 2 items')).toBeInTheDocument();
  });

  it('renders history section with no claims', () => {
    render(<History history={[]} />);
    expect(screen.getByText('History')).toBeInTheDocument();
    expect(screen.getByText('Claims History')).toBeInTheDocument();
    expect(screen.getByText('0')).toBeInTheDocument();
    expect(screen.getByText('Table with 0 items')).toBeInTheDocument();
  });
});