import React from 'react';
import { render } from '@testing-library/react';
import History from './History';
import Index from './index';

describe('index.tsx', () => {
  it('should re-export History component', () => {
    const { container: historyContainer } = render(<History />);
    const { container: indexContainer } = render(<Index />);
    
    expect(indexContainer.innerHTML).toBe(historyContainer.innerHTML);
  });
});