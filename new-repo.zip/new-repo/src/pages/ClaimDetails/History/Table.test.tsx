import React from 'react';
import { render, screen } from '@testing-library/react';
import Table from './Table';
import { ClaimHistoryProps } from '../../../api/core/get-claim-details';
import { historyTableColumns } from '../../../utils/constants';

describe('Table Component', () => {
  const mockHistory: ClaimHistoryProps[] = [
    { id: '1', date: '2023-01-01', status: 'Open', description: 'Claim opened' },
    { id: '2', date: '2023-01-02', status: 'In Progress', description: 'Claim in progress' },
  ];

  it('should render table with provided history data', () => {
    render(<Table history={mockHistory} />);

    // Check if table headers are rendered
    historyTableColumns.forEach(column => {
      expect(screen.getByText(column.label)).toBeInTheDocument();
    });

    // Check if table rows are rendered
    mockHistory.forEach(item => {
      expect(screen.getByText(item.date)).toBeInTheDocument();
      expect(screen.getByText(item.status)).toBeInTheDocument();
      expect(screen.getByText(item.description)).toBeInTheDocument();
    });
  });
});