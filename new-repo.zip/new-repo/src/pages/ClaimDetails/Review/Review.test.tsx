import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Review from './Review';
import { ClaimProps } from '../../../api/core/get-claim-details';
import { AxiosError } from 'axios';

// Mock data
const mockClaim: ClaimProps = {
  claim: {
    sclaim_number: '12345',
    overall_recommendation: 'Approved - All checks passed',
    iproduct_type_id: 1,
    is_updated: true,
    coverage_checks: 'Passed',
    dealer_customer_risk: 'Low',
    breakdown_risk: 'None',
    cost_checks: 'Approved',
  },
};

const mockError: AxiosError = {
  isAxiosError: true,
  response: {
    data: { detail: 'Server error' },
    status: 500,
    statusText: 'Internal Server Error',
    headers: {},
    config: {},
  },
} as AxiosError;

describe('Review Component', () => {
  test('renders loading state', () => {
    render(<Review isLoading={true} />);
    expect(screen.getByText('Fetching data...')).toBeInTheDocument();
  });

  test('renders error state', () => {
    render(<Review isError={true} error={mockError} />);
    expect(screen.getByText('Sorry. This request returned a server error.')).toBeInTheDocument();
    expect(screen.getByText('Server error')).toBeInTheDocument();
  });

  test('renders ClaimCard when data is available', () => {
    render(<Review data={mockClaim} />);
    expect(screen.getByText('12345')).toBeInTheDocument();
    expect(screen.getByText('Approved')).toBeInTheDocument();
    expect(screen.getByText('All checks passed')).toBeInTheDocument();
  });

  test('renders StatusCards when data is available', () => {
    render(<Review data={mockClaim} />);
    expect(screen.getByText('Coverage Checks')).toBeInTheDocument();
    expect(screen.getByText('Dealer & Customer Checks')).toBeInTheDocument();
    expect(screen.getByText('Breakdown Checks')).toBeInTheDocument();
    expect(screen.getByText('Cost Checks')).toBeInTheDocument();
  });

  test('renders outdated claim card', () => {
    const outdatedClaim = { ...mockClaim, claim: { ...mockClaim.claim, is_updated: false } };
    render(<Review data={outdatedClaim} />);
    expect(screen.getByText('Attention! This claim has been flagged as outdated.')).toBeInTheDocument();
  });
});