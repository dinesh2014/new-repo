import Review from './index';
import ActualReview from './Review';

describe('index.tsx', () => {
  it('should re-export Review component as default', () => {
    expect(Review).toBe(ActualReview);
  });
});