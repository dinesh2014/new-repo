import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import ClaimDetails from './ClaimDetails';
import { getClaimDetails } from '../../api/core/get-claim-details';
import { failureStatuses } from '../../utils/constants';
import { AxiosError } from 'axios';

// Mock the getClaimDetails API call
jest.mock('../../api/core/get-claim-details');
const mockedGetClaimDetails = getClaimDetails as jest.MockedFunction<typeof getClaimDetails>;

// Mock the useParams hook
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useParams: () => ({ claimNumber: '12345' }),
}));

const queryClient = new QueryClient();

const renderComponent = () =>
  render(
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <ClaimDetails />
      </BrowserRouter>
    </QueryClientProvider>
  );

describe('ClaimDetails', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders without crashing', () => {
    mockedGetClaimDetails.mockResolvedValueOnce({ claim: {}, reminders: [], claim_history: [] });
    renderComponent();
    expect(screen.getByLabelText('Claim Details')).toBeInTheDocument();
  });

  test('displays loading state', () => {
    mockedGetClaimDetails.mockReturnValueOnce(new Promise(() => {}));
    renderComponent();
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  test('displays error state', () => {
    mockedGetClaimDetails.mockRejectedValueOnce(new AxiosError('Error fetching data'));
    renderComponent();
    expect(screen.getByText(/error/i)).toBeInTheDocument();
  });

  test('conditionally renders sections based on job status', async () => {
    const mockData = {
      claim: { overall_recommendation: 'failure - test', iproduct_type_id: 1 },
      reminders: [],
      claim_history: [],
    };
    mockedGetClaimDetails.mockResolvedValueOnce(mockData);
    renderComponent();

    expect(await screen.findByLabelText('Review Section')).toBeInTheDocument();
    expect(screen.queryByLabelText('Reminders Section')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Customer Section')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Financial Section')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Highlights Section')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('History Section')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Feedback Section')).not.toBeInTheDocument();
  });

  test('renders all sections when job status is not failure', async () => {
    const mockData = {
      claim: { overall_recommendation: 'success - test', iproduct_type_id: 1 },
      reminders: [],
      claim_history: [],
    };
    mockedGetClaimDetails.mockResolvedValueOnce(mockData);
    renderComponent();

    expect(await screen.findByLabelText('Review Section')).toBeInTheDocument();
    expect(screen.getByLabelText('Reminders Section')).toBeInTheDocument();
    expect(screen.getByLabelText('Customer Section')).toBeInTheDocument();
    expect(screen.getByLabelText('Financial Section')).toBeInTheDocument();
    expect(screen.getByLabelText('Highlights Section')).toBeInTheDocument();
    expect(screen.getByLabelText('History Section')).toBeInTheDocument();
    expect(screen.getByLabelText('Feedback Section')).toBeInTheDocument();
  });
});