import IndexExport from './index';
import ClaimDetails from './ClaimDetails';

describe('index.tsx', () => {
  it('should re-export ClaimDetails as default', () => {
    expect(IndexExport).toBe(ClaimDetails);
  });
});