import React from 'react';
import { render } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import Router from './router';
import Home from './pages/Home';
import ClaimDetails from './pages/ClaimDetails';

describe('Router', () => {
  it('renders Home component for the root path', () => {
    const { getByText } = render(
      <MemoryRouter initialEntries={['/']}>
        <Router />
      </MemoryRouter>
    );
    expect(getByText('Home Page Content')).toBeInTheDocument();
  });

  it('renders ClaimDetails component for the /claim-details/:claimNumber path', () => {
    const { getByText } = render(
      <MemoryRouter initialEntries={['/claim-details/123']}>
        <Router />
      </MemoryRouter>
    );
    expect(getByText('Claim Details Content')).toBeInTheDocument();
  });
});