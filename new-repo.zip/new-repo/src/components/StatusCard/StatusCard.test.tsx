import { render, screen } from "@testing-library/react";
import StatusCard from "./StatusCard";
import { describe, expect, it } from "vitest";

const testProps = {
  label: "Test Label",
  status: "success" as const,
  statusText: "All good",
  displayIcon: true,
};

interface StatusCardProps {
    label: string;
    status: "warning" | "danger" | "success";
    statusText: string;
    displayIcon: boolean;
  }

describe("StatusCard", () => {
  const renderComponent = (props:StatusCardProps) => render(<StatusCard {...testProps} {...props} />);

  it("renders the label and status text correctly", () => {
    renderComponent(testProps); // Pass the required argument
    expect(screen.getByText("Test Label")).toBeInTheDocument();
    expect(screen.getByText("All good")).toBeInTheDocument();
  });


  it("displays the correct icon for warning status", () => {
    renderComponent({...testProps, status: "warning", statusText: "Be careful" });
    expect(screen.getByTestId("status-icon")).toContainElement(screen.getByTestId("FaExclamation"));
  });

  it("displays the correct icon for danger status", () => {
    renderComponent({ ...testProps,status: "danger", statusText: "Error occurred" });
    expect(screen.getByTestId("status-icon")).toContainElement(screen.getByTestId("FaXmark"));
  });

  it("does not display an icon when displayIcon is false", () => {
    renderComponent({ ...testProps,displayIcon: false });
    expect(screen.queryByTestId("FaCheck")).not.toBeInTheDocument();
    expect(screen.queryByTestId("FaExclamation")).not.toBeInTheDocument();
    expect(screen.queryByTestId("FaXmark")).not.toBeInTheDocument();
  });
});