export { default } from "./StatusCard";
