// GroupedLabeledInfo.test.tsx
import React from 'react';
import { render } from '@testing-library/react';
import GroupedLabeledInfo from './GroupedLabeledInfo';
import CustomDivider from '../CustomDivider';
import LabeledInfo from '../LabeledInfo';

jest.mock('../CustomDivider', () => () => <div data-testid="custom-divider" />);
jest.mock('../LabeledInfo', () => ({ label, value, isReversed }) => (
  <div data-testid="labeled-info">
    <span>{label}</span>
    <span>{value}</span>
    <span>{isReversed ? 'Reversed' : 'Not Reversed'}</span>
  </div>
));

describe('GroupedLabeledInfo', () => {
  test('renders with empty data array', () => {
    const { container, queryByTestId } = render(<GroupedLabeledInfo data={[]} />);
    expect(queryByTestId('custom-divider')).toBeInTheDocument();
    expect(container.querySelectorAll('[data-testid="labeled-info"]').length).toBe(0);
  });

  test('renders with non-empty data array', () => {
    const data = [
      { label: 'Label1', value: 'Value1', isReversed: false },
      { label: 'Label2', value: 'Value2', isReversed: true },
    ];
    const { container, getAllByTestId } = render(<GroupedLabeledInfo data={data} />);
    expect(getAllByTestId('custom-divider').length).toBe(1);
    const labeledInfoElements = container.querySelectorAll('[data-testid="labeled-info"]');
    expect(labeledInfoElements.length).toBe(2);
    expect(labeledInfoElements[0].textContent).toContain('Label1');
    expect(labeledInfoElements[0].textContent).toContain('Value1');
    expect(labeledInfoElements[0].textContent).toContain('Not Reversed');
    expect(labeledInfoElements[1].textContent).toContain('Label2');
    expect(labeledInfoElements[1].textContent).toContain('Value2');
    expect(labeledInfoElements[1].textContent).toContain('Reversed');
  });

  test('renders CustomDivider with vertical prop', () => {
    const { getByTestId } = render(<GroupedLabeledInfo data={[]} />);
    const customDivider = getByTestId('custom-divider');
    expect(customDivider).toBeInTheDocument();
  });
});