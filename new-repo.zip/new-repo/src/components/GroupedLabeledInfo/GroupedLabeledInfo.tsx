import CustomDivider from "../CustomDivider";
import LabeledInfo from "../LabeledInfo";
import { InfoProps } from "../LabeledInfo/LabeledInfo";

/**
 * Props for the GroupedLabeledInfo component.
 */
interface GroupedLabeledInfoProps {
  data: InfoProps[];
}

/**
 * Renders a grouped labeled information component.
 *
 * @component
 * @param {GroupedLabeledInfoProps} props - The component props.
 * @param {InfoProps[]} props.data - An array of objects containing label and value pairs.
 * @returns {JSX.Element} The rendered grouped labeled information component.
 */
const GroupedLabeledInfo = ({ data }: GroupedLabeledInfoProps) => {
  return (
    <div className="flex flex-auto">
      <CustomDivider vertical />
      <div className="flex flex-row gap-12 px-3">
        {data.map((item, index) => {
          const key = `Label-${item.label}-${index}`;
          return (
            <LabeledInfo
              key={key}
              label={item.label}
              value={item.value}
              isReversed={item.isReversed}
            />
          );
        })}
      </div>
    </div>
  );
};

export default GroupedLabeledInfo;
