import OriginalFeedbackModal from "./FeedbackModal";
import DefaultExport from "./index";

describe("index.tsx", () => {
  it("should export FeedbackModal as default", () => {
    expect(DefaultExport).toBe(OriginalFeedbackModal);
  });
});