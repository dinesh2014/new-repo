import BaseCard from "./index";
import OriginalBaseCard from "./BaseCard";

describe("index.tsx", () => {
  it("should export BaseCard as default", () => {
    expect(BaseCard).toBe(OriginalBaseCard);
  });
});