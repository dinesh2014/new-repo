import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import BaseCard from "./BaseCard";

describe("BaseCard", () => {
  const title = "Card Title";
  const additionalHeader = <span>Additional Header</span>;
  const children = <div>Card Content</div>;
  const expandContent = <div>Expandable Content</div>;

  it("should render the title correctly", () => {
    render(<BaseCard title={title} />);
    expect(screen.getByText(title)).toBeInTheDocument();
  });

  it("should render the additional header when provided", () => {
    render(<BaseCard title={title} additionalHeader={additionalHeader} />);
    expect(screen.getByText("Additional Header")).toBeInTheDocument();
  });

  it("should render the children content", () => {
    render(<BaseCard title={title}>{children}</BaseCard>);
    expect(screen.getByText("Card Content")).toBeInTheDocument();
  });

  it("should toggle the expandable content correctly", () => {
    render(
      <BaseCard title={title} expandContent={expandContent}>
        {children}
      </BaseCard>
    );

    const button = screen.getByText("View All Checks");
    expect(button).toBeInTheDocument();

    // Initially, the expandable content should not be visible
    expect(screen.queryByText("Expandable Content")).not.toBeVisible();

    // Click to expand
    fireEvent.click(button);
    expect(screen.getByText("Expandable Content")).toBeVisible();
    expect(screen.getByText("Close")).toBeInTheDocument();

    // Click to collapse
    fireEvent.click(screen.getByText("Close"));
    expect(screen.queryByText("Expandable Content")).not.toBeVisible();
    expect(screen.getByText("View All Checks")).toBeInTheDocument();
  });
});