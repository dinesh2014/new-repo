import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useParams } from "react-router-dom";
import { useQueries } from "@tanstack/react-query";
import Globals from "../../globals";
import { getClaireAgent1Data } from "../../api/core/get-claire-agent1-data";
import { getClaireAgent2Data } from "../../api/core/get-claire-agent2-data";
import Claire from "./Claire";

// Mock dependencies
jest.mock("react-router-dom", () => ({
  useParams: jest.fn(),
}));
jest.mock("@tanstack/react-query", () => ({
  useQueries: jest.fn(),
}));
jest.mock("../../globals", () => ({
  user: "JFlores@gsadmins.com",
}));
jest.mock("../../api/core/get-claire-agent1-data", () => ({
  getClaireAgent1Data: jest.fn(),
}));
jest.mock("../../api/core/get-claire-agent2-data", () => ({
  getClaireAgent2Data: jest.fn(),
}));

describe("Claire component", () => {
  beforeEach(() => {
    (useParams as jest.Mock).mockReturnValue({ claimNumber: "12345" });
    (useQueries as jest.Mock).mockReturnValue([
      {
        isLoading: false,
        data: { claim_event_part_details: [{ id: 1 }, { id: 2 }] },
      },
      {
        isLoading: false,
        data: { claim_event_part_details: [{ id: 3 }] },
      },
    ]);
  });

  it("should render the Claire component correctly when user is allowed and data is fetched", () => {
    render(<Claire />);

    // Check if the badge content is displayed correctly
    expect(screen.getByText("3")).toBeInTheDocument();

    // Check if the avatar is displayed
    expect(screen.getByAltText("Claire Avatar")).toBeInTheDocument();

    // Simulate clicking the avatar to open the modal
    fireEvent.click(screen.getByAltText("Claire Avatar"));

    // Check if the modal is opened
    expect(screen.getByText("ClaireModal")).toBeInTheDocument();
  });
});