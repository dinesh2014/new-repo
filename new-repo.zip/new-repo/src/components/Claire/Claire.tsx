import { Avatar, Badge, Modal, useDisclosure } from "@nextui-org/react";
import { useParams } from "react-router-dom";
import { useQueries } from "@tanstack/react-query";

import Globals from "../../globals";
import { getClaireAgent1Data } from "../../api/core/get-claire-agent1-data";
import { getClaireAgent2Data } from "../../api/core/get-claire-agent2-data";
import ClaireModal from "./ClaireModal";

/**
 * The Claire component displays information related to the Claire system.
 * It checks if the current user is allowed and displays relevant data fetched
 * from the ClaireAgent1 and ClaireAgent2 APIs.
 */
const Claire = () => {
  // Identifies the current user using global settings or defaults to a placeholder.
  const userIdentity = Globals.user || "undefined@email.com";

  // List of users who are allowed to access this component's data.
  const allowedUsers = [
    "undefined@email.com",
    // "AGuillermo@gsadmins.com",
    // "BDalziel@gsadmins.com",
    // "JLyon@gsadmins.com",
    "JFlores@gsadmins.com",
    "MReynosa@gsadmins.com",
    // "MMoses@gsadmins.com",
    // "PDugar@gsadmins.com",
    "AHanus@friedkin.com",
    "BIngegneri@friedkin.com",
    "GTeruya@friedkin.com",
    "JLobberecht@gsfsgroup.com",
    "JSethia@friedkin.com",
    "KGupta@friedkin.com",
    "KJagtiani@friedkin.com",
    "RYadav@friedkin.com",
    "RPutatunda@friedkin.com",
    "ACuintaco@friedkin.com",
    "amalhotra@friedkin.com",
    "EHenriksson@friedkin.com",
    "IGomez@friedkin.com",
    "SDowlatshahi@friedkin.com",
    "AGong@friedkin.com",
    "SGuilherme@friedkin.com",
    "MFraser@friedkin.com",
    // Add more allowed users as needed.
  ];

  /**
   * Checks if the current user is allowed to access the component's data.
   * @returns {boolean} True if the user is allowed, false otherwise.
   */
  const isAllowedUser = allowedUsers.some(
    (user) => user.toLowerCase() === userIdentity.toLowerCase(),
  );

  /**
   * Retrieves the claim number from the URL parameters.
   */
  const { claimNumber } = useParams<{ claimNumber: string }>();

  /**
   * Fetches data from the ClaireAgent1 and ClaireAgent2 APIs using react-query.
   */
  const [agent1Query, agent2Query] = useQueries({
    queries: [
      {
        queryKey: ["claireAgent1", claimNumber],
        queryFn: () => getClaireAgent1Data(claimNumber ?? ""),
      },
      {
        queryKey: ["claireAgent2", claimNumber],
        queryFn: () => getClaireAgent2Data(claimNumber ?? ""),
      },
    ],
  });

  /**
   * Checks if the queries are still loading.
   */
  const isLoadingQueries = agent1Query.isLoading ?? agent2Query.isLoading;

  /**
   * Retrieves the length of the claim event part details from the agent1Query and agent2Query.
   */
  const agent1QueryLength =
    agent1Query.data?.claim_event_part_details?.length ?? 0;
  const agent2QueryLength =
    agent2Query.data?.claim_event_part_details?.length ?? 0;

  /**
   * Calculates the badge content by summing the lengths of agent1Query and agent2Query.
   */
  const badgeContent = agent1QueryLength + agent2QueryLength;

  /**
   * Manages the state of the modal component.
   */
  const { isOpen, onOpen, onOpenChange } = useDisclosure();

  /**
   * Renders the Claire component.
   * @returns {JSX.Element} The rendered Claire component.
   */
  return (
    <div>
      {!isLoadingQueries && isAllowedUser && badgeContent > 0 && (
        <div className="flex flex-col absolute z-40 top-28 right-4 bg-blue-100 border-2 border-yellow-400 rounded-full w-[92px] h-[92px] absolute">
          <Badge
            content={badgeContent}
            color="danger"
            size="lg"
            showOutline={false}
            className="top-3 right-3"
          >
            <Avatar
              onClick={onOpen}
              showFallback
              fallback={<div className="w-100 h-100">Claire</div>}
              alt="Claire Avatar"
              src="img/claire-avatar-md.jpeg"
              className="w-[88px] h-[88px] bg-blue-100 text-xl cursor-pointer"
            />
          </Badge>
          <Modal
            size="5xl"
            isOpen={isOpen}
            onOpenChange={onOpenChange}
            placement="center"
            scrollBehavior="outside"
            backdrop="blur"
            classNames={{
              wrapper: "bg-black bg-opacity-50",
              base: "border-2 border-yellow-400",
              // backdrop:
              //   "bg-gradient-to-t from-zinc-900 to-zinc-900/10 backdrop-opacity-20",
            }}
          >
            <ClaireModal
              agent1Query={agent1Query}
              agent2Query={agent2Query}
            />
          </Modal>
        </div>
      )}
    </div>
  );
};

export default Claire;
