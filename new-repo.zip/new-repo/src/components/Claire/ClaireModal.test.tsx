import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "react-toastify";
import ClaireModal from "./ClaireModal";
import { PartLoss, KeyObservations } from "./ClaireModal";

jest.mock("@tanstack/react-query", () => ({
  useMutation: jest.fn(),
}));

jest.mock("react-toastify", () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    info: jest.fn(),
  },
}));

describe("ClaireModal Component", () => {
  const agent1Query = {
    data: {
      claim_event_part_details: [
        {
          claim_event_part_details_id: "1",
          part_number: "123",
          part_description: "Part 1",
          recommendation: "category_does_not_match",
          predicted_loss_category: "Category A",
          assigned_loss_category: "Category B",
          assigned_loss_code_description: "Description",
          assigned_loss_code: "Code",
        },
      ],
    },
    isSuccess: true,
  };

  const agent2Query = {
    data: {
      claim_event_part_details: [
        {
          claim_event_part_details_id: "2",
          part_number: "456",
          part_description: "Part 2",
          follow_up_questions_for_customer: ["Question 1"],
          follow_up_questions_for_technician: ["Question 2"],
          part_price: 100,
          level_one_classification: "Level 1",
          level_two_classification: "Level 2",
          level_three_classification: "Level 3",
          contractual_section_confidence_score: 90,
        },
      ],
    },
    isSuccess: true,
  };

  const mutation = {
    mutate: jest.fn(),
    isSuccess: false,
    isError: false,
  };

  beforeEach(() => {
    (useMutation as jest.Mock).mockReturnValue(mutation);
  });

  test("renders ClaireModal component", () => {
    render(<ClaireModal agent1Query={agent1Query} agent2Query={agent2Query} />);
    expect(screen.getByText("Hi! I'm Claire, your claims review assistant.")).toBeInTheDocument();
  });

  test("renders PartLoss component", () => {
    render(<PartLoss agent1Query={agent1Query} submitFeedback={jest.fn()} />);
    expect(screen.getByText("Part to Loss Category/Code mapping")).toBeInTheDocument();
    expect(screen.getByText("Part 1")).toBeInTheDocument();
  });

  test("renders KeyObservations component", () => {
    render(<KeyObservations agent2Query={agent2Query} submitFeedback={jest.fn()} />);
    expect(screen.getByText("Key observations and follow-up questions")).toBeInTheDocument();
    expect(screen.getByText("Part 2")).toBeInTheDocument();
  });

  test("calls submitFeedback on button click in PartLoss", () => {
    const submitFeedback = jest.fn();
    render(<PartLoss agent1Query={agent1Query} submitFeedback={submitFeedback} />);
    fireEvent.click(screen.getByTestId("feedback_button_thumbsUp"));
    expect(submitFeedback).toHaveBeenCalled();
  });

  test("calls submitFeedback on button click in KeyObservations", () => {
    const submitFeedback = jest.fn();
    render(<KeyObservations agent2Query={agent2Query} submitFeedback={submitFeedback} />);
    fireEvent.click(screen.getByTestId("feedback_button_thumbsUp"));
    expect(submitFeedback).toHaveBeenCalled();
  });

  test("calls notify on mutation success", () => {
    mutation.isSuccess = true;
    render(<ClaireModal agent1Query={agent1Query} agent2Query={agent2Query} />);
    expect(toast.success).toHaveBeenCalled();
  });

  test("calls notify on mutation error", () => {
    mutation.isError = true;
    render(<ClaireModal agent1Query={agent1Query} agent2Query={agent2Query} />);
    expect(toast.error).toHaveBeenCalled();
  });
});