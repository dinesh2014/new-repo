import OriginalClaire from "./Claire";
import Claire from "./index";


describe("index.tsx", () => {
  it("should export Claire as default", () => {
    expect(Claire).toBe(OriginalClaire);
  });
});