import SideNav from './SideNav';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export SideNav as default', () => {
    expect(DefaultExport).toBe(SideNav);
  });
});