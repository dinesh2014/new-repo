import React from 'react';
import { render } from '@testing-library/react';
import SideNav from './SideNav';
import { pagesList } from '../../pages/PagesList';

// Mock the pagesList
jest.mock('../../pages/PagesList', () => ({
  pagesList: [
    { href: '/home', label: 'Home' },
    { href: '/about', label: 'About' },
  ],
}));

describe('SideNav', () => {
  it('should render the side navigation component', () => {
    const { getByLabelText } = render(<SideNav />);
    const listbox = getByLabelText('User Menu');
    expect(listbox).toBeInTheDocument();
  });

  it('should render the correct number of items', () => {
    const { getAllByRole } = render(<SideNav />);
    const items = getAllByRole('option');
    expect(items).toHaveLength(pagesList.length);
  });

  it('should highlight the active item', () => {
    // Mock window.location.pathname
    delete window.location;
    window.location = { pathname: '/home' } as any;

    const { getByText } = render(<SideNav />);
    const activeItem = getByText('Home');
    expect(activeItem).toHaveClass('text-primary/90');
  });
});