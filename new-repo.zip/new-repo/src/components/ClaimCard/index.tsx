export { default } from "./ClaimCard";
