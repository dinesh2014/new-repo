/**
 * Represents the props for the LabeledInfo component.
 */
export interface InfoProps {
  label?: string;
  labelSize?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl";
  labelLeading?: "none" | "tight" | "snug" | "normal" | "relaxed" | "loose";
  value: string | number;
  valueSize?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl";
  valueLeading?: "none" | "tight" | "snug" | "normal" | "relaxed" | "loose";
  isReversed?: boolean;
  nullReplacement?: "N/A" | "Unknown" | "$0" | "0%";
}

/**
 * Renders a labeled information component.
 *
 * @component
 * @param {InfoProps} props - The component props.
 * @param {string} props.label - The label to display.
 * @param {string} [props.labelSize="sm"] - The size of the label text.
 * @param {string} [props.labelLeading="snug"] - The leading (line height) of the label text.
 * @param {string | number} [props.value=""] - The value to display.
 * @param {string} [props.valueSize="lg"] - The size of the value text.
 * @param {string} [props.valueLeading="snug"] - The leading (line height) of the value text.
 * @param {boolean} [props.isReversed] - Whether to reverse the order of label and value.
 * @param {string} [props.nullReplacement="N/A"] - The replacement text to display when value is null or unknown.
 * @returns {JSX.Element} The rendered labeled information component.
 */

const valueDisplay = (value:any , nullReplacement:any)=>{
  let displayValue;
  if (value && value !== "null" && value !== "unknown") {
    displayValue = value;
  } else {
    displayValue = nullReplacement;
  }
  return displayValue;
};

const LabeledInfo = ({
  label,
  labelSize = "sm",
  labelLeading = "snug",
  value = "",
  valueSize = "lg",
  valueLeading = "snug",
  isReversed,
  nullReplacement = "N/A",
}: InfoProps) => (

  <div
    className={`flex ${isReversed ? "flex-col-reverse" : "flex-col"} justify-center leading-none`}
  >
    {label && (
      <div
        className={`font-thin text-${labelSize} text-nowrap leading-${labelLeading}`}
      >
        {label}
      </div>
    )}
    <div
      className={`font-light text-${valueSize} text-nowrap leading-${valueLeading}`}
    >
      {valueDisplay(value ,nullReplacement )}
    </div>
  </div>
);

export default LabeledInfo;
