import {
  Avatar,
  Image,
  Navbar,
  NavbarBrand,
  NavbarContent,
  Link,
  Dropdown,
  DropdownTrigger,
  DropdownMenu,
  DropdownItem,
} from "@nextui-org/react";
import { useLocation } from "react-router-dom";
import SearchField from "../SearchField";
import Globals from "../../globals";

/**
 * The navigation bar component.
 * @returns JSX element representing the navigation bar.
 */
const NavBar = () => {
  const location = useLocation();

  return (
    <Navbar
      data-testid="navbar"
      isBordered
      maxWidth="full"
      classNames={{ base: "px-4 bg-white/85" }}
    >
      <NavbarBrand>
        <Link href="/">
          <Image
            width={150}
            alt="GSFS Group"
            src="img/gsfs-group-4x.png"
          />
        </Link>
      </NavbarBrand>
      <NavbarContent
        className="hidden sm:flex gap-4"
        justify="center"
      ></NavbarContent>
      <NavbarContent
        as="div"
        className="items-center"
        justify="end"
      >
        {location.pathname !== "/" && (
          <SearchField
            navbar
            size="sm"
          />
        )}

        <Dropdown placement="bottom-end">
          <DropdownTrigger>
            <Avatar
              isBordered
              showFallback
              as="button"
              className="transition-transform"
              color="default"
              name={Globals.user}
              size="sm"
              src=""
            />
          </DropdownTrigger>
          <DropdownMenu
            aria-label="Profile Actions"
            variant="flat"
          >
            <DropdownItem
              key="profile"
              className="h-14 gap-2"
            >
              <p className="font-semibold">Signed in as </p>
              <p className="font-semibold">{Globals.user || "yourself"}</p>
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      </NavbarContent>
    </Navbar>
  );
};

export default NavBar;
