import { render, screen, fireEvent } from "@testing-library/react";
import ModalBox from "./ModalBox";

const mockCheck = {
  description: "Item 1 | Item 2 | Item 3",
};

describe("ModalBox", () => {
  test("renders modal when isOpen is true", () => {
    render(<ModalBox check={mockCheck} isOpen={true} setVisibleId={jest.fn()} />);
    expect(screen.getByTestId("modal")).toBeInTheDocument();
  });

  test("does not render modal when isOpen is false", () => {
    render(<ModalBox check={mockCheck} isOpen={false} setVisibleId={jest.fn()} />);
    expect(screen.queryByTestId("modal")).not.toBeInTheDocument();
  });

  test("displays check description correctly", () => {
    render(<ModalBox check={mockCheck} isOpen={true} setVisibleId={jest.fn()} />);
    expect(screen.getByText("Item 1")).toBeInTheDocument();
    expect(screen.getByText("Item 2")).toBeInTheDocument();
    expect(screen.getByText("Item 3")).toBeInTheDocument();
  });

  test("calls onClose function when modal is closed", () => {
    const mockOnClose = jest.fn();
    render(<ModalBox check={mockCheck} isOpen={true} setVisibleId={mockOnClose} />);
    fireEvent.click(screen.getByTestId("modal"));
    expect(mockOnClose).toHaveBeenCalled();
  });
});