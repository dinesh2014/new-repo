import { useMemo, useState } from "react";
import { Button, Card, CardHeader, Divider } from "@nextui-org/react";
import clsx from "clsx";

import MainCardBody from "./MainCardBody";
import SecondaryCardBody from "./SecondaryCardBody";

/**
 * Represents a data object with a label and a value.
 */
export type Data = {
  label: string;
  value: string;
};

/**
 * Represents a check.
 */
export type Check = {
  title: string;
  description: string;
};

/**
 * Props for the HighlightCard component.
 */
export interface HighlightCardProps {
  section?: string;
  highlight?: string;
  product_type?: string | number;
  title: string;
  checks?: {
    passed: Check[];
    failed: Check[];
  };
  secondary?: boolean;
  secondaryInfo?: any[];
}

/**
 * Represents a highlight card component.
 *
 * @component
 * @param {HighlightCardProps} props - The props for the HighlightCard component.
 * @param {string} props.section - The section of the highlight card.
 * @param {string} props.highlight - The highlight of the card.
 * @param {string} props.title - The title of the card.
 * @param {string} props.product_type - The product type of the card.
 * @param {Check[]} props.checks - The checks of the card.
 * @param {boolean} [props.secondary=false] - Whether the card is secondary.
 * @param {any[]} props.secondaryInfo - The secondary info of the card.
 * @returns {JSX.Element} - The rendered HighlightCard component.
 */
const HighlightCard = ({
  section,
  highlight,
  title,
  product_type,
  checks,
  secondary = false,
  secondaryInfo,
}: HighlightCardProps) => {
  const [open, setOpen] = useState(false);

  const toggleCollapsible = () => {
    setOpen((prevState) => !prevState);
  };

  let buttonText = "";
  let secbuttonText = "";
  if ((checks?.passed?.length ?? 0) > 0) {
    buttonText = open ? "Close" : "View All Checks";
  }

  

  /**
   * Calculates the secondary checks based on the provided section, secondary flag, and highlight type.
   * @property {Array} failed - The failed secondary checks.
   * @property {Array} passed - The passed secondary checks.
   * @returns {SecondaryChecks} The result of secondary checks.
   */
  const secondaryChecks = useMemo(() => {
    const filterByBreakdownPropensity = (secondaryInfo:any[] | undefined, flag:number) => {
      return secondaryInfo?.filter((info) => info?.breakdown_propensity_flag === flag);
    };

    const isLossDescriptionWithBreakdown = (section:string | undefined, secondary:boolean | undefined, highlight:string | undefined) => {
      return section === "Loss Description" && secondary && highlight === "Breakdown";
    };

    if (isLossDescriptionWithBreakdown(section, secondary, highlight)) {
      return {
        failed: filterByBreakdownPropensity(secondaryInfo, 1),
        passed: filterByBreakdownPropensity(secondaryInfo, 0),
      };
    }

    if (
      section === "Parts (w/ Loss Description)" &&
      secondary &&
      highlight === "Breakdown"
    ) {
      return {
        failed: secondaryInfo?.filter(
          (info) => info?.breakdown_part_freq <= 0.05,
        ),
        passed: secondaryInfo?.filter(
          (info) =>
            info?.breakdown_part_freq > 0.05 ||
            info?.breakdown_part_freq === "Unknown",
        ),
      };
    }

    if (section === "Labor" && secondary && highlight === "Cost") {
      return {
        passed: secondaryInfo?.filter(
          (info) =>
            info?.labor_hours_prediction_flag !== 1 &&
            info?.labor_rate_deviation_flag !== 1 &&
            info?.labor_rate_variation_flag !== 1 &&
            info?.labor_per_part_cost_flag !== 1,
        ),
        failed: secondaryInfo?.filter(
          (info) =>
            info?.labor_hours_prediction_flag === 1 ||
            info?.labor_rate_deviation_flag === 1 ||
            info?.labor_rate_variation_flag === 1 ||
            info?.labor_per_part_cost_flag === 1,
        ),
      };
    }

    // logics for Tires and Wheels
    if (
      section === "M&B Labor" &&
      product_type == 8 &&
      secondary &&
      highlight === "Cost"
    ) {
      return {
        passed: secondaryInfo?.filter(
          (info) =>
            info?.mb_deviation_flag !== 1 && info?.mb_prediction_flag !== 1,
        ),
        failed: secondaryInfo?.filter(
          (info) =>
            info?.mb_deviation_flag === 1 || info?.mb_prediction_flag === 1,
        ),
      };
    }

    if (section === "Parts" && secondary && highlight === "Cost") {
      return {
        passed: secondaryInfo?.[0]?.passed ?? [],
        failed: secondaryInfo?.[0]?.failed ?? [],
      };
    }
  }, [secondaryInfo, section, highlight]);

  if (secondaryChecks?.passed && secondaryChecks?.passed.length > 0) {
    secbuttonText = open ? "Close" : "View All Checks";
  }

  return (
    <Card
      data-testid="highlight_card"
      className={clsx(
        "w-full shadow-none px-6 bg-white rounded-md border-1 border-gray-200",
        secondary && "w-full shadow-none bg-gsfs-blue-200",
      )}
    >
      <CardHeader className="flex flex-row items-center justify-between px-0">
        <h3 className="text-sm font-bold capitalize">{title}</h3>
        {checks && (
          <Button
            data-testid="highlight_card_button"
            variant="flat"
            className="text-gsfs-blue-900 rounded-full bg-transparent hover:bg-gray-100"
            onClick={toggleCollapsible}
            isDisabled={!(checks.passed.length > 0) }
          >
            {buttonText}
          </Button>
        )}
        {secondary && (
          <Button
            data-testid="highlight_card_button"
            variant="flat"
            className="text-gsfs-blue-900 rounded-full bg-transparent hover:bg-gray-100"
            onClick={toggleCollapsible}
            isDisabled={!(secondaryChecks?.passed && secondaryChecks?.passed.length > 0)
            }
          >
            {secbuttonText}
          </Button>
        )}
      </CardHeader>
      <Divider className="bg-gray-300 h-[2px]" />
      {secondary ? (
        <SecondaryCardBody
          open={open}
          checks={secondaryChecks}
          section={section}
          highlight={highlight}
          product_type={product_type}
        />
      ) : (
        <MainCardBody
          data-testid="highlight_card__main_card"
          checks={checks}
          open={open}
        />
      )}
    </Card>
  );
};

export default HighlightCard;
