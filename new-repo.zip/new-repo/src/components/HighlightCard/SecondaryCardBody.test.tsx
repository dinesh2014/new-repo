import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import SecondaryCardBody from './SecondaryCardBody';
import { CardBody } from "@nextui-org/react";
import CustomDivider from "../CustomDivider";

jest.mock("@nextui-org/react", () => ({
  CardBody: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock("../CustomDivider", () => () => <div>CustomDivider</div>);

describe('SecondaryCardBody', () => {
  const defaultProps = {
    open: true,
    checks: {
      failed: [],
      passed: [],
    },
    section: 'Parts',
    highlight: 'Cost',
    product_type: 8,
  };

  it('renders without crashing', () => {
    render(<SecondaryCardBody {...defaultProps} />);
    expect(screen.getByText('Passed checks')).toBeInTheDocument();
  });

  it('displays "All Checks Passed" when checks.passed is not empty', () => {
    const props = {
      ...defaultProps,
      checks: {
        ...defaultProps.checks,
        passed: [{ sloss_code: 'code1', sdetail_desc: 'desc1' }],
      },
    };
    render(<SecondaryCardBody {...props} />);
    expect(screen.getByText('All Checks Passed')).toBeInTheDocument();
  });

  it('displays "Not enough data" when checks.passed is empty', () => {
    const props = {
      ...defaultProps,
      checks: {
        ...defaultProps.checks,
        passed: [],
      },
    };
    render(<SecondaryCardBody {...props} />);
    expect(screen.getByText('Not enough data')).toBeInTheDocument();
  });

  it('handles different product_type values', () => {
    const props = {
      ...defaultProps,
      product_type: 9,
    };
    render(<SecondaryCardBody {...props} />);
    expect(screen.getByText('Passed checks')).toBeInTheDocument();
  });

  it('handles different section and highlight values', () => {
    const props = {
      ...defaultProps,
      section: 'Labor',
      highlight: 'Breakdown',
    };
    render(<SecondaryCardBody {...props} />);
    expect(screen.getByText('Passed checks')).toBeInTheDocument();
  });
});