import { CardBody, Divider } from "@nextui-org/react";
import { FaCircleInfo } from "react-icons/fa6";

import clsx from "clsx";
import { Fragment, useRef } from "react";

import CustomDivider from "../CustomDivider";

/**
 * Props for the SecondaryCardBody component.
 */
interface SecondaryCardBodyProps {
  open: boolean;
  checks?: {
    failed?: any[];
    passed?: any[];
  };
  section?: string;
  highlight?: string;
  product_type?: string | number;
}

/**
 * Checks if a value is a number.
 *
 * @param value - The value to check.
 * @returns `true` if the value is a number, `false` otherwise.
 */
function isNumber(value: any) {
  return typeof value === "number";
}

/**
 * Formats the given value based on its type and label.
 * If the value is a number and the label is not "Loss code", it adds a dollar sign ($) prefix.
 * If the value is "Unknown" or null, it returns "N/A".
 * Otherwise, it returns the original value.
 *
 * @param value - The value to be formatted.
 * @param label - The label associated with the value.
 * @returns The formatted value.
 */
const formatValue = (value: string | number, type: string) => {
  if (isNumber(value) && type === "currency") {
    return "$" + value;
  }

  if (value === "Unknown" || value === null) {
    return "N/A";
  }

  return value;
};

/**
 * Renders the secondary card body component.
 *
 * @component
 * @param {SecondaryCardBodyProps} props - The component props.
 * @param {boolean} props.open - Indicates if the card body is open.
 * @param {Array} props.checks - The checks array.
 * @param {string} props.section - The section of the card body.
 * @param {string} props.highlight - The highlight type.
 * @param {string | number} props.product_type - The product type.
 * @returns {JSX.Element} The rendered secondary card body component.
 */
const SecondaryCardBody = ({
  open,
  checks,
  section,
  highlight,
  product_type,
}: SecondaryCardBodyProps) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const laborType = product_type === 8 ? "M&B Labor" : "Labor";
  let displayText;

  const costLaborFinanceArray = [
    {
      key: "labor_rate",
      flag: "",
      label: "Requested $",
      type: "currency",
    },
  ];
  if (product_type === 8) {
    costLaborFinanceArray.push(
      {
        key: "mb_prediction",
        flag: "mb_prediction_flag",
        label: "Predicted",
        type: "currency",
      },
      {
        key: "mb_deviation_benchmark",
        flag: "mb_deviation_flag",
        label: "Benchmark",
        type: "currency",
      },
    );
  } else {
    costLaborFinanceArray.push(
      {
        key: "labor_rate_variation_benchmark",
        flag: "labor_rate_variation_flag",
        label: "Historical $",
        type: "currency",
      },
      {
        key: "labor_rate_deviation_benchmark",
        flag: "labor_rate_deviation_flag",
        label: "Forte",
        type: "currency",
      },
    );
  }

  const costPartsArray = [
    {
      key: "part_individual_count",
      flag: "part_individual_count_flag",
      label: "Quantity",
      type: "number",
    },
    {
      key: "part_price",
      flag: "",
      label: "Requested",
      type: "currency",
    },
  ];
  if (product_type === 8) {
    costPartsArray.push({
      key: "part_price_prediction_benchmark",
      flag: "part_price_prediction_flag",
      label: "Predicted",
      type: "currency",
    });
  } else {
    costPartsArray.push(
      {
        key: "part_price_variation_benchmark",
        flag: "part_price_variation_flag",
        label: "Historical",
        type: "currency",
      },
      {
        key: "part_price_deviation_benchmark",
        flag: "part_price_deviation_flag",
        label: "Forte",
        type: "currency",
      },
    );
  }

  const costLaborHoursArray = [
    {
      key: "labor_hours_req",
      flag: "labor_hours_prediction_flag", //it's related to prediction to show RED
      label: "Requested time",
      type: "number",
    },
    {
      key: "labor_hours_prediction",
      flag: "labor_hours_prediction_flag",
      label: "Prediction",
      type: "number",
    },
  ];

  let checksContent;
  if (checks?.passed && checks.passed.length > 0) {
    checksContent = <p className="text-lg">All Checks Passed</p>;
  } else {
    checksContent = <p className="text-lg text-gray-400">Not enough data</p>;
  }

  const hoursdisplay =(number:any)=>{
    if (isNumber(number)) {
      displayText = number === 1 ? " hour" : " hours";
    } else {
      displayText = "N/A";
    }
    return displayText;
  };
  // Extracted function to handle rendering of section information
  const renderSectionInfo = (section:string|undefined, info:any) => {
    if ((section === "lost" && info?.sloss_code) || (section === "Loss Description" && info?.sloss_code)) {
      return (
        <div className="grid grid-flow-row items-center">
          <span className="text-md font-semibold">
            {info?.sloss_code}
            {info?.sdetail_desc && " - " + info?.sdetail_desc}
          </span>
        </div>
      );
    } else if ((section === "Parts" && info?.spart_no) || (section === "Parts (w/ Loss Description)" && info?.spart_no)) {
      return (
        <div className="grid grid-flow-row items-center">
          <span className="text-md font-semibold uppercase">
            {info?.spart_no}
            {info?.spart_desc && info?.spart_desc != "None" && " - " + info?.spart_desc.replace(/-$/g, " ")}
          </span>
        </div>
      );
    }
    return null;
  };

  // Extracted function to handle rendering of highlight information
  const renderHighlightInfo = (highlight:string|undefined, section:string|undefined) => {
    if (highlight === "Breakdown") {
      return (
        <div className="flex flex-row items-center gap-2">
          <FaCircleInfo size={12} className="cursor-pointer text-red-600" />
          {section === "lost" || section === "Loss Description" ? (
            <span className="text-sm text-nowrap text-red-600">Low Breakdown</span>
          ) : null}
          {section === "Parts" || section === "Parts (w/ Loss Description)" ? (
            <span className="text-sm text-nowrap text-red-600">Low Frequency</span>
          ) : null}
        </div>
      );
    }
    return null;
  };

  // Function to render loss description
  const renderLossDescription = (section:string|undefined, info:any) => {
    if ((section === "lost" || section === "Loss Description") && info?.sloss_code) {
      return (
        <div className="grid grid-flow-row items-center">
          <span className="text-md">
            {info.sloss_code}
            {info.sdetail_desc && ` - ${info.sdetail_desc}`}
          </span>
        </div>
      );
    }
    return null;
  };

  // Function to render parts information
  const renderPartsInformation = (section:string|undefined, info:any) => {
    if ((section === "Parts" || section === "Parts (w/ Loss Description)") && info?.spart_no) {
      return (
        <div className="grid grid-flow-row items-center">
          <span className="text-md uppercase">
            {info.spart_no}
            {info.spart_desc && info.spart_desc !== "None" && ` - ${info.spart_desc.replace(/-$/g, " ")}`}
          </span>
        </div>
      );
    }
    return null;
  };

  // Function to render breakdown information
  const renderBreakdownInformation = (highlight:string|undefined, section:string|undefined, info:any) => {
    if (highlight === "Breakdown") {
      return (
        <div className="flex flex-row items-center gap-2">
          {section === "lost" || section === "Loss Description" ? (
            <span className="text-sm text-nowrap">Normal Breakdown</span>
          ) : null}
          {section === "Parts" || section === "Parts (w/ Loss Description)" ? (
            <span className="text-sm text-nowrap">
              {info?.breakdown_part_freq && info.breakdown_part_freq === "Unknown"
                ? "Frequency unknown"
                : "Normal Frequency"}
            </span>
          ) : null}
        </div>
      );
    }
    return null;
  };
  return (
    <CardBody className="px-0 py-7 transition-all duration-300 flex gap-1">
      {checks?.failed && checks.failed.length > 0 ? (
        checks?.failed?.map((info, index) => (
          <Fragment key={`${info[0]}-${index}`}>
            <div className="flex flex-row items-center justify-between">
              {renderSectionInfo(section, info)}
              {renderHighlightInfo(highlight, section)}
            </div>
            {highlight === "Cost" && (
              <div
                className={clsx(
                  "flex flex-rol items-center justify-between",
                  (checks?.failed?.length ?? 0) - 1 !== index && "",
                )}
              >
                {section === "Parts" && (
                  <div className="grid grid-flow-row grow pb-6">
                    <span className="text-lg font-semibold">
                      {info?.sloss_code}
                      {info?.sdetail_desc && " - " + info?.sdetail_desc}
                    </span>
                    {((info.nb_parts_flag == 1 && info.nb_parts_flag_text) ||
                      (info.part_req_total_flag == 1 &&
                        info.part_req_total_flag_text)) && (
                      <div className="my-2 font-bold text-sm text-red-600">
                        <div className="grid grid-flow-row flex-auto gap-2">
                          {info.nb_parts_flag == 1 && (
                            <div className="flex items-center text-md whitespace-pre-wrap">
                              {info.nb_parts_flag_text}
                            </div>
                          )}
                          {info.part_req_total_flag == 1 && (
                            <div className="flex items-center text-md whitespace-pre-wrap">
                              {info.part_req_total_flag_text}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    <div className="flex flex-auto pt-2 ps-1">
                      <CustomDivider
                        vertical
                        color="red"
                        width={1}
                      />
                      <div className="grid grid-flow-row gap-2 grow">
                        {info?.parts.map((partItem: any, index: number) => {
                          return (
                            <div
                              className={clsx(
                                product_type === 8
                                  ? "grid-cols-3"
                                  : "grid-cols-4",
                                "grid justify-between items-center ps-4 grow gap-2",
                              )}
                              key={partItem.spart_no + index}
                            >
                              <div className="col-span-4">
                                <div className="grid grid-flow-col auto-cols-max items-center gap-1">
                                  <span className="text-lg">
                                    {partItem?.spart_no}
                                    {partItem?.spart_desc &&
                                      partItem?.spart_desc != "None" &&
                                      " - " +
                                        partItem?.spart_desc.replace(
                                          /-$/g,
                                          " ",
                                        )}
                                  </span>
                                </div>
                              </div>

                              {partItem.part_individual_count_flag === 1 &&
                                partItem.part_individual_count_flag_text && (
                                <div className="col-span-4 font-bold text-sm text-red-600">
                                  <div className="flex items-center gap-2">
                                    <div className="grid grid-flow-row flex-auto gap-2">
                                      {partItem.part_individual_count_flag ===
                                          1 && (
                                        <div className="flex items-center text-md whitespace-pre-wrap">
                                          {
                                            partItem.part_individual_count_flag_text
                                          }
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              )}

                              {costPartsArray.map((item) => {
                                const itemValue = partItem[item.key];
                                const formattedValue = formatValue(
                                  itemValue,
                                  item.type,
                                );
                                const paintRed =
                                  (partItem[item.flag] === 1 &&
                                    formattedValue !== "N/A") ||
                                  (item.key === "part_price" &&
                                    (partItem["part_price_variation_flag"] ===
                                      1 ||
                                      partItem["part_price_deviation_flag"] ===
                                        1 ||
                                      partItem["part_price_prediction_flag"] ===
                                        1));

                                return (
                                  <div
                                    id={item.key}
                                    key={item.key}
                                    className="h-full flex flex-col justify-between items-start"
                                  >
                                    <span className="text-sm font-light">
                                      {item.label}
                                    </span>
                                    <span
                                      className={clsx(
                                        "text-lg ",
                                        paintRed
                                          ? "text-red-600"
                                          : "text-black",
                                      )}
                                    >
                                      {formattedValue}
                                    </span>
                                  </div>
                                );
                              })}

                              {info?.parts.length - 1 !== index && (
                                <div className="col-span-4 justify-center flex">
                                  <Divider className="bg-slate-300 h-[1px] w-full mb-2 mt-4" />
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}
                {(section === "Labor" || section === "M&B Labor") && (
                  <div className="grid grid-flow-row grow pb-6">
                    <span className="text-lg font-semibold">
                      {info?.sloss_code}
                      {info?.sdetail_desc && " - " + info?.sdetail_desc}
                    </span>
                    {info.labor_per_part_cost_flag === 1 &&
                      info.labor_per_part_cost_flag_text && (
                      <div className="my-2 font-bold text-sm text-red-600">
                        <div className="grid grid-flow-row flex-auto gap-2">
                          {info.labor_per_part_cost_flag === 1 && (
                            <div className="flex items-center text-md whitespace-pre-wrap">
                              {info.labor_per_part_cost_flag_text}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    <div className="flex flex-auto pt-2 ps-1">
                      <CustomDivider
                        vertical
                        color="red"
                        width={1}
                      />
                      <div className="grid grid-cols-3 justify-between items-center ps-4 grow">
                        {costLaborFinanceArray.map((item) => {
                          const itemValue = info[item.key];
                          const formattedValue = formatValue(
                            itemValue,
                            item.type,
                          );

                          const paintRed =
                              (info[item.flag] === 1 &&
                                formattedValue !== "N/A") ||
                              (item.key === "labor_rate" &&
                                (info["labor_rate_variation_flag"] === 1 ||
                                  info["labor_rate_deviation_flag"] === 1 ||
                                  info["mb_prediction_flag"] === 1 ||
                                  info["mb_deviation_flag"] === 1));

                          return (
                            <div
                              id={item.key}
                              key={item.key}
                              className="h-full flex flex-col justify-between items-start"
                            >
                              <span className="text-sm font-light">
                                {item.label}
                              </span>
                              <span
                                className={clsx(
                                  "text-lg ",
                                  paintRed ? "text-red-600" : "text-black",
                                )}
                              >
                                {formatValue(info?.[item.key], item.type)}
                              </span>
                            </div>
                          );
                        })}
                        {laborType !== "M&B Labor" &&
                            costLaborHoursArray.map((item) => {
                              const itemValue = info[item.key];
                              const formattedValue = formatValue(
                                itemValue,
                                item.type,
                              );
                              const paintRed =
                                info[item.flag] === 1 &&
                                formattedValue !== "N/A";
                              const roundedValue = (number: number) => {
                                return (
                                  Math.round((number + Number.EPSILON) * 100) /
                                  100
                                );
                              };
                              let displayValue;
                              if (isNumber(itemValue)) {
                                const rounded = roundedValue(itemValue);
                                const unit = itemValue === 1 ? " hour" : " hours";
                                displayValue = `${rounded}${unit}`;
                              } else {
                                displayValue = "N/A";
                              }

                              return (
                                <div
                                  id={item.key}
                                  key={item.key}
                                  className="h-full flex flex-col justify-between items-start"
                                >
                                  <span className="text-sm font-light">
                                    {item.label}
                                  </span>
                                  <span
                                    className={clsx(
                                      "text-lg ",
                                      paintRed ? "text-red-600" : "text-black",
                                    )}
                                  >
                                    {displayValue}
                                  </span>
                                </div>
                              );
                            })}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </Fragment>
        ))
      ) : checksContent}
      <div
        ref={contentRef}
        className="transition-[height] ease-in-out duration-400 overflow-hidden"
        style={{
          height: open ? contentRef.current?.scrollHeight : 0,
        }}
      >
        <h3 className="text-sm font-bold pt-6">Passed checks</h3>
        <Divider className="bg-slate-200 h-[2px] my-3" />
        <div className="flex flex-col gap-2">
          {checks?.passed &&
            checks.passed.length > 0 &&
            checks?.passed?.map((info, index) => (
              <Fragment key={`${info[0]}-${index}`}>
                <div className="flex flex-row items-center justify-between">
                  {renderLossDescription(section, info)}
                  {renderPartsInformation(section, info)}
                  {renderBreakdownInformation(highlight, section, info)}
                </div>
                {highlight === "Cost" && (
                  <div
                    className={clsx(
                      "flex flex-rol items-center justify-between",
                      (checks?.passed?.length ?? 0) - 1 !== index && "",
                    )}
                  >
                    {section === "Parts" && (
                      <div className="grid grid-flow-row pb-4 grow">
                        <span className="text-lg">
                          {info?.sloss_code}
                          {info?.sdetail_desc && " - " + info?.sdetail_desc}
                        </span>
                        <div className="flex flex-auto pt-2 ps-1">
                          <CustomDivider
                            vertical
                            color="gray"
                            width={1}
                          />
                          <div className="grid grid-flow-row gap-2 grow">
                            {info?.parts.map((partItem: any, index: number) => {
                              return (
                                <div
                                  className={clsx(
                                    "grid grid-cols-",
                                    product_type === 8 ? "3" : "4",
                                    "justify-between items-center ps-4 grow gap-2",
                                  )}
                                  key={partItem.spart_no + index}
                                >
                                  <div className="col-span-4">
                                    <div className="grid grid-flow-col auto-cols-max items-center gap-1 ">
                                      <span className="text-lg">
                                        {partItem?.spart_no}
                                        {partItem?.spart_desc &&
                                          partItem?.spart_desc != "None" &&
                                          " - " +
                                            partItem?.spart_desc.replace(
                                              /-$/g,
                                              " ",
                                            )}
                                      </span>
                                    </div>
                                  </div>

                                  {costPartsArray.map((item) => (
                                    <div
                                      id={item.key}
                                      key={item.key}
                                      className="h-full flex flex-col justify-between items-start"
                                    >
                                      <span className="text-sm font-light">
                                        {item.label}
                                      </span>
                                      <span className={clsx("text-lg")}>
                                        {formatValue(
                                          partItem?.[item.key],
                                          item.type,
                                        )}
                                      </span>
                                    </div>
                                  ))}

                                  {info?.parts.length - 1 !== index && (
                                    <div className="col-span-4 justify-center flex">
                                      <Divider className="bg-slate-300 h-[1px] w-full mb-2 mt-4" />
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                    {(section === "Labor" || section === "M&B Labor") && (
                      <div className="grid grid-flow-row pb-4 grow">
                        <span className="text-lg">
                          {info?.sloss_code}
                          {info?.sdetail_desc && " - " + info?.sdetail_desc}
                        </span>
                        <div className="flex flex-auto pt-2 ps-1">
                          <CustomDivider
                            vertical
                            color="gray"
                            width={1}
                          />
                          <div className="grid grid-cols-3 justify-between items-center ps-4 grow">
                            {costLaborFinanceArray.map((item) => (
                              <div
                                id={item.key}
                                key={item.key}
                                className="h-full flex flex-col justify-between items-start"
                              >
                                <span className="text-sm font-light">
                                  {item.label}
                                </span>
                                <span className={clsx("text-lg")}>
                                  {formatValue(info?.[item.key], item.type)}
                                </span>
                              </div>
                            ))}
                            {laborType !== "M&B Labor" &&
                              costLaborHoursArray.map((item) => (
                                <div
                                  id={item.key}
                                  key={item.key}
                                  className="h-full flex flex-col justify-between items-start"
                                >
                                  <span className="text-sm font-light">
                                    {item.label}
                                  </span>
                                  <span className={clsx("text-lg")}>
                                    {isNumber(info[item.key])
                                      ? Math.round(
                                        (info[item.key] + Number.EPSILON) *
                                            100,
                                      ) / 100
                                      : ""}
                                    {hoursdisplay(info[item.key])}
                                  </span>
                                </div>
                              ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </Fragment>
            ))}
        </div>
      </div>
    </CardBody>
  );
};

export default SecondaryCardBody;
