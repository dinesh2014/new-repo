import { describe, it, expect, afterEach, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";

import SideBar from "./SideBar";

describe("SideBar component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Should render SideBar component closed", () => {
    render(<SideBar open={false}>content here</SideBar>);

    const sidebar = screen.getByTestId("sidebar");
    const overlay = screen.queryByTestId("overlay");

    expect(sidebar).toHaveClass("-translate-x-full");
    expect(overlay).not.toBeInTheDocument();
  });

  it("Should render SideBar component open", () => {
    render(<SideBar open={true}>content here</SideBar>);

    const sidebar = screen.getByTestId("sidebar");
    const overlay = screen.getByTestId("overlay");

    expect(sidebar).toHaveClass("translate-x-0");
    expect(overlay).toBeInTheDocument();
  });

  it("Should render SideBar component open without overlay", () => {
    render(
      <SideBar
        open={true}
        hideOverlay
      >
        content here
      </SideBar>,
    );

    const sidebar = screen.getByTestId("sidebar");
    const overlay = screen.queryByTestId("overlay");

    expect(sidebar).toHaveClass("translate-x-0");
    expect(overlay).not.toBeInTheDocument();
  });

  it("Should call onClose when overlay is clicked", () => {
    const onClose = vi.fn();

    render(
      <SideBar
        open={true}
        onClose={onClose}
      >
        content here
      </SideBar>,
    );

    const overlay = screen.getByTestId("overlay");

    overlay.click();

    expect(onClose).toHaveBeenCalled();
  });
});
