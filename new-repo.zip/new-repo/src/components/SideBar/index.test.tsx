import SideBar from './SideBar';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export SideBar as default', () => {
    expect(DefaultExport).toBe(SideBar);
  });
});