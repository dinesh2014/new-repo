import { Divider } from "@nextui-org/react";
import clsx from "clsx";

/**
 * Props for the CircularProgress component.
 */
interface CircularProgressProps {
  strokeWidth?: number;
  size?: number;
  leftAmount: number;
  rightAmount: number;
}

/**
 * Renders a circular progress component.
 *
 * @component
 * @param {CircularProgressProps} props - The component props.
 * @param {number} [props.strokeWidth=5] - The width of the progress stroke.
 * @param {number} [props.size=72] - The size of the progress component.
 * @param {number} props.leftAmount - The amount for the left circle.
 * @param {number} props.rightAmount - The amount for the right circle.
 * @returns {JSX.Element} The rendered CircularProgress component.
 */
const CircularProgress = ({
  strokeWidth = 5,
  size = 72,
  leftAmount,
  rightAmount,
}: CircularProgressProps) => {
  const totalAmount = leftAmount + rightAmount;
  const radius = (size - strokeWidth) / 2;

  const circunference = radius * Math.PI * 2;
  const leftCircleDashOffset =
    circunference - circunference * (leftAmount / totalAmount);
  const rightCircleDashOffset =
    circunference - circunference * (rightAmount / totalAmount);

  return (
    <div
      className="relative inline-block"
      style={{ width: size, height: size }}
    >
      <div className="absolute flex w-full h-full row items-center justify-center px-3">
        <span className="text-2xl w-[50%] text-center">{leftAmount}</span>
        <Divider
          orientation="vertical"
          className="h-[50%] bg-gray-300"
        />
        <span
          className={clsx(
            "text-2xl w-[50%] text-center",
            rightAmount > 0 && "text-red-600",
          )}
        >
          {rightAmount}
        </span>
      </div>
      <svg
        data-testid="svg"
        width={size}
        height={size}
        xmlns="<http://www.w3.org/2000/svg>"
      >
        <circle
          data-testid="left-circle"
          className="fill-none stroke-gsfs-secondary-blue-900"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          strokeDasharray={circunference}
          strokeDashoffset={-leftCircleDashOffset}
        />
        <circle
          data-testid="right-circle"
          className="fill-none stroke-red-600 stroke-"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          strokeDasharray={circunference}
          strokeDashoffset={rightCircleDashOffset}
        />
      </svg>
    </div>
  );
};

export default CircularProgress;
