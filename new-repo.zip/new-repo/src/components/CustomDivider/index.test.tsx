import OriginalCustomDivider from "./CustomDivider";
import DefaultExport from "./index";

describe("index.tsx", () => {
  it("should export CustomDivider as default", () => {
    expect(DefaultExport).toBe(OriginalCustomDivider);
  });
});