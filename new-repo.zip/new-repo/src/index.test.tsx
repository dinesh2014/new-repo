import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { PostHogProvider } from 'posthog-js/react';
import { NextUIProvider } from '@nextui-org/react';
import { QueryClientProvider } from '@tanstack/react-query';
import Router from './router';
import App from './index';

jest.mock('posthog-js/react', () => ({
  PostHogProvider: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  usePostHog: () => ({
    identify: jest.fn(),
  }),
}));

jest.mock('@nextui-org/react', () => ({
  NextUIProvider: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock('@tanstack/react-query', () => ({
  QueryClientProvider: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  QueryClient: jest.fn(),
}));

jest.mock('./router', () => () => <div>Router</div>);

describe('App Component', () => {
  it('renders without crashing', () => {
    render(<App />);
    
    expect(screen.getByText('Router')).toBeInTheDocument();
  });
});