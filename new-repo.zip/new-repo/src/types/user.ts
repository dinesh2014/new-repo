/**
 * Represents a user.
 */
export interface IUser {
  name: string | null;
  email: string | null;
  counter: number;
  isLogged: boolean;
}

/**
 * Represents the state of a user.
 */
export interface IUserState {
  user: IUser;
  setUser: (user: Partial<IUser>) => void;
  resetUser: () => void;
  incrementCounter: () => void;
}
