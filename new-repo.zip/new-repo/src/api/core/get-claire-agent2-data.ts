import axios from "axios";
import Globals from "../../globals";

/**
 * Represents the props for the full details data for a Claire request.
 */
export interface ClaimEventPartDetailsProps {
  claim_event_part_details_id: number;
  part_description: string;
  part_number: string;
  part_price: number;
  prediction_id: number;
  follow_up_questions_for_customer: string[];
  follow_up_questions_for_technician: string[];
  recommendation: string;
  contractual_section: string;
  contractual_section_confidence_score: number;
  is_feedback_thumbs_up: boolean;
  user_feedback_text: string;
  is_deleted: boolean;
}

/**
 * Represents the properties and detailed array of a Claire response for agent 2.
 */
export interface Agent2Props {
  id: number;
  claim_number: string;
  claim_event_part_details: ClaimEventPartDetailsProps[];
}

/**
 * Retrieves the details of a claim.
 *
 * @param claimNumber - The claim number.
 * @returns A promise that resolves to Claire Agent 2 response.
 */
export const getClaireAgent2Data = (
  claimNumber: string,
): Promise<Agent2Props> => {
  return new Promise((resolve, reject) => {
    axios
      .get(`${Globals.apiURL}/v1/genai/agent2/${claimNumber}`)
      .then((res) => {
        resolve(res.data);
      })
      .catch((error) => {
        reject( new Error(error.message ?? error));
      });
  });
};
