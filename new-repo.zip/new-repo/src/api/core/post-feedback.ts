import axios from "axios";
import Globals from "../../globals";

/**
 * Represents the data structure for feedback.
 */
export interface FeedbackDataProps {
  [key: string]: string | boolean;
}

/**
 * Represents the properties of a feedback object.
 */
export interface FeedbackObjProps {
  type: string;
  text: string;
  visible: boolean;
  order: number;
}

/**
 * Sends feedback data to the server.
 * @param feedbackData - The feedback data to be sent.
 * @returns A Promise that resolves to an array of strings representing the server response.
 */
export const postFeedback = (
  feedbackData: FeedbackDataProps,
): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    axios
      .post(`${Globals.apiURL}/v1/feedback`, feedbackData)
      .then((response) => {
        resolve(response.data);
      })
      .catch((error) => {
        reject( new Error(error.message ?? error));
      });
  });
};
