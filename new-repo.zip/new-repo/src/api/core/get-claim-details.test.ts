import { describe, it, expect, vi } from "vitest";
import axios from "axios";
import { getClaimDetails } from "./get-claim-details";
import Globals from "../../globals";


vi.mock("axios");

describe("getClaimDetails API Route", () => {
  const claimNumber = "12345";
  const mockResponse = {
    data: {
      claimNumber: "12345",
      claimTitle: "Test Title",
      claimSubtitle: "Test Subtitle",
    },
  };

  it("resolves with claim details on successful API call", async () => {
    (axios.get as jest.Mock).mockResolvedValue(mockResponse);

    const result = await getClaimDetails(claimNumber);

    expect(result).toEqual(mockResponse.data);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/${claimNumber}`);
  });

  it("rejects with an error message on API call failure", async () => {
    const errorMessage = "Network Error";
    (axios.get as jest.Mock).mockRejectedValue(new Error(errorMessage));

    await expect(getClaimDetails(claimNumber)).rejects.toThrow(errorMessage);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/${claimNumber}`);
  });

  it("handles empty response gracefully", async () => {
    (axios.get as jest.Mock).mockResolvedValue({ data: {} });

    const result = await getClaimDetails(claimNumber);

    expect(result).toEqual({});
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/${claimNumber}`);
  });

  it("handles unexpected response structure gracefully", async () => {
    const unexpectedResponse = { data: { unexpectedKey: "unexpectedValue" } };
    (axios.get as jest.Mock).mockResolvedValue(unexpectedResponse);

    const result = await getClaimDetails(claimNumber);

    expect(result).toEqual(unexpectedResponse.data);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/${claimNumber}`);
  });

  it("handles network errors gracefully", async () => {
    const networkError = new Error("Network Error");
    (axios.get as jest.Mock).mockRejectedValue(networkError);

    await expect(getClaimDetails(claimNumber)).rejects.toThrow("Network Error");
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/${claimNumber}`);
  });
});