import axios from "axios";
import { postFeedback, FeedbackDataProps } from "./post-claire-feedback";
import Globals from "../../globals";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe("postFeedback", () => {
  const feedbackData: FeedbackDataProps = {
    prediction_id: 1,
    agent_type: 2,
    is_feedback_thumbs_up: true,
    user_feedback_text: "Great prediction!",
  };

  const mockResponse = ["Feedback received"];

  it("should resolve with the correct data", async () => {
    mockedAxios.post.mockResolvedValue({ data: mockResponse });

    const result = await postFeedback(feedbackData);
    expect(result).toEqual(mockResponse);
    expect(mockedAxios.post).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/feedback`, feedbackData);
  });

  it("should reject with an error message", async () => {
    const errorMessage = "Network Error";
    mockedAxios.post.mockRejectedValue(new Error(errorMessage));

    await expect(postFeedback(feedbackData)).rejects.toThrow(errorMessage);
    expect(mockedAxios.post).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/feedback`, feedbackData);
  });
});