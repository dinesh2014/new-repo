import axios from "axios";
import Globals from "../../globals";
import { postFeedback, FeedbackDataProps } from "./post-feedback";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe("postFeedback", () => {
  const feedbackData: FeedbackDataProps = {
    type: "bug",
    text: "There is a bug in the system.",
    visible: true,
    order: 1,
  };

  it("should resolve with the correct data when the server responds successfully", async () => {
    const responseData = ["Feedback received"];
    mockedAxios.post.mockResolvedValue({ data: responseData });

    await expect(postFeedback(feedbackData)).resolves.toEqual(responseData);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      `${Globals.apiURL}/v1/feedback`,
      feedbackData
    );
  });

  it("should reject with an error when the server responds with an error", async () => {
    const errorMessage = "Network Error";
    mockedAxios.post.mockRejectedValue(new Error(errorMessage));

    await expect(postFeedback(feedbackData)).rejects.toThrow(errorMessage);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      `${Globals.apiURL}/v1/feedback`,
      feedbackData
    );
  });
});