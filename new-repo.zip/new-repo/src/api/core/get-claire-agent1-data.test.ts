import axios from "axios";
import { getClaireAgent1Data, Agent1Props } from "./get-claire-agent1-data";
import Globals from "../../globals";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe("getClaireAgent1Data", () => {
  const claimNumber = "12345";
  const mockResponse: Agent1Props = {
    id: 1,
    claim_number: claimNumber,
    claim_event_part_details: [
      {
        claim_event_part_details_id: 1,
        part_description: "Part A",
        part_number: "A123",
        part_price: 100,
        assigned_loss_category: "Category A",
        assigned_loss_code: "Code A",
        is_assigned_loss_code_covered: true,
        prediction_id: 1,
        predicted_loss_category: "Category B",
        predicted_loss_code: "Code B",
        is_predicted_loss_code_covered: false,
        prediction_rationale: "Rationale",
        prediction_confidence_score: 0.9,
        is_feedback_thumbs_up: true,
        user_feedback_text: "Feedback",
        is_deleted: false,
      },
    ],
  };

  it("should resolve with the correct data", async () => {
    mockedAxios.get.mockResolvedValue({ data: mockResponse });

    const result = await getClaireAgent1Data(claimNumber);
    expect(result).toEqual(mockResponse);
    expect(mockedAxios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/agent1/${claimNumber}`);
  });

  it("should reject with an error message", async () => {
    const errorMessage = "Network Error";
    mockedAxios.get.mockRejectedValue(new Error(errorMessage));

    await expect(getClaireAgent1Data(claimNumber)).rejects.toThrow(errorMessage);
    expect(mockedAxios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/agent1/${claimNumber}`);
  });
});