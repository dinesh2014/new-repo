import axios from "axios";
import Globals from "../../globals";

/**
 * Represents the data structure for feedback.
 */
export interface FeedbackDataProps {
  prediction_id: number;
  agent_type: number;
  is_feedback_thumbs_up: boolean;
  user_feedback_text: string | null;
}

/**
 * Sends feedback data to the server.
 * @param {FeedbackDataProps} feedbackData - The feedback data to be sent.
 * @returns A Promise that resolves to an array of strings representing the server response.
 */
export const postFeedback = (
  feedbackData: FeedbackDataProps,
): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    axios
      .post(`${Globals.apiURL}/v1/genai/feedback`, feedbackData)
      .then((response) => {
        resolve(response.data);
      })
      .catch((error) => {
        reject( new Error(error.message ?? error));
      });
  });
};
