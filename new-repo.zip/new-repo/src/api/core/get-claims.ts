import axios from "axios";
import Globals from "../../globals";

/**
 * Retrieves the claims from the API.
 * @returns A promise that resolves to an array of strings representing the claims.
 */
export const getClaims = async (): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    axios
      .get(`${Globals.apiURL}/v1/claims/ids`)
      .then((res) => {
        resolve(res.data);
      })
      .catch((error) => {
        reject( new Error(error.message ?? error));
      });
  });
};
