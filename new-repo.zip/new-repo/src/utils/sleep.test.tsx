// sleep.test.tsx
import { sleep } from './sleep';

describe('sleep', () => {
  jest.useFakeTimers();

  it('should resolve after the specified timeout', () => {
    const timeout = 1000; // 1 second
    const promise = sleep(timeout);

    jest.advanceTimersByTime(timeout);

    return expect(promise).resolves.toBeUndefined();
  });
});