/**
 * Array of failure statuses.
 * These are the possible statuses when a claim fails to process.
 */
export const failureStatuses = [
  "analysis in progress",
  "unable to process",
  "data not found",
  "no claim in queue",
  "not enough data to process the claim",
  undefined,
];

/**
 * Represents a mapping of keys to color statuses.
 */
interface ColorsStatus {
  [key: string]: "danger" | "success" | "warning";
}

/**
 * Represents the mapping of status values to corresponding colors.
 */
export const colorsStatus: ColorsStatus = {
  Fail: "danger",
  Pass: "success",
  Low: "success",
  Medium: "warning",
  High: "danger",
};

/**
 * Represents the initial feedback data.
 * @property {string} type - The type of feedback.
 * @property {string} text - The feedback text.
 * @property {boolean} visible - Indicates whether the feedback is visible.
 * @property {number} order - The order of the feedback input.
 */
export const initialFeedbackData = [
  {
    type: "Coverage checks",
    text: "",
    visible: true,
    order: 1,
  },
  {
    type: "Dealer checks",
    text: "",
    visible: true,
    order: 2,
  },
  {
    type: "Customer checks",
    text: "",
    visible: true,
    order: 3,
  },
  {
    type: "Breakdown checks",
    text: "",
    visible: true,
    order: 4,
  },
  {
    type: "Cost checks",
    text: "",
    visible: true,
    order: 5,
  },
];

/**
 * Represents the columns configuration for the claim history table.
 */
export const historyTableColumns = [
  {
    key: "sclaim_number",
    label: "Claim Number",
  },
  {
    key: "sclaim_status",
    label: "Claim Status",
  },
  {
    key: "sdetail_desc",
    label: "Issue Type",
  },
  {
    key: "camt_paid",
    label: "Claim $",
  },
  {
    key: "dtpaid",
    label: "Date",
  },
];
