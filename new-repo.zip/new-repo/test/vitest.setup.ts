/// <reference types="vitest" />

import "@testing-library/jest-dom/vitest";
