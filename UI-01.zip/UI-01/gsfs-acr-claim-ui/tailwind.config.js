/* eslint-disable @typescript-eslint/no-var-requires */
const { nextui } = require("@nextui-org/react");

/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      borderWidth: {
        1: "1px",
      },
      colors: {
        gsfs: {
          "sky": {
            900: "#004071",
            800: "#265078",
            400: "#819db3",
          },
          "blue": {
            900: "#0076C0",
            800: "#287bbf",
            400: "#82b5d8",
            200: "#E5F1F9",
          },
          "secondary-blue": {
            900: "#30C1D7",
          },
        },
        bcgx: {
          green: {
            700: "#02786E",
            800: "#025C56",
          },
        },
      },
    },
  },
  plugins: [nextui()],
};
