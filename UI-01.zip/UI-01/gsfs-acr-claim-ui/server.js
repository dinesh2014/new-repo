import * as https from "https";
import path from "path";
import fs from "fs";
import config from "config";
import express from "express";
import ejs from "ejs";
const app = express();

const __dirname = import.meta.dirname;
const PORT = config.has("port") ? config.get("port") : null;
const TLS_KEY_PATH = config.has("tlsKeyPath") ? config.get("tlsKeyPath") : null;
const TLS_CRT_PATH = config.has("tlsCrtPath") ? config.get("tlsCrtPath") : null;

const PUBLIC_POSTHOG_KEY = config.has("pubPostHogKey")
  ? config.get("pubPostHogKey")
  : null;
const PUBLIC_POSTHOG_HOST = config.has("pubPostHogHost")
  ? config.get("pubPostHogHost")
  : null;



app.use("/.well-known/live", (req, res) => {
  res.status(200).write("ok");
  res.end();
});

app.get("/.well-known/ready", (req, res) => {
  res.status(200).json({ success: true });
});

const indexFile = fs.readFileSync(path.join(__dirname, "dist/index.html"), {
  encoding: "utf-8",
});

app.get("/", (req, res) => {
  const data = {
    user: null,
    pubPostHogKey: PUBLIC_POSTHOG_KEY,
    pubPostHogHost: PUBLIC_POSTHOG_HOST,
  };
  const email = req.headers["x-forwarded-email"];
  if (email) data.user = { email };

  res.setHeader("Content-Type", "text/html");
  res.status(200).send(ejs.render(indexFile, data));
});

app.use(express.static(path.join(__dirname, "dist")));

if (
  TLS_KEY_PATH &&
  fs.existsSync(TLS_KEY_PATH) &&
  TLS_CRT_PATH &&
  fs.existsSync(TLS_CRT_PATH)
) {
  const server = https
    .createServer(
      {
        key: fs.readFileSync(TLS_KEY_PATH),
        cert: fs.readFileSync(TLS_CRT_PATH),
      },
      app,
    )
    .listen(PORT, () => {
      console.info("Listening on https://+:" + PORT);
    });

  process.on("SIGTERM", () => {
    server.close(() => console.info("HTTPS server closed"));
  });

  process.on("SIGINT", () => {
    server.close(() => console.info("HTTPS server closed"));
  });
} else {
  const server = app.listen(PORT, () => {
    console.info("Listening on http://+:" + PORT);
  });

  process.on("SIGTERM", () => {
    server.close(() => console.info("HTTP server closed"));
  });

  process.on("SIGINT", () => {
    server.close(() => console.info("HTTP server closed"));
  });
}
