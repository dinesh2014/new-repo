import type {Config} from 'jest';

const config: Config = {
  collectCoverageFrom: [
    '**/*.{ts,tsx}'
  ],
};

export default config;
