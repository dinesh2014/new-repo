
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  Divider,
} from "@nextui-org/react";

import { failureStatuses } from "../../utils/constants";
import Feedback from "../../pages/ClaimDetails/Feedback";
import { capitalizeFirstLetter } from "../../utils/text";

/**
 * Props for the ClaimCard component.
 */
interface ClaimCardProps {
  claimNumber: string;
  claimTitle: string;
  claimSubtitle: string;
  isFailureJobStatus: boolean;
  iproduct_type_id: number;
}

/**
 * Renders a card component for displaying claim information.
 *
 * @component
 * @param {ClaimCardProps} props - The props for the ClaimCard component.
 * @param {string} props.claimNumber - The claim number.
 * @param {string} props.claimTitle - The claim title.
 * @param {string} props.claimSubtitle - The claim subtitle.
 * @param {boolean} props.isFailureJobStatus - Indicates if the claim has a failure job status.
 * @param {number} props.iproduct_type_id - The product_type_id associated with the claim.
 * @returns {JSX.Element} The rendered ClaimCard component.
 */
const ClaimCard = ({
  claimNumber,
  claimTitle,
  claimSubtitle,
  isFailureJobStatus,
  iproduct_type_id,
}: ClaimCardProps) => {
  return (
    <Card className="p-2 shadow-lg rounded-md border-1 border-black">
      <CardHeader data-testid="claim-number">
        <div className="grid grid-flow-col gap-2">
          <div>
            <p className="text-sm">Claim #</p>
          </div>
          <div>
            <Divider orientation="vertical" />
          </div>
          <div >
            <p  className="font-bold text-sm">{claimNumber}</p>
          </div>
        </div>
      </CardHeader>
      <Divider />
      <CardBody className="pb-0">
        <div className="grid grid-rows-2 gap-2 place-content-start">
          <div>
            <p
              data-testid="claim-title"
              className={
                failureStatuses.some(
                  (status) => status === claimTitle.toLowerCase(),
                )
                  ? "font-bold text-3xl text-red-500 capitalize"
                  : "font-bold text-3xl capitalize"
              }
            >
              {claimTitle}
            </p>
          </div>
          {claimSubtitle && (
            <div>
              <p className="font-light text-lg">
                {capitalizeFirstLetter(claimSubtitle)}
              </p>
            </div>
          )}
        </div>
      </CardBody>
      {!isFailureJobStatus && (
        <CardFooter className="grid justify-items-end pt-0">
          <Feedback
            claimNumber={claimNumber || ""}
            placement="top claim card"
            iproduct_type_id={iproduct_type_id}
          />
        </CardFooter>
      )}
    </Card>
  );
};

export default ClaimCard;
