import ClaimCard from "./ClaimCard";
import * as index from "./index";

describe("index.tsx", () => {
  it("should re-export ClaimCard as default", () => {
    expect(index.default).toBe(ClaimCard);
  });
});