import { render, screen, waitFor } from "@testing-library/react";
import ClaimCard from "./ClaimCard";
import { describe, expect, it } from "vitest";
import { failureStatuses } from "../../utils/constants";
import { capitalizeFirstLetter } from "../../utils/text";

const testProps = {
  claimNumber: "12345",
  claimTitle: "Test Title",
  claimSubtitle: "Test Subtitle",
  isFailureJobStatus: true,
  iproduct_type_id: 1,
};

describe("ClaimCard", () => {
  const renderComponent = (props = {}) => render(<ClaimCard {...testProps} {...props} />);

  it("renders the claim number correctly", () => {
    renderComponent();
    expect(screen.getByTestId("claim-number")).toHaveTextContent(testProps.claimNumber);
  });

  it("renders the claim title correctly", () => {
    renderComponent();
    expect(screen.getByTestId("claim-title")).toHaveTextContent(testProps.claimTitle);
  });

  it("applies the correct class for failure statuses", () => {
    renderComponent({ claimTitle: failureStatuses[0] });
    expect(screen.getByTestId("claim-title")).toHaveClass("text-red-500");
  });

  it("renders the claim subtitle correctly", () => {
    renderComponent();
    expect(screen.getByText(capitalizeFirstLetter("Test Subtitle"))).toBeInTheDocument();
  });

  it("does not render the Feedback component when isFailureJobStatus is true", () => {
    renderComponent({ isFailureJobStatus: true });
    expect(screen.queryByTestId("feedback-component")).not.toBeInTheDocument();
  });

  it("renders the Feedback component when isFailureJobStatus is false", () => {
    renderComponent();
    waitFor(()=>expect(screen.queryByTestId("feedback-component")).toBeInTheDocument());
  });
});