import NavBar from './NavBar';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export NavBar as default', () => {
    expect(DefaultExport).toBe(NavBar);
  });
});