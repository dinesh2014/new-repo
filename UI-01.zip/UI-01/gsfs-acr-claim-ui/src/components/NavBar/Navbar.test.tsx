import { screen, render, cleanup } from "@testing-library/react";
import { HashRouter } from "react-router-dom";
import { describe, it, expect, afterEach } from "vitest";
import NavBar from "./NavBar";

describe("NavBar component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Should render NavBar component", () => {
    render(
      <HashRouter>
        <NavBar />
      </HashRouter>,
    );
    const navbar = screen.getByTestId("navbar");
    expect(navbar).toBeInTheDocument();
  });
});
