import React from 'react';
import { render } from '@testing-library/react';
import SideNav from './SideNav';
import { pagesList } from '../../pages/PagesList';
import { describe, it, expect, vi } from "vitest";

// Mock the pagesList
vi.mock('../../pages/PagesList', () => ({
  pagesList: [
    { href: '/home', label: 'Home' },
    { href: '/about', label: 'About' },
  ],
}));

describe('SideNav', () => {
  it('should render the correct number of items', () => {
    const { getAllByRole } = render(<SideNav />);
    const items = getAllByRole('option');
    expect(items).toHaveLength(pagesList.length);
  });
});