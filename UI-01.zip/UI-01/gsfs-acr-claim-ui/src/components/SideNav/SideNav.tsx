import { Listbox, ListboxItem, ListboxSection } from "@nextui-org/react";
import { pagesList, PageProps } from "../../pages/PagesList";

/**
 * Renders the side navigation component.
 *
 * @returns The JSX element representing the side navigation.
 */
const SideNav = () => {
  return (
    <aside className="hidden lg:block w-64 p-4 h-screen fixed top-16">
      <Listbox
        aria-label="User Menu"
        // onAction={(key) => alert(key)}
        className="p-0 gap-0 divide-y divide-default-300/50 dark:divide-default-100/80 bg-content1 max-w-[300px] overflow-visible shadow-small rounded-medium"
        itemClasses={{
          base: "px-3 first:rounded-t-medium last:rounded-b-medium rounded-none gap-3 h-12 data-[hover=true]:bg-default-100/80 data-[hover=true]:text-primary/80",
        }}
      >
        <ListboxSection showDivider>
          {pagesList.map((item: PageProps) => (
            <ListboxItem
              key={item.href}
              href={item.href}
              className={
                window.location.pathname === item.href ? "text-primary/90" : ""
              }
            >
              {item.label}
            </ListboxItem>
          ))}
        </ListboxSection>
      </Listbox>
    </aside>
  );
};

export default SideNav;
