import IndexExport from './index';
import GroupedLabeledInfo from './GroupedLabeledInfo';

describe('index.tsx', () => {
  test('should re-export GroupedLabeledInfo as default', () => {
    expect(IndexExport).toBe(GroupedLabeledInfo);
  });
});