import {
  Divider,
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
} from "@nextui-org/react";
import { Check } from "./HighlightCard";

/**
 * Props for the ModalBox component.
 */
interface ModalBoxProps {
  check: Check | null;
  isOpen: boolean;
  setVisibleId: () => void;
}

/**
 * Represents a modal box component.
 *
 * @component
 * @param {ModalBoxProps} props - The component props.
 * @param {Check} props.check - The check object.
 * @param {boolean} [props.isOpen=false] - Indicates whether the modal is open or not.
 * @param {Function} props.setVisibleId - The function to set the visible ID.
 * @returns {JSX.Element} The rendered modal box component.
 */
const ModalBox = ({
  check,
  isOpen = false,
  setVisibleId: onClose,
}: ModalBoxProps) => {
  return (
    <Modal
      data-testid="modal"
      size="lg"
      isOpen={isOpen}
      onClose={onClose}
      radius="sm"
      scrollBehavior="outside"
      className="p-2 pb-6"
    >
      <ModalContent>
        <>
          <ModalHeader className="flex flex-row justify-between items-center">
            <div>
              <div className="font-semibold">For internal purposes only</div>
            </div>
          </ModalHeader>
          <div className="px-6 pb-2">
            <Divider />
          </div>
          <ModalBody>
            <div className="flex flex-col gap-0">
              {check?.description.split(" | ").map((item, index) => (
                <div
                  className="text-md font-light"
                  key={`Internal${item}${index}`}
                >
                  {item}
                </div>
              ))}
            </div>
          </ModalBody>
        </>
      </ModalContent>
    </Modal>
  );
};

export default ModalBox;
