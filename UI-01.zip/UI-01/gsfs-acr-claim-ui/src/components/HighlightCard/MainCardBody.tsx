import { useRef, useState } from "react";
import { FaCircleInfo } from "react-icons/fa6";

import { CardBody, Divider } from "@nextui-org/react";

import CircularProgress from "../CircularProgress";
import ModalBox from "./ModalBox";
import { Check } from "./HighlightCard";

/**
 * Props for the MainCardBody component.
 */
export interface MainCardBodyProps {
  open: boolean;
  checks?: {
    passed: Check[];
    failed: Check[];
  };
}

/**
 * Renders the main body of the HighlightCard component.
 *
 * @component
 * @param {MainCardBodyProps} props - The props for the MainCardBody component.
 * @param {boolean} props.open - Determines whether the modal is open or closed. Default is `false`.
 * @param {Check[]} props.checks - The checks of the card.
 * @returns {JSX.Element} The JSX element representing the MainCardBody component.
 */
const MainCardBody = ({ checks, open }: MainCardBodyProps) => {
  const contentRef = useRef<HTMLDivElement>(null);

  const passedCount = checks?.passed.length ?? 0;
  const failedCount = checks?.failed.length ?? 0;
  
  let checksContent;
  if (checks && checks.failed.length > 0) {
    checksContent = (
      <div className="space-y-3 max-w-[80%]">
        {checks.failed.map((check, index) => (
          check.title !== undefined && check.title !== null && (
            <div key={index + check.title.replace(/\s/g, "")}>
              <button
                className="flex flex-row justify-start items-center gap-2 cursor-pointer"
                onClick={() => openModal(check)}
              >
                <FaCircleInfo size={12} className="cursor-pointer text-red-400" />
                <span className="text-md grow font-semibold text-red-600">
                  {check.title}
                </span>
              </button>
            </div>
          )
        ))}
      </div>
    );
  } else if (checks && checks.passed.length > 0) {
    checksContent = <p className="text-lg">All Checks Passed</p>;
  } else {
    checksContent = <p className="text-lg text-gray-400">Not enough data</p>;
  }

  const [modalCheck, setModalCheck] = useState<{
    title: string;
    description: string;
  } | null>(null);
  const [modalOpen, setModalOpen] = useState<boolean>(false);

  const openModal = (check: Check) => {
    setModalCheck(check);
    setModalOpen(true);
  };

  return (
    <CardBody
      data-testid="main_card_body"
      className="px-0 py-7 transition-all duration-300 flex gap-4"
    >
      <div className="flex flex-row items-center justify-between">
        {checksContent}
        <CircularProgress leftAmount={passedCount} rightAmount={failedCount}/>
      </div>
      {passedCount > 0 && (
        <div
          aria-hidden={!open}
          data-testid="main_card__body"
          ref={contentRef}
          className="transition-[height] ease-in-out duration-400 overflow-hidden"
          style={{
            height: open ? contentRef.current?.scrollHeight : 0,
          }}
        >
          <h3 className="text-sm font-bold">Passed checks</h3>
          <Divider className="bg-slate-200 h-[2px] my-3" />
          <div className="space-y-1">
            {checks?.passed.map(
              (check, index) =>
                check.title !== undefined &&
                  check.title !== null && (
                  <button
                    data-testid={`passed_check_${index}`}
                    key={`passed_check_${check.title}${index}`}
                    className="flex flex-row justify-start gap-2 cursor-pointer"
                    onClick={() => openModal(check)}
                  >
                    <div className="flex flex-row items-center mt-2">
                      <FaCircleInfo
                        size={12}
                        className="cursor-pointer text-sky-300"
                      />
                    </div>
                    <span className="text-start text-md font-light">{check.title}</span>
                  </button>
                ),
            )}
          </div>
        </div>
      )}
      <ModalBox
        check={modalCheck}
        setVisibleId={() => setModalOpen(false)}
        isOpen={modalOpen}
      />
    </CardBody>
  );
};

export default MainCardBody;
