import IndexExport from './index';
import HighlightCard from './HighlightCard';

describe('index.tsx', () => {
  test('should re-export HighlightCard as default', () => {
    expect(IndexExport).toBe(HighlightCard);
  });
});