import { render, screen, fireEvent } from "@testing-library/react";
import BaseCard from "./BaseCard";

describe("BaseCard", () => {
  const title = "Card Title";
  const additionalHeader = <span>Additional Header</span>;
  const children = <div>Card Content</div>;
  const expandContent = <div>Expandable Content</div>;

  it("should render the title correctly", () => {
    render(<BaseCard title={title} />);
    expect(screen.getByText(title)).toBeInTheDocument();
  });

  it("should render the additional header when provided", () => {
    render(<BaseCard title={title} additionalHeader={additionalHeader} />);
    expect(screen.getByText("Additional Header")).toBeInTheDocument();
  });

  it("should render the children content", () => {
    render(<BaseCard title={title}>{children}</BaseCard>);
    expect(screen.getByText("Card Content")).toBeInTheDocument();
  });
});