import { useState, useRef, ReactNode } from "react";
import { Button, Card, CardHeader, Divider } from "@nextui-org/react";
import clsx from "clsx";

/**
 * Props for the BaseCard component.
 */
interface BaseCardProps {
  title: string;
  additionalHeader?: ReactNode;
  children?: ReactNode;
  expandContent?: ReactNode;
}

/**
 * BaseCard component represents a card with a title, optional additional header,
 * collapsible content, and expand/collapse functionality.
 * @component
 * @param {BaseCardProps} props - The component props.
 * @param {string} props.title - The title of the card.
 * @param {boolean} props.expand - expand/collapse functionality.
 * @param {ReactNode} props.additionalHeader - Additional header content.
 * @param {ReactNode} props.children - The content of the card.
 * @param {ReactNode} props.expandContent - The expandable content of the card.
 * @returns {JSX.Element} The rendered BaseCard component.
 *
 * @example
 * ```tsx
 * <BaseCard
 *   title="Card Title"
 *   additionalHeader={<span>Additional Header</span>}
 *   expandContent={<div>Expandable Content</div>}
 * >
 *   Card Content
 * </BaseCard>
 * ```
 */
const BaseCard = ({
  title,
  additionalHeader,
  children,
  expandContent,
}: BaseCardProps) => {
  const [open, setOpen] = useState(false);

  const toggleCollapsible = () => {
    setOpen((prevState) => !prevState);
  };

  const contentRef = useRef<HTMLDivElement>(null);

  return (
    <Card
      className={clsx(
        "w-full shadow-none px-6 bg-white rounded-md border-1 border-gray-200",
      )}
    >
      <CardHeader className="flex flex-row items-center justify-between px-0">
        <div className="flex flex-row gap-4 items-center">
          <h3 className="text-sm font-bold">{title}</h3>
          {additionalHeader}
        </div>
        {expandContent && (
          <Button
            variant="flat"
            className="text-gsfs-blue-900 rounded-full bg-transparent hover:bg-gray-100"
            onClick={toggleCollapsible}
          >
            {open ? "Close" : "View All Checks"}
          </Button>
        )}
      </CardHeader>
      {children && <Divider className="bg-gray-200 h-[2px]" />}
      {children}
      <div
        ref={contentRef}
        className="transition-[height] ease-in-out duration-400"
        style={{
          height: open ? contentRef.current?.scrollHeight : 0,
          overflow: open ? "auto" : "hidden",
        }}
      >
        {expandContent}
      </div>
    </Card>
  );
};

export default BaseCard;
