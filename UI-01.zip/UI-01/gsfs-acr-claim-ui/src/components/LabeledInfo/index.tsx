export { default } from "./LabeledInfo";
