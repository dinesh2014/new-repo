// index.test.tsx
import LabeledInfo from './LabeledInfo';
import DefaultExport from './index';

describe('index.tsx', () => {
  test('should re-export LabeledInfo as default', () => {
    expect(DefaultExport).toBe(LabeledInfo);
  });
});