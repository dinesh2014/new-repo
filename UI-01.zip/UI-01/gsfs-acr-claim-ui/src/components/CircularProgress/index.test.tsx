import CircularProgress from "./CircularProgress";
import * as index from "./index";

describe("index.tsx", () => {
  it("should re-export CircularProgress as default", () => {
    expect(index.default).toBe(CircularProgress);
  });
});