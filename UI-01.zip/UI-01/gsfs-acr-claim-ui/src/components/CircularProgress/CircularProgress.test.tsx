import { describe, it, expect, afterEach } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";

import CircularProgress from "./CircularProgress";

describe("CircularProgress component", () => {
  afterEach(() => {
    cleanup();
  });
    
  it("Should render CircularProgress component", () => {
    render(<CircularProgress leftAmount={3} rightAmount={0} />);
    
    const leftAmount = screen.getByText("3");
    const rightAmount = screen.getByText("0");
    
    expect(leftAmount).toBeInTheDocument();
    expect(rightAmount).toBeInTheDocument();
  });

  it("Should render CircularProgress component with right amount in red", () => {
    render(<CircularProgress leftAmount={3} rightAmount={2} />);
    
    const leftAmount = screen.getByText("3");
    const rightAmount = screen.getByText("2");
    
    expect(leftAmount).toBeInTheDocument();
    expect(rightAmount).toBeInTheDocument();
    expect(rightAmount).toHaveClass("text-red-600");
  });

  it("Should render CircularProgress with different size", () => {
    render(<CircularProgress leftAmount={3} rightAmount={0} size={100} />);
    
    const svg = screen.getByTestId("svg");
    
    expect(svg).toHaveAttribute("width", "100");
    expect(svg).toHaveAttribute("height", "100");
  });

  it("Should render CircularProgress with different stroke width", () => {
    render(<CircularProgress leftAmount={3} rightAmount={0} strokeWidth={8} />);
    
    const leftCircle = screen.getByTestId("left-circle");
    
    expect(leftCircle).toHaveAttribute("stroke-width", "8");
  });
});