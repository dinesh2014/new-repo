import { describe, it, expect, afterEach } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";

import FeedbackModal, { FeedbackModalProps } from "./FeedbackModal";

describe("FeedbackModal component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Should render FeedbackModal component", () => {
    const props: FeedbackModalProps = {
      claimNumber: "TEST10101",
      isPending: false,
      isOpen: true,
      isSuccess: false,
      onClose: () => {},
      onOpenChange: () => {},
      onSubmit: () => {},
      iproduct_type_id: 8,
    };

    render(<FeedbackModal {...props} />);

    const modalHeader = screen.getByTestId("feedback_modal__header");

    expect(modalHeader).toBeInTheDocument();
  });

  it("Should change submit button text/disable it", () => {
    const props: FeedbackModalProps = {
      claimNumber: "TEST10101",
      isPending: true,
      isOpen: true,
      isSuccess: false,
      onClose: () => {},
      onOpenChange: () => {},
      onSubmit: () => {},
      iproduct_type_id: 8,
    };

    render(<FeedbackModal {...props} />);
    const submitButton = screen.getByTestId("feedback_modal__submit_button");

    expect(submitButton.textContent).toBe("Submitting...");
    expect(submitButton.ariaDisabled).toBe("true");
  });
});
