/**
 * Props for the CustomDivider component.
 */
interface CustomDividerProps {
  vertical?: boolean;
  width?: 0.5 | 1 | 1.5 | 2 | 2.5 | 3 | 3.5 | 4 | 5 | 6 | 7 | 8;
  paddingX?: number;
  paddingY?: number;
  color?: "blue" | "red" | "gray";
}

/**
 * CustomDivider component.
 *
 * @component
 * @param {CustomDividerProps} props - The component props.
 * @param {boolean} [props.vertical=false] - Whether the divider should be vertical.
 * @param {number} [props.width=1] - The width of the divider.
 * @param {number} [props.paddingX=0] - The horizontal padding of the divider.
 * @param {number} [props.paddingY=0] - The vertical padding of the divider.
 * @param {string} [props.color="blue"] - The color of the divider. Possible values: "blue", "red", "gray".
 * @returns {JSX.Element} The rendered CustomDivider component.
 */
const CustomDivider = ({
  vertical = false,
  width = 1,
  paddingX = 0,
  paddingY = 0,
  color = "blue",
}: CustomDividerProps) => {
  const colorMap = {
    blue: "bg-gsfs-blue-800 dark:bg-gsfs-blue-400",
    red: "bg-red-600 dark:bg-red-300",
    gray: "bg-gray-400 dark:bg-gray-200",
  };
  const baseClasses = "flex shrink-0";
  const colorClasses = colorMap[color] ?? "";
  const paddingClasses = `px-${paddingX} py-${paddingY}`;
  const dinamicClasses = vertical ? `h-100 w-${width}` : `w-full h-${width}`;

  return (
    <div
      className={`${baseClasses} ${colorClasses} ${paddingClasses} ${dinamicClasses}`}
    ></div>
  );
};

export default CustomDivider;
