// CustomDivider.test.tsx
import React from 'react';
import { render } from '@testing-library/react';
import CustomDivider from './CustomDivider';

describe('CustomDivider', () => {
  test('renders with default props', () => {
    const { container } = render(<CustomDivider />);
    const divider = container.firstChild;
    expect(divider).toHaveClass('flex shrink-0 bg-gsfs-blue-800 dark:bg-gsfs-blue-400 px-0 py-0 w-full h-1');
  });

  test('renders with vertical prop', () => {
    const { container } = render(<CustomDivider vertical />);
    const divider = container.firstChild;
    expect(divider).toHaveClass('flex shrink-0 bg-gsfs-blue-800 dark:bg-gsfs-blue-400 px-0 py-0 h-100 w-1');
  });

  test('renders with custom width', () => {
    const { container } = render(<CustomDivider width={2} />);
    const divider = container.firstChild;
    expect(divider).toHaveClass('flex shrink-0 bg-gsfs-blue-800 dark:bg-gsfs-blue-400 px-0 py-0 w-full h-2');
  });

  test('renders with custom paddingX and paddingY', () => {
    const { container } = render(<CustomDivider paddingX={2} paddingY={3} />);
    const divider = container.firstChild;
    expect(divider).toHaveClass('flex shrink-0 bg-gsfs-blue-800 dark:bg-gsfs-blue-400 px-2 py-3 w-full h-1');
  });

  test('renders with custom color', () => {
    const { container } = render(<CustomDivider color="red" />);
    const divider = container.firstChild;
    expect(divider).toHaveClass('flex shrink-0 bg-red-600 dark:bg-red-300 px-0 py-0 w-full h-1');
  });

  test('renders with all custom props', () => {
    const { container } = render(<CustomDivider vertical width={3} paddingX={1} paddingY={1} color="gray" />);
    const divider = container.firstChild;
    expect(divider).toHaveClass('flex shrink-0 bg-gray-400 dark:bg-gray-200 px-1 py-1 h-100 w-3');
  });
});