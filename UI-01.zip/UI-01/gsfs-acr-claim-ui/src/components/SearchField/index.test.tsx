import SearchField from './SearchField';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export SearchField as default', () => {
    expect(DefaultExport).toBe(SearchField);
  });
});