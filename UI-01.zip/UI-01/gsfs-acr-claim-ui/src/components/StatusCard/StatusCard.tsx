import { FaCheck, FaExclamation, FaXmark } from "react-icons/fa6";

/**
 * Props for the StatusCard component.
 */
interface StatusCardProps {
  label: string;
  status: "warning" | "danger" | "success";
  statusText: string;
  displayIcon: boolean;
}

/**
 * Renders a status card component.
 *
 * @component
 * @param {StatusCardProps} props - The component props.
 * @param {string} props.label - The label for the status card.
 * @param {string} props.status - The status of the card (success, warning, danger).
 * @param {string} props.statusText - The text to display as the status.
 * @param {boolean} props.displayIcon - Whether to display an icon based on the status.
 * @returns {JSX.Element} The rendered status card component.
 */
const StatusCard = ({
  label,
  status,
  statusText,
  displayIcon,
}: StatusCardProps) => {
  const getStatusColor = () => {
    switch (status) {
    case "success":
      return "bg-green-500";
    case "warning":
      return "bg-sky-500";
    case "danger":
      return "bg-red-600";
    default:
      return "";
    }
  };

  const getStatusIcon = () => {
    switch (status) {
    case "success":
      return <FaCheck data-testid="FaCheck" className="text-white text-xs flex" />;
    case "warning":
      return <FaExclamation data-testid="FaExclamation" className="text-white text-xs flex" />;
    case "danger":
      return <FaXmark data-testid="FaXmark" className="text-white text-xs flex" />;
    default:
      return null;
    }
  };

  return (
    <div className="rounded-md bg-gsfs-sky-900 p-4 content-center">
      <div className="flex flex-col h-full">
        <div className="h-1/2 text-white font-thin text-sm text-balance content-end">
          {label}
        </div>
        <div className="flex flex-row gap-2 items-center">
          <div
            data-testid="status-icon"
            className={`w-4 h-4 flex items-center justify-center rounded-full ${getStatusColor()} text-white font-extralight`}
          >
            {displayIcon && getStatusIcon()}
          </div>
          <div className="text-white text-xl">{statusText}</div>
        </div>
      </div>
    </div>
  );
};

export default StatusCard;
