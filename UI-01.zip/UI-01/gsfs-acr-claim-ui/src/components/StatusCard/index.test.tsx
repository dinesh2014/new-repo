import StatusCard from './StatusCard';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export StatusCard as default', () => {
    expect(DefaultExport).toBe(StatusCard);
  });
});