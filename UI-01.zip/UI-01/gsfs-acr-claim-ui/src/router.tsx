import { HashRouter, Route, Routes } from "react-router-dom";
import ClaimDetails from "./pages/ClaimDetails";
import Home from "./pages/Home";

/**
 * Array of route objects.
 * Each route object contains a path and an element component.
 */
const appRoutes = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/claim-details/:claimNumber",
    element: <ClaimDetails />,
  },
];

/**
 * Renders the router component for handling navigation within the application.
 * @returns The router component.
 */
export default function Router() {
  return (
    <HashRouter>
      <Routes>
        {appRoutes.map((route, index) => (
          <Route
            key={`${route.path}-${index}`}
            path={route.path}
            element={route.element}
          />
        ))}
      </Routes>
    </HashRouter>
  );
}
