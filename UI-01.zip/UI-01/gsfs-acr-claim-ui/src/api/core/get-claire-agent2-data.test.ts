import axios from "axios";
import { describe, it, expect, vi } from "vitest";
import { getClaireAgent2Data, Agent2Props } from "./get-claire-agent2-data";
import Globals from "../../globals";


vi.mock("axios");
const mockedAxios = axios.get as jest.Mock

describe("getClaireAgent2Data", () => {
  const claimNumber = "12345";
  const mockResponse: Agent2Props = {
    id: 1,
    claim_number: claimNumber,
    claim_event_part_details: [
      {
        claim_event_part_details_id: 1,
        part_description: "Part A",
        part_number: "A123",
        part_price: 100,
        prediction_id: 1,
        follow_up_questions_for_customer: ["Question 1"],
        follow_up_questions_for_technician: ["Question 2"],
        recommendation: "Recommendation",
        contractual_section: "Section A",
        contractual_section_confidence_score: 0.9,
        is_feedback_thumbs_up: true,
        user_feedback_text: "Feedback",
        is_deleted: false,
      },
    ],
  };

  it("should resolve with the correct data", async () => {
    mockedAxios.mockResolvedValue({ data: mockResponse });

    const result = await getClaireAgent2Data(claimNumber);
    expect(result).toEqual(mockResponse);
    expect(mockedAxios).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/agent2/${claimNumber}`);
  });

  it("should reject with an error message", async () => {
    const errorMessage = "Network Error";
    mockedAxios.mockRejectedValue(new Error(errorMessage));

    await expect(getClaireAgent2Data(claimNumber)).rejects.toThrow(errorMessage);
    expect(mockedAxios).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/agent2/${claimNumber}`);
  });
});