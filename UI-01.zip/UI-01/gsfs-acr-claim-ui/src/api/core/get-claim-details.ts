import axios from "axios";
import Globals from "../../globals";

/**
 * Represents a reminder object.
 */
export interface ClaimReminderProps {
  id: number;
  sclaim_number: string;
  scontract_no: string;
  texts: [];
  job_status_id: number;
  created_at: string;
}

/**
 * Represents a history object.
 */
export type ClaimHistoryProps = {
  id: number;
  sclaim_number: string;
  sclaim_status: string;
  scontract_no: string;
  sloss_code: number;
  sdetail_type: string | null;
  sdetail_desc: string;
  camt_paid: number;
  dtpaid: string;
  job_status_id: number;
  created_at: string;
};

/**
 * Represents a breakdown loss codes object.
 */
export interface ClaimBreakdownLossCodesProps {
  sloss_code: number;
  iproduct_type_id: number;
  sdetail_desc: string;
  breakdown_propensity: number;
  breakdown_propensity_flag?: number;
  breakdown_propensity_threshold: number;
  breakdown_risk_tier: number;
}

/**
 * Represents a breakdown parts object.
 */
export interface ClaimBreakdownPartsProps {
  sloss_code: number;
  spart_no: string;
  spart_desc: string;
  iproduct_type_id: number;
  breakdown_part_freq: number;
}

/**
 * Represents a parts details object.
 */
export interface PartsProps {
  spart_no: string;
  spart_desc: string;
  iproduct_type_id: number;
  part_price: number;
  part_price_deviation_benchmark: number;
  part_price_deviation_flag: number;
  part_price_variation_benchmark: number;
  part_price_variation_flag?: number;
  part_price_prediction: number;
  part_price_prediction_benchmark: number;
  part_price_prediction_flag?: number;
}

/**
 * Represents a cost parts object.
 */
export interface ClaimCostPartsProps {
  sloss_code: number;
  sdetail_desc: string;
  parts: PartsProps[];
}

/**
 * Represents a cost labor or cost M&B object.
 */
export interface ClaimCostLaborProps {
  sloss_code: number;
  spart_no: string;
  spart_desc: string;
  iproduct_type_id: number;
  sdetail_desc: string;
  labor_hours_prediction: number;
  labor_hours_prediction_flag?: number;
  labor_hours_req: number;
  labor_rate: number;
  labor_rate_deviation_benchmark: number;
  labor_rate_deviation_flag?: number;
  labor_rate_variation_benchmark: number;
  labor_rate_variation_flag?: number;
  mb_deviation: number;
  mb_deviation_benchmark: number;
  mb_deviation_flag?: number;
  mb_prediction: number;
  mb_prediction_benchmark: number;
  mb_prediction_flag?: number;
}

/**
 * Represents the props for the full data of a claim request.
 */
export interface ClaimDetailsProps {
  claim: ClaimProps;
  reminders: ClaimReminderProps[];
  claim_history: ClaimHistoryProps[];
  breakdown_loss_codes: ClaimBreakdownLossCodesProps[];
  breakdown_parts: ClaimBreakdownPartsProps[];
  cost_parts: { string: ClaimCostPartsProps }[];
  cost_labor: ClaimCostLaborProps[];
}

/**
 * Represents the properties and details of a claim.
 */
export interface ClaimProps {
  [key: string]: any;
}

/**
 * Retrieves the details of a claim.
 *
 * @param claimNumber - The claim number.
 * @returns A promise that resolves to the claim details.
 */
export const getClaimDetails = (
  claimNumber: string,
): Promise<ClaimDetailsProps> => {
  return new Promise((resolve, reject) => {
    axios
      .get(`${Globals.apiURL}/v1/claims/${claimNumber}`)
      .then((res) => {
        resolve(res.data);
      })
      .catch((error) => {
        reject( new Error(error.message ?? error));
      });
  });
};
