import axios from "axios";
import { postFeedback, FeedbackDataProps } from "./post-claire-feedback";
import Globals from "../../globals";
import { describe, it, expect, vi } from "vitest";


vi.mock("axios");
const mockedAxios = axios.post as jest.Mock;

describe("postFeedback", () => {
  const feedbackData: FeedbackDataProps = {
    prediction_id: 1,
    agent_type: 2,
    is_feedback_thumbs_up: true,
    user_feedback_text: "Great prediction!",
  };

  const mockResponse = ["Feedback received"];

  it("should resolve with the correct data", async () => {
    mockedAxios.mockResolvedValue({ data: mockResponse });

    const result = await postFeedback(feedbackData);
    expect(result).toEqual(mockResponse);
    expect(mockedAxios).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/feedback`, feedbackData);
  });

  it("should reject with an error message", async () => {
    const errorMessage = "Network Error";
    mockedAxios.mockRejectedValue(new Error(errorMessage));

    await expect(postFeedback(feedbackData)).rejects.toThrow(errorMessage);
    expect(mockedAxios).toHaveBeenCalledWith(`${Globals.apiURL}/v1/genai/feedback`, feedbackData);
  });
});