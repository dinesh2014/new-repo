/**
 * Props for the SectionHeader component.
 */
interface SectionHeaderProps {
  title: string;
}

/**
 * Renders a section header with a given title.
 *
 * @component
 * @param {SectionHeaderProps} props - The component props.
 * @param {string} props.title - The title of the section.
 * @returns {JSX.Element} The rendered section header.
 */
const SectionHeader = ({ title }: SectionHeaderProps) => {
  return (
    <div className="flex flex-row pb-4 px-2">
      <div className="font-semibold text-sm uppercase">{title}</div>
    </div>
  );
};

export default SectionHeader;
