import { Chip } from "@nextui-org/react";

import BaseCard from "../../../components/BaseCard";
import Section from "../../../layouts/Section";
import SectionHeader from "./SectionHeader";
import Table from "./Table";
import { ClaimHistoryProps } from "../../../api/core/get-claim-details";

/**
 * Represents the props for the History component.
 */
interface HistoryProps {
  history?: ClaimHistoryProps[];
  isLoading?: boolean;
}

/**
 * Renders the history section of the claim details page.
 *
 * @param {HistoryProps} props - The component props.
 * @param {ClaimHistoryProps[]} props.history - The array of claim history objects.
 * @param {boolean} props.isLoading - Indicates whether the history is currently being loaded.
 * @returns {JSX.Element} The rendered history section.
 */
const History = ({ history, isLoading = false }: HistoryProps) => {
  return (
    <Section header={<SectionHeader title="History" />}>
      {isLoading ? (
        <Section
          id="loading-box"
          bordered
          paddingX={6}
          paddingY={4}
        >
          <div className="animate-pulse">Loading table...</div>
        </Section>
      ) : (
        <BaseCard
          title="Claims History"
          additionalHeader={
            <Chip
              size="sm"
              classNames={{
                base: "bg-gsfs-blue-900 dark:bg-gsfs-blue-400 dark:text-gsfs-blue-900",
              }}
              color="primary"
            >
              {history?.length ?? 0}
            </Chip>
          }
        >
          {history && (
            <div className="pb-8 pt-4">
              <Table history={history} />
            </div>
          )}
        </BaseCard>
      )}
    </Section>
  );
};

export default History;
