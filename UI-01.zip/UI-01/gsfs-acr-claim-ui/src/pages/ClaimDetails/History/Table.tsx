import {
  Table as NextTable,
  TableHeader,
  TableColumn,
  TableBody,
  TableRow,
  TableCell,
  getKeyValue,
} from "@nextui-org/react";
import { ClaimHistoryProps } from "../../../api/core/get-claim-details";
import { historyTableColumns } from "../../../utils/constants";

/**
 * Props for the Table component.
 */
interface TableProps {
  history: ClaimHistoryProps[];
}

/**
 * Renders a table component with the provided history data.
 *
 * @param {TableProps} props - The component props.
 * @param {ClaimHistoryProps[]} props.history - The history data to be displayed in the table.
 * @returns {JSX.Element} The rendered table component.
 */
export default function Table({ history }: Readonly<TableProps>) {
  return (
    <NextTable
      removeWrapper
      aria-label="Collection table"
      classNames={{
        th: ["bg-transparent", "font-light", "text-sm"],
        td: ["text-lg"],
        tr: ["even:bg-sky-50"],
      }}
    >
      <TableHeader columns={historyTableColumns}>
        {(column) => <TableColumn key={column.key}>{column.label}</TableColumn>}
      </TableHeader>
      <TableBody items={history}>
        {(item) => (
          <TableRow key={item.id}>
            {(columnKey) => (
              <TableCell>{getKeyValue(item, columnKey)}</TableCell>
            )}
          </TableRow>
        )}
      </TableBody>
    </NextTable>
  );
}
