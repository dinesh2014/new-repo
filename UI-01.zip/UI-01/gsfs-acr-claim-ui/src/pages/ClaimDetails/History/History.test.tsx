import { render, screen } from '@testing-library/react';
import History from './History';
import { ClaimHistoryProps } from '../../../api/core/get-claim-details';

describe('History', () => {
  const mockHistory: ClaimHistoryProps[] = [
    {
      id:1,sclaim_number: '1234',sclaim_status: 'open',scontract_no: '462589',sloss_code: 237689,sdetail_type:null,sdetail_desc: "description",camt_paid:34,dtpaid: '07-02-1989',job_status_id: 987678,created_at: '09-08-2023'
    }
  ];

  it('renders loading state', () => {
    render(<History isLoading={true} />);
    expect(screen.getByText('Loading table...')).toBeInTheDocument();
  });

  it('renders history section with claims', () => {
    render(<History history={mockHistory} />);
    expect(screen.getByText('History')).toBeInTheDocument();
    expect(screen.getByText('Claims History')).toBeInTheDocument();
  });

  it('renders history section with no claims', () => {
    render(<History history={[]} />);
    expect(screen.getByText('History')).toBeInTheDocument();
    expect(screen.getByText('Claims History')).toBeInTheDocument();
  });
});