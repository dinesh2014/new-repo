import Financial from './Financial';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export the default export from Financial.tsx', () => {
    expect(DefaultExport).toBe(Financial);
  });
});