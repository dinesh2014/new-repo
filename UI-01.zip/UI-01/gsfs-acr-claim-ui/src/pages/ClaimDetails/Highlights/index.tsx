export { default } from "./Highlights";
