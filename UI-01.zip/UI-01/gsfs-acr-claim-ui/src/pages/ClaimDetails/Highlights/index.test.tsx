import Highlights from './Highlights';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export the default export from Highlights.tsx', () => {
    expect(DefaultExport).toBe(Highlights);
  });
});