
import { render, screen } from '@testing-library/react';
import SectionHeader from './SectionHeader';

describe('SectionHeader Component', () => {
  it('should render the title', () => {
    render(<SectionHeader title="Test Title" />);
    expect(screen.getByText('Test Title')).toBeInTheDocument();
  });

  it('should render customer complaints flag ', () => {
    render(<SectionHeader title="Test Title" customerComplaints={1} />);
    expect(screen.getByText('Customer Complaints')).toBeInTheDocument();
  });

  it('should render technician found flag', () => {
    render(<SectionHeader title="Test Title" technicianFound={1} />);
    expect(screen.getByText('Technician Found')).toBeInTheDocument();
  });
});