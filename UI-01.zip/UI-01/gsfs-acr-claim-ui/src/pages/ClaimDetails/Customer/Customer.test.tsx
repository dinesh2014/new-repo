// Customer.test.tsx
import React from 'react';
import { render, screen } from '@testing-library/react';
import Customer from './Customer';
import { ClaimProps } from '../../../api/core/get-claim-details';

describe('Customer Component', () => {
  const mockClaim: ClaimProps = {
    smake: 'Toyota',
    smodel: 'Camry',
    strim: 'LE',
    imodel_year: 2020,
    scontract_holder_fname: 'John',
    scontract_holder_lname: 'Doe',
    dtcontract_expiration: '2023-12-31',
    pre_tenure_period: 30,
    miles_to_expiration: 10000,
    days_since_sales: 365,
    iodometer_at_time_of_loss: 15000,
  };

  it('should display loading state', () => {
    render(<Customer isLoading={true} />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('should display car details', () => {
    render(<Customer claim={mockClaim} isLoading={false} />);
    expect(screen.getByText('Make')).toBeInTheDocument();
    expect(screen.getByText('Toyota')).toBeInTheDocument();
    expect(screen.getByText('Model')).toBeInTheDocument();
    expect(screen.getByText('Camry')).toBeInTheDocument();
    expect(screen.getByText('Trim')).toBeInTheDocument();
    expect(screen.getByText('LE')).toBeInTheDocument();
    expect(screen.getByText('Year')).toBeInTheDocument();
    expect(screen.getByText('2020')).toBeInTheDocument();
    expect(screen.getByText('Customer')).toBeInTheDocument();
    expect(screen.getByText('John Doe')).toBeInTheDocument();
  });

  it('should display contract details', () => {
    render(<Customer claim={mockClaim} isLoading={false} />);
    expect(screen.getByText('Contract Exp Date')).toBeInTheDocument();
    expect(screen.getByText('2023-12-31')).toBeInTheDocument();
    expect(screen.getByText('Days to Exp')).toBeInTheDocument();
    expect(screen.getByText('30')).toBeInTheDocument();
    expect(screen.getByText('Miles to Exp')).toBeInTheDocument();
    expect(screen.getByText('10,000')).toBeInTheDocument();
    expect(screen.getByText('Days Since Sale')).toBeInTheDocument();
    expect(screen.getByText('365')).toBeInTheDocument();
    expect(screen.getByText('Miles Since Sale')).toBeInTheDocument();
    expect(screen.getByText('15,000')).toBeInTheDocument();
  });
});