import Customer from './Customer';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export the default export from Customer.tsx', () => {
    expect(DefaultExport).toBe(Customer);
  });
});