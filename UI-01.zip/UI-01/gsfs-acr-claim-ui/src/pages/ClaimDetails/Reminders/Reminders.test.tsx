import React from 'react';
import { render, screen } from '@testing-library/react';
import Reminders from './Reminders';
import { ClaimReminderProps } from '../../../api/core/get-claim-details';
import { describe, it, expect, vi } from "vitest";

describe('Reminders', () => {
  const mockReminders: ClaimReminderProps[] = [
    { id: 1, texts: ['Reminder 1', 'Reminder 2'] },
    { id: 2, texts: ['Reminder 3'] },
  ];

  it('renders loading state', () => {
    render(<Reminders isLoading={true} />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('renders reminders section with no reminders', () => {
    render(<Reminders reminders={[]} />);
    expect(screen.queryByText('Reminders')).not.toBeInTheDocument();
  });

});