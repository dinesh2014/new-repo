import Reminders from './Reminders';
import Index from './index';

describe('index.tsx', () => {
  it('should re-export Reminders as default', () => {
    expect(Index).toBe(Reminders);
  });
});