import React from 'react';
import { render, screen } from '@testing-library/react';
import ReminderTag from './ReminderTag';

describe('ReminderTag', () => {
  it('renders the reminder tag with the correct text', () => {
    const text = 'Test Reminder';
    render(<ReminderTag text={text} />);
    expect(screen.getByText(text)).toBeInTheDocument();
  });
  });
