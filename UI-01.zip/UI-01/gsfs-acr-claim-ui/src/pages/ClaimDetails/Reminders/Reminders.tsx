import ReminderTag from "./ReminderTag";
import Section from "../../../layouts/Section";
import CustomDivider from "../../../components/CustomDivider";
import { ClaimReminderProps } from "../../../api/core/get-claim-details";

/**
 * Represents the props for the Reminders component.
 */
interface RemindersProps {
  reminders?: ClaimReminderProps[];
  isLoading?: boolean;
}

/**
 * Renders a list of reminders.
 *
 * @component
 * @param {RemindersProps} props - The component props.
 * @param {ClaimRemindersProps[]} props.reminders - The list of reminders.
 * @param {boolean} [props.isLoading=false] - Indicates whether the reminders are currently being loaded.
 * @returns {JSX.Element|null} The rendered component.
 */
const Reminders = ({ reminders, isLoading = false }: RemindersProps) => {
  const usedTexts: string[] = [];
  if (!isLoading && reminders?.length === 0) {
    return null;
  } else {
    return (
      <Section
        id="reminders"
        paddingX={2}
      >
        <div className="flex flex-row py-2 gap-4">
          <div className="flex items-center font-semibold text-lg">
            Reminders
          </div>
          <CustomDivider
            vertical
            color="red"
          />
          {isLoading ? (
            <div className="animate-pulse">Loading...</div>
          ) : (
            <div className="flex flex-row flex-wrap gap-3">
              {reminders?.map((item) =>
                item?.texts?.map((text) => {
                  if (
                    !usedTexts.includes(text) &&
                    text !== "" &&
                    text !== "None"
                  ) {
                    usedTexts.push(text); // Add text to usedTexts array to avoid duplicated reminders
                    return (
                      <ReminderTag
                        key={item.id + text}
                        text={text}
                      />
                    );
                  }
                }),
              )}
            </div>
          )}
        </div>
      </Section>
    );
  }
};

export default Reminders;
