import Feedback from './Feedback';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export the default export from Feedback.tsx', () => {
    expect(DefaultExport).toBe(Feedback);
  });
});