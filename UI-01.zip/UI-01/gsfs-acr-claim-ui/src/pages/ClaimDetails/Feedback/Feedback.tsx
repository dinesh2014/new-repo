import { useEffect } from "react";
import { Button, useDisclosure } from "@nextui-org/react";
import { FaRegThumbsUp, FaRegThumbsDown } from "react-icons/fa6";
import { useMutation } from "@tanstack/react-query";
import { toast } from "react-toastify";
import { usePostHog } from "posthog-js/react";

import {
  FeedbackDataProps,
  postFeedback,
} from "../../../api/core/post-feedback";
import Globals from "../../../globals";

import FeedbackModal from "../../../components/FeedbackModal";

/**
 * Props for the Feedback component.
 */
export interface FeedbackProps {
  claimNumber: string;
  placement: string;
  iproduct_type_id: number;
}

/**
 * Represents the Feedback component.
 *
 * @component
 * @param {FeedbackProps} props - The component props.
 * @param {string} props.claimNumber - The claim number.
 * @param {string} props.placement - The placement.
 * @param {number} props.iproduct_type_id - The product associated with the claim.
 * @returns {JSX.Element} - The rendered Feedback component.
 */
const Feedback = ({
  claimNumber,
  placement,
  iproduct_type_id,
}: FeedbackProps) => {
  const posthog = usePostHog();
  const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

  const mutation = useMutation({
    mutationFn: (feedbackData: FeedbackDataProps) => postFeedback(feedbackData),
  });

  const submitFeedback = (finalFeedbackData: FeedbackDataProps) => {
    mutation.mutate(finalFeedbackData);
    posthog.capture("feedback_submit", {
      claim_number: claimNumber,
      placement: placement,
      feedback_rating: finalFeedbackData.thumbs_up_flag
        ? "positive"
        : "negative",
    });
  };

  const positiveFeedbackDefaultData = {
    user_email: Globals.user || "undefined@email.com",
    thumbs_up_flag: true,
    thumbs_down_flag: false,
    feedback_type_1: "Coverage checks",
    feedback_text_1: "",
    feedback_type_2: "Dealer checks",
    feedback_text_2: "",
    feedback_type_3: "Customer checks",
    feedback_text_3: "",
    feedback_type_4: "Breakdown checks",
    feedback_text_4: "",
    feedback_type_5: "Cost checks",
    feedback_text_5: "",
  };

  const notify = (
    type: "success" | "error" | "warn" | "info",
    msg?: string,
  ) => {
    type === "success" && toast.success(msg ?? "Success!", {});

    type === "error" &&
      toast.error(msg ?? "Something went wrong. Try again later.", {});

    type === "warn" && toast.warn(msg ?? "Warning!", {});

    type === "info" && toast.info(msg ?? "Info!", {});
  };

  useEffect(() => {
    if (mutation.isSuccess) {
      notify("success", "Feedback saved!");
    }
    if (mutation.isError) {
      notify("error", "Something went wrong. Please, try again later.");
    }
  }, [mutation.isSuccess, mutation.isError]);

  return (
    <>
      <div  data-testid="feedback-component" className="grid grid-flow-col gap-3">
        <div>
          <Button
            isIconOnly
            data-testid="feedback_button_thumbsUp"
            aria-label="approve claim"
            className={
              mutation.isPending
                ? "rounded-full bg-green-500 shadow-lg animate-pulse"
                : "rounded-full bg-gsfs-blue-800 shadow-lg"
            }
            onClick={() =>
              submitFeedback({
                ...positiveFeedbackDefaultData,
                claim_id: claimNumber,
              })
            }
          >
            <FaRegThumbsUp className="text-white text-xl " />
          </Button>
        </div>
        <div>
          <Button
            isIconOnly
            aria-label="deny claim"
            data-testid="feedback_button_thumbsDown"
            className="rounded-full bg-red-600 shadow-lg"
            onClick={() => onOpen()}
          >
            <FaRegThumbsDown className="text-white text-xl" />
          </Button>
        </div>
      </div>
      <FeedbackModal
        isOpen={isOpen}
        onClose={onClose}
        onOpenChange={onOpenChange}
        isPending={mutation.isPending}
        isSuccess={mutation.isSuccess}
        onSubmit={submitFeedback}
        claimNumber={claimNumber || ""}
        iproduct_type_id={iproduct_type_id}
      />
    </>
  );
};

export default Feedback;
