import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { getClaims } from "../../api/core/get-claims";
import SideBar from "../../components/SideBar/SideBar";
import SideNav from "../../components/SideNav";
import General from "../../layouts/General/General";
import SearchField from "../../components/SearchField";
import { Snippet } from "@nextui-org/react";

/**
 * Renders the Home page component.
 *
 * @returns The rendered Home page component.
 */
const Home = () => {
  const { data, isSuccess, isLoading } = useQuery<string[]>({
    queryKey: ["claims"],
    queryFn: getClaims,
  });

  const [open, setOpen] = useState(false);

  const onCloseSideBar = () => {
    setOpen(false);
  };

  return (
    <>
      <General isLoading={isLoading}>
        <div className="grid grid-cols-1 h-full justify-center gap-8 pt-[50px]">
          <div className="w-[500px]">
            <SearchField isLoading={isLoading} />
          </div>

          <div className="grid grid-cols-1 gap-4 place-items-center">
            {/* <Button
              className="h-36 w-36 p-5 border-slate-300 dark:border-slate-500 border-1 rounded-lg bg-gray-100 hover:bg-gray-300 text-gray-700 dark:bg-gray-300 dark:hover:bg-gray-100 dark:text-gray-700 dark:hover:text-gray-400 grid place-items-center text-center"
              onClick={toggleSideBar}
            >
              Sidebar
            </Button> */}

            {isLoading ? (
              <div className="animate-pulse">
                Loading auxiliary claims list...
              </div>
            ) : (
              <>
                <p>Available claims number</p>
                <div className="grid grid-cols-3 gap-4">
                  {isSuccess &&
                    Array.isArray(data) &&
                    [...new Set(data.map((claim: string) => claim.trim()))].map(
                      (claim: string, index: number) => (
                        <Snippet
                          key={`${claim}-${index}`}
                          classNames={{
                            base: "rounded-full px-2",
                            pre: "ps-2",
                          }}
                          size="sm"
                          variant="bordered"
                          color="default"
                          symbol=""
                        >
                          <span>{claim}</span>
                        </Snippet>
                      ),
                    )}
                </div>
              </>
            )}
          </div>
        </div>
      </General>

      <SideBar
        open={open}
        onClose={onCloseSideBar}
      >
        <SideNav />
      </SideBar>
    </>
  );
};

export default Home;
