/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Represents the global configuration for the application.
 */
declare const window: Window &
  typeof globalThis & {
    dataLayer: any[];
  };

/**
 * Sets up the global configuration by determining the API URL, PostHog variables, and user information.
 * @returns An object containing the API URL, PostHog key, PostHog host, and user email.
 */
const setup = () => {
  let basename = document.location.pathname || "/";
  if (!basename.endsWith("/")) basename += "/";

  const apiURL = import.meta.env.VITE_CLAIM_API_URL || basename + "api";

  // adding posthog variables to Globals configuration

  let pubPostHogKey;
  let pubPostHogHost;

  if (
    process.env.NODE_ENV == "development" &&
    (document.location.hostname === "localhost" ||
      document.location.hostname === "127.0.0.1")
  ) {
    pubPostHogKey = import.meta.env.VITE_PUBLIC_POSTHOG_KEY;
    pubPostHogHost = import.meta.env.VITE_PUBLIC_POSTHOG_HOST;
  } else {
    pubPostHogKey = (window.dataLayer || []).find(
      (x: any) => x["pubPostHogKey"],
    );
    pubPostHogHost = (window.dataLayer || []).find(
      (x: any) => x["pubPostHogHost"],
    );
  }

  // adding user to Globals configuration
  let user = window.dataLayer?.find((x: any) => x["user-email"]);
  if (user?.["user-email"]) user = user["user-email"];

  return { apiURL, pubPostHogKey, pubPostHogHost, user };
};

/**
 * The global configuration object.
 */
const Globals = setup();

export default Globals;
