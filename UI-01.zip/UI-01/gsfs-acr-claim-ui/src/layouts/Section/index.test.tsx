import Section from './Section';
import DefaultExport from './index';

describe('index.tsx', () => {
  it('should re-export Section as default', () => {
    expect(DefaultExport).toBe(Section);
  });
});