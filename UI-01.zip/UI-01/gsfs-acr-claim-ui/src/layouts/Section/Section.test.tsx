// Section.test.tsx
import React from 'react';
import { render } from '@testing-library/react';
import Section from './Section';

describe('Section Component', () => {
  it('renders without crashing', () => {
    const { container } = render(<Section />);
    expect(container).toBeInTheDocument();
  });

  it('applies default props correctly', () => {
    const { container } = render(<Section />);
    expect(container.firstChild).toHaveClass('px-0 py-0');
    expect(container.firstChild).not.toHaveClass('bg-white rounded-md border-1 border-gray-200');
  });

  it('applies custom padding correctly', () => {
    const { container } = render(<Section paddingX={4} paddingY={2} />);
    expect(container.firstChild).toHaveClass('px-4 py-2');
  });

  it('applies border class when bordered is true', () => {
    const { container } = render(<Section bordered />);
    expect(container.firstChild).toHaveClass('bg-white rounded-md border-1 border-gray-200');
  });

  it('renders header and children correctly', () => {
    const { getByText } = render(
      <Section header={<h1>Header</h1>}>
        <p>Child content</p>
      </Section>
    );
    expect(getByText('Header')).toBeInTheDocument();
    expect(getByText('Child content')).toBeInTheDocument();
  });

  it('applies id correctly', () => {
    const { container } = render(<Section id="test-id" />);
    expect(container.firstChild).toHaveAttribute('id', 'test-id');
  });
});