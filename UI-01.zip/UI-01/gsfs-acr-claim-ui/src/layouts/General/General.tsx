import NavBar from "../../components/NavBar/NavBar";
import Claire from "../../components/Claire";

/**
 * Props for the General layout component.
 */
type GeneralProps = {
  children?: React.ReactNode;
  isLoading?: boolean;
};

/**
 * Represents the General layout component.
 * This component provides a general layout structure for the application.
 *
 * @component
 * @param {GeneralProps} props - The component props.
 * @param {React.ReactNode} [props.children] - The children elements to be rendered inside the layout.
 * @param {boolean} [props.isLoading=false] - Specifies whether the layout is in a loading state.
 * @returns {JSX.Element} The rendered General layout component.
 */
const General = ({ children, isLoading = false }: GeneralProps) => {
  const loadingClass = isLoading ? "animate-pulse" : "";
  return (
    <div
      className={
        "w-screen min-h-screen bg-gray-50 dark:bg-zinc-900 " + loadingClass
      }
    >
      <nav className="flex flex-col justify-between sticky z-50 top-0 items-center">
        <NavBar />
        <Claire />
      </nav>
      <main className="flex flex-col w-full items-center p-6 px-9">
        {children}
      </main>
    </div>
  );
};

export default General;
