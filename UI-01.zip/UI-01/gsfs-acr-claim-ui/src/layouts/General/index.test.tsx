import General from './General';
import DefaultExport from './index';

describe('indext.tsx', () => {
  it('should re-export General as default', () => {
    expect(DefaultExport).toBe(General);
  });
});