// sleep.test.tsx
import { sleep } from './sleep';
import { describe, it, expect, vi } from "vitest";



describe('sleep', () => {
  vi.useFakeTimers();

  it('should resolve after the specified timeout', () => {
    const timeout = 1000; // 1 second
    const promise = sleep(timeout);

    vi.advanceTimersByTime(timeout);

    return expect(promise).resolves.toBeUndefined();
  });
});