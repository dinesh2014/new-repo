// text.test.tsx
import { capitalizeFirstLetter } from './text';

describe('capitalizeFirstLetter', () => {
  it('should capitalize the first letter of a lowercase string', () => {
    expect(capitalizeFirstLetter('hello')).toBe('Hello');
  });

  it('should return the same string if the first letter is already capitalized', () => {
    expect(capitalizeFirstLetter('Hello')).toBe('Hello');
  });

  it('should handle a single character string', () => {
    expect(capitalizeFirstLetter('a')).toBe('A');
  });

  it('should handle a string with the first letter as a space', () => {
    expect(capitalizeFirstLetter(' hello')).toBe(' hello');
  });
});