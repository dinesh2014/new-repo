/**
 * @param {number} timeout The timeout in milliseconds.
 */
export const sleep = (timeout: number) =>
  new Promise((resolve) => setTimeout(resolve, timeout));
