// constants.test.tsx
import {
    failureStatuses,
    colorsStatus,
    initialFeedbackData,
    historyTableColumns,
  } from './constants';
  
  describe('constants.tsx', () => {
    it('should have correct failure statuses', () => {
      expect(failureStatuses).toEqual([
        "analysis in progress",
        "unable to process",
        "data not found",
        "no claim in queue",
        "not enough data to process the claim",
        undefined,
      ]);
    });
  
    it('should have correct colors status mapping', () => {
      expect(colorsStatus).toEqual({
        Fail: "danger",
        Pass: "success",
        Low: "success",
        Medium: "warning",
        High: "danger",
      });
    });
  
    it('should have correct initial feedback data', () => {
      expect(initialFeedbackData).toEqual([
        {
          type: "Coverage checks",
          text: "",
          visible: true,
          order: 1,
        },
        {
          type: "Dealer checks",
          text: "",
          visible: true,
          order: 2,
        },
        {
          type: "Customer checks",
          text: "",
          visible: true,
          order: 3,
        },
        {
          type: "Breakdown checks",
          text: "",
          visible: true,
          order: 4,
        },
        {
          type: "Cost checks",
          text: "",
          visible: true,
          order: 5,
        },
      ]);
    });
  
    it('should have correct history table columns', () => {
      expect(historyTableColumns).toEqual([
        {
          key: "sclaim_number",
          label: "Claim Number",
        },
        {
          key: "sclaim_status",
          label: "Claim Status",
        },
        {
          key: "sdetail_desc",
          label: "Issue Type",
        },
        {
          key: "camt_paid",
          label: "Claim $",
        },
        {
          key: "dtpaid",
          label: "Date",
        },
      ]);
    });
  });