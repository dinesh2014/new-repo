import pandas as pd
import pickle
import re
from sklearn.model_selection import train_test_split
import lightgbm as lgb
from matplotlib import pyplot as plt
import shap
from sklearn.metrics import mean_squared_error, r2_score
import os
import seaborn as sns

# notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
# sys.path.append("/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path))))

from configs.config import BaseConfig

config_file = BaseConfig.UNIT_PRICE_MODEL_CONFIG
data_sources = config_file["set_up_configuration"]["data_sources"]
target = config_file["set_up_configuration"]["target"]
regex_pattern = config_file["set_up_configuration"]["regex_pattern"]
base_model_columns = config_file["set_up_configuration"]["base_model_columns"]
tire_specific_columns = config_file["set_up_configuration"]["tire_specific_columns"]
category_columns = config_file["set_up_configuration"]["category_columns"]
save_path = config_file["set_up_configuration"]["save_path"]
tec = config_file["set_up_configuration"]["tec"]
product_type = config_file["set_up_configuration"]["product_type"]


def load_data(filename, input_path):
    """Function used to load data from a CSV file into a DataFrame.

    Parameters:
        filename (str): the name of the file to be loaded
        input_path (str): the directory path where the file is located
    Returns:
        pd.DataFrame: the dataframe containing the loaded data
    """
    # Use os.path.join to properly concatenate the base path with the filename
    full_path = os.path.join(input_path, filename)

    # Load the CSV file into a DataFrame
    df = pd.read_csv(full_path)
    return df


def fix_dates(df, date_column):
    """Function used to fix dates in the specified date column of a DataFrame.

    Parameters:
        df (pd.DataFrame): the main dataframe
        date_column (str): the name of the column containing date values to be converted
    Returns:
        pd.DataFrame: the dataframe with the date column converted to datetime,
                      a new 'month_year' column added, and duplicates dropped
    """
    df[date_column] = pd.to_datetime(df[date_column])
    # Extract month and year as a new column
    df["month_year"] = df[date_column].dt.to_period("M")
    df = df.drop_duplicates()

    return df


def merge_dfs(df1, df2):
    """Function used to merge two DataFrames based on the 'month_year' column
    with a lagged comparison.

    Parameters:
        df1 (pd.DataFrame): the first dataframe containing the 'month_year' column
        df2 (pd.DataFrame): the second dataframe containing the 'month_year' column
    Returns:
        pd.DataFrame: the merged dataframe with df1 and df2 joined on 'month_year'
                      from df1 and lagged 'month_year' from df2
    """
    # Ensure 'month_year' columns in both dataframes are in datetime format
    # Convert from PeriodDtype if necessary
    if pd.api.types.is_period_dtype(df1["month_year"]):
        df1["month_year"] = df1["month_year"].dt.to_timestamp()
    if pd.api.types.is_period_dtype(df2["month_year"]):
        df2["month_year"] = df2["month_year"].dt.to_timestamp()

    # Adjust 'month_year' in df2 by subtracting 2 months to create a new column for lagged comparison
    df2["lagged_month_year"] = df2["month_year"] - pd.DateOffset(months=2)

    # Merge df1 with the modified df2 using the 'lagged_month_year' as the key for df2
    df3 = pd.merge(
        df1,
        df2,
        left_on="month_year",
        right_on="lagged_month_year",
        how="left",
        validate=None,
    )

    # Optionally, drop the 'lagged_month_year' column if it's no longer needed
    df3.drop("lagged_month_year", axis=1, inplace=True)

    return df3


def filter_product_rows(df, product_type, data_sources):
    """Function used to filter rows in a DataFrame based on the product type
    and data sources.

    Parameters:
        df (pd.DataFrame): the dataframe with processed claim data
        product_type (str): the type of product to filter ('tire', 'wheel', or 'M&B')
        data_sources (dict): dictionary containing product descriptions for filtering
    Returns:
        pd.DataFrame: the filtered dataframe with rows matching the product type criteria
    """
    # Filter the DataFrame based on product type
    if product_type == "tire":
        # Step 1) Filters rows to include only those with descriptions matching the tire list
        description_list = data_sources["product_descriptions"]["tire_list"]
        df_filtered = df[df["sdetail_desc"].isin(description_list)]

        # Step 2) Exclude rows not related to tires
        df_filtered = df_filtered[
            ~df_filtered["spart_desc"].str.contains(
                "stem|wheel|disk|m & b|M&B|m&b|balance|mount", na=False, case=False
            )
        ]

        # Step 3) Re-include certain rows where 'spart_desc' contains "tire" but not "wheel"
        df_tire_reinclude = df[
            (df["spart_desc"].str.contains("tire", na=False, case=False))
            & (~df["spart_desc"].str.contains("wheel", na=False, case=False))
        ]
        df_filtered = (
            pd.concat([df_filtered, df_tire_reinclude])
            .drop_duplicates()
            .reset_index(drop=True)
        )

        # Step 4) Filters rows to include only specific loss codes
        df_filtered = df_filtered[df_filtered["sloss_code"].isin([13063, 13020, 13051])]

    elif product_type == "wheel":
        # Step 1) Filters rows to include only those with descriptions matching the wheel list
        description_list = data_sources["product_descriptions"]["wheel_list"]
        df_filtered = df[df["sdetail_desc"].isin(description_list)]

        # Step 2) Handle special and general cases for wheels
        df_special_cases = df_filtered[
            df_filtered["sdetail_desc"].isin(
                [
                    "tec wheel replace - cost plus 30% / tire and wheel",
                    "wheel replace / tire and wheel",
                ]
            )
        ]
        df_general_cases = df_filtered[
            ~df_filtered["sdetail_desc"].isin(
                [
                    "tec wheel replace - cost plus 30% / tire and wheel",
                    "wheel replace / tire and wheel",
                ]
            )
            & df_filtered["spart_desc"].str.contains(
                "wheel|disc|aluminum", na=False, case=False
            )
        ]
        df_filtered = (
            pd.concat([df_special_cases, df_general_cases])
            .drop_duplicates()
            .reset_index(drop=True)
        )

        # Step 3) Exclude rows with specific tire size patterns in 'spart_desc'
        df_filtered = df_filtered[
            ~df_filtered["spart_desc"].str.contains(
                r"\d+/\d+R\d+", na=False, case=False, regex=True
            )
        ]

        # Step 4) Exclude rows with 'spart_desc' containing terms like "stem", "tire", "m & b", etc.
        df_filtered = df_filtered[
            ~df_filtered["spart_desc"].str.contains(
                "stem|tire|m & b|M&B|m&b|balance|mount", na=False, case=False
            )
        ]

        # Step 5) Filters rows with a unit cost greater than 60
        df_filtered = df_filtered[df_filtered["creq_unit_cost"] > 60]

        # Step 6) Filters rows to include only specific loss codes
        df_filtered = df_filtered[df_filtered["sloss_code"].isin([13064, 13022, 13059])]

    elif product_type == "M&B":
        # Step 1) Directly apply filters specific to M&B, bypassing description_list
        df_filtered = df[
            df["spart_desc_claim_detail_history"].str.contains(
                "m & b|M&B|m&b|balance|mount", na=False, case=False, regex=True
            )
        ]

    return df_filtered


def create_tire_features(df, regex_pattern):
    """Function used to create tire-related features in a DataFrame by applying
    regex patterns to extract tire dimensions and other attributes from text
    columns.

    Parameters:
        df (pd.DataFrame): the dataframe with processed claim data
        regex_pattern (str): the regex pattern used to extract tire dimensions
    Returns:
        pd.DataFrame: the dataframe with new tire-related feature columns added
    """
    # Step 1) Compile the provided regex pattern with case-insensitive flag
    pattern = re.compile(r"" + regex_pattern, flags=re.IGNORECASE)

    # Step 2) Apply the regex pattern to extract features from 'spart_desc' column
    extracted_features = df["spart_desc"].str.extract(pattern)

    # Step 3) Assign extracted features as new columns: 'Width', 'WheelDiameter', 'AspectRatio'
    df = pd.concat([df, extracted_features], axis=1)

    # Step 4) Convert these new columns to integers, replacing NaNs with 0
    df["Width"] = df["Width"].fillna(0).astype(int)
    df["WheelDiameter"] = df["WheelDiameter"].fillna(0).astype(int)
    df["AspectRatio"] = df["AspectRatio"].fillna(0).astype(int)

    # Step 5) Re-attempt extraction from 'spart_desc_claim_detail_history' column if initial extraction results in zeros
    reattempt_columns = ["Width", "WheelDiameter", "AspectRatio"]

    for column in reattempt_columns:
        needs_reattempt = df[column] == 0

        if needs_reattempt.any():
            reextracted = df.loc[
                needs_reattempt, "spart_desc_claim_detail_history"
            ].str.extract(pattern)
            df.loc[needs_reattempt, column] = reextracted[column].fillna(0).astype(int)

    # Step 6) Create flags for OEM, OEA, Scorpion, Bridgestone, BF, and LT status based on keywords in 'spart_desc'
    df["is_oea"] = (
        df["spart_desc"].str.contains("oea", case=False, na=False).astype(int)
    )
    df["is_oem"] = (
        df["spart_desc"].str.contains("oem", case=False, na=False).astype(int)
    )
    df["is_scorpion"] = (
        df["spart_desc"].str.contains("scorpion", case=False, na=False).astype(int)
    )
    df["is_bridgestone"] = (
        df["spart_desc"].str.contains("bridgestone", case=False, na=False).astype(int)
    )
    df["is_bf"] = df["spart_desc"].str.contains("bf", case=False, na=False).astype(int)
    df["is_lt"] = df["spart_desc"].str.contains("lt", case=False, na=False).astype(int)

    # Step 7) Drop rows where 'spart_desc' appears only once to remove outliers
    print(f"Count of rows before dropping desc outliers: {len(df)}")
    spart_desc_counts = df["spart_desc"].value_counts()
    df = df[df["spart_desc"].map(spart_desc_counts) > 1]

    final_row_count = len(df)
    print(
        f"Final number of rows after dropping 'spart_desc' that appear only once: {final_row_count}"
    )

    return df


def merge_tire_parts(df1, parts_df, tire_specific_columns):
    """Function used to merge tire-specific parts information into a DataFrame
    based on claim id.

    Parameters:
        df1 (pd.DataFrame): the main dataframe containing claims data
        parts_df (pd.DataFrame): the dataframe containing tire-specific parts information
        tire_specific_columns (list): list of columns specific to tire parts to retain from parts_df
    Returns:
        pd.DataFrame: the merged dataframe with tire-specific parts information added
    """
    # Step 1) Retain only the necessary columns from parts_df, including 'iclaim_id' and tire-specific columns
    cols_to_keep = ["iclaim_id"] + tire_specific_columns
    parts_df = parts_df[cols_to_keep]

    # Step 2) Remove duplicate rows in parts_df
    parts_df = parts_df.drop_duplicates()

    # Step 3) Merge df1 with parts_df on 'iclaim_id' using a left join
    merged_df = pd.merge(df1, parts_df, on="iclaim_id", how="left", validate=None)

    # Step 4) Fill NaN values in tire-specific columns with 0 and convert them to integers
    merged_df["Width"] = merged_df["Width"].fillna(0).astype(int)
    merged_df["WheelDiameter"] = merged_df["WheelDiameter"].fillna(0).astype(int)
    merged_df["AspectRatio"] = merged_df["AspectRatio"].fillna(0).astype(int)
    merged_df["is_oea"] = merged_df["is_oea"].fillna(0).astype(int)
    merged_df["is_oem"] = merged_df["is_oem"].fillna(0).astype(int)
    merged_df["is_scorpion"] = merged_df["is_scorpion"].fillna(0).astype(int)
    merged_df["is_bridgestone"] = merged_df["is_bridgestone"].fillna(0).astype(int)
    merged_df["is_bf"] = merged_df["is_bf"].fillna(0).astype(int)
    merged_df["is_lt"] = merged_df["is_lt"].fillna(0).astype(int)

    return merged_df


def filter_model_attributes(
    df, base_model_columns, tire_specific_columns, category_columns
):
    """Function used to filter a DataFrame based on selected columns and set
    data types for categorical variables.

    These
    are the columns that will be used for model training
    Parameters:
        df (pd.DataFrame): the dataframe with processed claim data
        base_model_columns (list): list of columns related to the base model to retain
        tire_specific_columns (list): list of tire-specific columns to retain
        category_columns (list): list of columns to be converted to categorical data type
    Returns:
        pd.DataFrame: the filtered dataframe with selected columns and categorical variables set
    """
    # Filter the DataFrame based on the selected columns
    columns = base_model_columns + tire_specific_columns
    tire_model_df = df[columns].copy()

    # Set data types for categorical variables
    for col in category_columns:
        if col in tire_model_df.columns:
            tire_model_df[col] = tire_model_df[col].astype("category")

    return tire_model_df


def split_x_y(df, target, tec):
    """Function used to split a DataFrame into training and test sets, with
    filtering based on TEC contract type.

    Parameters:
        df (pd.DataFrame): the dataframe with processed claim data
        target (str): the target variable column name
        tec (bool or None): flag to filter TEC (True), Non-TEC (False), or use full dataset (None)
    Returns:
        The training and test feature matrices (X_train, X_test),
        training and test target variables (y_train, y_test),
        training and test claim IDs (iclaim_ids_train, iclaim_ids_test),
        and list of categorical feature names
    """
    if tec is True:
        sample_df = df[df["icontract_type"].isin([40, 68])]
    elif tec is False:
        sample_df = df[~df["icontract_type"].isin([40, 68])]
    else:
        # If toyota is None or not specified, use the full dataset
        sample_df = df

    print(f"{len(sample_df)} rows left after TEC/Non-TEC filter")

    sample_df = sample_df.drop("icontract_type", axis=1)
    # Assuming 'result_df' is your DataFrame and already includes necessary preprocessing
    X = sample_df.drop(target, axis=1)  # Feature matrix
    y = sample_df[target]  # Target variable
    iclaim_ids = sample_df["sclaim_number"]  # Extracting iclaim_id for tracking

    # Splitting data into training and test sets
    X_train, X_test, y_train, y_test, iclaim_ids_train, iclaim_ids_test = (
        train_test_split(X, y, iclaim_ids, test_size=0.2, random_state=42)
    )

    # Remove 'iclaim_id' from X_train and X_test as it should not be used for training
    X_train = X_train.drop(["sclaim_number"], axis=1)
    X_test = X_test.drop(["sclaim_number"], axis=1)

    # Identify categorical features
    categorical_features = [
        column
        for column in X_train.columns
        if X_train[column].dtypes.name == "category"
    ]

    return (
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        categorical_features,
    )


def train_model(X_train, X_test, y_train, y_test, categorical_features):
    """Function used to train a LightGBM model using the provided training and
    test data.

    Parameters:
        X_train (pd.DataFrame): the training feature matrix
        X_test (pd.DataFrame): the test feature matrix
        y_train (pd.Series): the training target variable
        y_test (pd.Series): the test target variable
        categorical_features (list): list of feature names to be treated as categorical
    Returns:
        lgb.Booster: the trained LightGBM model
    """
    # Step 1) Print the lengths of the training and test data for verification
    print("Training model")
    print(f"With X_train len: {len(X_train)}")
    print(f"With y_train len: {len(y_train)}")
    print(f"With X_test len: {len(X_test)}")
    print(f"With y_test len: {len(y_test)}")

    # Step 2) Create LightGBM datasets for training and testing, specifying categorical features
    train_data = lgb.Dataset(
        X_train,
        label=y_train,
        categorical_feature=categorical_features,
        free_raw_data=False,
    )
    test_data = lgb.Dataset(
        X_test,
        label=y_test,
        categorical_feature=categorical_features,
        reference=train_data,
        free_raw_data=False,
    )

    # Step 3) Define model parameters, setting the objective to 'regression'
    params = {"objective": "regression"}

    # Step 4) Train the model using the specified parameters and training data, with test data for validation
    model = lgb.train(params, train_data, valid_sets=[test_data], num_boost_round=1000)

    print("Finished training model")
    return model


def run_shap(df_X_test, model, save_path, tec, product_type):
    """Function used to generate SHAP values and summary plot for the test
    dataset.

    Parameters:
        df_X_test (pd.DataFrame): the test feature matrix
        model (lgb.Booster): the trained LightGBM model
        save_path (str): the path where the SHAP summary plot will be saved
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
        product_type (str): the type of product being analyzed (e.g., "tire", "wheel")
    Returns:
        None
    """
    # Step 1) Determine the label for TEC, Non-TEC, or full dataset
    if tec is True:
        tec_label = "tec"
    elif tec is False:
        tec_label = "non_tec"
    else:
        tec_label = "full_dataset"

    # Step 2) Create a SHAP explainer using the provided model
    explainer = shap.TreeExplainer(model)

    # Step 3) Compute SHAP values for the test dataset
    out_of_sample_shap_values = explainer.shap_values(df_X_test)

    # Step 4) Generate and save a SHAP summary plot with an appropriate title
    shap.summary_plot(out_of_sample_shap_values, df_X_test, show=False)
    plt.title("Out of Sample Shap")
    plt.savefig(f"{save_path}/shap_summary_{tec_label}_{product_type}.png")

    # Step 5) Close the plot display window to prevent it from showing during execution
    plt.close()


def model_metrics(model, X_test, y_test, product_type, tec, save_path):
    """Function used to evaluate the model's performance using test data and
    save the metrics and plots.

    Parameters:
        model (lgb.Booster): the trained LightGBM model
        X_test (pd.DataFrame): the test feature matrix
        y_test (pd.Series): the test target variable
        product_type (str): the type of product being analyzed (e.g., "tire", "wheel")
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
        save_path (str): the path where the metrics and plots will be saved
    Returns:
        None
    """
    # Step 1) Determine the label for TEC, Non-TEC, or full dataset
    if tec is True:
        tec_label = "tec"
    elif tec is False:
        tec_label = "non_tec"
    else:
        tec_label = "full_dataset"

    # Step 2) Predict on the test set using the trained model
    y_pred = model.predict(X_test, num_iteration=model.best_iteration)

    # Step 3) Calculate evaluation metrics: Mean Squared Error (MSE), Root Mean Squared Error (RMSE), and R^2 Score
    mse = mean_squared_error(y_test, y_pred)
    rmse = mse**0.5
    r2 = r2_score(y_test, y_pred)

    # Step 4) Print the evaluation metrics
    print("MSE:", mse)
    print("RMSE:", rmse)
    print("R^2 Score:", r2)

    # Step 5) Save the metrics to a text file in the specified path
    metrics_file = f"{tec_label}_{product_type}/metrics.txt"
    os.makedirs(save_path, exist_ok=True)  # Ensure the directory exists
    with open(os.path.join(save_path, metrics_file), "w") as file:
        file.write(f"MSE: {mse}\n")
        file.write(f"RMSE: {rmse}\n")
        file.write(f"R^2 Score: {r2}\n")

    # Step 6) Generate and save a scatter plot of Predicted vs Actual values
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x=y_pred, y=y_test)
    plt.title("Predicted vs Actual Values")
    plt.xlabel("Predicted Values")
    plt.ylabel("Actual Values")
    plt.plot(
        [y_test.min(), y_test.max()], [y_test.min(), y_test.max()], "k--"
    )  # Diagonal line
    plt.savefig(
        os.path.join(
            save_path,
            f"{tec_label}_{product_type}/predicted_vs_actual_{tec_label}_{product_type}.png",
        )
    )
    plt.close()

    # Step 7) Generate and save a histogram of residuals
    residuals = y_test - y_pred
    plt.figure(figsize=(10, 6))
    sns.histplot(residuals, kde=True, bins=30)
    plt.title("Histogram of Residuals")
    plt.xlabel("Residuals")
    plt.ylabel("Frequency")
    plt.savefig(
        os.path.join(
            save_path,
            f"{tec_label}_{product_type}/residuals_histogram_{tec_label}_{product_type}.png",
        )
    )
    plt.close()

    # Step 8) Generate and save a histogram comparing the distribution of Actual and Predicted values
    plt.figure(figsize=(10, 6))
    sns.histplot(
        y_test,
        color="blue",
        label="Actual Values",
        kde=True,
        element="step",
        stat="density",
        common_norm=False,
    )
    sns.histplot(
        y_pred,
        color="red",
        label="Predicted Values",
        kde=True,
        element="step",
        stat="density",
        common_norm=False,
    )
    plt.title("Comparison of Actual and Predicted Values Distribution")
    plt.xlabel("Value")
    plt.ylabel("Density")
    plt.legend()
    plt.savefig(
        os.path.join(
            save_path,
            f"{tec_label}_{product_type}/actual_vs_predicted_distribution{tec_label}_{product_type}.png",
        )
    )
    plt.close()


def predict_full_dataset(
    model,
    X_train,
    X_test,
    y_train,
    y_test,
    iclaim_ids_train,
    iclaim_ids_test,
    product_type,
    tec,
):
    """Function used to predict on the full dataset using the trained model and
    flag significant discrepancies.

    Parameters:
        model (lgb.Booster): the trained LightGBM model
        X_train (pd.DataFrame): the training feature matrix
        X_test (pd.DataFrame): the test feature matrix
        y_train (pd.Series): the training target variable
        y_test (pd.Series): the test target variable
        iclaim_ids_train (pd.Series): claim IDs for the training data
        iclaim_ids_test (pd.Series): claim IDs for the test data
        product_type (str): the type of product being analyzed (e.g., "tire", "wheel")
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
    Returns:
        None
    """
    # Step 1) Determine the label for TEC, Non-TEC, or full dataset
    if tec is True:
        tec_label = "tec"
    elif tec is False:
        tec_label = "non_tec"
    else:
        tec_label = "full_dataset"

    # Step 2) Concatenate training and test sets for features, target, and claim IDs
    X_full = pd.concat([X_train, X_test])
    y_full = pd.concat([y_train, y_test])
    iclaim_ids_full = pd.concat([iclaim_ids_train, iclaim_ids_test])
    print(f"Flagging over {len(iclaim_ids_full)} claims")

    # Step 3) Predict on the full dataset using the trained model
    predictions = model.predict(X_full)

    # Step 4) Calculate discrepancies as a percentage
    discrepancies = (y_full - predictions) / predictions

    # Step 5) Ensure the save path directory exists
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # Step 6) Create a DataFrame with all original features for the discrepancies
    significant_features = X_full.copy()
    significant_features["sclaim_number"] = iclaim_ids_full
    significant_features["Actual"] = y_full
    significant_features["Predicted"] = predictions
    significant_features["Discrepancy"] = discrepancies

    # Step 7) Reorder the DataFrame to make 'sclaim_number' the first column
    cols = ["sclaim_number"] + [
        col for col in significant_features.columns if col != "sclaim_number"
    ]
    significant_features = significant_features[cols]

    # Step 8) Sort the DataFrame by Discrepancy in descending order
    significant_features.sort_values(by="Discrepancy", ascending=False, inplace=True)

    # Step 9) Save the DataFrame to CSV
    significant_features.to_csv(
        f"{save_path}/{tec_label}_{product_type}/significant_discrepancies_{tec_label}_{product_type}.csv",
        index=False,
    )
    print(f"{len(significant_features)} rows flagged")
    print(
        f"Significant discrepancies have been saved to '{save_path}/{tec_label}_{product_type}/significant_discrepancies.csv'."
    )


def save_pickle(tec, product_type, model):
    """Function used to save a trained model as a pickle file.

    Parameters:
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
        product_type (str): the type of product being analyzed (e.g., "tire", "wheel")
        model (lgb.Booster): the trained LightGBM model
    Returns:
        None
    """
    if tec is True:
        tec_label = "tec"
    elif tec is False:
        tec_label = "non_tec"
    else:
        tec_label = "full_dataset"

    directory = config_file["set_up_configuration"]["artifacts_output"]
    with open(
        f"{directory}/{tec_label}_{product_type}_connect_validation.pkl", "wb"
    ) as file:
        pickle.dump(model, file)


def run_tire_model(parts_df, fred_df, product_type, tec):
    """Function used to run the tire price model, including data preprocessing,
    feature creation, model training, evaluation, and saving the model.

    Parameters:
        parts_df (pd.DataFrame): the dataframe containing parts data
        fred_df (pd.DataFrame): the dataframe containing external data (e.g., economic indicators)
        product_type (str): the type of product being analyzed (e.g., "tire")
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
    Returns:
        None
    """
    print("RUNNING TIRE PRICE MODEL")

    # Step 1) Preprocess data (fix dates, merge dataframes, filter rows)
    parts_df = fix_dates(parts_df, data_sources["date_columns"]["parts_date"])
    fred_df = fix_dates(fred_df, data_sources["date_columns"]["fred_date"])
    print("Dates fixed")

    # Merge external data
    merged_df = merge_dfs(parts_df, fred_df)
    print("Merged sources")

    # Filter only product needed
    tire_df = filter_product_rows(merged_df, product_type, data_sources)
    print("Filtered tire rows")

    # Step 2) Create features and filter columns needed for modeling
    tire_df = create_tire_features(tire_df, regex_pattern)
    print("Created new features")

    # Filter to vars needed for modelling
    tire_df = filter_model_attributes(
        tire_df, base_model_columns, tire_specific_columns, category_columns
    )
    print("Filtered attributes needed for modelling")

    # Step 3) Split data into training and test sets
    (
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        categorical_features,
    ) = split_x_y(tire_df, target, tec)
    print("Splitted train test datasets")

    # Step 4) Train the model and generate SHAP values
    model = train_model(X_train, X_test, y_train, y_test, categorical_features)
    print("Model trained")

    # SHAPs
    run_shap(X_test, model, save_path, tec, product_type)

    # Step 5) Predict on the full dataset and evaluate model performance
    predict_full_dataset(
        model,
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        product_type,
        tec,
    )

    # Metrics
    model_metrics(model, X_test, y_test, product_type, tec, save_path)

    # Step 6) Save the trained model to disk
    save_pickle(tec, product_type, model)


def run_wheel_model(parts_df, fred_df, product_type, tec):
    """Function used to run the wheel price model, including data
    preprocessing, feature creation, model training, evaluation, and saving the
    model.

    Parameters:
        parts_df (pd.DataFrame): the dataframe containing parts data
        fred_df (pd.DataFrame): the dataframe containing external data (e.g., economic indicators)
        product_type (str): the type of product being analyzed (e.g., "wheel")
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
    Returns:
        None
    """
    print("RUNNING WHEEL PRICE MODEL")

    # Step 1) Preprocess data (fix dates, merge dataframes, filter rows)
    parts_df = fix_dates(parts_df, data_sources["date_columns"]["parts_date"])
    fred_df = fix_dates(fred_df, data_sources["date_columns"]["fred_date"])
    print("Dates fixed")

    # Merge external data
    merged_external_df = merge_dfs(parts_df, fred_df)
    print("Merged sources")

    # Filter only product needed
    tire_df = filter_product_rows(merged_external_df, "tire", data_sources)
    wheel_df = filter_product_rows(merged_external_df, product_type, data_sources)
    print("Filtered tire rows")
    print(
        f"Database has {len(wheel_df)} rows after filtering. This includes TEC and non-TEC"
    )

    # Step 2) Create features and filter columns needed for modeling
    tire_df = create_tire_features(tire_df, regex_pattern)
    print("Created new features")

    # Step 3) Merge tire features back into the wheel master dataframe
    merged_df = merge_tire_parts(wheel_df, tire_df, tire_specific_columns)

    # Filter to vars needed for modelling
    merged_df = filter_model_attributes(
        merged_df, base_model_columns, tire_specific_columns, category_columns
    )
    print("Filtered attributes needed for modelling")

    # Step 4) Split data into training and test sets
    (
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        categorical_features,
    ) = split_x_y(merged_df, target, tec)
    print("Splitted train test datasets")

    # Step 5) Train the model and generate SHAP values
    model = train_model(X_train, X_test, y_train, y_test, categorical_features)
    print("Model trained")

    # SHAPs
    run_shap(X_test, model, save_path, tec, product_type)

    # Step 6) Predict on the full dataset and evaluate model performance
    predict_full_dataset(
        model,
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        product_type,
        tec,
    )

    # Metrics
    model_metrics(model, X_test, y_test, product_type, tec, save_path)

    # Step 7) Save the trained model to disk
    save_pickle(tec, product_type, model)


def run_m_and_b_models(parts_df, fred_df, labor_df, product_type, tec):
    """Function used to run the M&B (Mounting and Balancing) price model,
    including data preprocessing, feature creation, model training, evaluation,
    and saving the model.

    Parameters:
        parts_df (pd.DataFrame): the dataframe containing parts data
        fred_df (pd.DataFrame): the dataframe containing external data (e.g., economic indicators)
        labor_df (pd.DataFrame): the dataframe containing labor data
        product_type (str): the type of product being analyzed (e.g., "M&B")
        tec (bool or None): flag indicating if the data is for TEC (True), Non-TEC (False), or full dataset (None)
    Returns:
        None
    """
    print("RUNNING M&B PRICE MODEL")

    # Step 1) Preprocess data (fix dates, merge dataframes, filter rows)
    labor_df = fix_dates(labor_df, data_sources["date_columns"]["parts_date"])
    fred_df = fix_dates(fred_df, data_sources["date_columns"]["fred_date"])
    print("Dates fixed")

    # Merge external data
    merged_external_df = merge_dfs(labor_df, fred_df)
    print(f"Merged (fred) data {len(merged_external_df)}")

    # Filter only product needed
    tire_df = filter_product_rows(parts_df, "tire", data_sources)
    merged_external_df = filter_product_rows(
        merged_external_df, product_type, data_sources
    )
    print("Filtered tire/wheel rows")

    # Step 2) Create features and filter columns needed for modeling
    tire_df = create_tire_features(tire_df, regex_pattern)
    print("Created new features")

    # Step 3) Merge tire features back into the labor and parts dataframe
    merged_df = merge_tire_parts(merged_external_df, tire_df, tire_specific_columns)

    # Filter to vars needed for modelling
    merged_df = filter_model_attributes(
        merged_df, base_model_columns, tire_specific_columns, category_columns
    )
    print("Filtered attributes needed for modelling")

    # Step 4) Split data into training and test sets
    (
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        categorical_features,
    ) = split_x_y(merged_df, target, tec)
    print("Splitted train test datasets")

    # Step 5) Train the model and generate SHAP values
    model = train_model(X_train, X_test, y_train, y_test, categorical_features)
    print("Model trained")

    # SHAPs
    run_shap(X_test, model, save_path, tec, product_type)

    # Step 6) Evaluate model performance and save metrics and plots
    model_metrics(model, X_test, y_test, product_type, tec, save_path)

    # Step 7) Predict on the full dataset and save the trained model to disk
    predict_full_dataset(
        model,
        X_train,
        X_test,
        y_train,
        y_test,
        iclaim_ids_train,
        iclaim_ids_test,
        product_type,
        tec,
    )

    # Save the model to disk
    save_pickle(tec, product_type, model)

    print("Finished model pipeline")


def main_tire_and_wheel():
    """Main function used to estimate Tire, wheel and M&B models."""

    # Read df_parts, df_labor and fred_index once:
    parts_df = load_data(
        data_sources["input"]["input_tables"]["parts_df"],
        data_sources["input"]["input_path"],
    )

    labor_df = load_data(
        data_sources["input"]["input_tables"]["labor_df"],
        data_sources["input"]["input_path"],
    )

    fred_df = load_data(
        data_sources["pre_computed"]["input_tables"]["fred_df"],
        data_sources["pre_computed"]["input_path"],
    )

    # Execute part price prediction for tire componentes:
    run_tire_model(parts_df, fred_df, "tire", True)
    run_tire_model(parts_df, fred_df, "tire", False)

    # Execute part price prediction for wheel componentes:
    run_wheel_model(parts_df, fred_df, "wheel", True)
    run_wheel_model(parts_df, fred_df, "wheel", False)

    # Execute labor cost prediction for M&B:
    run_m_and_b_models(parts_df, fred_df, labor_df, "M&B", True)
    run_m_and_b_models(parts_df, fred_df, labor_df, "M&B", False)

# if __name__ == "__main__":
#     main_tire_and_wheel()
