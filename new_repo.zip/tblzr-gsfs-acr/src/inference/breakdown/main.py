import logging
import warnings
from pyspark.sql.types import StructType, StructField, FloatType

from src.inference.breakdown.staking_info_task import stack_claim_information
from src.inference.breakdown.feature_engineering_task import (
    feature_engineering,
)
from src.inference.breakdown.inference_task import inference_task
from utils.utils import timing, save_intermediate_daily_files_s3
from databricks.connect import DatabricksSession

# Import functions to deal with exception (Breakdown):
from src.inference.breakdown.inference_task import (
    set_up_config as set_up_config_breakdown,
    interim_tables_config as interim_tables_config_breakdown,
    interim_bucket_path as interim_bucket_path_breakdown,
)

# Import function to deal with exception (Part):
from src.inference.breakdown.staking_info_task import (
    set_up_config as set_up_config_part,
    interim_tables_config as interim_tables_config_part,
    interim_bucket_path as interim_bucket_path_part,
)


# Disable warnings during execution
warnings.filterwarnings("ignore")

# Create SparkSession (Databricks)
spark = DatabricksSession.builder.getOrCreate()

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Defining spark configurations:
spark.conf.set("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2")
spark.conf.set("spark.hadoop.fs.s3a.fast.upload", "true")
spark.conf.set("spark.sql.parquet.compression.codec", "snappy")
spark.conf.set("spark.sql.parquet.enableVectorizedReader", "true")


@timing
def exec_inference_breakdown_task(
    json_contract: dict,
    id_execution: dict,
):
    """Executes the complete inference pipeline for breakdown analysis,
    including staking info, feature engineering, and breakdown inference.
    Handles exceptions by generating default outputs.

    Args:
        json_contract (dict): JSON contract containing details about the claim.
        id_execution (dict): Dictionary containing execution IDs and other metadata.

    Returns:
        None: This function does not return any value but directly
        affects external systems (e.g., database or files).
    """

    logger.info("*** Initializing inference task for Breakdown AI engine ***")

    try:
        # Parse Json contract with claim and stack key features:
        stack_claim_information(json_contract, id_execution, spark)

        # Calculate on-fly features and aggregate info at claim-loss type:
        feature_engineering(id_execution, spark)

        # Pull pre-trained model for MLFlow to generate breakdown probabilities:
        inference_task(id_execution, spark)

    except Exception as e:
        logger.warning("*** Exception occurred: %s ***", e)

        ##########################################
        # Generate Default Output for Breakdown ##
        ##########################################

        # Generate default output:
        required_cols = set_up_config_breakdown["select_final_cols"]
        schema = StructType(
            [StructField(col, FloatType(), True) for col in required_cols]
        )

        # Create an empty DataFrame with the schema
        empty_df = spark.createDataFrame([], schema)

        # Save result in job folder to be loaded by KPIS:
        save_intermediate_daily_files_s3(
            df=empty_df,
            s3_bucket=interim_bucket_path_breakdown,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config_breakdown["file_name"][
                "breakdown_inference"
            ],
        )

        ###########################################
        # Generate default output for part freq ###
        ###########################################

        # Generate default output:
        required_cols = set_up_config_part["final_cols_part_frequency"]
        schema = StructType(
            [StructField(col, FloatType(), True) for col in required_cols]
        )

        # Create an empty DataFrame with the schema
        empty_df = spark.createDataFrame([], schema)

        # Save result in job folder to be loaded by KPIS:
        save_intermediate_daily_files_s3(
            df=empty_df,
            s3_bucket=interim_bucket_path_part,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config_part["file_name"]["part_frequency_ratio"],
        )

        return None
