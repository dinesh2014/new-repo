import warnings
import logging
from databricks.sdk.runtime import *
from pyspark.sql.types import StructType, StructField, FloatType

from src.inference.labor_cost.feature_engineering_task import (
    feature_engineering,
)
from src.inference.labor_cost.inference_task import inference_task
from src.inference.labor_cost.staking_info_task import stack_claim_information
from databricks.connect import DatabricksSession
from utils.utils import timing, save_intermediate_daily_files_s3

# Import functions to deal with exception:
from src.inference.labor_cost.inference_task import (
    set_up_config,
    interim_tables_config,
    interim_bucket_path,
)

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Disable warnings during execution
warnings.filterwarnings("ignore")

# Create SparkSession (run on Databricks):
spark = DatabricksSession.builder.getOrCreate()


@timing
def exec_inference_cost_task(
    api_contract: dict,
    id_execution: dict,
):
    """Executes the inference process for labor cost assessment by coordinating
    the stacking of information, feature engineering, and labor cost prediction
    tasks. If an exception occurs, it generates a default output to ensure the
    workflow completes.

    Args:
        api_contract (dict): JSON-like dictionary containing the contract and claim details to process.
        id_execution (dict): Dictionary containing execution metadata such as job run IDs and execution dates.

    Returns:
        None: This function does not return any value. It either completes the inference task sequence or handles exceptions
        by creating a default output DataFrame.
    """
    logger.info("*** Initializing inference task for Cost AI engine ***")

    try:
        # Parse Json contract with claim and stack key features:
        stack_claim_information(api_contract, id_execution, spark)

        # Calculate on-fly features:
        feature_engineering(id_execution, spark)

        # Pull pre-trained model for MLFlow to generate labor cost prediction:
        inference_task(id_execution, spark)

    except Exception as e:
        logger.warning("*** Exception occurred: %s ***", e)

        ##########################################
        # Generate Default Output for Labor Cost #
        ##########################################

        # Generate default output:
        required_cols = set_up_config["final_cols_inference"]
        schema = StructType(
            [StructField(col, FloatType(), True) for col in required_cols]
        )

        # Create an empty DataFrame with the schema
        empty_df = spark.createDataFrame([], schema)

        # Save result in job folder to be loaded by KPIS:
        save_intermediate_daily_files_s3(
            df=empty_df,
            s3_bucket=interim_bucket_path,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config["file_name"]["labor_inference"],
        )

        return None
