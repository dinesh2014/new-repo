import logging
from datetime import datetime

from databricks.connect import DatabricksSession

from configs.config import BaseConfig

from src.inference.kpi_refreshment.flag_reminder import (
    assign_text_reminder,
    assign_text_reminder_tw,
)
from src.inference.kpi_refreshment.recommendation_logic import (
    apply_recommendation_logic,
    apply_recommendation_logic_tw,
)
from utils.utils import timing

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

config_file = BaseConfig.KPI_REFRESHMENT_CONFIG
set_up = config_file["set_up_configuration"]
data_sources = set_up["data_sources"]
output_folder = data_sources["output_folder"]
output_tables = data_sources["output_tables"]
today_date = datetime.now().strftime("%Y-%m-%d")

# Create SparkSession
spark = DatabricksSession.builder.getOrCreate()


@timing
def exec_inference_kpi_refreshment_task(
    df_breakdown, df_labor_hours, df_part_freq, run_id
):
    """Executes the complete inference pipeline for KPIs refreshment on VSC
    claims.

    Args:
        df_breakdown: spark dataframe with breakdown model results
        df_labor_hours: spark dataframe with labor cost model results
        df_part_freq: spark dataframe with part freq computation results
        run_id: unique ID identifier for the execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    logger.info("*** Initializing inference task for KPI refreshment ***")
    # Generate most raw ACR info and flags
    df_feature = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_kpi"
    )

    logger.info("KPI feature table is created.")

    # Apply recommendation logic
    apply_recommendation_logic(df_feature, df_breakdown, df_labor_hours, run_id)
    df_rec = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/rec_logic"
    )

    # Join part freq table
    df_rec_w_part = df_rec.join(
        df_part_freq.drop("risk_tier_part"),
        on=["smake", "smodel", "sloss_code", "spart_no"],
        how="left",
    )

    # Assign flag text and reminder
    df_out = assign_text_reminder(df_rec_w_part)

    # Return master acr output
    return df_out


@timing
def exec_inference_kpi_refreshment_task_tw(df_tw, run_id):
    """Executes the complete inference pipeline for KPIs refreshment on TW
    claims.

    Args:
        df_tw: spark dataframe with TW model results

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    logger.info("*** Initializing inference task for KPI refreshment ***")
    # Generate most raw ACR info and flags
    df_feature = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_kpi"
    )

    logger.info("KPI feature table is created.")

    # Apply recommendation logic
    apply_recommendation_logic_tw(df_feature, df_tw, run_id)

    df_rec = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/rec_logic"
    )

    # Assign flag text and reminder
    df_out = assign_text_reminder_tw(df_rec)

    # Return master acr output
    return df_out


if __name__ == "__main__":
    df_acr_output = exec_inference_kpi_refreshment_task()
