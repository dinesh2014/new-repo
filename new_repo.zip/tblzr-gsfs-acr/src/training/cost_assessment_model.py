import warnings
from datetime import datetime
from mlflow.deployments import get_deploy_client

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

from src.training.feature_engineering import main_costmodel
from configs.config import BaseConfig
from utils.utils import apply_hot_encoding
from databricks.connect import DatabricksSession

# Create SparkSession
spark = DatabricksSession.builder.getOrCreate()

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading parameters from config file
config_file = BaseConfig.COST_ASSESSMENT_CONFIG
data_sources = config_file["set_up_configuration"]["data_sources"]
model_sources = config_file["set_up_configuration"]["model_sources"]
kpis = config_file["set_up_configuration"]["kpis"]
anomaly_segments = config_file["set_up_configuration"]["anomaly_detection_segment"]
kpi_thresholds = config_file["set_up_configuration"]["kpi_thresholds"]
filter_thresholds = config_file["set_up_configuration"]["filter_thresholds"]
target_var = config_file["set_up_configuration"]["target_var"]
feature_list_pre = config_file["set_up_configuration"]["feature_list_pre"]
features_to_set_to_average = config_file["set_up_configuration"][
    "features_to_set_to_average"
]
features_to_set_to_1 = config_file["set_up_configuration"]["features_to_set_to_1"]
feature_outlier_removal_ls = config_file["set_up_configuration"][
    "feature_outlier_removal_ls"
]
run_feature_engineering = config_file["set_up_configuration"]["run_feature_engineering"]


def serving_model_endpoint(model_names):
    """Function used to create a serving endpoint for the model in MLFlow.

    Parameters:
        model_names: list of models names to serve.
    """

    if len(model_names) == 0:
        return

    # Set up MLFlow CLI:
    client = get_deploy_client("databricks")

    served_entities_list = [
        {
            "name": f"sk-learn-linear-regression-{model}",
            "entity_name": f"sk-learn-linear-regression-{model}",
            "workload_type": "GPU_MEDIUM",
            "workload_size": "Medium",
            "scale_to_zero_enabled": True,
            "entity_version": 1,
        }
        for model in model_names
    ]

    def create_list(N):
        average, remainder = 100 // N, 100 % N
        result = [average] * N
        for i in range(remainder):
            result[i] += 1
        return result

    model_traffic_perc = dict(zip(model_names, create_list(len(model_names))))

    traffic_config_list = [
        {
            "served_model_name": f"sk-learn-linear-regression-{model}",
            "traffic_percentage": traffic,
        }
        for model, traffic in model_traffic_perc.items()
    ]

    client.create_endpoint(
        name="cost-assesment-engine",
        config={
            "served_entities": served_entities_list,
            "traffic_config": {"routes": traffic_config_list},
        },
    )


def run_regression(
    df_input: pd.DataFrame,
    make: str,
    smodel: str,
    losscode: str,
    target_var: str,
    feature_ls_pre: list[str],
):
    """This function is used to run regression for 1 make, model, loss code
    combination with pre-defined feature list and target variable.

    Parameters:
        df_input (pd.DataFrame): the dataframe with input data after feature engineering for
        labor hours prediction modeling
        make (str): the name of the car make
        smodel (str): the name of car model
        losscode (str): the name of loss codes
        target_var (str): the target variable name
        feature_ls_pre (list): the list of pre-selected features
    """

    # Get the input dataframe
    df = df_input[df_input["sclaim_status"].str.lower() == "p"]

    # Get the dataframe to train regression model
    df_select = df[
        (df["smake"] == make)
        & (df["smodel"] == smodel)
        & (df["sloss_code"] == losscode)
    ].copy()

    # Apply one hot encoding
    cat_cols = ["strim"]
    df_train_select2_pre = apply_hot_encoding(df_select, cat_cols)

    # get trim_ls used in model
    trim_ls = [x for x in df_train_select2_pre.columns.tolist() if "trim" in x]
    trim_ls = trim_ls[:-1]

    # Define the features
    feature_ls = feature_ls_pre + trim_ls

    # Drop outlier values from feature set to make sure training is now skewed by extreme outliers
    df_select2 = df_train_select2_pre.copy()
    outlier_feature_ls = ["dealer_issue_labor_cost_per_claim", target_var]

    # Drop outliers by outside 2 std of mean
    for col in outlier_feature_ls:
        threshold = df_select2[col].std()
        mean = df_select2[col].mean()
        df_select2 = df_select2[
            (df_select2[col] <= mean + 2 * threshold)
            & (df_select2[col] >= mean - 2 * threshold)
        ]

    # Drop NA for X input
    df_select3 = df_select2[feature_ls + [target_var]].dropna()

    # Run loop across all combinations with enough claims:
    features = df_select3[feature_ls]

    # Define the target variable as 'charges'
    target = df_select3[target_var]

    # train the model
    model = LinearRegression()
    model.fit(features, target)

    # Get the coefficient, intercept and feature names of the model
    coefficients = model.coef_.tolist()
    intercept = model.intercept_.tolist()
    feature_name = model.feature_names_in_.tolist()
    r2_score = model.score(features, target)
    n_claim = len(df_select3)

    return model, coefficients, intercept, feature_name, r2_score, n_claim


def get_labor_hours_prediction(
    df_input: pd.DataFrame,
    df_run_model: pd.DataFrame,
    target_var: str,
    feature_ls_pre: list[str],
):
    """This function is used to generate labor hours prediction when enough
    claims are available.

    Parameters:
        df_input (pd.DataFrame): input dataframe with claims data
        df_run_model (pd.DataFrame): the dataframe of make, model, loss code
        combinations where meet the criteria for running prediction model
        target_var (str): the name of the target variable
        feature_ls_pre (list): the list of pre-selected features

    Returns:
        pd.DataFrame: the dataframe with prediction
        pd.DataFrame: the of make, model, loss code combinations that cannot
        meet the criteria of generating prediction after removing outliers
    """

    # Get input
    df = df_input.copy()

    # Run for loop to generate labor hours prediction by car make + model + loss code combinations
    print(
        "Generate labor hours prediction by car make, model and loss code combinations..."
    )

    df_coef = pd.DataFrame()
    for i in range(len(df_run_model)):
        make = df_run_model["smake"].values[i]
        smodel = df_run_model["smodel"].values[i]
        losscode = df_run_model["sloss_code"].values[i]

        mdl, coef, intercept, feat_name, r2_score, n_claim = run_regression(
            df, make, smodel, losscode, target_var, feature_ls_pre
        )
        itm = [make, smodel, losscode, coef, feat_name, intercept, r2_score, n_claim]
        df_itm = pd.DataFrame(itm).transpose()
        df_coef = pd.concat([df_coef, df_itm], axis=0)
        print(df_itm)
        print(f"R² score: {r2_score}")

    # Rename all the columns for coefficient
    df_coef.columns = [
        "smake",
        "smodel",
        "sloss_code",
        "coef",
        "feat",
        "intercept",
        "r2_score",
        "n_claims_trained",
    ]

    # Get today's timestamp
    current_timestamp = datetime.now()

    # Format the timestamp as a string
    formatted_timestamp = current_timestamp.strftime("%Y-%m-%d %H:%M:%S")

    df_coef["dtupdate"] = formatted_timestamp

    # convert output to dataframe and save it into S3s
    df_coef.to_parquet(data_sources["s3_files"]["cost_assessment_model_output"])
    print("All model trained successfully")


def split_by_rule_predictive(df_input: pd.DataFrame, claim_threshold: int):
    """This function is used to split features based on number of claims for
    each category.

    Parameters:
        df_input (pd.DataFrame): input dataframe with claims data
        claim_threshold: min sampling accepted to perform ML training

    Returns:
        pd.DataFrame: the dataframe that can be used on ML approach
        pd.DataFrame: dataframe used to apply rule based approach
    """

    # Get the input from feature engineering
    df = df_input.copy()

    # Specify claim status category by paid vs. not paid
    df["status_cat"] = np.where(
        df["sclaim_status"].str.lower() == "p", "paid", "not_paid"
    )

    # Run labor hours prediction model on paid claims only. So select sample size based on paid claims count
    paid_q = (
        df[df["sclaim_status"].str.lower() == "p"]
        .groupby(["smake", "smodel", "sloss_code"])["iclaim_id"]
        .nunique()
        .reset_index()
    )

    paid_q.rename(columns={"iclaim_id": "paid_claims"}, inplace=True)

    # Compile a dataframe with both total claim count and paid claim count by make, model and loss codes
    q = (
        df.groupby(["smake", "smodel", "sloss_code"])["iclaim_id"]
        .nunique()
        .reset_index()
    )
    q = pd.merge(
        q, paid_q, on=["smake", "smodel", "sloss_code"], how="left", validate=None
    )
    q["paid_claims"] = q["paid_claims"].fillna(0)

    # Split out 2 groups of the combinations: 1 for model, another one for rule based
    df_run_model = q[q["paid_claims"] >= claim_threshold]
    df_rule_based = q[q["paid_claims"] < claim_threshold]

    return df_run_model, df_rule_based


def flag_labor_hours_model():
    """This function is used to flag labor hours anomalies based on predictive
    model and rule-based model."""

    # Determine whether to run feature engineering
    if run_feature_engineering:
        print("Running feature engineering for labor hours prediction...")
        df = main_costmodel()
    else:
        print("Importing feature engineering for labor hours prediction...")

        # Load feature engineering output from S3:

        df = (
            spark.read.csv(
                data_sources["s3_files"]["cost_assessment_model_input"],
                header=True,
                inferSchema=True,
            )
        ).toPandas()

    # Split the feature table by # claims for each make + model + loss code category claim counts
    claim_threshold = int(filter_thresholds["claim_threshold"])
    print("Claim threshold", claim_threshold)

    df_run_model, df_rule_based = split_by_rule_predictive(df, claim_threshold)

    # Run prediction for the categories with enough claims
    get_labor_hours_prediction(df, df_run_model, target_var, feature_list_pre)
