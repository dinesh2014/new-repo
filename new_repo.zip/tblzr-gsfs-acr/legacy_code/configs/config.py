import os

from datetime import datetime
from utils.read_write_utils import read_yaml
from pathlib import Path


basedir = Path(__file__).parent.parent


def get_env_variables():
    env = os.getenv("ENV")

    base_path = "/Volumes/cat_gsfs"
    tier = ""
    if env == "dev":
        tier = "bronze"
    elif env == "test":
        tier = "silver"
    elif env == "prod":
        tier = "gold"

    return {
        "base_path": f"{base_path}/{tier}",
        "tier": tier,
        "deploy_service_principal": "5bf5b784-5083-4a2f-becd-9655d390dbcc",
        "env": os.getenv("ENV"),
    }


env_variables = get_env_variables()


# Loading config file
config_file = read_yaml("master_table_config.yml", env_variables)


def singleton(class_):
    instances = {}

    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]

    return getinstance


@singleton
class BaseConfigClass:
    BASE_PATH = basedir

    PRODUCT_CONFIG = read_yaml("product_config.yml", env_variables)
    MASTER_TABLE_CONFIG = read_yaml("master_table_config.yml", env_variables)
    PRE_COMPUTE_CONFIG = read_yaml("pre_compute.yml", env_variables)

    run_prod = PRODUCT_CONFIG["set_up_configuration"]["product"]
    print(f"*** INITIALIZING CONFIGURATION FOR {run_prod} ***")

    BREAKDOWN_PROB_CONFIG = read_yaml(
        f"{run_prod}/breakdown_prob_config.yml", env_variables
    )
    FEATURE_ENGINEERING_CONFIG = read_yaml(
        f"{run_prod}/feature_engineering_config.yml", env_variables
    )
    DATA_CLEANING_CONFIG = read_yaml(
        f"{run_prod}/data_cleaning_config.yml", env_variables
    )
    ACR_TOOL_CONFIG = read_yaml(f"{run_prod}/acr_tool_config.yml", env_variables)

    COST_ASSESSMENT_CONFIG = read_yaml(
        f"{run_prod}/cost_assessment_config.yml", env_variables
    )
    UNIT_PRICE_MODEL_CONFIG = read_yaml(
        f"{run_prod}/unit_price_model_config.yml", env_variables
    )

    # INFERENCE CONFIG:
    INF_STAKING_INFO_CONFIG = read_yaml(
        "inference_configuration/staking_info_config.yml", env_variables
    )
    INF_FEATURE_ENGINEERING_CONFIG = read_yaml(
        "inference_configuration/feature_engineering_config.yml", env_variables
    )
    INF_BREAKDOWN_CONFIG = read_yaml(
        "inference_configuration/inference_breakdown_config.yml", env_variables
    )
    KPI_REFRESHMENT_CONFIG = read_yaml(
        "inference_configuration/kpi_refreshment_config.yml", env_variables
    )
    TW_PREDICTION_CONFIG = read_yaml(
        "inference_configuration/tw_prediction_config.yml", env_variables
    )

    if run_prod not in ["VSC", "T&W"]:
        raise ValueError("Please choose the correct product name for configuration!")

    # Directories

    # Columns

    # Model param


BaseConfig = BaseConfigClass()
print("Config Created Time:", datetime.now().strftime("%H:%M:%S"))
