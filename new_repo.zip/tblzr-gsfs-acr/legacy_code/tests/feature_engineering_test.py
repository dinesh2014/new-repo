import pytest
import pandas as pd
import tests.dummy_params_test as inputs

from src.ai_training_pipeline.feature_engineering import (
    aggregate_claims_to_loss_type_level,
    generate_time_features,
    estimate_average_mileage_per_year,
)


@pytest.mark.parametrize(
    "input, expected",
    [
        (inputs.aggregate_claims_input, inputs.aggregate_claims_expected),
    ],
)
def test_aggregate_claims_to_loss_type_level(input, expected):
    pd.testing.assert_frame_equal(aggregate_claims_to_loss_type_level(input), expected)


@pytest.mark.parametrize(
    "input, expected",
    [
        (inputs.generate_time_features_input, inputs.generate_time_features_expected),
    ],
)
def test_generate_time_features(input, expected):
    pd.testing.assert_frame_equal(generate_time_features(input), expected)


@pytest.mark.parametrize(
    "input, expected",
    [
        (
            inputs.average_mileage_per_year_input,
            inputs.average_mileage_per_year_expected,
        ),
    ],
)
def test_generate_time_features(input, expected):
    pd.testing.assert_frame_equal(
        estimate_average_mileage_per_year(
            input, "vehicle_age", "mileage_per_year_ratio"
        ),
        expected,
    )
