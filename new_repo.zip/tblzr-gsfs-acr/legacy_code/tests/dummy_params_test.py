import pandas as pd

#############################
# Feature engineering inputs:
#############################

#######################################
# 1. aggregate_claims_to_loss_type_level
#######################################

# 1. Test aggregate_claims_to_loss_type_level (Input):
aggregate_claims_input = {
    "iclaim_id": [4866724, 4866724, 3692160, 3692160],
    "cretail_base_price": [21850, 91950, 18990, 83825],
    "iodometer_at_time_of_loss": [107517, 90636, 90411, 63605],
    "icontract_mileage": [125000, 24000, 100000, 125000],
    "icontract_term": [84, 24, 48, 48],
    "camt_paid": [59.97, 1200, 734.35, 104.47],
    "cretail_rate": [2375, 3510, 1876, 1507],
    "cnet_rate": [1041, 2510, 1176, 1307],
    "cpremium_rate": [629.85, 1463.37, 822.39, 934.5],
    "creq_unit_cost": [99.95, 120, 152.99, 96.51],
    "sloss_code": [24003, 24003, 6005, 9087],
}

# 1. Calculate mean expected result:
aggregate_claims_expected = {
    "iclaim_id": [4866724, 3692160, 3692160],
    "sloss_code": [24003, 6005, 9087],
    "cretail_base_price": [91950, 18990, 83825],
    "iodometer_at_time_of_loss": [107517, 90411, 63605],
    "icontract_mileage": [125000, 100000, 125000],
    "icontract_term": [84, 48, 48],
    "camt_paid": [1259.97, 734.35, 104.47],
    "cretail_rate": [3510, 1876, 1507],
    "cnet_rate": [2510, 1176, 1307],
    "cpremium_rate": [1463.37, 822.39, 934.5],
    "creq_unit_cost": [120, 152.99, 96.51],
}

aggregate_claims_expected = pd.DataFrame(aggregate_claims_expected)
aggregate_claims_input = pd.DataFrame(aggregate_claims_input)

#######################################
# 2. aggregate_claims_to_loss_type_level
#######################################

# 2. Test generate_time_features (Input):
generate_time_features_input = {
    "iclaim_id": [4866724, 4866744, 3692160, 3692160],
    "dtdate_loss_occurred": ["2021-05-26", "2021-05-26", "2020-11-23", "2023-01-17"],
}

# 2. Test generate_time_features (Expected):
generate_time_features_expected = {
    "iclaim_id": [4866724, 4866744, 3692160, 3692160],
    "dtdate_loss_occurred": ["2021-05-26", "2021-05-26", "2020-11-23", "2023-01-17"],
    "month_loss_occurred": [5, 5, 11, 1],
    "year_loss_occurred": [2021, 2021, 2020, 2023],
}

generate_time_features_input = pd.DataFrame(generate_time_features_input)
generate_time_features_expected = pd.DataFrame(generate_time_features_expected)
generate_time_features_expected["dtdate_loss_occurred"] = pd.to_datetime(
    generate_time_features_expected["dtdate_loss_occurred"]
)

generate_time_features_expected["month_loss_occurred"] = (
    generate_time_features_expected["month_loss_occurred"].astype("int32")
)

generate_time_features_expected["year_loss_occurred"] = generate_time_features_expected[
    "year_loss_occurred"
].astype("int32")

#######################################
# 3. estimate_average_mileage_per_year
#######################################

average_mileage_per_year_input = {
    "iclaim_id": [4000939, 3839643, 3861741],
    "imodel_year": [2016, 2019, 2014],
    "smake": ["chevrolet", "toyota", "toyota"],
    "smodel": ["silverado", "camry", "4runner"],
    "iodometer_at_time_of_loss": [112940, 36715, 73769],
    "dtdate_loss_occurred": ["2021-05-26", "2020-10-27", "2020-11-23"],
}

average_mileage_per_year_expected = {
    "iclaim_id": [4000939, 3839643, 3861741],
    "imodel_year": [2016, 2019, 2014],
    "smake": ["chevrolet", "toyota", "toyota"],
    "smodel": ["silverado", "camry", "4runner"],
    "iodometer_at_time_of_loss": [112940, 36715, 73769],
    "dtdate_loss_occurred": ["2021-05-26", "2020-10-27", "2020-11-23"],
    "vehicle_age": [5.40, 1.82, 6.90],
    "mileage_per_year_ratio": [1.0, 1.0, 1.0],
    "mileage_per_year_segment": [20914.0, 20173.0, 10691.0],
}

average_mileage_per_year_input = pd.DataFrame(average_mileage_per_year_input)
average_mileage_per_year_expected = pd.DataFrame(average_mileage_per_year_expected)

average_mileage_per_year_expected["mileage_per_year_ratio"] = (
    average_mileage_per_year_expected["mileage_per_year_ratio"].astype("float64")
)

##################
# Breakdown Model:
##################

hot_encode_input = {
    "iclaim_id": [1, 2, 3, 4],
    "snew_used": ["n", "u", "n", "n"],
    "sbody_style": ["sd", "ut", "ut", "sd"],
    "sfuel": ["g", "g", "g", "f"],
    "sdriving_type": ["fwd", "fwd", "4rd", "4rd"],
    "spayee_state": ["tx", "al", "tx", "tx"],
    "urbanicity": ["urban", "suburban", "urban", "urban"],
}

hot_encode_expected = {
    "iclaim_id": [1, 2, 3, 4],
    "snew_used_n": [True, False, True, True],
    "snew_used_u": [False, True, False, False],
    "sbody_style_sd": [True, False, False, True],
    "sbody_style_ut": [False, True, True, False],
    "sfuel_f": [False, False, False, True],
    "sfuel_g": [True, True, True, False],
    "sdriving_type_4rd": [False, False, True, True],
    "sdriving_type_fwd": [True, True, False, False],
    "spayee_state_al": [False, True, False, False],
    "spayee_state_tx": [True, False, True, True],
    "urbanicity_suburban": [False, True, False, False],
    "urbanicity_urban": [True, False, True, True],
}
hot_encode_input = pd.DataFrame(hot_encode_input)
hot_encode_expected = pd.DataFrame(hot_encode_expected)
