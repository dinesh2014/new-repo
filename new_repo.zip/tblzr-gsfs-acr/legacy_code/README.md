# tblzr_gsfs_poc

=========================

This document contains the guidelines for developers who want to contribute to the codebase.

- [1. Setup](#1-setup)
  - [1.1. Python version](#11-install-environment)
  - [1.2. Create virtual env](#12-create-viritual-environment)
  - [1.3. Install dependencies](#13-install-dependencies)
  - [1.4. Install pre-commit](#14-install-pre-commit)
- [2. Tool components](#2-tool-components)
- [3. Running the code](#3-running-the-code)
- [4. Best practices with GitHub Flow](#4-best-practices-with-github-flow)
- [5. Generate documentation html](#5-generate-documentation-html)
- [6. Run PyLint Security and Code Quality Report](#6-run-pylint-security-and-code-quality-report)


# 1. Setup

## 1.1. Install environment
This repository requires Python 3.11.6. To manage multiple Python versions we recommend using `pyenv`.

- Install pyenv, see [docs](https://github.com/pyenv/pyenv?tab=readme-ov-file#installation)
- Configure your shell's environment for pyenv, see [docs](https://github.com/pyenv/pyenv#set-up-your-shell-environment-for-pyenv)
- Install the required Python version:
shell
pyenv install 3.11.6
- Temporarily set it as the python version for the current shell session:
shell
pyenv shell 3.11.6
Note that you can also permanently set the Python version using:
pyenv global 3.11.6

## 1.2. Create virtual environment

After having installed the required Python version, we recommend using `venv` to create a virtual environment for this project.

Run from the root folder:

shell
python -m venv .venv

Activate the virtual environment:

> On Windows:

shell
> .venv\Scripts\activate.bat
>

## 1.3. Install dependencies

Install the required dependencies with pip:

shell
pip install -r requirements.txt

## 1.4. Install pre-commit

This project uses [pre-commit hooks](https://pre-commit.com/) to maintain code quality,
following [PEP8](https://www.python.org/dev/peps/pep-0008/) style guide with  line length 120. To install them, run:

shell
pre-commit install

Pre-commit hooks will be run automatically before every commit. If any of them fails, the commit will be aborted.
You will have to fix the issues before committing again.

The pre-commit hooks can be triggered manually by running:

shell
pre-commit run

## 2. Tool components

Following image shows the architecture of the ACR tool repo. Please notice this is build following
the logic of store configuration, source code and utils functions pragmatically.
![img_2.png](img_2.png)
First component to consider are the configuration of each module (VSC, TW and inference piece)
under the relative path ´´configs´´. This will serve as a parameter setting across mayor modules on the tool

Secondly, one can notice all the codebase is stored under ´´src´´. Under this folder there are the mayor
three modules for train machine learning models (using the path ´´ai_training_pipeline´´), create and preload
table on S3 cluster (´´nightly_computation_pipeline´´) and finally consider the module to process real time claims
and estimate risk checks based on ML and rule base definition (´´inference_pipeline´´).

Finally, one more folder is considering all functions and algorithms to
serve multiple functions across BU and modules. These are loaded under ´´utils´´.


## 3. Running the code

This tool belong to a full DataBricks environment. Having an active account and being able to access
to inputs stored into the Catalog is a must. Please refer to the official tool documentation on Jira
to map those file dependencies in details.

To execute ´´inference_pipeline´´ and ´´nightly_computation_pipeline´´, and other sub jobs
required to generate tool request are already exists the following  jobs that can handle request
based on a scheduler or by real time request coming as an API request.

**Jobs listed on DataBricks with main module**

* acr-prod-inference-engine - src/inference_pipeline/main.py
* acr-prod-nightly-pipeline - src/nightly_computation_pipeline/pre_compute.py
* acr-prod-preload-tables - src/nightly_computation_pipeline/preload_precompute.py
* acr-prod-static-pipeline - src/static_pipeline/static_features.py

If for any reason, the user want so execute one of these jobs, the only action need it is to
open the python module listed above and execute a new request on Databricks console.

## 4. Best practices with GitHub Flow

We use GitHub Flow for our workflow. Here's a quick rundown:

1.  Branch: Create a branch from main for each new feature or improvement.
2.  Commit: Make your changes and commit to your branch.
3.  Pull Request: When you're ready, open a pull request for review.
4.  Review & Collaborate: Discuss and review your code with the team.
5.  Deploy: Test your changes in a staging or production environment.
6.  Merge: Once everything is tested and approved, merge your changes into the main.

# 5. Run PyLint and Safety Security and Code Quality Report
1. Run `pylint src > pylint_report.txt` to generate the pylint code quality report
2. Run `safety check --full-report > safety_report.txt` to generate the safety security of your current virtual env or run `safety check --full-report --file=requirements.txt > safety_report.txt` to generate the safety security of your project dependencies

Contributing
Please read CONTRIBUTING.md for details on our code of conduct and the process for submitting pull requests to us.

Versioning
We use SemVer for versioning. For the versions available, see the tags on this repository.

Authors
Your Name - Initial work - TheSinghAjit
See also the list of contributors who participated in this project.

License


Contact
For any inquiries, please reach out to asingh@friedkin.com.

