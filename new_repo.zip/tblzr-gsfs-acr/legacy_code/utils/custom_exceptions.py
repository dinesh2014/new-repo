# Custom error to map when there is a missing active contract on master table:
class MissingActiveContractError(Exception):
    def __init__(
        self, message="Request consider a non-active contract on master table"
    ):
        self.message = message
        super().__init__(self.message)


class MissingLaborDetailsError(Exception):
    def __init__(
        self, message="Cannot calculate Labor predictions. Labor details are missing."
    ):
        self.message = message
        super().__init__(self.message)
