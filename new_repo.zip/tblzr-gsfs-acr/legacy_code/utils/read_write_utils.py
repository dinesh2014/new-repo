import os
import yaml
from pathlib import Path
from jinja2 import Template

# Get the current script's directory
script_dir = os.path.dirname(os.path.realpath(__file__))


def read_yaml(yaml_file_name: str, env_variables):
    """Auxiliary function to real yaml files.

    :return:
    """

    # Specify the path to your YAML file in the config folder
    yaml_file_path = os.path.join(Path(script_dir).parent, "configs", yaml_file_name)

    with open(yaml_file_path, "r") as yaml_file:
        template = Template(yaml_file.read())
        rendered = template.render(**env_variables)

        config_data = yaml.safe_load(rendered)
    return config_data
