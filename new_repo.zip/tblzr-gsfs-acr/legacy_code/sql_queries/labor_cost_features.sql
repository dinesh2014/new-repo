
----- Generate dealer size by claim date table for cost assessment - labor hours prediction model

---- Get the dealer size, # contracts for each dealer hold at that time
drop table [bcg].[dbo].dealer_size_by_claimdate;
    select a.iclaim_id,
    a.dtdate_loss_occurred,
    a.spayee_no,
    count(Distinct b.icontract_id) dealer_n_contract_hold
    into [bcg].[dbo].dealer_size_by_claimdate
    from [bcg].[dbo].final_clean_master_table  a
    left join [scs_auto_gsfs].[dbo].scs_contracts b
    on a.spayee_no = b.sdealer_number and
     a.sdetail_type='L'
     and a.btcovered_flag = 1 and
     a.dtdate_loss_occurred between b.dtcontract_effect and b.dtcontract_expiration
    and a.dtdate_loss_occurred <= b.dtcontract_eff_cancell
    and a.dtdate_loss_occurred >= '2019-12-01' and b.iproduct_type_id= 4
    group by a.iclaim_id, a.dtdate_loss_occurred,a.spayee_no
