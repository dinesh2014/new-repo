/*
**  This script allows you to import multiple delimited text files into a SQL database. The tables
**  into which the data is imported, including all required columns, are created automatically. This
**  script uses tab-delimited (tsv) files and SQL Server Management Studio. The script may need some
**  minor adjustments for other formats and tools. The scripts makes several assumptions which need
**  to be valid before it can run properly. First of all, it assumes none of the output tables exist
**  in the SQL tool before starting. Therefore, it may be necessary to clean the database and delete
**  all the existing tables. Secondly, the script assumes that, if multiple text files are imported
**  into the same output table, the number and order of the columns of these files is identical. If
**  this is not the case, some manual work may need to be done to the text files before importing.
**  Finally, please note that this script only imports data as strings (to be precise, as NVARCHAR's
**  of length 255). It does not allow you to specify the datatype per column. This would need to be
**  done using another script after importing the data as strings.
*/

-- 1.   Import Multiple Delimited Text Files into a SQL Database

-- 1.1  Define the path to the input and define the terminators

/*
**  In this section, some initial parameters are set. Obviously, the 'DatabaseName' refers to the
**  database in which you want to create new tables. The '@Path' parameter sets the folder in
**  which the text files are located which you want to import. Delimited files are defined by
**  two characters: one which separates columns and one which separates rows. Usually, the
**  row-terminator is the newline character CHAR(10), also given by '\n'. When files are created
**  in Windows, the row-terminator often includes a carriage return CHAR(13), also given by '\r\n'.
**  Often, a tab is used to separate each column. This is given by CHAR(9) or by the character '\t'.
**  Other useful characters include the comma CHAR(44), the semi-colon CHAR(59) and the pipe
**  CHAR(124).
*/

USE [bcg]
DECLARE @Path NVARCHAR(255) = '\\GSFS-ScsSQL-D01\scsexpress\FileTransfer\SCSFileTransferGSFS\FORTE_PARTS\INBOUND\Archive\'
DECLARE @HeaderTable NVARCHAR(50) = 'forte_header.txt'
DECLARE @RowTerminator NVARCHAR(5) = CHAR(13) + CHAR(10)
DECLARE @ColumnTerminator NVARCHAR(5) = CHAR(9)

-- 1.2  Define the list of input and output in a temporary table

/*
**  In this section, a temporary table is created which lists all the filenames of the delimited
**  files which need to be imported, as well as the names of the tables which are created and into
**  which the data is imported. Multiple files may be imported into the same output table. Each row
**  is prepended with an integer which increments up starting from 1. It is essential that this
**  number follows this logic. The temporary table is deleted at the end of this script.
*/

IF OBJECT_ID('[dbo].[Files_Temporary]', 'U') IS NOT NULL
DROP TABLE [dbo].[Files_Temporary];
CREATE TABLE [dbo].[Files_Temporary]
(
    [ID] INT
    , [FileName] NVARCHAR(255)
    , [TableName] NVARCHAR(255)
);

----INSERT INTO [dbo].[Files_Temporary] SELECT 1,   'puv2.txt',  'table1'
-----INSERT INTO [dbo].[Files_Temporary] SELECT 2,   'puv201092024_085956.txt',  'table2'

INSERT INTO [dbo].[Files_Temporary] SELECT 1 , 'puv2.txt',  'table 1'
INSERT INTO [dbo].[Files_Temporary] SELECT 2 , 'puv201092024_085956.txt',  'table 2'
INSERT INTO [dbo].[Files_Temporary] SELECT 3 , 'puv201042024_090614.txt',  'table 3'
INSERT INTO [dbo].[Files_Temporary] SELECT 4 , 'puv212282023_105109.txt',  'table 4'
INSERT INTO [dbo].[Files_Temporary] SELECT 5 , 'puv210172023_115411.txt',  'table 5'
INSERT INTO [dbo].[Files_Temporary] SELECT 6 , 'puv210102023_093959.txt',  'table 6'
INSERT INTO [dbo].[Files_Temporary] SELECT 7 , 'puv210052023_110508.txt',  'table 7'
INSERT INTO [dbo].[Files_Temporary] SELECT 8 , 'puv210022023_091607.txt',  'table 8'
INSERT INTO [dbo].[Files_Temporary] SELECT 9 , 'puv209112023_105453.txt',  'table 9'
INSERT INTO [dbo].[Files_Temporary] SELECT 10 , 'puv209052023_093948.txt',  'table 10'
INSERT INTO [dbo].[Files_Temporary] SELECT 11 , 'puv209012023_094553.txt',  'table 11'
INSERT INTO [dbo].[Files_Temporary] SELECT 12 , 'puv208082023_104327.txt',  'table 12'
INSERT INTO [dbo].[Files_Temporary] SELECT 13 , 'puv208042023_100359.txt',  'table 13'
INSERT INTO [dbo].[Files_Temporary] SELECT 14 , 'puv208012023_110329.txt',  'table 14'
INSERT INTO [dbo].[Files_Temporary] SELECT 15 , 'puv207102023_100212.txt',  'table 15'
INSERT INTO [dbo].[Files_Temporary] SELECT 16 , 'puv207062023_101909.txt',  'table 16'
INSERT INTO [dbo].[Files_Temporary] SELECT 17 , 'puv206302023_101938.txt',  'table 17'
INSERT INTO [dbo].[Files_Temporary] SELECT 18 , 'puv206122023_110646.txt',  'table 18'
INSERT INTO [dbo].[Files_Temporary] SELECT 19 , 'puv206092023_114026.txt',  'table 19'
INSERT INTO [dbo].[Files_Temporary] SELECT 20 , 'puv206052023_103853.txt',  'table 20'
INSERT INTO [dbo].[Files_Temporary] SELECT 21 , 'puv206052023_102559.txt',  'table 21'
INSERT INTO [dbo].[Files_Temporary] SELECT 22 , 'puv206012023_222633.txt',  'table 22'
INSERT INTO [dbo].[Files_Temporary] SELECT 23 , 'puv205162023_120202.txt',  'table 23'
INSERT INTO [dbo].[Files_Temporary] SELECT 24 , 'puv205112023_112045.txt',  'table 24'
INSERT INTO [dbo].[Files_Temporary] SELECT 25 , 'puv205102023_091524.txt',  'table 25'
INSERT INTO [dbo].[Files_Temporary] SELECT 26 , 'puv205042023_094134.txt',  'table 26'
INSERT INTO [dbo].[Files_Temporary] SELECT 27 , 'puv205012023_110105.txt',  'table 27'
INSERT INTO [dbo].[Files_Temporary] SELECT 28 , 'puv204102023_095131.txt',  'table 28'
INSERT INTO [dbo].[Files_Temporary] SELECT 29 , 'puv204032023_115528.txt',  'table 29'
INSERT INTO [dbo].[Files_Temporary] SELECT 30 , 'puv203072023_202823.txt',  'table 30'
INSERT INTO [dbo].[Files_Temporary] SELECT 31 , 'puv203012023_115952.txt',  'table 31'
INSERT INTO [dbo].[Files_Temporary] SELECT 32 , 'puv202102023_103634.txt',  'table 32'
INSERT INTO [dbo].[Files_Temporary] SELECT 33 , 'puv202012023_111044.txt',  'table 33'
INSERT INTO [dbo].[Files_Temporary] SELECT 34 , 'puv201092023_102135.txt',  'table 34'
INSERT INTO [dbo].[Files_Temporary] SELECT 35 , 'puv201062023_202540.txt',  'table 35'
INSERT INTO [dbo].[Files_Temporary] SELECT 36 , 'puv201032023_094103.txt',  'table 36'
INSERT INTO [dbo].[Files_Temporary] SELECT 37 , 'puv205092022_114909.txt',  'table 37'
INSERT INTO [dbo].[Files_Temporary] SELECT 38 , 'puv205052022_111853.txt',  'table 38'
INSERT INTO [dbo].[Files_Temporary] SELECT 39 , 'puv205022022_131818.txt',  'table 39'
INSERT INTO [dbo].[Files_Temporary] SELECT 40 , 'puv204112022_163607.txt',  'table 40'
INSERT INTO [dbo].[Files_Temporary] SELECT 41 , 'puv204012022_163407.txt',  'table 41'
INSERT INTO [dbo].[Files_Temporary] SELECT 42 , 'puv203112022_150557.txt',  'table 42'
INSERT INTO [dbo].[Files_Temporary] SELECT 43 , 'puv203092022_100924.txt',  'table 43'
INSERT INTO [dbo].[Files_Temporary] SELECT 44 , 'puv203072022_095139.txt',  'table 44'
INSERT INTO [dbo].[Files_Temporary] SELECT 45 , 'puv203012022_092642.txt',  'table 45'
INSERT INTO [dbo].[Files_Temporary] SELECT 46 , 'puv202082022_095053.txt',  'table 46'
INSERT INTO [dbo].[Files_Temporary] SELECT 47 , 'puv202042022_090410.txt',  'table 47'
INSERT INTO [dbo].[Files_Temporary] SELECT 48 , 'puv202012022_132430.txt',  'table 48'
INSERT INTO [dbo].[Files_Temporary] SELECT 49 , 'puv201182022_090015.txt',  'table 49'
INSERT INTO [dbo].[Files_Temporary] SELECT 50 , 'puv201102022_092126.txt',  'table 50'
INSERT INTO [dbo].[Files_Temporary] SELECT 51 , 'puv201032022_104713.txt',  'table 51'
INSERT INTO [dbo].[Files_Temporary] SELECT 52 , 'puv212092021_084459.txt',  'table 52'
INSERT INTO [dbo].[Files_Temporary] SELECT 53 , 'puv202112021_101702.txt',  'table 53'
INSERT INTO [dbo].[Files_Temporary] SELECT 54 , 'puv202082021_103206.txt',  'table 54'
INSERT INTO [dbo].[Files_Temporary] SELECT 55 , 'puv202012021_230213.txt',  'table 55'
INSERT INTO [dbo].[Files_Temporary] SELECT 56 , 'puv201152021_094928.txt',  'table 56'
INSERT INTO [dbo].[Files_Temporary] SELECT 57 , 'puv201112021_090819.txt',  'table 57'
INSERT INTO [dbo].[Files_Temporary] SELECT 58 , 'puv201062021_095241.txt',  'table 58'
INSERT INTO [dbo].[Files_Temporary] SELECT 59 , 'puv201052021_141752.txt',  'table 59'
INSERT INTO [dbo].[Files_Temporary] SELECT 60 , 'puv201042021_123222.txt',  'table 60'
INSERT INTO [dbo].[Files_Temporary] SELECT 61 , 'puv205102020_211535.txt',  'table 61'
INSERT INTO [dbo].[Files_Temporary] SELECT 62 , 'puv205052020_131418.txt',  'table 62'
INSERT INTO [dbo].[Files_Temporary] SELECT 63 , 'puv205012020_125051.txt',  'table 63'
INSERT INTO [dbo].[Files_Temporary] SELECT 64 , 'puv204132020_093413.txt',  'table 64'
INSERT INTO [dbo].[Files_Temporary] SELECT 65 , 'puv204072020_125417.txt',  'table 65'
INSERT INTO [dbo].[Files_Temporary] SELECT 66 , 'puv204032020_120750.txt',  'table 66'
INSERT INTO [dbo].[Files_Temporary] SELECT 67 , 'puv204012020_143727.txt',  'table 67'
INSERT INTO [dbo].[Files_Temporary] SELECT 68 , 'puv203062020_113952.txt',  'table 68'
INSERT INTO [dbo].[Files_Temporary] SELECT 69 , 'puv203042020_120724.txt',  'table 69'
INSERT INTO [dbo].[Files_Temporary] SELECT 70 , 'puv203032020_115208.txt',  'table 70'
INSERT INTO [dbo].[Files_Temporary] SELECT 71 , 'puv203022020_124335.txt',  'table 71'
INSERT INTO [dbo].[Files_Temporary] SELECT 72 , 'puv202112020_112128.txt',  'table 72'
INSERT INTO [dbo].[Files_Temporary] SELECT 73 , 'puv202092020_095438.txt',  'table 73'
INSERT INTO [dbo].[Files_Temporary] SELECT 74 , 'puv202062020_111753.txt',  'table 74'





-- 1.3  Loop over the list of input and output and import each file to the correct table

/*
**  In this section, the 'WHILE' statement is used to loop over all input files. A counter is defined
**  which starts at '1' and increments with each iteration. The filename and tablename are retrieved
**  from the previously defined temporary table. The next step of the script is to check whether the
**  output table already exists or not.
*/

DECLARE @Counter INT = 1

WHILE @Counter <= (SELECT COUNT(*) FROM [dbo].[Files_Temporary])
BEGIN
    PRINT 'Counter is ''' + CONVERT(NVARCHAR(5), @Counter) + '''.'

    DECLARE @FileName NVARCHAR(255)
    DECLARE @TableName NVARCHAR(255)
    DECLARE @Header NVARCHAR(MAX)
    DECLARE @SQL_Header NVARCHAR(MAX)
    DECLARE @CreateHeader NVARCHAR(MAX) = ''
    DECLARE @SQL_CreateHeader NVARCHAR(MAX)
	DECLARE @ColumnTableName NVARCHAR(128) = 'scs_parts_import_temp'

    SELECT @FileName = [FileName], @TableName = [TableName] FROM [dbo].[Files_Temporary] WHERE [ID] = @Counter

    IF OBJECT_ID('[dbo].[' + @TableName + ']', 'U') IS NULL
    BEGIN
/*
**  If the output table does not yet exist, it needs to be created. This requires the list of all
**  columnnames for that table to be retrieved from the first line of the text file, which includes
**  the header. A piece of SQL code is generated and executed which imports the header of the text
**  file. A second temporary table is created which stores this header as a single string.
*/
        PRINT 'Creating new table with name ''' + @TableName + '''.'

        IF OBJECT_ID('[dbo].[Header_Temporary]', 'U') IS NOT NULL
        DROP TABLE [dbo].[Header_Temporary];
        CREATE TABLE [dbo].[Header_Temporary]
        (
            [Header] NVARCHAR(MAX)
        );

		SET @SQL_Header = '
            BULK INSERT [dbo].[Header_Temporary]
            FROM ''' + @Path + @HeaderTable + '''
            WITH
            (
                FIRSTROW = 1,
                LASTROW = 1,
                MAXERRORS = 0,
                FIELDTERMINATOR = ''' + @RowTerminator + ''',
                ROWTERMINATOR = ''' + @RowTerminator + '''
            )'
        EXEC(@SQL_Header)


        SET @Header = (SELECT TOP 1 [Header] FROM [dbo].[Header_Temporary])
        PRINT 'Extracted header ''' + @Header + ''' for table ''' + @TableName + '''.'
/*
**  The columnnames in the header are separated using the column-terminator. This can be used to loop
**  over each columnname. A new piece of SQL code is generated which will create the output table
**  with the correctly named columns.
*/
        WHILE CHARINDEX(@ColumnTerminator, @Header) > 0
        BEGIN
            SET @CreateHeader = @CreateHeader + '[' + LTRIM(RTRIM(SUBSTRING(@Header, 1, CHARINDEX(@ColumnTerminator, @Header) - 1))) + '] NVARCHAR(255), '
            SET @Header = SUBSTRING(@Header, CHARINDEX(@ColumnTerminator, @Header) + 1, LEN(@Header))
        END
        SET @CreateHeader = @CreateHeader + '[' + @Header + '] NVARCHAR(255)'

        SET @SQL_CreateHeader = 'CREATE TABLE [' + @TableName + '] (' + @CreateHeader + ')'
        EXEC(@SQL_CreateHeader)
    END

/*
**  Finally, the data from the text file is imported into the newly created table. The first line,
**  including the header information, is skipped. If multiple text files are imported into the same
**  output table, it is essential that the number and the order of the columns is identical, as the
**  table will only be created once, using the header information of the first text file.
*/
    PRINT 'Inserting data from ''' + @FileName + ''' to ''' + @TableName + '''.'
    DECLARE @SQL NVARCHAR(MAX)
    SET @SQL = '
        BULK INSERT [dbo].[' + @TableName + ']
        FROM ''' + @Path + @FileName + '''
        WITH
        (
            FIRSTROW = 2,
            MAXERRORS = 0,
            FIELDTERMINATOR = ''' + @ColumnTerminator + ''',
            ROWTERMINATOR = ''' + @RowTerminator + '''
        )'
    EXEC(@SQL)

    SET @Counter = @Counter + 1
END;

-- 1.4  Cleanup temporary tables

/*
**  In this section, the temporary tables which were created and used by this script are deleted.
**  Alternatively, the script could have used 'real' temporary table (identified by the '#' character
**  in front of the name) or a table variable. These would have deleted themselves once they were no
**  longer in use. However, the end result is the same.
*/

