declare @pre_mon int;
set @pre_mon = 3;

WITH a AS (
    SELECT DISTINCT
        spayee_no,
        icontract_id,
        iclaim_id,
        dtpaid
    FROM [bcg].[dbo].[final_clean_master_table]
    where iproduct_type_id = 4
),
b AS (
    SELECT DISTINCT
        spayee_no,
        icontract_id AS icontract_id2,
        dtcontract_eff_cancell,
        dtcontract_effect,
        dtcontract_expiration,
        ctotal_earned_prem,
        cpremium_rate
    FROM [bcg].[dbo].[final_clean_master_table]
    where iproduct_type_id = 4
)


SELECT a.spayee_no, icontract_id, iclaim_id, dtpaid, count(distinct icontract_id2) nb_contract,
sum(ctotal_earned_prem) earned_prem_total, sum(cpremium_rate) prem_Rate
into [bcg].[dbo].previous_x_month_total_earned_percent
FROM a
LEFT JOIN b ON a.spayee_no = b.spayee_no
    AND b.dtcontract_effect < a.dtpaid
    AND b.dtcontract_expiration > DATEADD(MONTH, -@pre_mon, a.dtpaid)
    AND (b.dtcontract_eff_cancell IS NULL OR b.dtcontract_eff_cancell > DATEADD(MONTH, -@pre_mon, a.dtpaid))
group by a.spayee_no, icontract_id, iclaim_id, dtpaid;



declare @pre_mon int;
set @pre_mon = 3;
WITH a AS (
    SELECT DISTINCT
        spayee_no,
        icontract_id,
        iclaim_id,
        dtpaid
    FROM [bcg].[dbo].[final_clean_master_table]
    where iproduct_type_id = 4
)

select m.spayee_no,
m.icontract_id,
m.iclaim_id,
m.dtpaid,
m.nb_contract,
m.earned_prem_total,
m.prem_rate,
count(distinct a.iclaim_id) nb_paid_claims
into [bcg].[dbo].previsou3month_total_claim_req_pre
from [bcg].[dbo].previous_x_month_total_earned_percent m
left join a
on m.spayee_no = a.spayee_no
and m.dtpaid>a.dtpaid
and a.dtpaid>dateadd(MONTH, -@pre_mon, m.dtpaid)
group by
m.spayee_no,
m.icontract_id,
m.iclaim_id,
m.dtpaid,
m.nb_contract,
m.earned_prem_total,
m.prem_rate



select a.*,
nb_paid_claims/nullif((earned_prem_total/nullif(prem_rate,0)),0)/nb_contract claim_freq
into [bcg].[dbo].previsou3month_total_claim_req
from  [bcg].[dbo].previsou3month_total_claim_req_pre a

select top 5 * from [bcg].[dbo].previous_total_claim_req_part
