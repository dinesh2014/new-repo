------ Merge all tables together

truncate table  [bcg].[dbo].[historical_forte_parts];


TRUNCATE TABLE  [bcg].[dbo].[historical_forte_part_pricing];

-- Declare variables for cursor and other required variables
USE [BCG]
DECLARE @TableName NVARCHAR(128);
DECLARE @SQL_Insert NVARCHAR(MAX);
DECLARE @Cursor CURSOR;

-- Create a cursor to loop through the small tables
SET @Cursor = CURSOR FOR
SELECT name
FROM sys.tables
WHERE (name LIKE '%table 1%') or (name LIKE '%table 2%') or (name LIKE '%table 3%') or (name LIKE '%table 4%')
-- Initialize the cursor
OPEN @Cursor;

-- Fetch the first table name from the cursor
FETCH NEXT FROM @Cursor INTO @TableName;

-- Loop through the small tables
WHILE @@FETCH_STATUS = 0
BEGIN
    -- Dynamic SQL to insert data from the current small table into the master table
    SET @SQL_Insert = '
        INSERT INTO [dbo].[historical_forte_part_pricing]
        SELECT * FROM ' + QUOTENAME(@TableName);

    -- Execute the dynamic SQL
    EXEC sp_executesql @SQL_Insert;

    -- Fetch the next table name from the cursor
    FETCH NEXT FROM @Cursor INTO @TableName;
	print  'Inserted ''' + @TableName + '''.'
END;

-- Close and deallocate the cursor
CLOSE @Cursor;
DEALLOCATE @Cursor;




---------Generate from_date and to_date
drop table [bcg].[dbo].[historical_forte_parts_process1];
drop table [bcg].[dbo].[historical_forte_parts_process2];

(select distinct part_no from claim_master_table)

select b.*
into  [bcg].[dbo].[historical_forte_parts_process1]
from
(SELECT a.*,
        LEAD(dtretail_date) OVER
           (PARTITION BY scurrency_type, soem_code, spart_number, spart_status, spart_desc ORDER BY dtretail_date) AS to_date
		   ,
		LAG(dtretail_date) OVER
          (PARTITION BY scurrency_type, soem_code, spart_number, spart_status, spart_desc ORDER BY dtretail_date) AS previous_date
FROM  [bcg].[dbo].[historical_forte_part_pricing] a
where spart_number in (select distinct spart_no from claim_master_table)) as b ;



select b.*
into  [bcg].[dbo].[historical_forte_parts_process2]
from
(select
scurrency_type,
soem_code,
spart_number,
cretail_price,
dtretail_date,
spart_status,
spart_desc,
ssuperceded_number,
case when dtretail_date is not null and previous_date is null then cast('1998-01-01' as date) else dtretail_date end from_date,
case when dtretail_date is not null and previous_date is null then dtretail_date else to_date end to_date
from [bcg].[dbo].[historical_forte_parts_process1]
where previous_date is null
union
select
scurrency_type,
soem_code,
spart_number,
cretail_price,
dtretail_date,
spart_status,
spart_desc,
ssuperceded_number,
dtretail_date from_date,
case when to_date is null then cast('2025-01-01' as date) else to_date end to_date
from [bcg].[dbo].[historical_forte_parts_process1]
where previous_date is not null) b ;

drop table [bcg].[dbo].[historical_forte_parts];


select *
into [bcg].[dbo].[historical_forte_parts]
from
[bcg].[dbo].[historical_forte_parts_process2]





select
top 5 * from
[bcg].[dbo].claim_master_table a
left join
--[bcg].[dbo].[historical_forte_parts] b
[bcg].[dbo].[historical_forte_parts_process2] b
on a.smanufacturer_code = b.soem_code and a.spart_no = b.spart_number and a.dtclaim_system_entry_date > b.from_date and a.dtclaim_system_entry_date<b.to_date





select top 5 * from [bcg].[dbo].[historical_forte_part_pricing]
where spart_number = '0083252500'

select top 100 * from [bcg].[dbo].[puv2]

 CREATE TABLE [bcg].[dbo].[Header_Temporary]
        (
            [Header] NVARCHAR(MAX)
        );
select * from  [bcg].[dbo].[Header_Temporary]

insert into [bcg].[dbo].[Header_Temporary]
select a.* from
(select column_name header from information_schema.columns where table_name = 'scs_parts_import_temp' and ordinal_position >1) a

select column_name from information_schema.columns
where table_name = 'scs_parts_import_temp' and ordinal_position >1

select top 100 * from

select top 100 * from

drop table [bcg].[dbo].puv201092024_085956
drop table [bcg].[dbo].puv2

select * from [bcg].[dbo].Header_Temp2


select top 100 * from  [bcg].[dbo].puv201092024_085956
where ssuperceded_number is not null
drop table [bcg].[dbo].puv2




truncate table [bcg].[dbo].[historical_forte_part_pricing]

select *
into [bcg].[dbo].[historical_forte_part_pricing]
from

insert into [bcg].[dbo].[historical_forte_part_pricing]
select a.*
from
(select * from [bcg].[dbo].[table 1]
union
select * from [bcg].[dbo].[table 2]
union
select * from [bcg].[dbo].[table 3]
union
select * from [bcg].[dbo].[table 4]) a


