declare @min_date date;
declare @max_date date;
set @min_date = '2023-01-01';
set @max_date = '2023-12-31';

SELECT
iclaim_id,
mast.icontract_id,
dtclaim_system_entry_date,
clabor_rate,
sclaim_status,
--sclaim_note,
--sclose_code,
--scorrectiveaction,
ssubstatus,
--scause,
--tslast_record_maintenance,
--ssrv_name,
smanufacturer_code,
--idetail_id,
sdetail_type,
mast.sloss_code,
sdetail_desc,
cext_total_amt,
camt_paid,
spayee_type,
--scontract_holder_city,
--scontract_holder_state,
contracts.snew_used,
mast.icontract_term,
--svehicle_class,
mast.iproduct_type_id,
--sauto_code,
mast.strim,
mast.srating_vin,
--ivehicle_year,
--sownership_type_code,
--sownership,
contracts.sdealer_number,
dealer.sdealer_name,
dealer.sdealer_city,
dealer.sdealer_state,
svin,
scpf_model,
smake,
imodel_year,
loss_codes.spart_desc

FROM [BCG].[dbo].[final_clean_master_table] as mast

LEFT JOIN [scs_auto_gsfs].[dbo].scs_contracts as contracts
ON mast.icontract_id = contracts.icontract_id
LEFT JOIN [scs_auto_gsfs].[dbo].scs_dealers as dealer
on contracts.sdealer_number = dealer.sdealer_number
LEFT JOIN [scs_auto_gsfs].[dbo].scs_loss_codes as loss_codes
on mast.sloss_code = loss_codes.sloss_code

where 1=1
and dtclaim_system_entry_date >= @min_date
and dtclaim_system_entry_date <= @max_date
