declare @min_date date;
declare @max_date date;
set @min_date = '2023-01-01';
set @max_date = '2023-12-31';

with cte as (
select distinct
icontract_id, iclaim_id,dtclaim_system_entry_date
FROM [BCG].[dbo].[final_clean_master_table] as mast
where 1=1
and dtclaim_system_entry_date >= @min_date
and dtclaim_system_entry_date <= @max_date
)

select icontract_id,iclaim_id,dtclaim_system_entry_date,
COALESCE(DATEDIFF(day, LAG(dtclaim_system_entry_date) OVER (PARTITION BY icontract_id order by dtclaim_system_entry_date), dtclaim_system_entry_date),0) as days_between_claims
from cte
order by icontract_id, dtclaim_system_entry_date