select o.[name], c.[name]
from sys.columns c
join sys.objects o
on o.object_id = c.object_id
where c.[name] like '%total_earned_prem%'