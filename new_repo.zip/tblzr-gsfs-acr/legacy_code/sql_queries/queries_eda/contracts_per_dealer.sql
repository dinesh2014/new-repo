declare @min_date date;
declare @max_date date;
set @min_date = '2023-01-01';
set @max_date = '2023-12-31';

SELECT sdealer_number, round(sum(e.ctotal_earned_prem / NULLIF(c.cpremium_rate, 0)),0) as nb_contracts

FROM [scs_auto_gsfs].[dbo].scs_contracts as c
left join [scs_auto_gsfs].[dbo].scs_contract_earnings as e
on c.icontract_id = e.icontract_id
WHERE 1=1
and iproduct_type_id = 4
and dtcontract_effect <= @max_date
and dtcontract_expiration >= @min_date
group by sdealer_number