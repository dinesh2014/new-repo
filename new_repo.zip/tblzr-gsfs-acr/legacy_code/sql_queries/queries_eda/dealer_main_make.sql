declare @min_date date;
set @min_date = '01-01-2023';


SELECT
dealer.sdealer_number,
dealer.sdealer_name,
vin.smake as main_make,
count(vin.smake) as count_make,
row_number () over (partition by dealer.sdealer_number, dealer.sdealer_name order by count(vin.smake) desc) as ranking

FROM [scs_auto_gsfs].[dbo].scs_claims as claim
LEFT JOIN [scs_auto_gsfs].[dbo].scs_contracts as contracts
ON claim.icontract_id = contracts.icontract_id
LEFT JOIN [scs_auto_gsfs].[dbo].scs_dealers as dealer
on contracts.sdealer_number = dealer.sdealer_number
LEFT JOIN [scs_auto_master].[dbo].scs_vin_detail as vin
ON vin.svin = contracts.srating_vin

WHERE  1=1
and claim.dtclaim_system_entry_date >= @min_date
GROUP BY dealer.sdealer_number, dealer.sdealer_name, vin.smake