USE [scs_stage]
GO
/****** Object:  StoredProcedure [dbo].[SP_GSFS_SCS_Load_Parts]    Script Date: 4/3/2024 10:33:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*****************************************************************************************************/
 -- Name:			GSFS_SCS_Load_Parts
 --
 -- Description:	The SP returns compare the additional rows from Flat File of Load Parts.
 --
 --
 --
 -- Created by:		Kishore Kumar Darga
 -- Created:		08/05/2016
 -- Modified:		02/06/2018 - Hodes - TW values, deleting TW values, again inserting new values as per new Part file
/*****************************************************************************************************/
ALTER Proc [dbo].[SP_GSFS_SCS_Load_Parts]
as
Begin
IF OBJECT_ID(N'tempdb..#temp_part_stg') IS NOT NULL drop table #temp_part_stg
SELECT
       SMANUFACTURER_CODE
	  ,SPART_NO
	  ,SPART_DESC
	  ,CDEALER_COST
	  ,CRETAIL_COST
INTO #temp_part_stg
FROM [SCS_STAGE].[DBO].[SCS_PARTS]   --1973832
IF OBJECT_ID(N'tempdb..#temp_part_prod') IS NOT NULL drop table #temp_part_prod
SELECT
        ipart_id
       ,SMANUFACTURER_CODE
	  ,SPART_NO
	  ,SPART_DESC
	  ,CDEALER_COST
	  ,CRETAIL_COST
INTO #temp_part_prod
FROM [SCS_AUTO_GSFS].[DBO].[SCS_PARTS]  WITH(NOLOCK) --13120603
--INSERT NEW RECORDS INTO STAGING TABLE
IF OBJECT_ID(N'tempdb..#temp_part_new') IS NOT NULL drop table #temp_part_new
SELECT
	 A.SMANUFACTURER_CODE
	,A.SPART_NO
	,A.SPART_DESC
	,A.CDEALER_COST
	,A.CRETAIL_COST
INTO #temp_part_new
FROM #temp_part_stg A
left join #temp_part_prod B
ON  A.SMANUFACTURER_CODE=B.SMANUFACTURER_CODE
AND A.SPART_NO=B.SPART_NO
WHERE  B.SPART_NO is null  --51
-- TAKING THE PRODUCTION TABLE BACKUP
IF OBJECT_ID('SCS_STAGE.DBO.SCS_PARTS_BKP', 'U') IS NOT NULL
DROP TABLE [SCS_STAGE].[DBO].[SCS_PARTS_BKP];
SELECT * INTO [SCS_PARTS_BKP] FROM [SCS_AUTO_GSFS].[DBO].[SCS_PARTS]  WITH(NOLOCK)
--INSERT NEW RECORDS INTO STAGING TABLE
INSERT INTO [SCS_AUTO_GSFS].[DBO].[SCS_PARTS]
			   ( SMANUFACTURER_CODE
				,SPART_NO
				,SPART_DESC
				,CDEALER_COST
				,CRETAIL_COST)
SELECT
	 A.SMANUFACTURER_CODE
	,A.SPART_NO
	,A.SPART_DESC
	,A.CDEALER_COST
	,A.CRETAIL_COST
FROM #temp_part_new A  --51
--UPDATE MODIFIED RECORDS INTO STAGING TABLE
IF OBJECT_ID(N'tempdb..#temp_part_update') IS NOT NULL drop table #temp_part_update
SELECT
     B.IPART_ID
	,A.SMANUFACTURER_CODE
	,A.SPART_NO
	,A.SPART_DESC
	,A.CDEALER_COST
	,A.CRETAIL_COST
INTO #temp_part_update
FROM #temp_part_stg A
left join #temp_part_prod B
ON  A.SMANUFACTURER_CODE=B.SMANUFACTURER_CODE
AND A.SPART_NO=B.SPART_NO
WHERE
    (A.SPART_DESC<>B.SPART_DESC OR (B.SPART_DESC IS NULL AND A.SPART_DESC IS NOT NULL)) OR
	(A.CDEALER_COST<>B.CDEALER_COST OR (B.CDEALER_COST IS NULL AND A.CDEALER_COST IS NOT NULL)) OR
	(A.CRETAIL_COST<>B.CRETAIL_COST OR (B.CRETAIL_COST IS NULL AND A.CRETAIL_COST IS NOT NULL)) --1529796
 --UPDATE MODIFIED CRETAIL_COST info.
UPDATE A
SET A.[CRETAIL_COST]=B.[CRETAIL_COST],
    A.CDEALER_COST=B.CDEALER_COST,
    A.SPART_DESC=B.SPART_DESC,
	A.dtlast_record_maintenance=getdate(),
	A.dtupdate_last=getdate(),
	A.suser_id='BATCH',
	A.supdate_user_id='BATCH'
FROM [SCS_AUTO_GSFS].[DBO].[SCS_PARTS]  A
JOIN #temp_part_update B
ON  B.IPART_ID = A.IPART_ID  --1529745
--address the �TW� parts that are created from the �00� parts
delete from scs_auto_gsfs.dbo.scs_parts WHERE smanufacturer_code = 'TW'
INSERT INTO scs_auto_gsfs.dbo.scs_parts
           ([smanufacturer_code]
           ,[spart_no]
           ,[spart_desc]
           ,[cdealer_cost]
           ,[cretail_cost]
           ,[dtlast_record_maintenance]
           ,[suser_id]
           ,[supdate_user_id]
           ,[iupdate_userid_type]
           ,[dtupdate_last]
		   )
       SELECT        'TW' AS [smanufacturer_code]
                     ,[spart_no]
                     ,[spart_desc]
                     ,[cdealer_cost]
                     ,[cdealer_cost] * 1.1 AS [cretail_cost]
                     ,[dtlast_record_maintenance]
                     ,[suser_id]
                     ,[supdate_user_id]
                     ,[iupdate_userid_type]
                     ,[dtupdate_last]
              FROM scs_stage.dbo.scs_parts
              WHERE smanufacturer_code = '00' --850950
--select top 5 * from  [SCS_AUTO_GSFS].[DBO].[SCS_PARTS] where suser_id='Batch'
/*
--REMOVE DELETE RECORDS INTO STAGING TABLE
DELETE A
FROM  [SCS_AUTO_GSFS].[DBO].[SCS_PARTS_07142016] A
LEFT JOIN #temp_part  B
ON  A.SMANUFACTURER_CODE=B.SMANUFACTURER_CODE and
	A.SPART_NO=B.SPART_NO
WHERE  B.SMANUFACTURER_CODE is null and
	   B.SPART_NO is null --51
	   */
end
--select * from [SCS_AUTO_GSFS].[DBO].[SCS_PARTS_07142016] where spart_desc='unknown from update'