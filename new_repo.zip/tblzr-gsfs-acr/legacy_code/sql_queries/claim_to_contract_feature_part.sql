declare @pre_mon int;
set @pre_mon = 3;

drop table [bcg].[dbo].previous_x_month_total_earned_percent_part;

WITH a AS (
    SELECT DISTINCT
        spayee_no,
        icontract_id,
        iclaim_id,
        spart_no,
        dtpaid
    FROM [bcg].[dbo].[final_clean_master_table]
    where iproduct_type_id = 4 and sdetail_type = 'P' and btcovered_flag=1
),
b AS (
    SELECT DISTINCT
        spayee_no,
        spart_no,
        icontract_id AS icontract_id2,
        dtcontract_eff_cancell,
        dtcontract_effect,
        dtcontract_expiration,
        ctotal_earned_prem,
        cpremium_rate
    FROM [bcg].[dbo].[final_clean_master_table]
    where iproduct_type_id = 4 and sdetail_type = 'P' and btcovered_flag=1
)


SELECT a.spayee_no, icontract_id, iclaim_id, dtpaid, a.spart_no, count(distinct icontract_id2) nb_contract,
sum(ctotal_earned_prem) earned_prem_total, sum(cpremium_rate) prem_Rate
into [bcg].[dbo].previous_x_month_total_earned_percent_part
FROM a
LEFT JOIN b ON a.spayee_no = b.spayee_no and a.spart_no = b.spart_no
    AND b.dtcontract_effect < a.dtpaid
    AND b.dtcontract_expiration > DATEADD(MONTH, -@pre_mon, a.dtpaid)
    AND (b.dtcontract_eff_cancell IS NULL OR b.dtcontract_eff_cancell > DATEADD(MONTH, -@pre_mon, a.dtpaid))
group by a.spayee_no, icontract_id, iclaim_id, dtpaid, a.spart_no;


drop table [bcg].[dbo].previsou3month_total_claim_req_pre_part;


declare @pre_mon int;
set @pre_mon = 3;
WITH a AS (
    SELECT DISTINCT
        spayee_no,
        icontract_id,
        iclaim_id,
        spart_no,
        dtpaid
    FROM [bcg].[dbo].[final_clean_master_table]
    where iproduct_type_id = 4 and sdetail_type = 'P' and btcovered_flag=1
)

select m.spayee_no,
m.icontract_id,
m.iclaim_id,
m.spart_no,
m.dtpaid,
m.nb_contract,
m.earned_prem_total,
m.prem_rate,
count(distinct a.iclaim_id) nb_paid_claims
into [bcg].[dbo].previsou3month_total_claim_req_pre_part
from [bcg].[dbo].previous_x_month_total_earned_percent_part m
left join a
on m.spayee_no = a.spayee_no and m.spart_no = a.spart_no
and m.dtpaid>a.dtpaid
and a.dtpaid>dateadd(MONTH, -@pre_mon, m.dtpaid)
group by
m.spayee_no,
m.icontract_id,
m.iclaim_id,
m.spart_no,
m.dtpaid,
m.nb_contract,
m.earned_prem_total,
m.prem_rate;



select a.*,
nb_paid_claims/nullif((earned_prem_total/nullif(prem_rate,0)),0)/nb_contract claim_freq
into [bcg].[dbo].previsou3month_total_claim_req_part
from  [bcg].[dbo].previsou3month_total_claim_req_pre_part a

select sum(nb_paid_claims) from [bcg].[dbo].previsou3month_total_claim_req_part
where spayee_no like '%42273%' and iclaim_id = 4049904;

select top 100 * from [bcg].[dbo].previsou3month_total_claim_req
where spayee_no like '%42273%' and iclaim_id = 4049904;


select