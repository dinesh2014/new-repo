Data sources descriptions
=========================
This section introduces the major data sources used in ACR data pipeline. Data dictionary, time span and pre-requisites can be found here.


.. note::
    Please notice all of these tables are located under either ``scs_auto_gsfs``  or ``scs_auto_master`` database in GSFS SQL Server. Reach out to Kishore for access.

Claim Details History
----------------------

Database table named as ``[scs_auto_gsfs].[dbo].[scs_claim_details_history]``. It contains
all historical claim detail information, including key pieces such as claim status, loss code/type, payout
by part and labor.

^^^^^^^^^^^^^^^^^
Included periods:
^^^^^^^^^^^^^^^^^

Time period available: 10-25-1995 to present, with about 7 day lag.


^^^^^^^^^^^^^^^^^
Mandatory fields:
^^^^^^^^^^^^^^^^^

* ``iclaim_id``: Unique identifier for each claim
* ``irecord_id``: Unique identifier for each record in the database
* ``ssource_table``: Name of the source table from which the raw data originated from
* ``suser_id``: Identifier for the IT/system user associated with the claim detail entries
* ``sdetail_type``: Describe if detail entry is associated to a part repair or labor issue
* ``sloss_code``: Code indicating the type of loss associated with the claim
* ``sdetail_desc``: Description of the detail associated with the claim
* ``btcovered_flag``: Flag indicating whether the claim is covered by the vehicle service contract
* ``nreq_qty``: Quantity requested for the claim
* ``creq_unit_cost``: Unit cost requested for the claim
* ``creq_total``: Total cost requested for the claim (quantity * unit cost)
* ``nauth_qty``: Quantity authorized for the claim
* ``cauth_unit_cost``: Unit cost authorized for the claim
* ``cauth_total``: Total cost authorized for the claim (quantity * unit cost)
* ``ntax_percent``: Tax percentage applied to the claim
* ``ctax_amt``: Tax amount applied to the claim
* ``cext_total_amt``: Extended total amount for the claim (including tax)
* ``cadj_ext_total_amt``: Adjusted extended total amount for the claim
* ``iclaim_det_status_id``: Identifier indicating the status of the claim detail
* ``cmsrp_unit_cost``: Manufacturer's suggested retail price for the claimed part
* ``spart_no``: Part number associated with the claim
* ``camt_paid``: Amount paid for the claim
* ``dtpaid``: Date when the claim was paid
* ``spayee_type``: Type of payee (individual, company, etc.)
* ``spayee_no``: Identification number of the payee
* ``spayee_name``: Name of the payee
* ``spayee_addr_1``: Address line 1 of the payee
* ``spayee_addr_2``: Address line 2 of the payee
* ``spayee_city``: City of the payee
* ``spayee_state``: State of the payee
* ``spayee_zip_code``: ZIP code of the payee
* ``sjob_no``: Job number associated with the claim


Overall Claims
---------------

Database table name as ``[scs_auto_GSFS].[dbo].[Scs_claims]``.
This table contains attributes for all claims such as claim number,
claim status (paid vs denied), contract, paid date, loss date and etc.

This is the key table to link claim detail history and contract, and even dealers.

^^^^^^^^^^^^^^^^^
Included periods:
^^^^^^^^^^^^^^^^^

Time period available: 03-13-1960 to present

^^^^^^^^^^^^^^^^^
Mandatory fields:
^^^^^^^^^^^^^^^^^

* ``iclaim_id``: Unique identifier for each claim (ID)
* ``icontract_id``: Unique identifier for CSC owner
* ``sclaim_number``: Unique identifier for each claim (Number)
* ``smanufacturer_code``: Code associated to the OEM
* ``iservice_center_id``: Unique identifier for the service center
* ``sservice_center_type``: Type for the service center (Shop vs dealer)
* ``dtdate_loss_occurred``: Date where the loss occurred
* ``iodometer_at_time_of_loss``: Mileage captured from the vehicles while repairments is set
* ``dtclaim_system_entry_date``: Date where the claim enters into the system
* ``dtlast_claim_maintenance_date``: Last date where a claim record has a maintenance
* ``dtdate_claim_paid``: Date where claim mas paid to the dealer
* ``srepair_order_number``: Order number for the repair
* ``cclaim_amt_deductible``: Total amount of deductible based on coverage on contract
* ``sclaim_status``: Identifier for the status of a claim. Describe paid, denied, cancelled claims
* ``ssubstatus``: Detailed description of claim issue
* ``sadjuster``: Identifier for adjudicator who take the claim

Contracts
----------

Database table with the name ``[scs_auto_GSFS].[dbo].[scs_contracts]``.
This table contains information relevant to each contracts. Datasource that
provide details on contract definitions as start date of contract, expiration date,
premium rate and other contract demographics.

^^^^^^^^^^^^^^^^^
Included periods:
^^^^^^^^^^^^^^^^^

Contract data consider since beginning to active contracts under consideration.

^^^^^^^^^^^^^^^^^
Mandatory fields:
^^^^^^^^^^^^^^^^^

* ``icontract_id``: Unique identifier for each contract
* ``scontract_no``: Contract number associated with the contract
* ``srating_vin``: VIN (Vehicle Identification Number) associated with the contract
* ``iproduct_type_id``: Identifier for the type of product covered by the contract
* ``icontract_mileage``: Mileage covered by the contract
* ``icontract_term``: Term duration of the contract
* ``icontract_effective_odometer``: Odometer reading at the effective date of the contract
* ``icontract_sale_odometer``: Odometer reading at the sale date of the contract
* ``icontract_expiration_odometer``: Odometer reading at the expiration date of the contrac
* ``dtcontract_effect``: Effective date of the contract
* ``dtcontract_expiration``: Expiration date of the contract
* ``snew_used``: Indication of whether the vehicle is new or used
* ``cretail_rate``: Retail rate of the contract
* ``cnet_rate``: Net rate of the contract
* ``cpremium_rate``: Premium rate of the contract
* ``scontract_holder_address_1``: Address line 1 of the contract holder
* ``scontract_holder_address_2``: Address line 2 of the contract holder
* ``scontract_holder_city``: City of the contract holder
* ``scontract_holder_state``: State of the contract holder
* ``scontract_holder_zip_code``: ZIP code of the contract holder
* ``dtcontract_eff_cancell``: Effective date of contract cancellation, if applicable
* ``sdealer_number``: Dealer number associated with the contract
* ``scontract_holder_fname``: First name of the contract holder
* ``scontract_holder_lname``: Last name of the contract holder
* ``scontract_holder_email``: Email address of the contract holder


Vehicle Information
--------------------

Database table name as ``[scs_auto_master].[dbo].[scs_vin_detail]``.
This table includes fields relevant to identify car descriptions as model, make,
trim, engine type, drive type etc.

^^^^^^^^^^^^^^^^^
Mandatory fields:
^^^^^^^^^^^^^^^^^

* ``ivin_id``: Unique identifier for each VIN (Vehicle Identification Number)
* ``svin_prefix``: Prefix of the VIN
* ``svin``: VIN (Vehicle Identification Number)
* ``imodel_year``: Model year of the vehicle
* ``sasset_type``: Type of asset (e.g., vehicle)
* ``smake``: Make of the vehicle
* ``smodel``: Model of the vehicle
* ``strim``: Trim level of the vehicle
* ``sbody_style``: Body style of the vehicle
* ``scid``: CID (Cubic Inch Displacement) of the vehicle
* ``scc``: CC (Cubic Centimeter) of the vehicle
* ``scyl``: Number of cylinders in the vehicle's engine
* ``sfuel``: Type of fuel used by the vehicle
* ``sgvwr``: Gross Vehicle Weight Rating (GVWR) of the vehicle
* ``scycle``: Cycle type of the vehicle (e.g., 2-cycle, 4-cycle)
* ``ston_rating``: Tonnage rating of the vehicle
* ``cretail_base_price``: Retail base price of the vehicle
* ``sdriving_type``: Driving type of the vehicle (e.g., 2WD, 4WD)
* ``swheel_count``: Number of wheels on the vehicle
* ``swheel_drive_count``: Number of wheels that are drive wheels
* ``stransmission``: Type of transmission in the vehicle
* ``ssegmentation``: Segmentation category of the vehicle
* ``sturbocharged``: Indicator if the vehicle is turbocharged
* ``ssupercharged``: Indicator if the vehicle is supercharged
* ``saspiration``: Aspiration type of the vehicle (e.g., naturally aspirated)
* ``scarc``: CARB (California Air Resources Board) certification status
* ``scountry``: Country of manufacture of the vehicle
* ``sproactive_vin``: Proactive VIN (Vehicle Identification Number) from the manufacturer
* ``scpf_model``: CP/F model of the vehicle
* ``stransmission_desc``: Description of the transmission in the vehicle
* ``scomplete_vin``: Complete VIN (Vehicle Identification Number) of the vehicle

Output Data Dictionaries
------------------------

Following we list the data dictionaries for the tables in the ``[BCG].[dbo]`` database
and ``data`` folder with interim model results.

Please reference to the **Pipeline Tasks** documentation module to reference where
each table is used or generated.

**claim_detail_history_flt**

Interim table under the ``get_master_table`` step that consider
``scs_claim_details_history`` table as a left key table and merge most recent information from
``Scs_claims`` table.

Following the key fields and data type for this output:

* ``iclaim_id``: [INT]
* ``irecord_id``: [INT]
* ``ssource_table``: [VARCHAR]
* ``dtcycle_date``: [DATETIME]
* ``suser_id``: [VARCHAR]
* ``sdetail_type``: [VARCHAR]
* ``sloss_code``: [CHAR]
* ``sdetail_desc``: [VARCHAR]
* ``btcovered_flag``: [BIT]
* ``nreq_qty``: [NUMERIC]
* ``creq_unit_cost``: [MONEY]
* ``creq_total``: [MONEY]
* ``nauth_qty``: [NUMERIC]
* ``cauth_unit_cost``: [MONEY]
* ``cauth_total``: [MONEY]
* ``ntax_percent``: [NUMERIC]
* ``ctax_amt``: [MONEY]
* ``cext_total_amt``: [MONEY]
* ``cadj_ext_total_amt``: [MONEY]
* ``iclaim_det_status_id``: [INT]
* ``ireason_id``: [INT]
* ``cmsrp_unit_cost``: [MONEY]
* ``spart_no``: [CHAR]
* ``camt_paid``: [MONEY]
* ``dtpaid``: [DATETIME]
* ``spayee_type``: [CHAR]
* ``spayee_no``: [VARCHAR]
* ``spayee_name``: [VARCHAR]
* ``spayee_addr_1``: [VARCHAR]
* ``spayee_addr_2``: [VARCHAR]
* ``spayee_city``: [VARCHAR]
* ``spayee_state``: [CHAR]
* ``spayee_zip_code``: [VARCHAR]
* ``supdate_user_id``: [VARCHAR]
* ``ipart_source_id``: [INT]
* ``iterm_id``: [INT]
* ``ctax_amt_1``: [MONEY]
* ``ctax_amt_2``: [MONEY]
* ``iclaim_payee_id``: [INT]
* ``spart_desc_claim_detail_history``: [VARCHAR]
* ``sjob_no``: [CHAR]
* ``icontract_id``: [INT]
* ``sclaim_number``: [CHAR]
* ``smanufacturer_code``: [CHAR]
* ``iservice_center_id``: [INT]
* ``sservice_center_type``: [CHAR]
* ``dtdate_loss_occurred``: [DATETIME]
* ``iodometer_at_time_of_loss``: [INT]
* ``dtclaim_system_entry_date``: [DATETIME]
* ``dtlast_claim_maINTenance_date``: [DATETIME]
* ``dtdate_claim_paid``: [DATETIME]
* ``srepair_order_number``: [CHAR]
* ``cclaim_amt_deductible``: [MONEY]
* ``sclaim_component_loss_code``: [CHAR]
* ``sclaim_status``: [CHAR]
* ``ssubstatus``: [VARCHAR]
* ``sadjuster``: [VARCHAR]


**claim_contract_vin_table**

Interim table under the ``get_master_table`` step that consider
``claim_detail_history_flt`` table as a left key table and incorporate
information related to contract holder from ``scs_contacts`` and VIN details
from ``scs_vin_detail``.

Columns included from ``scs_contacts``:

* ``scontract_no``: [CHAR]
* ``srating_vin``: [VARCHAR]
* ``iproduct_type_id``: [INT]
* ``icontract_mileage``: [INT]
* ``icontract_term``: [INT]
* ``icontract_effective_odometer``: [INT]
* ``icontract_sale_odometer``: [INT]
* ``icontract_expiration_odometer``: [INT]
* ``dtcontract_effect``: [DATETIME]
* ``dtcontract_expiration``: [DATETIME]
* ``snew_used``: [CHAR]
* ``cretail_rate``: [MONEY]
* ``cnet_rate``: [MONEY]
* ``cpremium_rate``: [MONEY]
* ``scontract_holder_address_1``: [CHAR]
* ``scontract_holder_address_2``: [CHAR]
* ``scontract_holder_city``: [CHAR]
* ``scontract_holder_state``: [CHAR]
* ``scontract_holder_zip_code``: [CHAR]
* ``dtcontract_eff_cancell``: [DATETIME]
* ``sdealer_number``: [CHAR]
* ``scontract_holder_fname``: [CHAR]
* ``scontract_holder_lname``: [CHAR]
* ``scontract_holder_email``: [VARCHAR]

Columns included from ``scs_vin_detail``:

* ``ivin_id``: [INT]
* ``svin_prefix``: [VARCHAR]
* ``svin``: [VARCHAR]
* ``imodel_year``: [INT]
* ``sasset_type``: [VARCHAR]
* ``smake``: [VARCHAR]
* ``smodel``: [VARCHAR]
* ``strim``: [VARCHAR]
* ``sbody_style``: [VARCHAR]
* ``scid``: [VARCHAR]
* ``scc``: [VARCHAR]
* ``scyl``: [VARCHAR]
* ``sfuel``: [VARCHAR]
* ``sgvwr``: [VARCHAR]
* ``scycle``: [VARCHAR]
* ``ston_rating``: [VARCHAR]
* ``cretail_base_price``: [MONEY]
* ``sdriving_type``: [VARCHAR]
* ``swheel_count``: [VARCHAR]
* ``swheel_drive_count``: [VARCHAR]
* ``stransmission``: [VARCHAR]
* ``ssegmentation``: [VARCHAR]
* ``sturbocharged``: [VARCHAR]
* ``ssupercharged``: [VARCHAR]
* ``saspiration``: [VARCHAR]
* ``scarb``: [VARCHAR]
* ``scountry``: [VARCHAR]
* ``sproactive_vin``: [[VARCHAR]]


**claim_contract_vin_part_table**

Interim table under the ``get_master_table`` step that consider
``claim_detail_history_flt`` table as a left key table and incorporate
information related to part price from ``scs_parts`` and ``historical_forte_parts``.

Following the key fields and data type added in this step:

* ``ipart_id``:  [INT]
* ``spart_desc``: [VARCHAR]
* ``cdealer_cost``: [MONEY]
* ``cretail_cost``: [MONEY]
* ``dtlast_record_maintenance``: [DATETIME]
* ``soem_code``: [CHAR]
* ``spart_number``: [CHAR]
* ``cretail_price``: [MONEY]
* ``dtretail_date``: [DATETIME]
* ``from_date``: [DATETIME]
* ``to_date``: [DATETIME]


**claim_master_table**

Final output table under the ``get_master_table`` step that consider
``claim_contract_vin_part_table`` table as a left key table and incorporate
information for forte labor from ``scs_labor_rate_date_ranges``.

Following the key fields and data type added in this step:

* ``sparent_type_code``: [VARCHAR]
* ``iparent_id``: [INT]
* ``dtstart``: [DATE]
* ``dtend``: [DATE]
* ``clabor_rate``: [MONEY]
