Dashboard Overview
============================================
Purpose of this visual tool is to provide users with a comprehensive and user-friendly view of the ACR tool. Designed with a focus on usability, it facilitates easy access to detailed information for a selected claim or contract number.

The dashboard is organized into two primary sections, each dedicated to showcasing different facets of the data:

1. **Claim, Vehicle, and Contract Information**

   This section displays various details related to claims, vehicles, and contracts. It includes:

   - **Claim Details**: Dates of claim and expiration, total paid amount, contract total, expiration mileage, and breakdown parts.
   - **Vehicle Details**: Information such as mileage, make, model, trim, and model year.
   - **Contract Details**: A comprehensive overview including all claims under the contract, Tech found, and Customer Claims (CC).

2. **Risk KPIs Table**

   The Risk KPIs Table focuses on key performance indicators related to risk assessment. It provides critical insights that help in understanding the risk profile associated with each claim or contract. This section includes:

   - **Risk Group**: Categorization based on the level of risk.
   - **Value**: The calculated risk value.
   - **Threshold**: Pre-defined risk thresholds for comparison.
   - **Difference**: The difference between the current value and the threshold.
   - **Flag**: Indicates whether the risk value exceeds the set threshold.
   - **Risk Score**: The overall risk score is an aggregated measure that summarizes all of the risk KPIs values. This score will be displayed in red above a value of 30%.

Data Processing Script Overview
-------------------------------

This section provides a detailed walkthrough of the Python Jupyter Notebook (`data_transformation_dashboard.ipynb`) used for processing the output of the Automated Claims Review (ACR) tool. The script employs the `pandas` and `numpy` libraries to manipulate and analyze the data, preparing it for visualization in a dashboard.

The script performs several key operations, outlined in the steps below:

1. **Import Libraries**
   The script begins by importing the necessary libraries for data manipulation (`pandas`) and numerical calculations (`numpy`).

2. **Load Data**
   It reads data from a CSV file containing ACR tool results into a DataFrame named `df`.

3. **Set apart the variables for the Claim, Vehicle, and Contract Information**.

4. **Format adjusting**

   * Decimal places are rounded, and numeric formats are adjusted for clarity and consistency.
   * Zeros in certain columns are replaced with `None` to differentiate between uncalculated values and actual zeros.
   * Some columns representing percentages are adjusted to display values in percentage format.
   * Numeric columns are formatted to include commas for thousands, improving readability.

5. **Risk Group Assignment**
    Each KPI is assigned to a risk group.

6. **Join External Data**
    The script merges ACR information with additional data from an Excel file, enriching the dataset with Tech Found and Customer Complaint counts.

7. **Save Resulting DataFrame**
    The processed and enriched data is saved to a CSV file, ready for dashboard visualization or further analysis.

By following these steps, the script transforms raw data from the ACR tool into a structured, enriched dataset that can be effectively utilized in a dashboard to visualize and analyze the data.

Dashboard Implementation
------------------------

The dashboard was developed in PowerBI, offering advanced filtering capabilities by claim number or contract number. This implementation enhances user interaction, allowing for detailed and specific data analysis within the dashboard environment.
To access the dashboard the user must download PowerBI Desktop.