Security and Privacy
====================

Purpose of this section is to describe two approach
implemented for validate data security and privacy during the code base
development. This was done using two libraries who review the code base
and detect any leakage or possible risk attached to dependencies.

Security checks
----------------
Safety CLI is a Python dependency vulnerability scanner designed to enhance
software supply chain security by detecting packages with known vulnerabilities
and malicious packages in local development environments, CI/CD, and production systems.

Following command line on the terminal willm execute the library, pointing
to the specific folder you want to save the validation:

.. code-block:: powershell

    safety check --full-report > security_and_privacy/safety_report.txt

This is gonna generate a report and loaded into the folder ``security_and_privacy`` as
showing in the following snapshot:

.. image:: images/safety_report_snapshot.png
   :width: 100%
   :align: center

For further information on Safety library, please refer to the official documentation
using `this link <https://pypi.org/project/safety/>`_.

Data quality on codebase
------------------------

In order to validate the consistency of the code and quality of it, we have moving towards
for using Pylint CLI python library that scan the database and provide insights on possible bugs.

For further information on pylint as a data quality code validator please refer to the following
`documentation page <https://pylint.readthedocs.io/en/stable/>`_.

Following command line on the terminal willm execute the pylint library, pointing
to the specific folder with the codebase to validate, and the path to save the report:

.. code-block:: powershell

    pylint src > security_and_privacy/pylint_report.txt

This is gonna generate a report and loaded into the folder ``security_and_privacy``
as the previous section does.

Testing Coverage
----------------

Purpose of this section is to introduce the user on some of the key unit tests for the tool.
This tests are highly recommended to validate the correct execution of each function and
avoid bugs during the tool run.

We have decided to implement ``pytest`` as a main library for unit testing because it is
straightforward the way to plug and play it on the database.

Use the following code on the terminal line to run the pytest library on the ``test``
folder:

.. code-block:: powershell

    pytest test

You should be able to see the following result on the IDE terminal, denoting the
different unit test results applied on the folder ``test`` for the main repository:

.. image:: images/unit_test_results.png
   :width: 100%
   :align: center

