How-to guides
=============

This document is a user guide for the ACR Data Pipeline.
It is intended for GSFS users who will be interacting with the pipeline on a daily basis.
The pipeline is a set of python modules that ingest data from SQL server database, process it,
and store it back into a database.

Prerequisites
---------------

**Administrator Privileges**

For some of the commands below, administrator privileges may be required. This can be the case for running
``pip install .``, or setting environment variables. If you get a permission denied at some point in this process,
please refer to your system administrator.

**Python 3.10+**

Python 3.10 or higher must be installed in your machine. Python can be downloaded and installed for Windows using
`this link <https://www.python.org/downloads/windows/>`_. Python 3.10 has been released in the end of 2021
and will be supported until the end of 2026.

**Local folder for modelling results**

Breakdown model and validation cost requires a pre defined folder on your local machine to load and save
files during the process. Make sure it is created on the first level of the repo

You can easily create this empty folder with the following command:

.. code-block:: powershell

    mkdir data


Set up dependencies
--------------------
In order to run the tool successfully, is mandatory to set up all libraries and dependencies.
Also is highly recommended to instantiate a virtual environment from the very beginning.

First, run the following command on the IDE terminal to instantiate a virtual environment:
.. code-block:: powershell

    venv\Scripts\activate

Once virtual environment was set up, you can install packages and other dependencies listed on the
``requirements.txt`` file as following:

.. code-block:: powershell

    pip install -r requirements.txt

All set! you have completed the required set up for running the tree base workstreams that compose this tool.
In the sections bellow there is a detailed guides on how to run each of them.

Trigger the tool
----------------

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
claim Information compiler
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

In order compile all claim information in a single master table, you can run it in two straightforward steps.
First, lets run the python module ``src.get_master_table.py`` that compile all datasource information
in a single source:

.. code-block:: powershell

    python -m src.get_master_table

After you execute it, you should saw this commend from the command line describing the execution ran successfully:

``Final Master table created into SQL Server``

Secondly, you would need to execute the ``src.data_cleaning.py`` module in order to filter out
claims out of the scope and other unwanted columns for the analysis. For that, please run the following
command in the console:

.. code-block:: powershell

    python -m src.data_cleaning

After this task is done, you should be able to see the following message into the console:

``Clean master table created into BCG database.``

^^^^^^^^^^^^^^^^^^^
Breakdown Model
^^^^^^^^^^^^^^^^^^^

After the output for claim information compiler was updated in th SQL server database,
you can start the first step of doing feature engineering.

Please use the following command for generating new contextual features to be used in the
breakdown model step:

.. code-block:: powershell

    python -m src.feature_engineering

Once this step is done, you can validate the output was saved in the local folder ``data``.

Therefore, we can use this output with the new features in order to implement our ML engine
anc estimate probabilities of a breakdown. You can do this running the following command line:

.. code-block:: powershell

    python -m src.breakdown_model

Once again, please check that the process runs successfully following messages on the console and
validating that output was saved in the local folder ``data``.

Lastly, you would need to execute one more command line in order to do postprocessing of the result
and calculate risk tiers and VAR threshold. Following command execute the task in the backend:

.. code-block:: powershell

    python -m src.postprocessing_breakdown

Finally, you should be able to see a new csv file with the postprocessing results in the
specified folder as following:

.. image:: images/ss_breakdown_output.png
   :width: 100%
   :align: center

^^^^^^^^^^^^^^^^^^^^^^^^^^
Labor/Part Cost Assessment
^^^^^^^^^^^^^^^^^^^^^^^^^^
Once master tables are generated and necessary filters are applied during claim information compiling step,
start assessment for labor cost and part cost.

1. Kick off feature engineering step. Notice that Labor/Part Cost Assessment shared the same feature engineering
module with breakdown prediction. So you can use config file ``configs/feature_engineering_config.yaml`` to specify
generating features for either one of two models (breakdown & cost assessment) or both.

.. code-block:: powershell

    python -m src.feature_engineering.py

The output of feature engineering step will be found in corresponding local folders:``data/breakdown/``
and ``data/cost_assessment``

2. Identify anomalies based on 5 scenarios identified:

* Part price deviation vs. industry benchmark
* Part price variation vs. historical median
* Labor rate deviation vs. industry benchmark
* Labor rate variation vs. historical median
* Labor hours variation vs. predicted from models (ML engined & rule-based depending on data size)

Before running the core engine, make sure parameters such as input/output paths,
features selected, model configuration are well specified in config file ``configs/cost_assessment_config.yml``.
Run core module of cost assessment by executing below script

.. code-block:: powershell

    python -m src.cost_assessment_model.py

The output of cost assessment step will be found in local data folder ``data/cost_assessment``

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
ACR Tool - Overarching Anomaly Flagging
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Overarching ACR Tool will be ran as the last step when all above are complete.
It collects risk flags from 4 different groups: client, requestor, vehicle (breakdown) and financial (including part/cost assessment).
On top of this, it also contains coverage check and exception check based on business rules. Coverage and exception flags
will determine whether a claim is under coverage and hence being evaluated for risks. Therefore coverage and exception flags won't be
included into risk score calculation.

Before running the core module, make sure parameters such as input/output paths,
features selected, model configuration are well specified in config file ``configs/acr_tool_config.yml``.
Run core module of ACR Tool by executing below script

.. code-block:: powershell

    python -m src.acr_tool.py

The output of ACR Tool can be found in local data folder ``data/ACR_tool/``.


