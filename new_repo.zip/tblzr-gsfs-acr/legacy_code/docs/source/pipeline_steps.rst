Pipeline Tasks
==============

This section outlines the key steps to build & run the ACR pipeline.

1. Compile claim information
2. Breakdown propensity model
3. Part/Labor cost validation
4. ACR Tool - overarching anomaly flagging

Please note that currently above steps are required to be executed **sequentially and manually**. The next step
is to fully automate the ACR pipeline with automatic CI/CO structure.

All the interim intput/output tables are stored in ``[BCG].[dbo]`` for development purpose.

Compile Claim Information
-------------------------

^^^^^^^^^^^^^^^^^^^^^^
Generate Master Table
^^^^^^^^^^^^^^^^^^^^^^

First step of the tool is compiling all claim, contract, VIN and part information in a single
data source to be used for modelling proposes later. This step is responsible for stacking all data sources
into a single dataframe, keeping only the set of columns defined in the ``master_table_config.yml`` file.



Following are listed the main submodule tasks:

1. Create historical claim table
2. Add contract and vehicle information
3. Add part and labor cost
4. Incorporate part labor from Forte
5. Write output into SQL Server table


To get this task done, you can use the ``src.get_master_table`` module.

**Input files and location:**
Input files of this step are listed in the section ``Data sources descriptions``.

**Output files and location:**
Output is stored in the following SQL Server location:
``claim_master_table``

.. Note::
    For more information about interim outputs and output schema on this task,
    please refer to the sections ``Output Data Dictionaries``.

^^^^^^^^^^^^^^
Data Cleaning
^^^^^^^^^^^^^^

This task is the last step on the data compilation. The goal is to
clean up the raw master table built from the last step, for example
filtering for products in scope (e.g. VSC) and the specific claim
status related (e.g. paid, denied and etc.).

Configuration on the code base for this task is defined in the
``data_cleaning_config.py`` file.

Following are the main submodule tasks:

1. Apply filters to remove claims that are out of scope
2. Cross match Part and Labor information at the row level
3. Rename total amount paid column to differentiate values from denied claims vs. paid claims
4. Write output into SQL Server table

To get this task done, you can use the ``src.data_cleaning.py`` module.

**Input files and location:**
Input file consist on the table ``claim_master_table`` built in previous step.

**Output files and location:**
Output is stored in the following SQL Server location:
``final_clean_master_table``

Breakdown Propensity Models
---------------------------
The primary objective of this module is to deploy a Machine Learning (ML) engine
capable of accurately predicting the likelihood of specific loss types
occurring in vehicles. This predictive capability relies on a set of most explanatory
features, including but not limited to mileage at the time of loss, model year and
demographic factors, which collectively aid in understanding breakdown propensities.

Notably, this tool serves to identify claims wherein the occurrence of a particular
loss type appears uncommon for the vehicle under analysis. Such instances are flagged
as anomalies, signifying potential discrepancies warranting further scrutiny.

Aligned with the methodology introduced in preceding modules, the subsequent section
outlines the core tasks implemented within the codebase to facilitate the generation
of actionable insights within this workstream.


^^^^^^^^^^^^^^^^^^^^
Feature Engineering
^^^^^^^^^^^^^^^^^^^^

This is the first step for estimating breakdown probabilities. It consists
loading the ``final_clean_master_table`` and generating features, which
helps gain more predictive power and yield insights from the model

Configuration about the columns to use and features to create are listed under ``feature_engineering.py`` file.

Following are the key steps:

1. Load clean master table from database
2. Filter out claims with missing information required
3. Aggregate table to claim-vehicle-loss type level
4. Generate demographic features (urbanicity, paved/unpaved percentage, etc)
5. Generate time features (month of loss, year of loss, etc)
6. Generate claim related features (mileage per year ratio, claim to contract, etc)
7. Generate Price features (retail base price, average premium rate, etc)
8. Write output into SQL Server database

To get this task done, you can use ``feature_engineering.main_breakdown()`` function
under the the ``src.feature_engineering.py`` module.

.. autofunction:: ../../feature_engineering.main_breakdown

**Input files and location:**
Input file consist on the table ``final_clean_master_table`` built in previous step.

**Output files and location:**
Output is stored in the following local path:
``data/feature_engineering_output_{DATE_OF_EXECUTION}.csv``

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Breakdown Probabilities Estimation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

At high level, this tasks consider the features created on the past task and filter the data
for a series at the time, and implement a Multinomial Logistic Regression to classify each vehicle in
a pre-existing loss type.

After the model has trained with 70% of claims, we compute the probability of a vehicle that fall into each loss type
and use it as a metric to flag very unlikely breakdowns events.

Following are the key steps under this module in the codebase:

1. Load feature engineering output
2. Implement Hot Encoding and Label Encoding
3. Select top parts with high occurrence to model
4. Implement LGB Model for Multiclass
5. Estimate the uplift probability based on 5% prob. quantile buckets
6. Concat results into a single table and save results

To get this task done, you can use ``main()`` function
under the the ``src.breakdown_model.py`` module.

.. autofunction:: ../../breakdown_model.main

**Input files and location:**
Input is stored in the following local path:
``data/feature_engineering_output_{DATE_OF_EXECUTION}.csv``

**Output files and location:**
Output is stored in the following local path:
``data/model_outputs/predicted_classes_exploded_full.csv``


^^^^^^^^^^^^^^^
Postprocessing
^^^^^^^^^^^^^^^
The final phase of the breakdown prediction model involves the comprehensive
assessment of all claims originating from VSC contracts. Within this step,
each claim is assigned a breakdown propensity, derived from the predictive
output generated by the ML engine.

Essentially, this stage entails the computation of part frequency probabilities,
a crucial metric employed to identify and flag records linked to uncommon parts
within specific loss types and vehicle models. This proactive approach enables the
detection of potential anomalies, ensuring thorough scrutiny and proactive
intervention where necessary.

Following are the key steps under this module in the codebase:

1. Import clean master table from local path
2. Import breakdown probabilities
3. Calculate part frequency at loss level and series (claim_part_data)
4. Define high/low volume vehicle claims
5. Assign breakdown probabilities to part-claim table
6. Implement risk tiers probabilities and VAR threshold
6. Save results

To get this task done, you can use ``main()`` function
under the the ``src.post_processing_breakdown.py`` module.

**Input files and location:**
Input is stored in the following local path:
``data/model_outputs/predicted_classes_exploded_full.csv``

**Output files and location:**
Output is stored in the following local path:
``data/model_outputs/part_breakdown_results_{DATE_OF_EXECUTION}.csv``


Labor/Part Cost Assessment
---------------------------------------------
^^^^^^^^^^^^^^^^^
Feature Engineering:
^^^^^^^^^^^^^^^^^
Before starting cost assessment and anomaly detection, generate features required to be used in labor
hours prediction model and labor rate & part price rule-based models.

Below are the kep steps for feature engineering:
1. Load clean master table from database
2. Filter out claims with missing information required
3. Aggregate table to claim-vehicle-loss type level
4. Generate claim related features (mileage per year ratio, claim to contract, etc)
5. Generate labor related features (overhual, normal hours, manual adjustment, etc)
6. Save output locally for modeling

To get this task done, you can use ``feature_engineering.main_costmodel()`` function
under the the ``src.feature_engineering.py`` module.


**Config file and location:**
Feature engineering part is shared for breakdown propensity model and cost assessment. So
please refer to ``configs/feature_engineering.py`` for configuration.

**Input files and location:**
Input file consist on the table ``final_clean_master_table`` built in previous step.

**Output files and location:**
Output is stored in the following local path:
``data/cost_feature_engineering_output_{DATE_OF_EXECUTION}.csv``


^^^^^^^^^^^^^^^^^
Cost Assessment & Anomaly Detection:
^^^^^^^^^^^^^^^^^

.. image:: images/cost_assessment_methodology.PNG
   :align: center

Cost assessment module joins industry benchmark with AI predictions to flag anomalies.

This step identifies 5 anomaly scenarios as below:

1. **Labor rate deviation**: labor rate requested by dealer is higher than industry benchmark
2. **Labor rate variation**: labor rate requested by dealer is higher than historical median
3. **Part price deviation**: part price requested by dealer is higher than industry benchmark
4. **Part price variation**: part price requested by dealer is higher than historical median
5. **Labor hours variation**: labor hours requested by dealer is higher than ML engine suggests

Based on above scenarios, we built rule-based model or ML engines accordingly. Python module
``src.cost_assessment_model.py`` should be used to execute this task.

**Config file and location**: The config file specifies and input and output path for cost assessment module
:``configs/cost_assessment_config.yml`` .

**Input files and location**:
Two input files are required for cost assessment module:

* Final clean master table for rule-based modeling (scenario 1 - 4) : ``[BCG].[dbo].final_clean_master_table``
* Feature engineering output for ML engine-based modeling (scenario 5): ``data/cost_assessment/cost_engineering_output_{DATE_OF_EXECUTION}.csv``


**Output files and location**: Output files will be stored in data/cost_assessment folder as below

* Labor rate deviation: ``data/cost_assessment/labor_rate_deviation_flagged_{DATE_OF_EXECUTION}.csv``
* Labor rate variation: ``data/cost_assessment/labor_rate_variation_flagged_{DATE_OF_EXECUTION}.csv``
* Part price deviation: ``data/cost_assessment/part_price_deviation_flagged_{DATE_OF_EXECUTION}.csv``
* Part price variation: ``data/cost_assessment/part_price_variation_flagged_{DATE_OF_EXECUTION}.csv``
* Labor hours variation:  Two output files for this one at different granularity level. ``labor_hours_prediction_raw_level_{DATE_OF_EXECUTION}`` at the most granular level where the anomaly is detected. ``labor_hours_prediction_claim_level_{DATE_OF_EXECUTION}`` at the aggregated claim level.


ACR Tool - Overarching Anomaly Flagging
----------------------------------------
The goal of ACR Tool is to assist adjusters streamline review process and identify potential
risks more efficient. It collects risk signals from 4 categories:

* Client risk: risks from customer behavior and coverage
* Requestor risk: risks from dealer/shops who submitted the claim
* Vehicle risk: risks from the breakdown probability
* Financial risk: risks from the cost of labor/part that GSFS might need to pay

To capture above 4 types of risks, we worked with GSFS experts to identify the list of KPIs to track,
and determine the reasonable thresholds based on scenario analysis & feedback from key stakeholders.
On top of risks, we also flag exceptions and coverage check based on business needs.

Below are the python modules to realize ACR Tool:

* Overarching executor: ``src/acr_tool.py``
* Sub modules to collect risks from different categories:

    * ``src/acr_tool/client_risk.py``
    * ``src/acr_tool/financial_risk.py``
    * ``src/acr_tool/requestor_risk.py``
    * ``src/acr_tool/vehicle_risk.py``
    * ``src/acr_tool/exception.py``
* helper module to run compiling and aggregation: ``src/acr_tool/utils.py``


**Config file and location**: The config file specified the thresholds and weights of flags for KPIs flown into ACR tool
:``configs/acr_tool_config.yml`` .

**Input files and location**:

* Input for client risk & requestor risk: ``[bcg].[dbo].final_master_clean_table``
* Input for financial risk:
    * labor/part cost: output from labor/part cost assessment
    * other financial risk:  ``[bcg].[dbo].final_master_clean_table``
* Input for vehicle risk: output from breakdown propensity model

**Output files and location**: The output file will be stored in ``data/acr_tool_result_between_{START_CLAIM_DATE_PULLED}_and_{END_CLAIM_DATE_PULLED}_at_{DATE_OF_EXECUTION}.csv``


