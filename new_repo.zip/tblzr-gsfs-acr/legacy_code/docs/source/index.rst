.. trailblaizer_gsfs documentation master file, created by
   sphinx-quickstart on Mon Mar  4 16:27:35 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GSFS Automated Claim Review (ACR) Tool Documentation
============================================
The ACR (Automated Claim Review) Tool is an innovative AI-driven solution designed to revolutionize claim review processes.
By seamlessly integrating advanced technologies, including Machine Learning (ML) techniques and expert-derived business rules,
it aims to optimize adjudicator efficiency and operational efficacy within the claims ecosystem.

Key Objectives:

1. Automate Claim Review: The tool is engineered to automate the intricate process of claim review,
mitigating manual efforts and expediting decision-making.

2. Enhance Efficiency: By harnessing the power of AI, the ACR Tool seeks to significantly
enhance adjudicator efficiency, enabling swift identification and resolution of claim discrepancies.

3. Streamline Processes: The primary goal is to streamline claim review procedures by leveraging
cutting-edge technology to identify and address anomalies effectively.

4. Validation with experts: Combining ML algorithms with expert-derived business rules ensures a holistic approach to claim review,
integrating domain expertise with the power of automation.

In essence, the ACR Tool represents a paradigm shift in claim management,
offering a refined, efficient, and technologically-driven approach to enhance
operational excellence and mitigate risks effectively.



Below are key components to build this tool:

* ``Compile claim information``
* ``Coverage & Exception Checks``
* ``Client Risks``
* ``Requestor Risks``
* ``Breakdown Propensity``
* ``Labor/Part Cost Assessment``
* ``Coverage and Exceptions``

Pipeline flow can be found as below:

.. image:: images/workflow_acr_no_tittle.png
   :width: 100%
   :align: center


Indices and contents
---------------------

.. toctree::
   input_descriptions
   pipeline_steps
   user_guides
   security_and_privacy
   dashboard
   :maxdepth: 2



