import time
import shap
import os
import warnings
import mlflow
import pandas as pd
import numpy as np
import sys
# print(sys.path)
import mlflow.sklearn
from mlflow.models import infer_signature
from mlflow.deployments import get_deploy_client
import matplotlib.pyplot as plt
from pathlib import Path


from sklearn.linear_model import LogisticRegression
from databricks.connect import DatabricksSession
from sklearn.preprocessing import StandardScaler

notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
sys.path.append("/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)+"/tblzr-gsfs-acr")))

print("/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)+"/tblzr-gsfs-acr")))
# dbutils.fs.getWorkingDir('/Workspace/Users/akumar@friedkin.com/tblzr-gsfs-acr/configs/')
from configs.config import BaseConfig


# Run session databricks:
spark = DatabricksSession.builder.getOrCreate()

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading config file
config_file = BaseConfig.BREAKDOWN_PROB_CONFIG
data_sources = config_file["set_up_configuration"]["data_sources"]
filters = config_file["set_up_configuration"]["filters"]
modelling_config = config_file["set_up_configuration"]["modelling"]
features_to_set_to_average = modelling_config["features_to_set_to_average"]

FOLDER_PATH = data_sources["model_results_path"]
post_processing_config = config_file["set_up_configuration"]["post_processing"]

# Breakdown risk boundaries:
breakdown_risk_boundaries = config_file["set_up_configuration"]["breakdown_risk_tiers"]

# Part level granularity:
TARGET_VARIABLE = "sloss_code"


def apply_hot_encoding(df: pd.DataFrame):
    """Function used to Hot-Encode categorical features in Wide format.

    Parameters:
        df: dataframe from feature engineering step

    Returns:
        pd.DataFrame: df with hot encoded features
    """

    data = df.copy()

    # Fill missing values:
    data["strim"].fillna("-", inplace=True)

    # Implement hot encoding for non-ordinal features:
    data_hot_encoded = pd.get_dummies(
        data, columns=modelling_config["hot_encode_features"]
    )

    return data_hot_encoded


def pre_process_train_data(df: pd.DataFrame):
    """Function used remove unused fields and drop Nulls before training.

    Parameters:
        df: dataframe from feature engineering step at convo level

    Returns:
        pd.DataFrame: df with the selected rows and cols
    """

    data = df.copy()

    # Implement a logistic regression:
    data = data.dropna()

    # Remove claim_id:
    data.drop(
        columns=["iclaim_id", "make_model", "total_breakdowns_segment_ratio"],
        inplace=True,
    )
    return data


def serving_model_endpoint(model_names):
    """Function used to create a serving endpoint for the model in MLFlow.

    Parameters:
        model_names: list of models names to serve.
    """

    if len(model_names) == 0:
        return

    # Set up MLFlow CLI:
    client = get_deploy_client("databricks")

    served_entities_list = [
        {
            "name": f"sk-learn-multinomial-logit-{model}",
            "entity_name": f"sk-learn-multinomial-logit-{model}",
            "workload_type": "GPU_MEDIUM",
            "workload_size": "Medium",
            "scale_to_zero_enabled": True,
            "entity_version": 1,
        }
        for model in model_names
    ]

    def create_list(N):
        average, remainder = 100 // N, 100 % N
        result = [average] * N
        for i in range(remainder):
            result[i] += 1
        return result

    model_traffic_perc = dict(zip(model_names, create_list(len(model_names))))

    traffic_config_list = [
        {
            "served_model_name": f"sk-learn-multinomial-logit-{model}",
            "traffic_percentage": traffic,
        }
        for model, traffic in model_traffic_perc.items()
    ]

    client.create_endpoint(
        name="breakdown-engine",
        config={
            "served_entities": served_entities_list,
            "traffic_config": {"routes": traffic_config_list},
        },
    )


def dataframe_to_json(data):
    """Auxiliar function used to transform a df into a json str as a
    requirement for model serving.

    Parameters:
        data: dataframe to transform

    Returns:
        Json: json with the df information
    """

    if isinstance(data, pd.DataFrame):
        return {"inputs": {name: data[name].tolist() for name in data.columns}}
    else:
        raise ValueError("Input must be a pandas DataFrame")


class CustomModel(mlflow.pyfunc.PythonModel):
    """Attributes to be used in the prediction logic.

    Parameters:
        mlflow.pyfunc.PythonModel: MLFlow class used to build custom models
    """

    def __init__(self, model):
        self.model = model

    def predict(self, context, model_input: pd.DataFrame):

        # Get probability prediction from the model
        output = {
            "classes": self.model.classes_,
            "probabilities": self.model.predict_proba(model_input),
        }

        return output


def train_model(
    df: pd.DataFrame,
    model_name: str,
):
    """Train breakdown model and return model using pre-processed data with na
    value dropped.

    Parameters:
        df: dataframe at make-model convo used to train logit model
        model_name: model name used to store

    Returns:
        output_dict: dict with all the parameters to use for the model
        scaler: standard_scaler() object already fit
    """

    target = TARGET_VARIABLE
    data = pre_process_train_data(df)

    # Define features tu use:
    features = [col for col in data.columns if col != target]
    X = data[features]
    Y = data[target]

    # Scale numeric features using standardscaler and save std and mean for later use:
    numeric_features = X.select_dtypes(include=["float64", "int32"]).columns

    # Initialize the StandardScaler
    scaler = StandardScaler()

    # Fit the scaler on the numeric features and save the mean and std
    scaler.fit(X[numeric_features])

    # Create a dictionary to store the mean and std values by feature
    scaling_parameters_dict = {
        feature: {"mean": mean, "std_dev": std_dev}
        for feature, mean, std_dev in zip(
            scaler.feature_names_in_, scaler.mean_, scaler.scale_
        )
    }

    # Now transform (scale) the numeric features
    X_scaled = X.copy()
    X_scaled[numeric_features] = scaler.transform(X_scaled[numeric_features])

    # Define params and fit Logit engine:
    params = {
        "random_state": 42,
        "multi_class": "ovr",
        "penalty": "l1",
        "solver": "saga",
        "class_weight": "balanced",
        "n_jobs": -1,
    }

    # Fit model:
    start_time = time.time()
    model = LogisticRegression(**params)
    model.fit(pd.get_dummies(X_scaled), Y)
    print(f"Model trained in {time.time() - start_time} seconds")

    # Split the string at the first occurrence of "-"
    make_model_str = model_name.split("-", 1)

    # Store model keys and coefficients:
    itm_ls = [
        make_model_str[0].upper(),
        make_model_str[1].upper(),
        list(pd.get_dummies(X_scaled)),
        model.coef_.tolist(),
        model.classes_.tolist(),
        model.intercept_.tolist(),
        scaling_parameters_dict,
    ]

    # Implement MLFlow here to train Multinomial Logi:
    if config_file["set_up_configuration"]["mlflow_flag"]:
        exp = mlflow.set_experiment(
            experiment_name=f"{data_sources['mlflow_experiment_name']}_{model_name}"
        )

        with mlflow.start_run(experiment_id=exp.experiment_id):

            # Define custom model:
            custom_model = CustomModel(model)

            # Infer the model signature:
            output_ml = custom_model.predict(None, pd.get_dummies(X_scaled))
            signature = infer_signature(
                model_input=pd.get_dummies(X_scaled), model_output=output_ml
            )

            # Log parameters and metrics using the MLFlow APIs:
            mlflow.log_params(params)

            # Log the sklearn model and register as version:
            mlflow.pyfunc.log_model(
                python_model=custom_model,
                artifact_path="sklearn-model",
                signature=signature,
                registered_model_name=f"sk-learn-multinomial-logit-{model_name}",
            )

            print("Model successfully loaded into experiments and register MLFlow...")

    # Generate output dict:
    output_dict = {
        "model": model,
        "data": data,
        "X": X,
        "Y": Y,
        "itm_ls": itm_ls,
        "scaling_params": scaling_parameters_dict,
    }

    return output_dict, scaler


def safe_cut(x, q, labels=None, duplicates="drop"):
    """Function used to safely implement cut for a given column.

    Parameters:
        x: data used to divide on equal size percentiles
        q: number of bins to split the data
        labels: label names for bins
        duplicates: drop claim where belong to two different bins

    Returns:
        pd.DataFrame: data with the new column that map bins associated to each claim
    """

    unique_counts = x.nunique()
    if unique_counts < q:  # fewer unique values than quantiles
        # Reduce number of quantiles or handle otherwise
        return pd.qcut(
            x, unique_counts, labels=range(1, unique_counts + 1), duplicates=duplicates
        )
    else:
        return pd.qcut(x, q, labels=labels, duplicates=duplicates)


def evaluate_trained_model(
    df: pd.DataFrame,
    output_dict: dict,
    model_name: str,
    scaler: StandardScaler,
):
    """Initial Function used to implement Classifier Model and get the
    probabilities distribution used to assign risk tiers on inference.

    Parameters:
        df: master table with calculated features used to predict probabilities
        output_dict: dict with model parameters and model object
        model_name: make-model name used to filter cuts on data
        scaler: StandardScaler() object used to transform data before predicting
    """

    # Define main params:
    data = output_dict["data"].copy()
    Y = output_dict["Y"].copy()
    X = output_dict["X"].copy()

    # pull model:
    log = output_dict["model"]

    # Set to average those features for dealer dimension (predict what could happen
    # if a random dealer would serve this claim (claim to contract ratio, hours
    agg_level = ["smake", "smodel", "imodel_year"]

    average_baseline_features = (
        df.groupby(agg_level)[features_to_set_to_average].mean()
    ).reset_index()

    # Merge the average dealer values:
    x_data = X.copy()
    x_data.drop(columns=features_to_set_to_average, inplace=True)
    x_data["original_index"] = x_data.index  # Save the original index

    x_data = x_data.merge(
        average_baseline_features, on=agg_level, how="left", validate=None
    )

    # Set the original index as index (used later to match pred):
    x_data.set_index("original_index", inplace=True)  # Restore the original index

    # Scale features used during training part:
    x_data[scaler.feature_names_in_] = scaler.transform(
        x_data[scaler.feature_names_in_]
    )

    # Make predictions on the test set to get probabilities
    class_names = log.classes_

    # Get probabilities and predicted classes:
    probabilities = log.predict_proba(pd.get_dummies(x_data)[pd.get_dummies(X).columns])
    predicted_probabilities_df = pd.DataFrame(probabilities, columns=class_names)
    predicted_probabilities_df["predicted_classes"] = predicted_probabilities_df.idxmax(
        axis=1
    )

    ###########################################
    # Return readable table with final results:
    ###########################################

    # Sort df in the same order of indexes passed into prediction:
    raw_data = df.loc[x_data.index]

    # Check that the len of predicted_probabilities_df = len(raw_data):
    assert len(raw_data) == len(predicted_probabilities_df), "mismatch in shapes..."

    # Matching initial sample data:
    data_to_check = pd.concat(
        [
            raw_data.reset_index(drop=True),
            predicted_probabilities_df.reset_index(drop=True),
        ],
        axis=1,
        ignore_index=False,
    )

    #####################################################
    # Convert file in long format and add prob/threshold:
    #####################################################

    # Convert file in long format:
    id_vars = [col for col in data_to_check if col not in Y.unique()]
    value_vars = [col for col in data_to_check if col in Y.unique()]

    data_to_check_lf = pd.melt(
        data_to_check,
        id_vars=id_vars,
        value_vars=value_vars,
        var_name="category",
        value_name="probability",
    )

    # Create target probability:
    target = TARGET_VARIABLE
    data_to_check_lf["target_prob"] = np.where(
        data_to_check_lf[target] == data_to_check_lf["category"], 1, 0
    )

    ###########################
    # Calibrate probabilities:
    ##########################

    # Adjust  target to get boundaries based on category feature.
    target = "category"
    try:
        data_to_check_lf["cuts"] = data_to_check_lf.groupby(target)[
            "probability"
        ].transform(lambda x: safe_cut(x, 20, labels=range(1, 21), duplicates="drop"))

    except ValueError:
        print(
            "Error in cut function, non spread of diverse values to perform cut binning: Skip model"
        )
        return None

    # Calculate min and max boundaries per bin
    quantiles_info = data_to_check_lf.groupby([target, "cuts"])["probability"].agg(
        ["min", "max"]
    )
    quantiles_info["lift_probs_cut_boundaries"] = quantiles_info.apply(
        lambda row: [row["min"], row["max"]], axis=1
    )
    quantiles_info = (
        quantiles_info.reset_index()
        .drop_duplicates(subset=[target, "cuts"])
        .drop(columns=["min", "max"])
    )

    # merge quantiles info to base table:
    data_to_check_lf = data_to_check_lf.merge(
        quantiles_info, on=[target, "cuts"], how="left", validate=None
    )

    data_to_check_lf["overall_prob"] = data_to_check_lf.groupby([target])[
        "probability"
    ].transform("mean")
    data_to_check_lf["probability_cuts"] = data_to_check_lf.groupby([target, "cuts"])[
        "probability"
    ].transform("mean")
    data_to_check_lf["claim_counts_cuts"] = data_to_check_lf.groupby([target, "cuts"])[
        "iclaim_id"
    ].transform("size")
    data_to_check_lf["overall_prob_cuts"] = data_to_check_lf.groupby([target, "cuts"])[
        "overall_prob"
    ].transform("mean")

    # Benefit of using percentile adjustment instead part average:
    data_to_check_lf["lift"] = (
        data_to_check_lf["probability_cuts"] / data_to_check_lf["overall_prob_cuts"]
    )

    # Estimate multiple lift scenarios:
    lift_ranges = [2, 1, 0.8, 0.5]
    for i in lift_ranges:
        # Estimate lift value:
        data_to_check_lf[f"bellow_{i}x_lift"] = np.where(
            (data_to_check_lf["lift"] < i) & (data_to_check_lf["target_prob"] == 1),
            1,
            0,
        )
        # Print the number of claims flagged:
        mask_target = data_to_check_lf["target_prob"] == 1
        data_to_check_lf_copy = data_to_check_lf[mask_target]

        print("-- Percentage of claims being flagged --")
        print(
            f"bellow_{i}x_lift",
            data_to_check_lf_copy[f"bellow_{i}x_lift"].value_counts(normalize=True),
        )

    ######################################
    # Map loss code to unique description:
    ######################################

    # Load loss code from S3:
    loss_code_desc = spark.read.csv(
        data_sources["s3_files"]["loss_code_desc"], inferSchema=True, header=True
    ).toPandas()

    # Drop duplicates:
    loss_code_desc = loss_code_desc.drop_duplicates(
        subset="sloss_code", keep="first"
    ).reset_index()

    loss_code_dict = {
        loss_code_desc["sloss_code"][i]: loss_code_desc["sdetail_desc"][i]
        for i in range(len(loss_code_desc))
    }

    # map target into files to review:
    data_to_check_lf["loss_code_desc"] = data_to_check_lf[TARGET_VARIABLE].replace(
        loss_code_dict
    )

    # display shap values
    # display_shap_values(X_train, X_test, Y, log, model_name, loss_code_dict)

    # Save flat file for analysis and tier risk calculation:
    data.to_csv(f"{FOLDER_PATH}/{model_name}/model_input_data.csv", index=False)

    data_to_check_lf.to_parquet(
        f"{FOLDER_PATH}/{model_name}/predicted_classes_exploded.parquet",
    )


def display_shap_values(X_train, X_test, Y, log, model_name: str, sloss_code_dict):
    """Function used to display shap values per vehicle and loss code
    dimension.

    Parameters:
        X_train: train set dataframe
        X_test: test set dataframe
        Y: target name
        log: log object to perform Shaps
        model_name: make-model convo
        sloss_code_dict: list of loss codes used to train model
    """

    ######################
    # Display shap values:
    ######################

    X_train_ = pd.get_dummies(X_train)[pd.get_dummies(X_train).columns]
    X_test_ = pd.get_dummies(pd.get_dummies(X_test)[pd.get_dummies(X_test).columns])

    if modelling_config["compute_shap"]:
        # Create a SHAP explainer object

        explainer = shap.Explainer(log, X_train_)

        # Calculate SHAP values
        shap_values = explainer.shap_values(X_test_)

        # Display the SHAP summary plot
        for idx, part in enumerate(list(Y.unique())):

            # Create folder for part level:
            part_str = part
            sloss_code_desc = sloss_code_dict[part].replace("/", "-")

            part_veh_folder = (
                f"{FOLDER_PATH}/{model_name}/Shap Plots/{part_str} - {sloss_code_desc}"
            )
            os.makedirs(part_veh_folder)

            # Get feature index for those to include:
            features_to_include = [
                col for col in X_train_ if col not in features_to_set_to_average
            ]
            feature_indexes = [
                X_test_.columns.get_loc(feature) for feature in features_to_include
            ]

            # Filter shap for feats to consider:
            filtered_shaps = shap_values[idx][:, feature_indexes]
            filtered_X = X_test_[features_to_include]

            # Save Summary Plots:
            plt.figure(figsize=(20, 10))
            shap.summary_plot(
                filtered_shaps.astype(float),
                filtered_X,
                feature_names=filtered_X.columns,
                show=False,
            )
            plt.title("SHAP Summary Plot - {} - {}".format(part, sloss_code_desc))
            plt.savefig(
                f"{part_veh_folder}/SHAP Summary Plot - {part_str}.png",
                bbox_inches="tight",
            )

            # Close the current figure to prevent overlap
            plt.close()

            # Display shape distribution for each part/feature:
            feature = [
                col
                for col in features_to_include
                if "spayee_" not in col
                and "sloss_code" not in col
                and "strim" not in col
            ]

            for feature_ in feature:
                if X_test_[feature_].dtype == "category":
                    pass
                else:
                    shap.dependence_plot(
                        feature_,
                        shap_values[idx],
                        X_test_,
                        interaction_index=None,
                        show=False,
                    )
                    plt.title(
                        "Dependence_plot - {} - {} - {}".format(
                            part, feature_, sloss_code_desc
                        )
                    )
                    plt.savefig(
                        f"{part_veh_folder}/Dependence_plot - {part_str} - {feature_}.png"
                    )

                    # Close the current figure to prevent overlap
                    plt.close()


def implement_classifier(
    df: pd.DataFrame,
    model_name: str,
):
    """Initial Function used to implement LGB Classifier Model.

    Parameters:
        df: data input for model step
        model_name: make-model convo used to perform model

    Returns:
        pd.DataFrame: data with the new column that map bins associated to each claim
    """

    # Train the individual model based on car configuration
    output_dict, scaler = train_model(df, model_name)

    # Evaluate model trained and generate shap plots
    evaluate_trained_model(df, output_dict, model_name, scaler)

    return output_dict["model"], model_name, output_dict["itm_ls"]


def create_path_folder(folder_name: str):
    """Function used to creat folder with the make-model name on S3
    dynamically.

    Parameters:
        folder_name: folder name to create on S3
    """

    # Create a folder to dave part results:

    folder_path = f"{FOLDER_PATH}/{folder_name}"
    if not os.path.exists(folder_path):
        try:
            os.makedirs(folder_path)
            print("Directory ", folder_path, " Created ")
        except FileExistsError:
            print("Directory ", folder_path, " already exists")
    else:
        print("Directory ", folder_path, " already exists")


def concat_model_parquets(car_loss_vol):
    """Auxiliar step used to concat moke-model model outputs into a single
    parquet file.

    Parameters:
        car_loss_vol: df with volume threshold used to append into model predictions

    return:
        pd.DataFrame: output with the concat model output and volume output df
    """

    df_list = []

    # Consider only folders and not any existing parquet:
    veh_folders = [i for i in os.listdir(FOLDER_PATH) if ".parquet" not in i]

    for folder in veh_folders:

        try:
            # Read Parquet file for each model:
            df_output = pd.read_parquet(
                Path(FOLDER_PATH) / folder / "predicted_classes_exploded.parquet"
            )
            print(f"Loading Parquet for {folder} with shape {df_output.shape}")

            # Merge car_loss_vol with data:
            df_output_merge = df_output.merge(
                car_loss_vol,
                on=["smake", "smodel", "category"],
                how="left",
                validate=None,
            )

            assert (
                df_output.shape[0] == df_output_merge.shape[0]
            ), "Duplicating rows in concat_model_parquets"

            # Concat model outputs with empy df:
            df_list.append(df_output_merge)

        except FileNotFoundError:
            print(f"No Parquet for {folder}")

    # Concat df outputs:
    final_df = pd.concat(df_list, axis=0, ignore_index=True)
    print(final_df.shape)

    # Save concat output as parquet:
    final_df.to_parquet(data_sources["s3_files"]["breakdown_inference_output"])

    return final_df


def generate_master_model(model_coefficient: list):
    """Function used to generate master model table.

    Parameters:
        model_coefficient: dict with model coefficients
    """

    # Create breakdown master model table:
    breakdown_master_model = pd.DataFrame(
        model_coefficient,
        columns=[
            "make",
            "model",
            "features",
            "coefficients",
            "classes",
            "intercept",
            "scaler_params",
        ],
    )

    # Save table into S3:
    breakdown_master_model.to_parquet(data_sources["s3_files"]["master_model_results"])


def implement_ai_engine(data: pd.DataFrame):
    """Main function used to train breakdown models, based on multiple data
    cuts depending on what vehicle segment is under consideration.

    Parameters:
        data: df used to implement modelling
    """

    data_to_model = data.copy()

    # Replace backslash for dash to not break code when saving results:
    data_to_model["make_model"] = (
        data_to_model["smake"].str.replace("/", "-")
        + "-"
        + data_to_model["smodel"].str.replace("/", "-")
    )

    # Create empty dict to save models and coefficients:
    model_coefficient = []
    model_name_list = []

    make_model_list = list(set([i for i in data_to_model["make_model"]]))
    print(f"Number of unique make_model: {len(make_model_list)}")

    for model in make_model_list:

        print(f"*** Estimating Breakdown Probabilities for model: {model} ***")

        # Create folder to save model outputs and plots:
        create_path_folder(folder_name=model)

        # Filter data by model:
        data_by_model = data_to_model[data_to_model["make_model"] == model]

        # Include hot encoding specific to model:
        data_by_model = apply_hot_encoding(data_by_model)

        print(
            f"data shape : {data_by_model.shape}, "
            f"Number of unique Loss codes: {len(data_by_model[TARGET_VARIABLE].unique())}"
        )

        # Skip execution if loss type have low sample:
        if data_by_model[TARGET_VARIABLE].nunique() < 10:
            print("Low number of parts to model - Skip")
            continue

        # Skip execution if p >n (features greater than datapoints):
        if data_by_model.shape[0] < data_by_model.shape[1]:
            print("features set greater than datapoints to model - Skip")
            continue

        # Implement Model for Multiclass:
        mdl, model_name_mlflow, itm_ls = implement_classifier(
            df=data_by_model,
            model_name=model,
        )

        model_name_list.append(model_name_mlflow)
        model_coefficient.append(itm_ls)

    # Create breakdown master model table:
    generate_master_model(model_coefficient)


def implement_risk_tiers(
    data: pd.DataFrame,
):
    """Function used to implement risk tiers and lift boundary information.
    This considers the lift estimated on prediction step, and assign risk tiers
    to each bin depending on lift value.

    Parameters:
        data: df with model predictions and bins calculation.

    return:
        pd.DataFrame: output with risk tier assigned by bin
    """

    df = data.copy()

    # capture high car and loss volume mask:
    high_car_volume_mask = df["low_car_volume"] == 0
    high_volume_mask = high_car_volume_mask

    # Implement low, medium and high risk boundaries depending on lift:
    high_risk_mask = (
        df["lift"].between(
            breakdown_risk_boundaries["low_boundary_high_risk"],
            breakdown_risk_boundaries["high_boundary_high_risk"],
        )
    ) & high_volume_mask

    medium_risk_mask = (
        df["lift"].between(
            breakdown_risk_boundaries["low_boundary_medium_risk"],
            breakdown_risk_boundaries["high_boundary_medium_risk"],
        )
    ) & high_volume_mask

    low_risk_mask = (
        df["lift"] > breakdown_risk_boundaries["high_boundary_medium_risk"]
    ) & high_volume_mask

    # Implement risk tiers:
    df.loc[high_risk_mask, "risk_tier"] = 1
    df.loc[medium_risk_mask | ~high_car_volume_mask, "risk_tier"] = 2
    df.loc[low_risk_mask, "risk_tier"] = 3

    print(
        "**Risk Tiers Breakdown:**\n",
        df.groupby("risk_tier", observed=True)["lift"].agg(["min", "max"]),
    )

    return df


def generate_volume_loss_threshold(data):
    """Function used to generate volume and loss frequency threshold. This is
    required to identify low make-model vehicles representation and turn off
    model recommendation.

    Parameters:
        data: df with vehicle volume count

    return:
        pd.DataFrame: output with risk tier assigned by bin
    """

    volume = (
        data.groupby(["smake", "smodel"])["iclaim_id"]
        .count()
        .to_frame("count")
        .reset_index()
    )
    loss_freq = (
        data.groupby(["smake", "smodel", "sloss_code"])["iclaim_id"]
        .count()
        .to_frame("count")
        .reset_index()
    )

    # Estimate 10th percentile threshold for vehicle and loss frequency:
    volume["volume_threshold"] = 100
    loss_freq["loss_threshold"] = loss_freq["count"].mean()

    # Define low volume and loss frequency:
    volume["low_car_volume"] = np.where(
        volume["count"] < volume["volume_threshold"], 1, 0
    )

    loss_freq["low_loss_volume"] = np.where(
        loss_freq["count"] < loss_freq["loss_threshold"], 1, 0
    )

    # remove count cols:
    volume.drop(columns="count", inplace=True)
    loss_freq.drop(columns="count", inplace=True)

    table = loss_freq.merge(volume, on=["smake", "smodel"], how="left", validate=None)

    # rename category to match with inference pipeline:
    table.rename(columns={"sloss_code": "category"}, inplace=True)

    return table


def generate_risk_tiers_inference(
    df: pd.DataFrame,
):
    """Function used to calculate risk tiers, depending on the predicted
    probability, hit rate of the model during backtesting and review claim
    cost. This estimates the value at risk (VAR) threshold need it for flagging
    a claim as a high medium and low risk.

    Parameters:
        df: df with the model predictions

    return:
        pd.DataFrame: output with risk tier assigned
    """

    cols_to_track = [
        "smake",
        "smodel",
        "category",
        "cuts",
        "lift",
        "volume_threshold",
        "loss_threshold",
        "low_car_volume",
        "low_loss_volume",
        "lift_probs_cut_boundaries",
    ]

    # Remove duplicated claims that has been handle for different dealers:
    model_output = df[cols_to_track].copy()
    model_output = model_output.dropna(subset="lift").drop_duplicates(
        subset=cols_to_track[:-1]
    )

    # Implement risk tiers dataset:
    breakdown_output_full = implement_risk_tiers(model_output)

    # Retrieve the Hit rates and assign to each lift tier:
    hit_rate_breakdown = pd.DataFrame(
        post_processing_config["hit_rate_breakdown"].items(),
        columns=["risk_tier", "hit_rate"],
    )

    # Map hit rates to pre-computed table:
    breakdown_output_full["hit_rate"] = breakdown_output_full["risk_tier"].map(
        hit_rate_breakdown.set_index("risk_tier")["hit_rate"]
    )

    # rename category to match with inference pipeline:
    breakdown_output_full.rename(columns={"category": "sloss_code"}, inplace=True)

    # Write the interim output into S3:
    breakdown_output_full.to_parquet(data_sources["s3_files"]["risk_tiers_output"])


def main():
    """Main function to orchestrate steps to perform model training,
    probabilities evaluation, lift calculation and risk tier computation on
    breakdown."""

    print("*** Initializing Breakdown Probability Model ***")

    # Load feature engineering output from S3:
    feature_engineering_output = spark.read.csv(
        data_sources["s3_files"]["breakdown_inference_input"],
        header=True,
        inferSchema=True,
    ).toPandas()
    print("Feature engineering output loaded...")

    # Generate threshold on volume and loss frequency:
    car_loss_vol = generate_volume_loss_threshold(feature_engineering_output)
    print("generate_volume_loss_threshold loaded...")

    # Implement classifier by vehicle granularity:
    implement_ai_engine(feature_engineering_output)
    print("Step to train and register MLFlow models is done...")

    # Concatenate model results:
    final_df = concat_model_parquets(car_loss_vol)
    print("Concatenate model results is done...")

    # generate risk tiers and lift boundary information:
    generate_risk_tiers_inference(final_df)
    print("Pre-compute risk tiers and probability cuts is done...")

if __name__ == "__main__":
    main()
