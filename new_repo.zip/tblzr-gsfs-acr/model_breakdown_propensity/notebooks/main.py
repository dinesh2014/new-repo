import cProfile
import pstats

from io import StringIO
from datetime import datetime, timezone, timedelta
import sys

sys.path.append("../../")
# sys.path.append(str(pathlib.Path(__file__).parent.parent.parent.resolve()))

from configs.config import get_env_variables

from model1.feature_engineering.features.feature_engineering import (
    main_breakdown as main_feature_engineering_breakdown,
)
from model1.training.train.breakdown_model import main as main_train_breakdown


# Define the path to save the profile report:
env_vars = get_env_variables()
profile_results_path = f"{env_vars['base_path']}/artifacts/acr_profile/ml_training/"

# Define the time difference between UTC and Central Time
ct_offset = timedelta(hours=-5)

# Get the current date and time in Central Time
date_folder = (datetime.now(timezone.utc) + ct_offset).strftime("%Y-%m-%d")


def train_ml_models():
    """Main executor for training package on breakdown, labor hours and tire
    and wheels models."""

    # Initialize profiling execution:
    pr = cProfile.Profile()
    pr.enable()

    try:
        # Load master table and train breakdown model:
        fe_output = main_feature_engineering_breakdown()
        main_train_breakdown(fe_output)

        # Load master table and train labor hour model:
        # fe_labor_hours = main_feature_engineering_labor_hours()
        # main_train_labor_hours(fe_labor_hours)

        # Load master table for TW and train models:
        # main_feature_engineering_tire_and_wheel()
        # main_train_tire_and_wheel()

    finally:
        pr.disable()

        # Define the folder path to save results:
        folder_path = profile_results_path + date_folder
        print(folder_path)

        # Create unique folder path:
        dbutils.fs.mkdirs(folder_path)

        # Save profile report on date-jobid folder:
        profile_file = folder_path + "/" + "profile_data.prof"
        pr.dump_stats(profile_file)

        # Write to text file as well
        text_profile_file = folder_path + "/" + "profile_data.txt"
        stats = pstats.Stats(str(profile_file))
        stats.sort_stats("cumulative")
        s = StringIO()
        stats.stream = s
        stats.print_stats()
        profile_stats = s.getvalue()
        with open(text_profile_file, "w") as f:
            f.write(profile_stats)

        print(f"Code profiling completed. Saved in {profile_file}")
        print("To view the profile file with snakeviz, run: `snakeviz <profile_file>`")


if __name__ == "__main__":
    train_ml_models()
