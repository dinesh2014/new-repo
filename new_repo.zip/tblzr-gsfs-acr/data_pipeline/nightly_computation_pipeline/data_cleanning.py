import sys
import os

notebook_path = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
sys.path.append(
    "/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)))
)
import warnings
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, trim
from pyspark.sql.types import StringType
from configs.config import BaseConfig

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading config file
config_file = BaseConfig.DATA_CLEANING_CONFIG
loss_table_cols_to_keep = config_file["loss_table_cols_keep"]
data_sources = config_file["set_up_configuration"]["data_sources"]
input_folder = data_sources["input_folder"]
output_folder = data_sources["output_folder"]
filters = config_file["set_up_configuration"]["filters"]


def clean_master_table():
    """Function used to filter claim status different to "Paid", to pull part
    information to the same level as claim status (loss code).

    Parameters:
        None
    Returns:
        pyspark.sql.DataFrame: the filtered dataframe with relevant claims
    """
    # Define input source to use
    raw_claim_master_table = data_sources["input_tables"]["claim_master_table"]

    # Filter string values to apply
    relevant_claim_filters = filters["relevant_claim_filters"]

    claim_status_str_list = relevant_claim_filters["iclaim_det_status_id"]
    claim_detail_str_list = relevant_claim_filters["sdetail_type"]
    source_claim_str_list = relevant_claim_filters["ssource_table"]
    bt_coverage_flag_str_list = relevant_claim_filters["btcovered_flag"]
    iproduct_type_id_str_list = relevant_claim_filters["iproduct_type_id"]

    # Load base table
    df = spark.read.parquet(f"{input_folder}/{raw_claim_master_table}")

    # Filter on raw master claim table
    filtered_df = df.filter(
        (
            (trim(col("sdetail_type")).isin(claim_detail_str_list))
            & (trim(col("ssource_table")).isin(source_claim_str_list))
            & (col("iproduct_type_id").isin(iproduct_type_id_str_list))
        )
        | (col("iclaim_id").isNull())
    )
    # .filter(col("btcovered_flag").isin(bt_coverage_flag_str_list))
    # .filter(col("iclaim_det_status_id").isin(claim_status_str_list))

    return filtered_df


def cross_match_part_to_loss_details(filtered_df: DataFrame):
    """Main function to cross merge los detail information (tagged with
    ssource_table = 'D') with part details for the same loss (tagged with
    ssource_table = 'P')

    :param
        db_manager (DBManager): the class of database connector
        config: set of configuration files needed to run the code
    :return:
        None
    """
    final_clean_master_table = data_sources["output_tables"]["final_clean_master_table"]

    # Process source table = D
    df_master_loss_desc = filtered_df.filter(
        (trim(col("ssource_table")) == "D")
        & (col("btcovered_flag") == True)
        & (col("sloss_code").isNotNull())
    ).dropDuplicates()

    # Process source table = P
    df_master_part_desc = filtered_df.filter(
        (trim(col("ssource_table")) == "P")
        & ((col("btcovered_flag").isNull()) | (col("btcovered_flag") == False))
    ).dropDuplicates()

    df_empty_claim = filtered_df.filter(
        (col("iclaim_id").isNull()) & (col("icontract_id").isNotNull())
    )

    # Get column names of the filtered DataFrame
    full_mt_cols = filtered_df.columns

    # Assuming loss_table_cols_to_keep and loss_table_cols_tp_keep are lists of column names
    # Add table prefix to keep only target columns
    full_mt_cols_selected = list(
        set([col for col in full_mt_cols if col not in loss_table_cols_to_keep])
    )
    loss_cols_selected = list(
        set(
            [col for col in loss_table_cols_to_keep if col not in full_mt_cols_selected]
        )
    )

    join_key = ["iclaim_id", "sdetail_type", "creq_total", "dtcycle_date", "sjob_no"]
    loss_cols_selected = list(set(loss_cols_selected + join_key))

    # Select columns from df_master_part_desc and df_master_loss_desc
    df_final_clean_master_table = df_master_part_desc.select(
        full_mt_cols_selected
    ).join(df_master_loss_desc.select(loss_cols_selected), on=join_key, how="left")

    # Attach empty claim dataframe
    df_empty_claim_selected = df_empty_claim.select(
        list(df_final_clean_master_table.columns)
    )

    df_combined = df_final_clean_master_table.unionByName(df_empty_claim_selected)

    # Rename columns
    df_combined = df_combined.withColumnRenamed("camt_paid", "camt_paid_original")
    df_combined = df_combined.withColumnRenamed("cext_total_amt", "camt_paid")

    # Trim all columns
    new_cols = []
    for field in df_combined.schema.fields:
        if isinstance(field.dataType, StringType):
            new_cols.append(F.trim(F.col(field.name)).alias(field.name))
        else:
            new_cols.append(F.col(field.name))
    trimed_df = df_combined.select(*new_cols)

    # Clean up swheel drive count column
    trimed_df = trimed_df.withColumn(
        "swheel_drive_count", F.col("swheel_drive_count").cast("integer")
    )
    trimed_df = trimed_df.fillna({"swheel_drive_count": 2})

    # Step to convert empty strings to None
    trimed_df = trimed_df.withColumn(
        "sloss_code",
        F.when(F.trim(F.col("sloss_code")) == "", None).otherwise(
            F.trim(F.col("sloss_code"))
        ),
    ).withColumn(
        "spart_no",
        F.when(F.trim(F.col("spart_no")) == "", None).otherwise(
            F.trim(F.col("spart_no"))
        ),
    )

    # Save output to s3
    # Write the DataFrame to Parquet format in S3
    df_out = trimed_df.dropDuplicates()
    df_out.write.mode("overwrite").parquet(
        f"{output_folder}/{final_clean_master_table}"
    )


def data_cleaning():
    """Filtering data for breakdown model and cost detection approach.

    :param:
        None

    :return:
        None
    """

    # Apply filters to non desire claim status:
    filtered_df = clean_master_table()
    print("Cleaning up master table for relevant claim status...")

    # Pull part information into same loss type level:
    cross_match_part_to_loss_details(filtered_df)
    print("Matching part information to loss descriptions...")

    print("Data cleaning is complete.")


if __name__ == "__main__":
    data_cleaning()
