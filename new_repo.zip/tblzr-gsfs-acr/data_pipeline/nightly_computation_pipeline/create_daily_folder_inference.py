import sys
import os

notebook_path = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
sys.path.append(
    "/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)))
)

from datetime import datetime
from pyspark.sql import SparkSession
from configs.config import env_variables


# Create SparkSession (Databricks)
spark = SparkSession.builder.appName("CreateEmptyFolderInS3").getOrCreate()

S3_BUCKET_INTERIM_RESULTS = (
    f"{env_variables['base_path']}/ingest/intermediate_results/inference/"
)


def generate_daily_folder_uc(
    spark: SparkSession,
    s3_bucket: str,
    inference_folder: str,
):
    """Function used to generate an empty folder in S3 with the current date.
    This function is used to create a daily folder in S3 to store the inference
    results.

    Parameters:
        spark (SparkSession): the class of SparkSession
        s3_bucket (str): the S3 bucket name
        inference_folder (str): the path to the folder in S3

    Returns:
        None
    """
    # Get today's date
    today_date = datetime.now().strftime("%Y-%m-%d")

    # Define S3 path where the folder will be created
    folder_path = s3_bucket + inference_folder + "/" + today_date + "/"

    # Create an empty DataFrame
    empty_df = spark.createDataFrame([], "dummy STRING")
    dbutils.fs.mkdirs(folder_path)

    # Write the empty DataFrame to the specified S3 path, this will create the folder
    empty_df.write.mode("overwrite").parquet(folder_path)

    print("Empty folder created at:", folder_path)


if __name__ == "__main__":
    # Define folders to create daily sub folder.
    folder_names = ["breakdown", "labor_hours", "kpi_refreshment", "tire_and_wheel"]

    for folder in folder_names:
        generate_daily_folder_uc(spark, S3_BUCKET_INTERIM_RESULTS, folder + "/")
        print("*** Daily folder created for:", folder, "***")
