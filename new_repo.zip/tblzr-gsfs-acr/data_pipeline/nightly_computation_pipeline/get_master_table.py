import sys
import os

notebook_path = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
sys.path.append(
    "/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)))
)

from configs.config import BaseConfig
from datetime import datetime
import warnings
from pyspark.sql.functions import col, trim, max, when
from pyspark.sql import functions as F

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading config file
config_file = BaseConfig.MASTER_TABLE_CONFIG
data_sources = config_file["set_up_configuration"]["data_sources"]
filters = config_file["set_up_configuration"]["filters"]
input_folder = data_sources["input_folder"]
output_folder = data_sources["output_folder"]


def create_historical_claim_table(
    config: dict,
) -> None:
    """Function used to execute SQL queries to merge historical claims with
    claim details.

    :param: config: set of config information needed to run the model
    :return: None
    """

    # Datasets to consider:
    claim_history_table = data_sources["input_tables"]["claim_history_table"]
    overall_claim_table = data_sources["input_tables"]["overall_claim_table"]
    claim_detail_hist_table = data_sources["output_tables"]["claim_detail_history_flt"]

    # Columns to keep from both tables:
    claims_history_cols = config["scs_claim_details_history_cols"]
    overall_claim_cols = config["scs_claims_cols"]

    # Load files required

    df = (
        spark.read.parquet(f"{input_folder}/{claim_history_table}")
        .select(claims_history_cols)
        .withColumnRenamed("spart_desc", "spart_desc_claim_detail_history")
    )

    df2 = spark.read.parquet(f"{input_folder}/{overall_claim_table}").select(
        overall_claim_cols
    )

    # Merge tables
    merged_df = df.join(df2, on="iclaim_id", how="inner")

    # Write the DataFrame to Parquet format in S3
    merged_df.write.mode("overwrite").parquet(
        f"{output_folder}/{claim_detail_hist_table}"
    )


def add_contract_and_vehicle_information(
    config: dict,
) -> None:
    """Pull "claim_detail_history_flt" table from input data.

    :param: config: set of config files needed to run the model
    :return: None
    """

    # Datasets to consider:
    contracts_table = data_sources["input_tables"]["contracts_table"]
    contracts_earning_table = data_sources["input_tables"]["contracts_earning_table"]
    vin_information_table = data_sources["input_tables"]["vin_information_table"]
    claim_detail_hist_table = data_sources["output_tables"]["claim_detail_history_flt"]

    # Table to write results:
    claim_contract_vin_table = data_sources["output_tables"]["claim_contract_vin_table"]

    # Columns to keep from both tables:
    contract_cols = config["scs_contracts_cols"]
    contracts_earning_cols = config["scs_contract_earnings_cols"]
    vin_information_cols = config["polk_vin_detail_cols"]

    # Load files required
    df_base = spark.read.parquet(f"{output_folder}/{claim_detail_hist_table}")
    df_contract = spark.read.parquet(f"{input_folder}/{contracts_table}")
    df_contract = df_contract.select(
        [c for c in df_contract.columns if c in contract_cols]
    )

    df_contract_earning = spark.read.parquet(
        f"{input_folder}/{contracts_earning_table}"
    )
    df_contract_earning = df_contract_earning.select(
        [c for c in df_contract_earning.columns if c in contracts_earning_cols]
    )

    df_vin = spark.read.parquet(f"{input_folder}/{vin_information_table}")
    df_vin = df_vin.select([c for c in df_vin.columns if c in vin_information_cols])

    # Filter on active contracts and specific product types
    df_contract = df_contract.filter(
        (col("dtcontract_effect") <= F.current_date())
        & (col("dtcontract_expiration") > F.current_date())
        & (col("dtcontract_eff_cancell").isNull())
    )  # valid contract
    df_contract = df_contract.filter(
        col("iproduct_type_id").isin([int(x) for x in filters["iproduct_type_id"]])
    )

    # Merge tables
    merged_df = df_base.join(df_contract, on="icontract_id", how="right")
    merged_df = merged_df.join(df_contract_earning, on="icontract_id", how="left")
    merged_df = merged_df.join(
        df_vin, merged_df["srating_vin"] == df_vin["svin"], how="left"
    )

    # Write the DataFrame to Parquet format in S3
    merged_df.write.mode("overwrite").parquet(
        f"{output_folder}/{claim_contract_vin_table}"
    )


def add_part_details_into_master_table(config: dict) -> None:
    """Function used to merge 'claim_contract_vin_table' with scs_parts :param
    db_manager:

    :param config:
    :return: None
    """

    # Datasets to consider:
    claim_contract_vin_table = data_sources["output_tables"]["claim_contract_vin_table"]
    scs_parts_table = data_sources["input_tables"]["scs_parts_table"]
    # forte_parts_table = data_sources['input_tables']['forte_parts_table']

    # Table to write results:
    claim_contract_vin_part_table = data_sources["output_tables"][
        "claim_contract_vin_part_table"
    ]

    # Columns to pull
    scs_parts_cols = config["scs_parts_cols"]
    # forte_parts_cols = config['scs_parts_import_temp_cols']

    # Load files required
    df_base = spark.read.parquet(f"{output_folder}/{claim_contract_vin_table}")

    df_parts = spark.read.parquet(f"{input_folder}/{scs_parts_table}")
    df_parts = df_parts.select([c for c in df_parts.columns if c in scs_parts_cols])

    # Merge columns in
    merged_df = df_base.join(
        df_parts, on=["spart_no", "smanufacturer_code"], how="left"
    )

    # Write the DataFrame to Parquet format in S3
    merged_df.write.mode("overwrite").parquet(
        f"{output_folder}/{claim_contract_vin_part_table}"
    )


def add_forte_labor_into_master_table(config: dict) -> None:
    """Function used to merge 'claim_contract_vin_part_table' with historical
    Forte labor rate table :param db_manager:

    :param config:
    :return:
    """

    # Datasets to consider:
    claim_contract_vin_part_table = data_sources["output_tables"][
        "claim_contract_vin_part_table"
    ]
    forte_labor_table = data_sources["input_tables"]["forte_labor_table"]
    claim_payees_table = data_sources["input_tables"]["claim_payees_table"]

    # Table to write results:
    claim_master_table = data_sources["output_tables"]["claim_master_table"]
    forte_labor_cols = config["scs_labor_rate_date_ranges_cols"]

    # Load files required
    df_base = spark.read.parquet(f"{output_folder}/{claim_contract_vin_part_table}")

    df_forte_labor = spark.read.parquet(f"{input_folder}/{forte_labor_table}")
    df_forte_labor = df_forte_labor.select(
        [c for c in df_forte_labor.columns if c in forte_labor_cols]
    )

    df_payee = spark.read.parquet(f"{input_folder}/{claim_payees_table}")
    df_payee = (
        df_payee.filter((col("spayee_no").isNotNull()) & (trim(col("spayee_no")) != ""))
        .groupby("spayee_no", "spayee_type")
        .agg(max("ipayee_id").alias("ipayee_id"))
    )

    # Merge columns in
    joined_df_1 = df_base.join(df_payee, on=["spayee_no", "spayee_type"], how="left")

    # Trim columns in joined
    joined_df_1 = joined_df_1.withColumn(
        "sservice_center_type", trim(col("sservice_center_type"))
    ).withColumn("spayee_type", trim(col("spayee_type")))

    # Trim columns
    df_forte_labor = df_forte_labor.withColumn(
        "sparent_type_code", trim(col("sparent_type_code"))
    )

    # Define join conditions for the second join
    join_condition = (
        (joined_df_1["ipayee_id"] == df_forte_labor["iparent_id"])
        & (joined_df_1["dtdate_claim_paid"] >= df_forte_labor["dtstart"])
        & (
            joined_df_1["dtdate_claim_paid"]
            <= when(df_forte_labor["dtend"].isNull(), "2199-12-31").otherwise(
                df_forte_labor["dtend"]
            )
        )
        & (
            (
                when(
                    (joined_df_1["sservice_center_type"] == "D")
                    | (joined_df_1["spayee_type"] == "D"),
                    "SLR",
                )
            ).otherwise("SVC")
            == df_forte_labor["sparent_type_code"]
        )
    )

    # Perform the second left join and select the columns
    merged_df = joined_df_1.join(df_forte_labor, join_condition, "left")

    # Write the DataFrame to Parquet format in S3
    merged_df.write.mode("overwrite").parquet(f"{output_folder}/{claim_master_table}")

    ## TODO: Add historical forte part pricing file
    """
    IF OBJECT_ID('{claim_contract_vin_part_table}', 'U') IS NOT NULL
    DROP TABLE {claim_contract_vin_part_table};

    SELECT T1.*, {cols_to_pull}
    INTO {claim_contract_vin_part_table}
    FROM {claim_contract_vin_table} T1
    LEFT JOIN
        {scs_parts_table} T2 ON T1.spart_no = T2.spart_no
        AND T1.smanufacturer_code = T2.smanufacturer_code
    LEFT JOIN
        {forte_parts_table} T3 ON T1.smanufacturer_code = T3.soem_code
        AND T1.spart_no = T3.spart_number and T1.dtclaim_system_entry_date>T3.from_date
        AND T1.dtclaim_system_entry_date <= T3.to_date

    """


def main():
    """Main function used to stack initial tables and create a master table.

    :param:
    :return: None
    """

    # Capture start time for execution:
    start_time = datetime.now()

    # Execute query to build historical_claim table:
    create_historical_claim_table(config_file)
    print("Temporal claim history table already created")

    # Execute function to add contract and vehicle information:
    add_contract_and_vehicle_information(config_file)
    print("Vehicle information included into MT data")

    # Incorporate part details for Toyota and Non-Toyota Vehicles:
    add_part_details_into_master_table(config_file)
    print("Part information included into MT data")

    # Incorporate Forte labor details for Toyota and Non-Toyota Vehicles:
    add_forte_labor_into_master_table(config_file)
    print("Forte labor information included into MT data")

    print(
        "Final Master table created into SQL Server. Time to get done: {}".format(
            datetime.now() - start_time
        )
    )


if __name__ == "__main__":
    main()
