import sys
import os
import pandas as pd
import numpy as np

notebook_path = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
sys.path.append(
    "/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)))
)
import warnings
from pyspark.sql.functions import col, current_date, avg
from pyspark.sql import functions as F
from pyspark.sql.functions import (
    expr,
    first,
    lower,
    row_number,
    when,
    year,
    countDistinct,
    regexp_extract,
    split,
)
from pyspark.sql.types import DoubleType
from configs.config import BaseConfig
from pyspark.sql.window import Window

from utils.utils import save_output, trim_all_string_columns

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading config file
config_file = BaseConfig.PRE_COMPUTE_CONFIG
data_sources = config_file["set_up_configuration"]["data_sources"]
input_folder = data_sources["input_folder"]
sample_input_folder = data_sources["sample_input_folder"]
raw_input_folder = data_sources["raw_input_folder"]
input_tables = data_sources["input_tables"]
output_folder = data_sources["output_folder"]
output_tables = data_sources["output_tables"]
params = config_file["params"]
master_input_file = data_sources["input_tables"]["master_clean_table"]
selected_cols = config_file["selected_cols"]

from databricks.connect import DatabricksSession

# Disable warnings during execution
warnings.filterwarnings("ignore")

# Create SparkSession (Local)
spark = DatabricksSession.builder.getOrCreate()


def create_contract_parts_config(df_input, prod_suffix):
    """Function to take master dataset and create information on contract.

    Parameters:
        df_input (DataFrame): Input DataFrame with dealer data.
        n_mon (int): Number of months to look back for calculating metrics.
        prod_suffix (str): t&w or vsc

    Returns:
        df_out (dataframe): A DataFrame with aggregated data
    """
    if prod_suffix == "":
        df_out = df_input.select(
            ["scontract_no", "smake", "strim", "smodel", "imodel_year"]
        ).dropDuplicates(subset=["scontract_no"])
    elif prod_suffix == "_tw":
        df_out = df_input.select(
            [
                "scontract_no",
                "smake",
                "strim",
                "smodel",
                "imodel_year",
                "snew_used",
                "icontract_mileage",
                "icontract_term",
                "cpremium_rate",
                "icontract_type",
            ]
        ).dropDuplicates(subset=["scontract_no"])
    else:
        df_out = df_input.select(
            ["scontract_no", "smake", "strim", "smodel", "imodel_year"]
        ).dropDuplicates(subset=["scontract_no"])

    # Write the DataFrame to Parquet format in S3
    save_output(
        df_out,
        f"{output_folder}{output_tables['contract_parts_config']}{prod_suffix}",
        ["smake"],
    )

    return df_out


# Create benchmark - part + make + issue
# Create claim level benchmark metrics


def create_benchmark_part_make_issue_level_metrics(df_input, n_mon, prod_suffix):
    """This function is used to generate part make-issue pre-comp metrics from
    a DataFrame at make, loss code & part number.

    Parameters:
        df_input (DataFrame): Input DataFrame with master data
        n_mon (int): Number of months to look back for calculating metrics.
        prod_suffix (str): t&w or vsc

    Returns:
        df_out (dataframe): A DataFrame with aggregated data
    """

    # Get a copy of the input DataFrame
    df = df_input
    grp_level = ["smake", "sloss_code", "spart_no"]

    # Calculate the date x months ago from today
    x_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter on # paid claims over last 12 months
    df = df.filter(
        (df["dtdate_loss_occurred"] >= x_months_ago)
        & (df["sclaim_status"].contains("P"))
        & (df["iclaim_det_status_id"] == 4)
    )

    # Get part cost and labor cost
    df_part = (
        df.filter(df["sdetail_type"].contains("P"))
        .groupBy(["sclaim_number"] + grp_level)
        .agg(F.sum("nreq_qty").alias("part_individual_count"))
    )

    # Aggregate to calculate the number of claims and total per agg level:
    df_claim_count = df_part.groupBy(grp_level).agg(
        F.countDistinct("sclaim_number").alias("part_make_issue_prev_paid_claims_cnt"),
    )

    # Calculate thresholds
    threshold_ls = [0.80, 0.90, 0.95]

    # Aggregate calculations for each percentile threshold
    df_part_agg = df_part.groupBy(grp_level).agg(
        expr(f"percentile(part_individual_count, {threshold_ls[0]})").alias(
            f"part_individual_count_{int(threshold_ls[0] * 100)}"
        )
    )

    for threshold_percentile in threshold_ls[1:]:
        df_part_itm = df_part.groupBy(grp_level).agg(
            expr(f"percentile(part_individual_count, {threshold_percentile})").alias(
                f"part_individual_count_{int(threshold_percentile * 100)}"
            )
        )

        df_part_agg = df_part_agg.join(df_part_itm, grp_level, "outer")

    df_out = df_part_agg
    df_out = df_out.join(df_claim_count, grp_level, "outer")

    # Write the DataFrame to Parquet format in S3

    save_output(
        df_out,
        f"{output_folder}{output_tables['benchmark_part_make_issue_level_metrics']}{prod_suffix}",
        ["sloss_code"],
    )

    return df_out


# Create benchmark - make + issue


def create_benchmark_make_issue_level_metrics(df_input, n_mon, prod_suffix):
    """This function is used to generate claim-level pre-comp metrics from a
    DataFrame.

    Parameters:
        df_input (DataFrame): Input DataFrame with master data
        n_mon (int): Number of months to look back for calculating metrics.
        prod_suffix (str): t&w or vsc

    Returns:
        df_out (dataframe): A DataFrame with aggregated data
    """

    # Get a copy of the input DataFrame
    df = df_input
    grp_level = ["smake", "sloss_code"]

    # Calculate the date x months ago from today
    x_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter on # paid claims over last x months
    df = df.filter(
        (df["dtdate_loss_occurred"] >= x_months_ago)
        & (df["sclaim_status"].contains("P"))
        & (df["iclaim_det_status_id"] == 4)
    )

    # Get part cost and labor cost
    df_part = (
        df.filter(df["sdetail_type"].contains("P"))
        .groupBy(["sclaim_number"] + grp_level)
        .agg(
            F.sum("camt_paid_original").alias("part_req_total"),
            F.countDistinct("spart_no").alias("nb_parts"),
        )
    )
    df_labor = (
        df.filter(df["sdetail_type"].contains("L"))
        .groupBy(["sclaim_number"] + grp_level)
        .agg(F.sum("camt_paid_original").alias("labor_req_total"))
    )

    # Aggregate to calculate the number of claims and total per agg level:
    df_claim_count = df_part.groupBy(grp_level).agg(
        F.countDistinct("sclaim_number").alias("make_issue_prev_paid_claims_cnt"),
    )

    # Calculate thresholds
    threshold_ls = [0.80, 0.90, 0.95]

    # Aggregate calculations for each percentile threshold
    df_part_agg = df_part.groupBy(grp_level).agg(
        expr(f"percentile(part_req_total, {threshold_ls[0]})").alias(
            f"part_req_total_{int(threshold_ls[0] * 100)}"
        )
    )
    df_part_agg2 = df_part.groupBy(grp_level).agg(
        expr(f"percentile(nb_parts, {threshold_ls[0]})").alias(
            f"nb_parts_{int(threshold_ls[0] * 100)}"
        )
    )
    df_part_agg = df_part_agg.join(df_part_agg2, grp_level, "outer")

    df_labor_agg = df_labor.groupBy(grp_level).agg(
        expr(f"percentile(labor_req_total, {threshold_ls[0]})").alias(
            f"labor_req_total_{int(threshold_ls[0] * 100)}"
        )
    )

    for threshold_percentile in threshold_ls[1:]:
        df_part_itm = df_part.groupBy(grp_level).agg(
            expr(f"percentile(part_req_total, {threshold_percentile})").alias(
                f"part_req_total_{int(threshold_percentile * 100)}"
            )
        )
        df_part_itm2 = df_part.groupBy(grp_level).agg(
            expr(f"percentile(nb_parts, {threshold_percentile})").alias(
                f"nb_parts_{int(threshold_percentile * 100)}"
            )
        )

        df_labor_itm = df_labor.groupBy(grp_level).agg(
            expr(f"percentile(labor_req_total, {threshold_percentile})").alias(
                f"labor_req_total_{int(threshold_percentile * 100)}"
            )
        )

        df_part_itm = df_part_itm.join(df_part_itm2, grp_level, "outer")
        df_part_agg = df_part_agg.join(df_part_itm, grp_level, "outer")
        df_labor_agg = df_labor_agg.join(df_labor_itm, grp_level, "outer")

    df_out = df_part_agg.join(df_labor_agg, grp_level, "outer")
    df_out = df_out.join(df_claim_count, grp_level, "outer")

    # Write the DataFrame to Parquet format in S3

    save_output(
        df_out,
        f"{output_folder}{output_tables['benchmark_make_issue_level_metrics']}{prod_suffix}",
        ["sloss_code"],
    )

    return df_out


def create_benchmark_dealer_issue_level_metrics(df_dealer_issue):
    """This function is used to generate claim-level pre-comp metrics from a
    DataFrame.

    Parameters:
        df_dealer_issue (DataFrame): Input DataFrame with master data

    Returns:
        df_out (dataframe): A DataFrame with aggregated data
    """

    # Get a copy of the input DataFrame

    grp_level = ["sloss_code"]

    # Calculate thresholds
    threshold_ls = [0.80, 0.90, 0.95]

    # Aggregate calculations for each percentile threshold
    df_agg = df_dealer_issue.groupBy(grp_level).agg(
        expr(f"percentile(dealer_issue_repair_freq, {threshold_ls[0]})").alias(
            f"dealer_issue_repair_freq_{int(threshold_ls[0] * 100)}"
        )
    )

    for threshold_percentile in threshold_ls[1:]:
        df_itm = df_dealer_issue.groupBy(grp_level).agg(
            expr(f"percentile(dealer_issue_repair_freq, {threshold_percentile})").alias(
                f"dealer_issue_repair_freq_{int(threshold_percentile * 100)}"
            )
        )

        df_agg = df_agg.join(df_itm, grp_level, "outer")

    df_out = df_agg

    return df_out


# Create contract level metric
def create_contract_level_metrics(df_input, n_mon, prod_suffix):
    """This function is used to generate 3 pre-compute metrics at contract
    level, i.e. # paid claims, total previous claim payout, latest mileage at
    loss.

    Parameters:
        df_input (DataFrame): Input DataFrame with master data
        n_mon (int): Number of months to look back for calculating metrics.
        prod_suffix (str): t&w or vsc

    Returns:
        df_out (dataframe): A DataFrame with aggregated data
    """
    # Get a copy of input dataframe
    df = df_input

    # Calculate the date 12 months ago from today
    twelve_months_ago = F.add_months(F.current_date(), -n_mon)

    # Apply filters on paid entries only
    df_contract = df.filter(df["iclaim_det_status_id"] == 4)

    # Calculate # of paid claims over last 12 months under the same contract for the same product. This will be directly used for contract claim freq flag
    df_contract0 = (
        df_contract.filter(col("dtdate_loss_occurred") >= twelve_months_ago)
        .groupBy("scontract_no")
        .agg(F.countDistinct("sclaim_number").alias("contract_prev_paid_claims_cnt"))
    )

    # Get total previous payout and claim count across entire history
    df_contract1 = df_contract.groupBy("scontract_no").agg(
        F.sum("camt_paid_original").alias("contract_prev_claim_payout"),
        F.max("cmsrp").alias("msrp"),
    )

    # Calculate the latest mileage at loss
    # Step 1: Sort the DataFrame
    df_contract = df_contract.sort(df_contract["dtdate_loss_occurred"].desc())

    # Step 2: Group by 'scontract_no' and get the first 'iodometer_at_time_of_loss' from each group
    df_contract2 = df_contract.groupBy("scontract_no").agg(
        F.first("iodometer_at_time_of_loss").alias("latest_mileage_at_loss")
    )

    # Merge all contract level metrics
    df_out = df_contract1.join(df_contract2, on="scontract_no", how="outer").join(
        df_contract0, on="scontract_no", how="outer"
    )
    df_out = df_out.fillna(
        {"contract_prev_paid_claims_cnt": 0, "contract_prev_claim_payout": 0}
    )

    # Get total claim payut / MSRP
    df_out = df_out.withColumn(
        "contract_payout_msrp",
        F.when(
            col("msrp") != 0, col("contract_prev_claim_payout") / col("msrp")
        ).otherwise(F.lit(None)),
    )

    # Write the DataFrame to Parquet format in S3
    df_out.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['contract_level_metrics']}{prod_suffix}"
    )

    return df_out


def create_customer_level_metrics(df_input, n_mon, prod_suffix):
    """Generate customer-level metrics including claim counts, claim payouts,
    premium totals, and claim to contract ratios, based on claims and contract
    data from the last n months.

    Parameters:
    df_input (DataFrame): Input DataFrame with mastr data
    n_mon (int): Number of months to look back from the current date for metrics calculation.

    Returns:
    df_customer (DataFrame): A DataFrame with aggregated customer-level metrics.
    """
    # Calculate the date 12 months ago from today
    twelve_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last 12 months --> Use this to calculate how many claims paid in last 12 months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= twelve_months_ago)
        & (df_input["sclaim_status"].contains("P"))
        & (df_input["iclaim_det_status_id"] == 4)
        & (df_input["spayee_no"].isNotNull())
        & (df_input["spayee_no"] != "")
    )

    # Don't filter on claims --> Use this to calculate how many contracts earned in last 12 months
    # This table needs to be at contract level
    df_filtered2 = df_input.select(
        "scontract_no",
        "scontract_holder_fname",
        "scontract_holder_lname",
        "scontract_holder_email",
        "dtcontract_effect",
        "dtcontract_expiration",
        "dtcontract_eff_cancell",
        "dtcontract_eff_cancell",
        "ctotal_earned_prem",
        "cpremium_rate",
    ).dropDuplicates(
        subset=[
            "scontract_no",
            "scontract_holder_fname",
            "scontract_holder_lname",
            "scontract_holder_email",
        ]
    )

    # Aggregate to get the number of claims and total claim payout per customer in last 12 months
    df_customer_claims = df_filtered.groupBy(
        "scontract_holder_fname", "scontract_holder_lname", "scontract_holder_email"
    ).agg(
        F.countDistinct("sclaim_number").alias("customer_prev_paid_claims_cnt"),
        F.sum("camt_paid_original").alias("customer_prev_claim_payout"),
    )
    df_customer_claims = df_customer_claims.filter(
        col("customer_prev_claim_payout") > 0
    )

    # Filter and group to calculate total earned premium and number of contracts per customer
    df_customer_contracts = (
        df_filtered2.filter(
            (df_filtered2["dtcontract_effect"] < F.current_date())
            & (df_filtered2["dtcontract_expiration"] > twelve_months_ago)
            & (
                (df_filtered2["dtcontract_eff_cancell"].isNull())
                | (df_filtered2["dtcontract_eff_cancell"] > twelve_months_ago)
            )
        )
        .groupBy(
            "scontract_holder_fname", "scontract_holder_lname", "scontract_holder_email"
        )
        .agg(
            F.sum("ctotal_earned_prem").alias("customer_earned_premium"),
            F.countDistinct("scontract_no").alias("customer_nb_contracts"),
            F.sum("cpremium_rate").alias("customer_prem_rate"),
        )
    )

    # Join the claim data with contract data
    df_customer = df_customer_claims.join(
        df_customer_contracts,
        on=[
            "scontract_holder_fname",
            "scontract_holder_lname",
            "scontract_holder_email",
        ],
        how="outer",
    )

    # Fill NaN with a specific value
    df_customer = df_customer.fillna(
        {
            "customer_prev_paid_claims_cnt": 0,
            "customer_nb_contracts": 0,
            "customer_earned_premium": 0,
            "customer_prem_rate": 0,
        }
    )

    # Calculate the claim to contract ratio, handling division by zero
    df_customer = df_customer.withColumn(
        "customer_claim_to_contract_ratio",
        F.when(
            col("customer_earned_premium") != 0,
            col("customer_prev_paid_claims_cnt")
            / (col("customer_earned_premium") / col("customer_prem_rate"))
            / col("customer_nb_contracts"),
        ).otherwise(F.lit(None)),
    )

    # Write the DataFrame to Parquet format in S3
    df_customer.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['customer_level_metrics']}{prod_suffix}"
    )

    return df_customer


## Create dealer level metrics


def create_dealer_level_metrics(df_input, n_mon, prod_suffix):
    """Create dealer-level metrics based on input DataFrame and specified
    number of months.

    Parameters:
        df_input (DataFrame): Input DataFrame with master data
        n_mon (int): Number of months to look back for calculating metrics.
        prod_suffix (str): t&w or vsc

    Returns:
        df_dealer (dataframe): A DataFrame with aggregated data
    """
    # Calculate the date 12 months ago from today
    twelve_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last 12 months --> Use this to calculate how many claims paid in last 12 months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= twelve_months_ago)
        & (df_input["sclaim_status"].contains("P"))
        & (df_input["iclaim_det_status_id"] == 4)
        & (df_input["spayee_no"].isNotNull())
        & (df_input["spayee_no"] != "")
    )

    # Don't filter on claims --> Use this to calculate how many contracts earned in last 12 months
    # This table needs to be at contract level
    df_filtered2 = df_input.select(
        "scontract_no",
        "sdealer_number",
        "dtcontract_effect",
        "dtcontract_expiration",
        "dtcontract_eff_cancell",
        "dtcontract_eff_cancell",
        "ctotal_earned_prem",
        "cpremium_rate",
    ).dropDuplicates(subset=["scontract_no", "sdealer_number"])

    # Aggregate to calculate the number of claims and total payout per dealer
    df_dealer1 = df_filtered.groupBy("spayee_no").agg(
        F.countDistinct("sclaim_number").alias("dealer_prev_paid_claims_cnt"),
        F.sum("camt_paid_original").alias("dealer_prev_claim_payout"),
    )

    # Calculate all the contracts sold that ever been active in last 12 months
    df_dealer2 = (
        df_filtered2.filter(
            (df_filtered2["dtcontract_effect"] < F.current_date())
            & (df_filtered2["dtcontract_expiration"] > twelve_months_ago)
            & (
                (df_filtered2["dtcontract_eff_cancell"].isNull())
                | (df_filtered2["dtcontract_eff_cancell"] > twelve_months_ago)
            )
        )
        .groupBy(col("sdealer_number").alias("spayee_no"))
        .agg(
            F.countDistinct("scontract_no").alias("dealer_nb_contracts"),
            F.sum("ctotal_earned_prem").alias("dealer_earned_premium"),
            F.sum("cpremium_rate").alias("dealer_prem_rate"),
        )
    )

    # Join the aggregates to compute dealer-level metrics
    df_dealer = df_dealer1.join(df_dealer2, on=["spayee_no"], how="outer")

    # Fill NaN with a specific value
    df_dealer = df_dealer.fillna(
        {
            "dealer_prev_paid_claims_cnt": 0,
            "dealer_nb_contracts": 0,
            "dealer_earned_premium": 0,
            "dealer_prem_rate": 0,
        }
    )

    # Calculate the dealer claim to contract ratio and average payout per claim
    df_dealer = df_dealer.withColumn(
        "dealer_claim_to_contract_ratio",
        F.when(
            col("dealer_earned_premium") != 0,
            col("dealer_prev_paid_claims_cnt")
            / (
                (col("dealer_earned_premium") / col("dealer_prem_rate"))
                * col("dealer_nb_contracts")
            ),
        ).otherwise(F.lit(None)),
    ).withColumn(
        "dealer_avg_payout_per_claim",
        F.when(
            col("dealer_prev_paid_claims_cnt") != 0,
            col("dealer_prev_claim_payout") / col("dealer_prev_paid_claims_cnt"),
        ).otherwise(F.lit(None)),
    )

    # Write the DataFrame to Parquet format in S3
    df_dealer.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['dealer_level_metrics']}{prod_suffix}"
    )

    return df_dealer


# Create dealer issue level metrics


def create_dealer_issue_level_metrics(df_input, n_mon, prod_suffix):
    """Create dealer-issue level metrics based on input DataFrame and specified
    number of months.

    Parameters:
        df_input (DataFrame): Input DataFrame with master data
        n_mon (int): Number of months to look back for calculating metrics.
        prod_suffix (str): t&w or vsc

    Returns:
        df_dealer_issue (dataframe): A DataFrame with aggregated data
    """
    # Calculate the date 12 months ago from today
    twelve_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last 12 months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= twelve_months_ago)
        & (df_input["sclaim_status"].contains("P"))
    )

    # Aggregate to calculate the number of claims and total payout per dealer for each loss code
    df_dealer_issue = df_filtered.groupBy("spayee_no", "sloss_code").agg(
        F.countDistinct("sclaim_number").alias("dealer_issue_prev_paid_claims_cnt"),
        F.sum("camt_paid_original").alias("dealer_issue_prev_claim_payout"),
    )
    df_dealer_issue = df_dealer_issue.withColumn(
        "dealer_issue_avg_payout_per_claim",
        col("dealer_issue_prev_claim_payout")
        / col("dealer_issue_prev_paid_claims_cnt"),
    )

    # Calculate averages per loss code
    df_losscode_avg = df_dealer_issue.groupBy("sloss_code").agg(
        F.mean("dealer_issue_prev_paid_claims_cnt").alias("issue_avg_paid_claims_cnt"),
        F.mean("dealer_issue_avg_payout_per_claim").alias("issue_avg_payout_per_claim"),
    )

    # Join back issue level averages into dealer issue table
    df_dealer_issue = df_dealer_issue.join(df_losscode_avg, on="sloss_code", how="left")
    df_dealer_issue = df_dealer_issue.withColumn(
        "dealer_issue_repair_freq",
        col("dealer_issue_prev_paid_claims_cnt") / col("issue_avg_paid_claims_cnt"),
    )

    # Get the labor hours for issues where detail type is 'L'
    df_dealer_labor = (
        df_input.filter(
            (df_input["sdetail_type"].contains("L"))
            & (df_input["sclaim_status"].contains("P"))
        )
        .groupBy("spayee_no", "sloss_code")
        .agg(F.sum("nreq_qty").alias("dealer_issue_labor_hours"))
    )

    # Calculate average labor hours per loss code
    df_losscode_labor_avg = df_dealer_labor.groupBy("sloss_code").agg(
        F.mean("dealer_issue_labor_hours").alias("issue_avg_labor_hours")
    )

    # Join labor hours averages back into dealer labor table
    df_dealer_labor = df_dealer_labor.join(
        df_losscode_labor_avg, on="sloss_code", how="left"
    )

    # Merge all dealer issue level metrics
    df_dealer_issue = df_dealer_issue.join(
        df_dealer_labor, on=["spayee_no", "sloss_code"], how="outer"
    )

    # Calculate indexed labor hours per claim weighted
    df_dealer_issue = df_dealer_issue.withColumn(
        "dealer_issue_labor_hours_per_claim",
        col("dealer_issue_labor_hours") / col("issue_avg_labor_hours"),
    )

    # Generate  threshold
    df_threshold = create_benchmark_dealer_issue_level_metrics(df_dealer_issue)

    df_dealer_issue = df_dealer_issue.join(df_threshold, on="sloss_code", how="outer")

    # Write the DataFrame to Parquet format in S3

    save_output(
        df_dealer_issue,
        f"{output_folder}{output_tables['dealer_issue_level_metrics']}{prod_suffix}",
        ["sloss_code"],
    )
    return df_dealer_issue


def create_make_model_mdlyr_dealer_issue_level_metrics(df_input, n_mon):
    """Create dealer-issue level metrics based on input DataFrame and specified
    number of months.

    Parameters:
        df_input (DataFrame): Input DataFrame with mster data
        n_mon (int): Number of months to look back for calculating metrics.
     prod_suffix (str): Suffix for the output table names..

    Returns:
        df_final (DataFrame): A dataframe with aggregated data
    """
    # Calculate the date n_mon months ago from today
    twelve_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last n_mon months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= twelve_months_ago)
        & (df_input["sclaim_status"].contains("P"))
    )

    # Aggregate to calculate the number of claims and total payout per dealer for each loss code
    df_dealer_issue = df_filtered.groupBy(
        "spayee_no", "sloss_code", "smake", "smodel", "imodel_year"
    ).agg(
        F.countDistinct("sclaim_number").alias("issue_dealer_car_segment_claims_cnt"),
        F.sum("camt_paid_original").alias("issue_dealer_car_segment_payout"),
    )

    # Calculate averages per loss codes
    df_losscode_avg = df_dealer_issue.groupBy(
        "sloss_code", "smake", "smodel", "imodel_year"
    ).agg(
        F.sum("issue_dealer_car_segment_claims_cnt").alias(
            "issue_total_car_segment_claims_cnt"
        )
    )

    # Join back issue level averages into dealer issue table
    df_dealer_issue = (
        df_dealer_issue.join(
            df_losscode_avg,
            on=["sloss_code", "smake", "smodel", "imodel_year"],
            how="left",
        )
        .withColumn(
            "issue_dealer_car_segment_ratio",
            col("issue_dealer_car_segment_claims_cnt")
            / col("issue_total_car_segment_claims_cnt"),
        )
        .withColumn(
            "dealer_issue_labor_cost_per_claim",
            col("issue_dealer_car_segment_payout")
            / col("issue_dealer_car_segment_claims_cnt"),
        )
    )

    # Get the labor hours for issues where detail type is 'L'
    df_dealer_labor_pre = (
        df_input.filter(
            (df_input["sdetail_type"].contains("L"))
            & (df_input["sclaim_status"].contains("P"))
            & (df_input["dtdate_loss_occurred"] >= twelve_months_ago)
            & (df_input["iclaim_det_status_id"] == 4)
        )
        .groupBy(
            "spayee_no", "sloss_code", "smake", "smodel", "imodel_year", "sclaim_number"
        )
        .agg(F.sum("nreq_qty").alias("claim_dealer_issue_labor_hours"))
    )

    df_dealer_labor = df_dealer_labor_pre.groupBy(
        "spayee_no", "sloss_code", "smake", "smodel", "imodel_year"
    ).agg(F.mean("claim_dealer_issue_labor_hours").alias("dealer_issue_labor_hours"))

    # Calculate average labor hours per loss code
    df_losscode_labor_avg = df_dealer_labor_pre.groupBy(
        "sloss_code", "smake", "smodel", "imodel_year"
    ).agg(F.mean("claim_dealer_issue_labor_hours").alias("issue_avg_labor_hours"))

    # Join labor hours averages back into dealer labor table
    df_dealer_labor = df_dealer_labor.join(
        df_losscode_labor_avg,
        on=["sloss_code", "smake", "smodel", "imodel_year"],
        how="left",
    ).withColumn(
        "avg_prev_labor_hours_ratio",
        col("dealer_issue_labor_hours") / col("issue_avg_labor_hours"),
    )

    # Merge all dealer issue level metrics
    df_out = df_dealer_issue.join(
        df_dealer_labor,
        on=["spayee_no", "sloss_code", "smake", "smodel", "imodel_year"],
        how="outer",
    )

    # Take average of all 3 metrics that will be used in modeling
    df_out1 = df_out.groupBy("sloss_code", "smake", "smodel", "imodel_year").agg(
        F.mean("avg_prev_labor_hours_ratio").alias("avg_prev_labor_hours_ratio"),
        F.mean("issue_dealer_car_segment_ratio").alias(
            "issue_dealer_car_segment_ratio"
        ),
    )

    df_out2 = df_out.select(
        "spayee_no",
        "smake",
        "smodel",
        "imodel_year",
        "sloss_code",
        "dealer_issue_labor_cost_per_claim",
    )

    df_final = df_out2.join(
        df_out1, on=["sloss_code", "smake", "smodel", "imodel_year"], how="right"
    )

    # Fill na
    df_final = df_final.fillna(
        {
            "dealer_issue_labor_cost_per_claim": 0,
            "avg_prev_labor_hours_ratio": 0,
            "issue_dealer_car_segment_ratio": 0,
        }
    )

    # drop negative value
    df_final = df_final.withColumn(
        "dealer_issue_labor_cost_per_claim",
        when(col("dealer_issue_labor_cost_per_claim") < 0, None).otherwise(
            col("dealer_issue_labor_cost_per_claim")
        ),
    )

    # Write the DataFrame to Parquet format in S3
    df_final.write.mode("overwrite").parquet(
        f"{output_folder}{output_tables['make_model_mdlyr_dealer_issue_level_metrics']}"
    )

    return df_final


# Create make model issue metrics


def create_make_model_issue_level_metrics(df_input, n_mon):
    """Create make-model-issue level metrics based on input DataFrame and
    specified number of months.

    Parameters:
    df_input (DataFrame): Input DataFrame from master tabel
    n_mon (int): Number of months to look back for calculating metrics.

    Returns:
    df_make_model_issue (DataFrame): An aggregated data frame
    """

    # Calculate the date x months ago from today
    x_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last 3 months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= x_months_ago)
        & (df_input["sclaim_status"].contains("P"))
    )

    # Aggregate to calculate the number of claims and total payout per make, model, and issue
    df_make_model_issue = df_filtered.groupBy("smake", "smodel", "sloss_code").agg(
        F.countDistinct("sclaim_number").alias("make_model_issue_prev_paid_claims_cnt"),
        F.sum("camt_paid_original").alias("make_model_issue_prev_claim_payout"),
    )

    # Calculate averages per make and model
    df_make_model_avg = df_make_model_issue.groupBy("smake", "smodel").agg(
        F.mean("make_model_issue_prev_paid_claims_cnt").alias(
            "make_model_avg_paid_claims_cnt"
        )
    )

    # Join back make-model level averages into the make-model-issue table
    df_make_model_issue = df_make_model_issue.join(
        df_make_model_avg, on=["smake", "smodel"], how="left"
    ).withColumn(
        "make_model_issue_repair_freq",
        col("make_model_issue_prev_paid_claims_cnt")
        / col("make_model_avg_paid_claims_cnt"),
    )

    # Write the DataFrame to Parquet format in S3
    save_output(
        df_make_model_issue,
        f"{output_folder}{output_tables['make_model_issue_level_metrics']}",
        ["sloss_code"],
    )

    return df_make_model_issue


# Create dealer make model issue level metrics


def create_dealer_make_model_issue_level_metrics(df_input, n_mon, prod_suffix):
    """Create dealer-make-model-issue level metrics based on input DataFrame
    and specified number of months.

    Parameters:
    df_input (DataFrame): Input DataFrame of mater input data
    n_mon (int): Number of months to look back for calculating metrics.

    Returns:
    df_dealer_issue_make_model (dataframe): A DataFrame with aggregated output
    """

    # Calculate the date x months ago from today
    x_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last 12 months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= x_months_ago)
        & (df_input["sclaim_status"].contains("P"))
        & (df_input["iclaim_det_status_id"] == 4)
    )

    # Aggregate to calculate the number of claims and total payout per dealer, make, model, and issue
    df_dealer_issue_make_model = (
        df_filtered.groupBy("spayee_no", "smake", "smodel", "sloss_code")
        .agg(
            F.countDistinct("sclaim_number").alias(
                "dealer_issue_make_model_prev_paid_claims_cnt"
            ),
            F.sum("camt_paid_original").alias(
                "dealer_issue_make_model_prev_claim_payout"
            ),
        )
        .withColumn(
            "issue_make_model_avg_payout_per_claim",
            col("dealer_issue_make_model_prev_claim_payout")
            / col("dealer_issue_make_model_prev_paid_claims_cnt"),
        )
    )

    # Calculate make + model + loss code level total paid cnt across dealers
    df_total_cnt = df_dealer_issue_make_model.groupBy(
        "smake", "smodel", "sloss_code"
    ).agg(
        F.sum("dealer_issue_make_model_prev_paid_claims_cnt").alias(
            "total_paid_claims_cnt"
        )
    )
    df_dealer_issue_make_model = df_dealer_issue_make_model.join(
        df_total_cnt, on=["smake", "smodel", "sloss_code"], how="left"
    )
    del df_total_cnt

    # Calculate % of paid claim cnt vs. total for each dealer at different make + model + loss code level
    df_dealer_issue_make_model = df_dealer_issue_make_model.withColumn(
        "issue_dealer_car_segment_ratio_index",
        col("dealer_issue_make_model_prev_paid_claims_cnt")
        / col("total_paid_claims_cnt"),
    )

    # Calculate avg % of paid claim cnt ratio across dealers for inference flow
    df_avg_ratio = df_dealer_issue_make_model.groupBy(
        "smake", "smodel", "sloss_code"
    ).agg(
        F.mean("issue_dealer_car_segment_ratio_index").alias(
            "issue_dealer_car_segment_ratio"
        )
    )

    # Join back the metrics we calculated
    df_dealer_issue_make_model = df_dealer_issue_make_model.join(
        df_avg_ratio, on=["smake", "smodel", "sloss_code"], how="left"
    )
    df_dealer_issue_make_model = df_dealer_issue_make_model.drop(
        "issue_dealer_car_segment_ratio_index", "total_paid_claims_cnt"
    )
    del df_avg_ratio

    # Get the labor cost for entries where detail type is 'L'
    df_dealer_labor_cost = (
        df_filtered.filter(df_filtered["sdetail_type"].contains("L"))
        .groupBy("spayee_no", "sloss_code", "smake", "smodel")
        .agg(F.sum("camt_paid_original").alias("dealer_issue_make_model_labor_cost"))
    )

    # Merge all metrics
    df_dealer_issue_make_model = df_dealer_issue_make_model.join(
        df_dealer_labor_cost,
        on=["spayee_no", "sloss_code", "smake", "smodel"],
        how="outer",
    ).withColumn(
        "dealer_issue_make_model_labor_cost_per_claim",
        col("dealer_issue_make_model_labor_cost")
        / col("dealer_issue_make_model_prev_paid_claims_cnt"),
    )
    # Write the DataFrame to Parquet format in S3

    save_output(
        df_dealer_issue_make_model,
        f"{output_folder}{output_tables['dealer_issue_make_model_level_metrics']}{prod_suffix}",
        ["sloss_code"],
    )
    return df_dealer_issue_make_model


# Create part make model issue level metrics


def create_part_make_model_issue_level_metrics(df_input, n_mon=12):
    """Create median part price for past 12 months.

    Parameters:
        df_input (DataFrame): Input DataFrame of master input table
        n_mon (int): Number of months to look back for calculating metrics.

    Returns:
        df_part_make_model_issue_median (DataFrame): An aggregated data frame
    """
    # Calculate the date n months ago from today
    months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last n months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= months_ago)
        & (df_input["sclaim_status"].contains("P"))
    )

    # Calculate historical median
    df_part_make_model_issue_median = df_filtered.groupBy(
        "spart_no", "smake", "smodel", "sloss_code"
    ).agg(F.median(col("creq_unit_cost")).alias("part_price_median"))

    # Write the DataFrame to Parquet format in S3

    save_output(
        df_part_make_model_issue_median,
        f"{output_folder}{output_tables['part_make_model_issue_median_metrics']}",
        ["sloss_code"],
    )
    return df_part_make_model_issue_median


# Create dealer issue make level metrics


def create_dealer_make_issue_level_metrics(df_input, n_mon=12):
    """Compute labor rates for past n months.

    Parameters:
        df_input (DataFrame): Input DataFrame with dealer, make, and issue types.
        n_mon (int): Number of months to look back for calculating metrics.

    Returns:
        df_dealer_make_issue_median (DataFrame): An aggregated data frame
    """

    # Calculate the date n months ago from today
    months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter claims that were paid in the last n months
    df_filtered = df_input.filter(
        (df_input["dtdate_loss_occurred"] >= months_ago)
        & (df_input["sdetail_type"].contains("L"))
    )

    # Calculate historical median
    df_dealer_make_issue_median = df_filtered.groupBy(
        "spayee_no", "smake", "sloss_code"
    ).agg(F.median(col("creq_unit_cost")).alias("labor_rate_median"))
    # Write the DataFrame to Parquet format in S3

    save_output(
        df_dealer_make_issue_median,
        f"{output_folder}{output_tables['dealer_make_issue_median_metrics']}",
        ["sloss_code"],
    )
    return df_dealer_make_issue_median


def pull_labor_rate_deviation(prod_suffix):
    """Function used to pull the latest labor rate for labor rate deviation
    calculation at the dealer level.

    Parameters:
        prod_suffix (str): Suffix to be added to the output table name
    Returns:
        pyspark.sql.DataFrame: the dataframe with the latest labor rates by dealer and dealer type level
    """
    # Get the latest forte labor rate by dealer and dealer type level
    df_labor_rate = spark.read.parquet(
        raw_input_folder + data_sources["input_tables"]["labor_rate_table"]
    )

    # Get the master claim payee information to find payee id and payee no mapping
    df_payees = (
        spark.read.parquet(raw_input_folder + data_sources["input_tables"]["payee"])
        .select("ipayee_id", "spayee_no")
        .dropDuplicates()
    )

    # Trim all string columns for raw tables
    df_labor_rate = trim_all_string_columns(df_labor_rate)
    df_payees = trim_all_string_columns(df_payees)

    # Apply filters to payee table and labor rate tables
    df_payees = df_payees.filter(
        (df_payees["spayee_no"] != "") & (df_payees["spayee_no"].isNotNull())
    )

    # Join the latest labor rate and payee mapping table
    df_labor_rate = df_labor_rate.join(
        df_payees, df_labor_rate["iparent_id"] == df_payees["ipayee_id"], how="inner"
    )

    # Find the latest labor rate ordering by start date
    df_labor_rate = df_labor_rate.orderBy(col("dtstart").desc())
    df_labor_rate = df_labor_rate.groupBy("sparent_type_code", "spayee_no").agg(
        first("clabor_rate").alias("clabor_rate")
    )

    df_labor_rate = df_labor_rate.drop("ipayee_id", "iparent_id")

    # Write the DataFrame to Parquet format in S3
    df_labor_rate.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['labor_rate_deviation_metircs']}{prod_suffix}"
    )

    return df_labor_rate


def pull_part_price_variation_metrics(df_input, n_mon=12):
    """This function is used to pull part price historical median.

    Parameters:
        df_input (DataFrame): Input DataFrame of master dataset
        n_mon (int): Number of months to look back for calculating metrics.

    Returns:
        df_dealer_make_issue_median (DataFrame): An aggregated data frame
    """

    # Get the input table
    df = df_input

    # remove empty part no:
    df = df.filter("spart_no != ''")

    # Apply filters
    months_ago = F.add_months(F.current_date(), -n_mon)

    df = df.filter(
        (col("sdetail_type").contains("P"))
        & (col("iclaim_det_status_id") == 4)
        & (col("sclaim_status").contains("P"))
        & (col("dtdate_loss_occurred") > months_ago)
    )

    # Select specific columns and remove duplicates
    df = df.select(
        [
            "sclaim_number",
            "spart_no",
            "sloss_code",
            "smake",
            "spart_desc_claim_detail_history",
            "cauth_unit_cost",
        ]
    ).dropDuplicates()

    # Apply filters to exclude specific descriptions and enforce a minimum claim count
    df = df.filter(
        ~F.lower(col("spart_desc_claim_detail_history")).contains("reman")
        & ~F.lower(col("spart_desc_claim_detail_history")).contains("refrig")
        & ~F.lower(col("spart_desc_claim_detail_history")).contains("superceded")
    )

    # Perform aggregation to compute median and count distinct values
    df_out = df.groupBy(["spart_no", "sloss_code", "smake"]).agg(
        F.median("cauth_unit_cost").alias("median_part_price"),
        F.countDistinct("sclaim_number").alias("n_claim"),
    )

    df_out = df_out.filter(col("n_claim") >= 5).drop("n_claim")

    # Write the DataFrame to Parquet format in S3

    save_output(
        df_out,
        f"{output_folder}{output_tables['part_price_variation_metircs']}",
        ["sloss_code"],
    )
    return df_out


def create_state_list_table(prod_suffix):
    """Create a DataFrame in PySpark containing a list of state codes.

    Parameters:
    prod_suffix (str):

    Returns:
    DataFrame: A DataFrame with a single column 'state' listing all states.
    """
    # Extract the list of state codes from the config dictionary

    flag_state_list = params["flag_state_ls" + prod_suffix]

    # Create a DataFrame from the list of state codes
    df = spark.createDataFrame(
        [(state,) for state in flag_state_list], ["spayee_state"]
    )
    df = df.withColumn("requester_state_flag", F.lit(1))

    # This function now returns the DataFrame instead of showing it

    # Write the DataFrame to Parquet format in S3
    df.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['flag_state_metrics']}{prod_suffix}"
    )
    return df


def pull_labor_rate_variation_metrics(df_input, n_mon=12):
    """Function used to pull historical median labor rates from the input
    DataFrame.

    Parameters:
        df_input (DataFrame): the input dataframe containing labor rate data
        n_mon (int): the number of months of historical data to consider (default is 12)
    Returns:
        DataFrame: the dataframe with median labor rates and filtered relevant data
    """
    # Get the input table
    df = df_input

    # Apply filters
    months_ago = F.add_months(F.current_date(), -n_mon)
    df = df.filter(
        (col("sdetail_type").contains("L"))
        & (col("iclaim_det_status_id") == 4)
        & (col("sclaim_status").contains("P"))
        & (col("dtdate_loss_occurred") > months_ago)
    )

    # Select specific columns and remove duplicates
    df = df.select(
        ["sclaim_number", "spayee_no", "sloss_code", "smake", "cauth_unit_cost"]
    ).dropDuplicates()

    # Perform aggregation to compute median and count distinct values
    df_out = df.groupBy(["spayee_no", "sloss_code", "smake"]).agg(
        F.median("cauth_unit_cost").alias("median_labor_rate"),
        F.countDistinct("sclaim_number").alias("n_claim"),
    )

    # Filter on dealer + make + loss codes with enough claims
    df_out = df_out.filter(col("n_claim") >= 5).drop("n_claim")

    # Filter out invalid dealers
    df_out = df_out.filter((col("spayee_no") != "") & (col("spayee_no").isNotNull()))

    # Write the DataFrame to Parquet format in S3
    save_output(
        df_out,
        f"{output_folder}{output_tables['labor_rate_variation_metrics']}",
        ["sloss_code"],
    )
    return df_out


def create_supporting_mapping(df, prod_suffix):
    """
    Function used to create an auxiliary table to map parts within a loss type.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe containing the parts and loss type data
        prod_suffix (str): suffix to be added to the output table names
    Returns:
        tuple: two dataframes - one with loss code mappings and one with part number mappings
    """
    # Drop rows with null values in the specified columns
    df_filtered = df.na.drop(subset=["sloss_code", "spart_no"])

    # Create a dataframe for loss codes
    df_loss_code = df_filtered.select("sloss_code", "sdetail_desc").dropDuplicates(
        subset=["sloss_code"]
    )

    # Create a dataframe for part numbers
    df_part_no = (
        df_filtered.filter(col("sdetail_type") == "P")
        .select("spart_no", "smake", "spart_desc")
        .dropDuplicates(subset=["spart_no", "smake"])
    )

    # Write the DataFrame to Parquet format in S3
    df_loss_code.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['loss_code_mapping']}{prod_suffix}"
    )
    df_part_no.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['part_no_mapping']}{prod_suffix}"
    )

    return df_loss_code, df_part_no


def create_supporting_mapping_tw(df):
    """Function to create part mapping for tire & wheel.

    Parameters:
        df (DataFrame): Dataframe input of master dataset

    Returns:
        df_out (DataFrame): An aggregated data frame with part prices mapped
    """
    # Drop nulls based on loss code and detail type
    df_filtered = df.filter(col("sdetail_type") == "P").na.drop(
        subset=["sloss_code", "spart_no"]
    )
    df_filtered = df_filtered.filter(col("sloss_code") != "")

    # Select a subset of columns and drop duplicates
    df_filtered = df_filtered.select(
        "sloss_code",
        "sdetail_desc",
        "spart_no",
        "spart_desc",
        "sdetail_type",
        "spart_desc_claim_detail_history",
    ).dropDuplicates(subset=["sloss_code", "spart_no"])

    # Fill na with '' for spart_desc
    df_filtered = df_filtered.withColumn("spart_desc", col("spart_desc").cast("string"))
    df_filtered = df_filtered.withColumn("spart_no", col("spart_no").cast("string"))
    df_filtered = df_filtered.fillna({"spart_desc": ""})

    # Identify tire and wheel replacement from loss code description
    df_filtered = (
        df_filtered.withColumn("split_detail_desc", split(col("sdetail_desc"), "/"))
        .withColumn("detail", col("split_detail_desc").getItem(0))
        .withColumn("grp", col("split_detail_desc").getItem(1))
    )

    # TODO might no longer be needed
    # Identify product type between wheel vs tire, we only consider modeling fore replacement, accounting for 98% of cases
    df_filtered = df_filtered.withColumn(
        "tw_prod_type",
        when(lower(col("detail")).contains("wheel replace"), "wheel").otherwise(
            when(lower(col("detail")).contains("tire replace"), "tire").otherwise(
                "other_prod"
            )
        ),
    )

    # Remove unused columns
    df_filtered = df_filtered.drop("split_detail_desc", "detail", "grp")

    # Extract extra features for T&W
    # Define the regex pattern
    regex_pattern = "(?P<Prefix>[A-Za-z]*\s?)?(?P<Width>\d{3})/(?P<AspectRatio>\d{2})R(?P<WheelDiameter>\d{2})(?P<Suffix>\s*[A-Z]*\s*)?"

    # Apply regex pattern and extract groups
    df_filtered = (
        df_filtered.withColumn("Prefix", regexp_extract("spart_desc", regex_pattern, 1))
        .withColumn("Width", regexp_extract("spart_desc", regex_pattern, 2).cast("int"))
        .withColumn(
            "AspectRatio", regexp_extract("spart_desc", regex_pattern, 3).cast("int")
        )
        .withColumn(
            "WheelDiameter", regexp_extract("spart_desc", regex_pattern, 4).cast("int")
        )
        .withColumn("Suffix", regexp_extract("spart_desc", regex_pattern, 5))
    )

    df_filtered = (
        df_filtered.withColumn(
            "Prefix2",
            regexp_extract("spart_desc_claim_detail_history", regex_pattern, 1),
        )
        .withColumn(
            "Width2",
            regexp_extract("spart_desc_claim_detail_history", regex_pattern, 2).cast(
                "int"
            ),
        )
        .withColumn(
            "AspectRatio2",
            regexp_extract("spart_desc_claim_detail_history", regex_pattern, 3).cast(
                "int"
            ),
        )
        .withColumn(
            "WheelDiameter2",
            regexp_extract("spart_desc_claim_detail_history", regex_pattern, 4).cast(
                "int"
            ),
        )
        .withColumn(
            "Suffix2",
            regexp_extract("spart_desc_claim_detail_history", regex_pattern, 5),
        )
    )

    df_filtered = (
        df_filtered.withColumn(
            "Width", when(col("Width") > 0, col("Width")).otherwise(col("Width2"))
        )
        .withColumn(
            "AspectRatio",
            when(col("AspectRatio") > 0, col("AspectRatio")).otherwise(
                col("AspectRatio2")
            ),
        )
        .withColumn(
            "WheelDiameter",
            when(col("WheelDiameter") > 0, col("WheelDiameter")).otherwise(
                col("WheelDiameter2")
            ),
        )
    )

    # Fill missing values with zero for numerical columns
    df_filtered = (
        df_filtered.withColumn(
            "Width", when(col("Width").isNull(), 0).otherwise(col("Width"))
        )
        .withColumn(
            "WheelDiameter",
            when(col("WheelDiameter").isNull(), 0).otherwise(col("WheelDiameter")),
        )
        .withColumn(
            "AspectRatio",
            when(col("AspectRatio").isNull(), 0).otherwise(col("AspectRatio")),
        )
    )

    # Add a binary column based on substring match
    df_filtered = (
        df_filtered.withColumn(
            "is_oea", when(lower(col("spart_desc")).contains("oea"), 1).otherwise(0)
        )
        .withColumn(
            "is_oem", when(lower(col("spart_desc")).contains("oem"), 1).otherwise(0)
        )
        .withColumn(
            "is_scorpion",
            when(lower(col("spart_desc")).contains("scorpion"), 1).otherwise(0),
        )
        .withColumn(
            "is_bridgestone",
            when(lower(col("spart_desc")).contains("bridgestone"), 1).otherwise(0),
        )
        .withColumn(
            "is_bf", when(lower(col("spart_desc")).contains("bf"), 1).otherwise(0)
        )
        .withColumn(
            "is_lt", when(lower(col("spart_desc")).contains("lt"), 1).otherwise(0)
        )
    )

    df_out = df_filtered.drop(
        "spart_desc_claim_detail_history",
        "Prefix",
        "Suffix",
        "Prefix2",
        "Suffix2",
        "Width2",
        "AspectRatio2",
        "WheelDiameter2",
    )

    # Write the DataFrame to Parquet format in S3
    df_out.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['part_no_mapping']}_tw"
    )

    return df_out


def create_anomaly_threshold():
    """Function used to format thresholds coming from input data.

    This function reads the anomaly threshold data, renames columns,
    cleans up the data by removing dollar signs and commas, converts
    thresholds to double, and saves the formatted data as a parquet file.
    Parameters:
        None
    Returns:
        pyspark.sql.DataFrame: the dataframe with formatted anomaly thresholds
    """
    print("Anomaly threshold file")
    print(f"{sample_input_folder}{input_tables['anomaly_threshold']}")
    df = spark.read.csv(
        f"{sample_input_folder}{input_tables['anomaly_threshold']}",
        header=True,
        inferSchema=True,
    )

    # Rename column names
    old_names = df.columns
    new_name = [
        "dealer_customer_risk",
        "breakdown_risk",
        "review_threshold",
        "inspection_threshold",
    ]

    # Rename column names
    df = df.select([col(old).alias(new) for old, new in zip(old_names, new_name)])

    # Remove dollar signs and commas, then convert to double
    df = df.withColumn(
        "review_threshold",
        F.regexp_replace(col("review_threshold"), "[\$,]", "").cast(DoubleType()),
    )
    df = df.withColumn(
        "inspection_threshold",
        F.regexp_replace(col("inspection_threshold"), "[\$,]", "").cast(DoubleType()),
    )

    # Save output
    df.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['anomaly_threshold']}"
    )
    return df


def create_part_price_dev():
    """Function used to create part price deviation metrics by processing
    industry benchmark part price raw files.

    The function reads data from parquet files, processes the data by sorting, removing duplicates, and merging,
    and then saves the output to a specified location.
    Parameters:
        None
    Returns:
        pyspark.sql.DataFrame: the dataframe with part price deviation metrics
    """
    # Load industry benchmark part price raw files
    df_forte = spark.read.parquet(
        raw_input_folder + input_tables["part_price_forte_table"]
    )
    df_toyota = spark.read.parquet(
        raw_input_folder + input_tables["part_price_toyota_table"]
    )

    # Trim all columns
    df_forte = trim_all_string_columns(df_forte)
    df_toyota = trim_all_string_columns(df_toyota)

    # Step 1: Sort by date in descending order
    df_forte = df_forte.orderBy(col("dtretail_date").desc())
    df_toyota = df_toyota.orderBy(col("dtupdate_last").desc())

    # Step 2: Remove duplicates and select the first row using Window functions for more complex scenarios
    windowSpec = Window.partitionBy("spart_number", "soem_code").orderBy(
        col("dtretail_date").desc()
    )
    df_forte = (
        df_forte.withColumn("rn", row_number().over(windowSpec))
        .filter(col("rn") == 1)
        .drop("rn")
    )

    windowSpec2 = Window.partitionBy("spart_no", "smanufacturer_code").orderBy(
        col("dtupdate_last").desc()
    )
    df_toyota = (
        df_toyota.withColumn("rn", row_number().over(windowSpec2))
        .filter(col("rn") == 1)
        .drop("rn")
    )

    # Step 3: select filtered columns and rename
    df_forte = (
        df_forte.select("spart_number", "soem_code", "cretail_price")
        .withColumnRenamed("spart_number", "spart_no")
        .withColumnRenamed("soem_code", "smanufacturer_code")
    )
    df_toyota = df_toyota.select(
        "spart_no", "smanufacturer_code", "cdealer_cost", "cretail_cost", "spart_desc"
    )

    # Step 4: merge fields from forte and toyota
    df_out = df_forte.join(
        df_toyota, on=["spart_no", "smanufacturer_code"], how="outer"
    )

    # Step 5: drop duplicates and clean up column names
    df_out = df_out.withColumn(
        "cretail_cost",
        when(col("cretail_price").isNull(), col("cretail_cost")).otherwise(
            col("cretail_price")
        ),
    )

    # Step 6: filter on columns needed
    df_out = df_out.filter(
        (~col("spart_desc").contains("superceded")) & (col("cretail_cost") > 0.01)
    )

    # Select columns required
    df_out = df_out.select(
        "spart_no", "smanufacturer_code", "cdealer_cost", "cretail_cost"
    ).dropDuplicates(["spart_no", "smanufacturer_code"])

    # Save output into precompute S3 folder
    save_output(
        df_out,
        f"{output_folder}{output_tables['part_price_deviation_metrics']}",
        ["smanufacturer_code"],
    )

    return df_out


def create_part_price_dev_tw(df_part_map):
    """Function used to create part price deviation metrics for tires and
    wheels by processing industry benchmark part price raw files.

    The function reads data from parquet files, processes the data by sorting, removing duplicates, and merging,
    and then saves the output to a specified location.
    Parameters:
        df_part_map (pyspark.sql.DataFrame): the dataframe containing part mapping data
    Returns:
        pyspark.sql.DataFrame: the dataframe with part price deviation metrics for tires and wheels
    """
    # Extract wheel vs. tire from part mapping
    df_part_map = (
        df_part_map.filter(col("sdetail_type") == "P")
        .select("spart_no", "tw_prod_type")
        .dropDuplicates(subset=["spart_no"])
    )
    df_part_map = df_part_map.filter(
        (col("spart_no") != "") & (col("spart_no").isNotNull())
    )

    # Load industry benchmark part price raw files
    df_forte = spark.read.parquet(
        raw_input_folder + input_tables["part_price_forte_table"]
    )
    df_toyota = spark.read.parquet(
        raw_input_folder + input_tables["part_price_toyota_table"]
    )

    # Trim all columns
    df_forte = trim_all_string_columns(df_forte)
    df_toyota = trim_all_string_columns(df_toyota)

    # Step 1: Sort by date in descending order
    df_forte = df_forte.orderBy(col("dtretail_date").desc())
    df_toyota = df_toyota.orderBy(col("dtupdate_last").desc())

    # Step 2: Remove duplicates and select the first row using Window functions for more complex scenarios
    windowSpec = Window.partitionBy("spart_number").orderBy(col("dtretail_date").desc())
    df_forte = (
        df_forte.withColumn("rn", row_number().over(windowSpec))
        .filter(col("rn") == 1)
        .drop("rn")
    )

    windowSpec2 = Window.partitionBy("spart_no").orderBy(col("dtupdate_last").desc())
    df_toyota = (
        df_toyota.withColumn("rn", row_number().over(windowSpec2))
        .filter(col("rn") == 1)
        .drop("rn")
    )

    # Step 3: select filtered columns and rename
    df_forte = df_forte.select("spart_number", "cretail_price").withColumnRenamed(
        "spart_number", "spart_no"
    )
    df_toyota = df_toyota.select(
        "spart_no", "cdealer_cost", "cretail_cost", "spart_desc"
    )

    # Step 4: merge fields from forte and toyota
    df_out = df_forte.join(df_toyota, on=["spart_no"], how="outer")

    # Step 5: drop duplicates and clean up column names
    df_out = df_out.withColumn(
        "cretail_cost",
        when(col("cretail_price").isNull(), col("cretail_cost")).otherwise(
            col("cretail_price")
        ),
    )

    # Step 6: join prod type
    df_out = df_out.join(df_part_map, on=["spart_no"], how="left")

    # Step 7: clean up price
    df_out = df_out.withColumn(
        "cretail_cost",
        when(col("cretail_cost") <= 0.01, None).otherwise(col("cretail_cost")),
    )
    df_out = df_out.withColumn(
        "cdealer_cost",
        when(col("cdealer_cost") <= 0.01, None).otherwise(col("cdealer_cost")),
    )

    # Select columns required
    df_out = df_out.select(
        "spart_no", "cdealer_cost", "cretail_cost", "tw_prod_type"
    ).dropDuplicates(["spart_no"])

    # Save output into precompute S3 folder
    save_output(
        df_out, f"{output_folder}{output_tables['part_price_deviation_metrics']}_tw", []
    )

    return df_out


def create_do_dealer_threshold():
    """Function to create DO dealer threshold.

    This function loads a CSV file containing dealer threshold data, processes the data by renaming columns,
    filling missing values, converting to a Spark DataFrame, removing duplicates, and saving the result as a parquet file.
    Parameters:
        None
    Returns:
        pyspark.sql.DataFrame: the dataframe with DO dealer thresholds
    """

    # Base configuration paths, should be predefined or configured in your environment
    full_path = sample_input_folder + input_tables["do_dealer_table"]

    # Load the file
    df_do = pd.read_csv(full_path)

    # Rename columns
    df_do.columns = ["sdealer_number", "do_threshold"]

    # Fill na
    df_do["do_threshold"] = df_do["do_threshold"].fillna(0)

    # Convert to pyspark dataframe
    df_do = spark.createDataFrame(df_do)

    # Clean up duplicates, if any
    df_out = df_do.dropDuplicates(["sdealer_number"])

    # Save output into precompute S3 folder
    df_out.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['do_dealer_list']}"
    )

    return df_out


def flag_by_comment(df_master, substrings, col_name):
    """Flags DataFrame entries based on the presence of specified substrings in
    a comment column, aggregates results by 'iclaim_id', and merges with a
    master DataFrame.

    Parameters:
    - df_master: Master DataFrame to merge results into.
    - substrings: List of substrings to search within the comments column.
    - col_name: The name of the column where flags should be stored.

    Returns:
    - DataFrame with results merged from the master DataFrame, filtered by the presence of comments.
    """
    # Load in comments table
    df = (
        spark.read.parquet(raw_input_folder + input_tables["comments"])
        .select("iclaim_id", "scomments", "dtcomm_date")
        .dropDuplicates()
    )

    # Creating the filter condition dynamically from the list of substrings
    # Join substrings into a single regular expression pattern
    pattern = "|".join(
        [f".*{s}.*" for s in substrings]
    )  # Regex pattern like ".*Doe.*|.*Smith.*|.*Johnson.*"

    # Filter the DataFrame using the dynamically created pattern with rlike
    # Applying lower() to make the search case-insensitive
    df = df.withColumn(
        col_name, when(lower(col("scomments")).rlike(pattern), 1).otherwise(0)
    )

    # Aggregate by 'iclaim_id' to find any '1' values within the group
    df = df.groupBy("iclaim_id").agg(F.max(col(col_name)).alias(col_name))

    # Filter to retain only groups where the flag is set to '1'
    df = df.filter(col(col_name) == 1)

    # Select key columns from the master DataFrame
    df_master = df_master.select(["sclaim_number", "iclaim_id"])

    # Merge with master DataFrame based on 'iclaim_id'
    df = df.join(df_master, "iclaim_id", how="inner")

    # Remove 'iclaim_id' after the merge and remove any duplicates that might have resulted from the join
    df = df.drop("iclaim_id").dropDuplicates()

    return df


def create_tech_found(df, prod_suffix):
    """Function to flag records where specific technical substrings are found
    in the comments.

    This function uses predefined substrings to flag rows in the dataframe and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
        prod_suffix (str): suffix to be added to the output table name
    Returns:
        pyspark.sql.DataFrame: the dataframe with flagged records
    """
    substrings = params["tech_found"]
    df_out = flag_by_comment(df, substrings, "tech_found")

    # Write the DataFrame to Parquet format in S3
    df_out.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['tech_found']}{prod_suffix}"
    )

    return df_out


def create_avg_loss_labor_hours(df):
    """Function to create average loss labor hours for the breakdown model.

    This function filters paid claims over the last n months, aggregates data to the claim level,
    calculates the average loss labor hours, and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
    Returns:
        pyspark.sql.DataFrame: the dataframe with average loss labor hours
    """
    n_mon = params["n_mon"]
    # Calculate the date n months ago from today
    twelve_months_ago = F.add_months(F.current_date(), -n_mon)

    # Filter on paid claims over the last n months
    df = df.filter(
        (df["dtdate_loss_occurred"] >= twelve_months_ago)
        & (df["sclaim_status"].contains("P"))
        & (df["iclaim_det_status_id"] == 4)
        & (df["sdetail_type"].contains("L"))
    )

    # Aggregate data to claim level
    df_claim = df.groupBy(
        "sclaim_number", "smake", "smodel", "imodel_year", "sloss_code"
    ).agg(F.sum(col("nreq_qty")).alias("labor_hours"))

    # Aggregate to get average per claim
    df_out = df_claim.groupBy(["smake", "smodel", "imodel_year", "sloss_code"]).agg(
        F.mean(col("labor_hours")).alias("average_loss_labor_hours")
    )

    # Write the DataFrame to Parquet format in S3
    save_output(
        df_out,
        f"{output_folder}/{output_tables['average_loss_labor_hours']}",
        ["sloss_code"],
    )

    return df_out


def create_customer_complaints(df, prod_suffix):
    """Function to flag customer complaints based on predefined substrings.

    This function flags rows in the dataframe where customer complaints are found in the comments,
    and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
        prod_suffix (str): suffix to be added to the output table name
    Returns:
        pyspark.sql.DataFrame: the dataframe with flagged customer complaints
    """
    substrings = params["customer_complaints"]
    df_out = flag_by_comment(df, substrings, "customer_comp")

    # Write the DataFrame to Parquet format in S3
    df_out.write.mode("overwrite").parquet(
        f"{output_folder}/{output_tables['customer_complaints']}{prod_suffix}"
    )

    return df_out


def create_mileage_per_year_segment(df):
    """Function to create mileage per year segment for vehicles.

    This function calculates the average mileage per year for each vehicle based on the odometer reading at the time of loss,
    and then aggregates this data to get the average mileage per year for each segment (make, model, and model year).
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
    Returns:
        pyspark.sql.DataFrame: the dataframe with mileage per year segment
    """
    # Select the columns needed
    df = df.select(
        "sclaim_number",
        "smake",
        "smodel",
        "imodel_year",
        "iodometer_at_time_of_loss",
        "dtdate_loss_occurred",
    ).dropDuplicates()

    # Calculate metrics
    df = df.withColumn(
        "model_age", year(col("dtdate_loss_occurred")) - col("imodel_year")
    )
    df = df.withColumn(
        "average_mileage_per_year", col("iodometer_at_time_of_loss") / col("model_age")
    )

    # Get the average over the group
    df_out = df.groupBy("smake", "smodel", "imodel_year").agg(
        F.mean("average_mileage_per_year").alias("mileage_per_year_segment")
    )

    # Write the DataFrame to Parquet format in S3
    save_output(
        df_out,
        f"{output_folder}/{output_tables['mileage_per_year_segment']}",
        ["smake"],
    )

    return df_out


def create_claim_history(df, prod_suffix):
    """Function used to create claim history.

    This function selects relevant columns, filters claims with a specific status,
    calculates the total amount paid for each claim, and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
        prod_suffix (str): suffix to be added to the output table name
    Returns:
        pyspark.sql.DataFrame: the dataframe with claim history
    """
    df_selected = df.select(
        "sclaim_number",
        "sclaim_status",
        "scontract_no",
        "irecord_id",
        "sloss_code",
        "iclaim_det_status_id",
        "sdetail_desc",
        "dtdate_loss_occurred",
        "dtpaid",
        "sdetail_type",
        "camt_paid_original",
    )

    # Filter claims with the status id of 4
    df_selected = df_selected.filter(col("iclaim_det_status_id") == 4)

    # Calculate claim level total paid
    df_out = df_selected.groupBy(
        "sclaim_number",
        "sclaim_status",
        "scontract_no",
        "sloss_code",
        "sdetail_desc",
        "dtpaid",
    ).agg(F.sum(col("camt_paid_original")).alias("camt_paid"))

    # Write the DataFrame to Parquet format in S3
    save_output(
        df_out,
        f"{output_folder}/{output_tables['claim_history_table']}{prod_suffix}",
        [],  # tested need to remove partition on this to improve performance, too granular
    )

    return df_out


def create_average_labor_request_dealer_loss_code(df, n_days=365):
    """Function to calculate the average total labor hours requested per claim
    loss for each dealer and loss code.

    This function filters data for the last n_days, groups by specific columns, aggregates the total requested quantity,
    calculates the average, and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
        n_days (int): the number of days to look back for filtering the data (default is 365 days)
    Returns:
        pyspark.sql.DataFrame: the dataframe with average total labor hours per claim loss for each dealer and loss code
    """
    # Read the table from a parquet file
    DATE_COL = "dtcycle_date"
    TYPE_COL = "sdetail_type"
    REQ_UNIT_COL = "nreq_qty"
    AGG_COLS = ["iclaim_id", "sloss_code", "spayee_no", "smake"]

    # Filter data for the last n_days and labor type
    df_filtered = df.filter(
        (F.datediff(current_date(), col(DATE_COL)) <= 365) & (col(TYPE_COL) == "L")
    )

    # Group and aggregate data
    grouped_data = df_filtered.groupBy(AGG_COLS).agg(
        F.sum(REQ_UNIT_COL).alias(REQ_UNIT_COL)
    )

    # Calculate average total labor hours claim loss
    final_data = grouped_data.groupBy(AGG_COLS[1:]).agg(
        avg(REQ_UNIT_COL).alias("average_total_labor_hours_claim_loss")
    )

    # Save result to S3 pre-computed tables
    save_output(
        final_data,
        f"{output_folder}/{output_tables['avg_labor_request_dealer_table']}",
        ["sloss_code"],
    )

    return final_data


def create_dealer_contract_customer_precal(df, df1, prod_suffix):
    """Function used to bring in contract level metrics and car configuration
    information for ACR KPI features.

    This function selects specified columns, joins dataframes, adds a TEC column if applicable,
    and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the main dataframe containing contract information
        df1 (pyspark.sql.DataFrame): the dataframe containing precomputed contract metrics
        prod_suffix (str): suffix to be added to the output table name
    Returns:
        pyspark.sql.DataFrame: the dataframe with combined contract and customer information
    """
    # Select relevant columns and remove duplicates based on 'scontract_no'
    ls = list(
        set(
            selected_cols["contract_cols"] + ["smake", "strim", "smodel", "imodel_year"]
        )
    )
    df_pre = df.select(ls).dropDuplicates(subset=["scontract_no"])

    # Join with precomputed contract metrics
    df_out = df_pre.join(
        df1.select(selected_cols["contract_precomp_cols"]),
        on=["scontract_no"],
        how="left",
    )

    # Add is_tec column for T&W if applicable
    if prod_suffix == "_tw":
        df_out = df_out.withColumn(
            "is_tec",
            when(
                col("icontract_type").isin([int(x) for x in params["is_tec"]]), 1
            ).otherwise(0),
        )

    # Save output
    save_output(
        df_out,
        f"{output_folder}/{output_tables['dealer_customer_contract_combo']}{prod_suffix}",
        [],
    )

    return df_out


def create_part_frequency(df):
    """Function used to create a part frequency table to use in the Breakdown
    model.

    This function calculates part frequency at the loss level, estimates tier risk,
    selects final columns, and saves the result as a parquet file.
    Parameters:
        df (pyspark.sql.DataFrame): the dataframe to process
    Returns:
        pyspark.sql.DataFrame: the dataframe with part frequency and risk tiers
    """
    # Load table from S3 and drop duplicates
    table = df.dropDuplicates()

    print("read table...")

    # Calculate part frequency at loss level and series
    bare_bone_df = calculate_part_loss_freq(table)
    print("estimate part freq...")

    # Estimate tier risk
    bare_bone_df = add_risk_tiers_low_part_freq(bare_bone_df)
    print("add risk tiers...")

    # Select final columns
    final_cols = [
        "smake",
        "smodel",
        "sloss_code",
        "spart_no",
        "breakdown_part_freq",
        "risk_tier_part",
    ]
    bare_bone_df = bare_bone_df.select(*final_cols).dropDuplicates()
    print((bare_bone_df.count(), len(bare_bone_df.columns)))

    # Write the DataFrame to Parquet format in S3
    save_output(
        bare_bone_df,
        f"{output_folder}/{output_tables['part_frequency_table']}",
        ["sloss_code"],
    )

    return bare_bone_df


def add_risk_tiers_low_part_freq(spark_df: F.DataFrame):
    """Function used to assign risk tiers to low part frequency data.

    This function creates risk tiers by part frequency ratio, prints the risk tiers part frequency,
    and prints the risk distribution.
    Parameters:
        spark_df (pyspark.sql.DataFrame): the dataframe containing part frequency data
    Returns:
        pyspark.sql.DataFrame: the dataframe with risk tiers assigned
    """
    # Create risk tier by part frequency ratio
    spark_df = spark_df.withColumn(
        "risk_tier_part", expr("ntile(3) over (order by breakdown_part_freq)")
    )

    # Print risk tiers part frequency
    print("**Risk Tiers Part Frequency:**")
    spark_df.groupby("risk_tier_part").agg(
        F.min(col("breakdown_part_freq")).alias("min"),
        F.max(col("breakdown_part_freq")).alias("max"),
    ).show()

    # Print risk distribution
    print("**Risk distribution:**")
    spark_df.groupby("risk_tier_part").agg(
        countDistinct("iclaim_id").alias("nunique")
    ).show()

    return spark_df


def calculate_part_loss_freq(spark_df: F.DataFrame):
    """Function used to calculate the part frequency across the entire history.

    This function trims part numbers, calculates the part count at the loss level,
    estimates the part frequency, and merges the results with the original dataframe.
    Parameters:
        spark_df (pyspark.sql.DataFrame): the dataframe containing historical part data
    Returns:
        pyspark.sql.DataFrame: the dataframe with part frequency calculated
    """
    # Strip part number
    spark_df = spark_df.withColumn("spart_no_strip", F.trim(col("spart_no")))
    spark_df = spark_df.withColumn(
        "spart_no_strip",
        when(col("spart_no_strip") == "", None).otherwise(col("spart_no_strip")),
    )

    # Drop rows with null part numbers
    spark_df = spark_df.dropna(subset=["spart_no_strip"])

    # Get the number of parts repaired by part, series, and loss type dimension
    part_count_at_loss_car = spark_df.groupby(
        "smake", "smodel", "sloss_code", "spart_no_strip"
    ).agg(F.count("iclaim_id").alias("part_count_at_loss_car"))

    # Get the overall number of parts repaired by series and loss type
    overall_parts_count = part_count_at_loss_car.groupby(
        "smake", "smodel", "sloss_code"
    ).agg(F.sum("part_count_at_loss_car").alias("overall_parts_count"))

    # Estimate the part frequency
    claim_part_data_freq = part_count_at_loss_car.join(
        overall_parts_count, ["smake", "smodel", "sloss_code"], "left"
    )
    claim_part_data_freq = claim_part_data_freq.withColumn(
        "breakdown_part_freq",
        col("part_count_at_loss_car") / col("overall_parts_count"),
    )

    # Merge part frequency with the original DataFrame
    bare_bone_table = spark_df.join(
        claim_part_data_freq,
        ["smake", "smodel", "sloss_code", "spart_no_strip"],
        "left",
    )

    # Assert the length of DataFrame
    assert (
        bare_bone_table.count() == spark_df.count()
    ), "Duplicates after calculate_part_loss_freq function..."

    return bare_bone_table


def filter_clean_master(prod_ls):
    """Function used to filter the cleaned master table based on specific
    product types and other conditions.

    This function loads the final clean master table, applies several filters, and processes the data
    to ensure only the latest entries per group are kept. It also identifies the product type between
    wheel and tire, considering only replacements and filtering out irrelevant data.
    Parameters:
        prod_ls (list): list of product type IDs to filter
    Returns:
        tuple: a tuple containing the original dataframe and the filtered dataframe
    """
    # Load final clean master table
    df0 = spark.read.parquet(input_folder + master_input_file).filter(
        col("iproduct_type_id").isin(prod_ls)
    )

    # Apply filters, making sure all active contracts with null claim id are included
    dfm = df0.filter((col("btcovered_flag") == True) | col("iclaim_id").isNull())

    # Filter out overall claim status is Declined or Cancelled
    dfm = dfm.filter(
        ((~col("sclaim_status").contains("D")) & (~col("sclaim_status").contains("C")))
        | (col("sclaim_status").isNull())
    )

    # Filter out detailed line items that are Declined or Cancelled
    dfm = dfm.filter(
        (~col("iclaim_det_status_id").isin([3, 6]))
        | (col("iclaim_det_status_id").isNull())
    )

    # Filter on active contracts only
    dfm = dfm.filter(
        (col("dtcontract_effect") <= F.current_date())
        & (col("dtcontract_expiration") > F.current_date())
        & (col("dtcontract_eff_cancell").isNull())
    )  # valid contract

    # Make sure 1 record id can only have one latest entry
    # Define the window specification to make sure this function can handle the cases where date column is null
    windowSpec = Window.partitionBy(
        "sclaim_number", "sclaim_status", "sdetail_type", "irecord_id"
    ).orderBy(F.col("dtpaid").desc())

    # Assign row numbers based on the window specification
    dfm = dfm.withColumn("row_number", F.row_number().over(windowSpec))

    # Filter to obtain only the rows with the maximum 'dtpaid' per group
    df_out = dfm.filter(F.col("row_number") == 1).drop("row_number")

    # Identify product type between wheel vs tire, considering modeling for replacement, accounting for 98% of cases
    if prod_ls == [8]:
        df_out = df_out.withColumn(
            "tw_prod_type",
            when(
                lower(F.col("sdetail_desc")).contains("wheel replace"), "wheel"
            ).otherwise(
                when(
                    lower(F.col("sdetail_desc")).contains("tire replace"), "tire"
                ).otherwise("other_prod")
            ),
        )
        df_out = df_out.filter(F.col("tw_prod_type").isin({"wheel", "tire"}))

        df_out = df_out.filter(
            ~((F.col("creq_unit_cost") <= 10) | (F.col("spart_no").like("%disp%")))
        )

    return df0, df_out


def generate_shared_precomputed_metrics_by_product(prod_ls, n_mon):
    """Function to generate precomputed metrics for different product types.

    This function filters the cleaned master table, creates various metrics tables, and saves the results to specified locations.
    Parameters:
        prod_ls (list): list of product type IDs to filter
        n_mon (int): the number of months to look back for metrics calculations
    Returns:
        tuple: a tuple containing the filtered dataframe and the unfiltered dataframe
    """
    if prod_ls == [4]:
        prod_suffix = ""
    elif prod_ls == [8]:
        prod_suffix = "_tw"
    else:
        prod_suffix = "_else"

    # Get filtered clean master table to start with
    unfiltered_df, df = filter_clean_master(prod_ls)

    print("Creating contract level metrics...")
    df1 = create_contract_level_metrics(df, n_mon, prod_suffix)
    df1.show()

    print("Creating customer level metrics...")
    df2 = create_customer_level_metrics(df, n_mon, prod_suffix)
    df2.show()

    print("Creating dealer level metrics...")
    df3 = create_dealer_level_metrics(df, n_mon, prod_suffix)
    df3.show()

    # Get reference state list table
    create_state_list_table(prod_suffix)

    print("Creating dealer issue level metrics...")
    df4 = create_dealer_issue_level_metrics(df, n_mon, prod_suffix)
    df4.show()

    print("Creating dealer make model issue level metrics...")
    df6 = create_dealer_make_model_issue_level_metrics(df, 84, prod_suffix)
    df6.show()

    print("Creating claim level benchmark metrics table...")
    df_make_issue_benchmark = create_benchmark_make_issue_level_metrics(
        df, 84, prod_suffix
    )
    df_make_issue_benchmark.show()

    print("Creating claim level benchmark metrics table...")
    df_part_make_issue_benchmark = create_benchmark_part_make_issue_level_metrics(
        df, 84, prod_suffix
    )
    df_part_make_issue_benchmark.show()

    print("Creating contract car config tables...")
    df_contract_parts_config = create_contract_parts_config(unfiltered_df, prod_suffix)
    df_contract_parts_config.show()

    print("Creating combined dealer_customer_contract table for KPI features...")
    create_dealer_contract_customer_precal(unfiltered_df, df1, prod_suffix)

    # Get labor rate industry benchmark
    df_labor_rate_deviation = pull_labor_rate_deviation(prod_suffix)
    df_labor_rate_deviation.show()

    print("Creating claim history table...")
    df_claim = create_claim_history(df, prod_suffix)
    print("Claim history table ready")

    create_tech_found(df, prod_suffix)
    create_customer_complaints(df, prod_suffix)
    print("Created customer complaints and tech found")

    return df, unfiltered_df


def generate_precomputed_metrics_vsc():
    """Function to generate precomputed metrics for Vehicle Service Contracts
    (VSC).

    This function filters the master table, creates various metrics tables, and saves the results to specified locations.
    Parameters:
        None
    Returns:
        None
    """
    prod_ls = [4]
    # Get number of months look back window
    n_mon = params["n_mon"]

    # Get base tables with filtered and unfiltered data
    df, unfiltered_df = generate_shared_precomputed_metrics_by_product(prod_ls, n_mon)

    # Create make model issue level metrics
    df5 = create_make_model_issue_level_metrics(df, 84)
    df5.show()

    # Create part make model issue level metrics
    df7 = create_part_make_model_issue_level_metrics(df, n_mon)
    df7.show()

    # Create part price variation metrics table
    df_part_price_var = pull_part_price_variation_metrics(unfiltered_df, n_mon)
    df_part_price_var.show()

    # Create labor rate variation metrics table
    df_labor_rate_var = pull_labor_rate_variation_metrics(unfiltered_df, n_mon)
    df_labor_rate_var.show()

    # Create make_model_mdlyr_dealer_issue_level_metrics for labor hours model
    df_labor_feat = create_make_model_mdlyr_dealer_issue_level_metrics(df, n_mon)
    df_labor_feat.show()

    # Create anomaly threshold
    create_anomaly_threshold()
    print("anomaly threshold table created")

    # Create part price deviation thresholds
    create_part_price_dev()

    # Create do dealer list for VSC exception
    create_do_dealer_threshold()
    print("do threshold table ready")

    # Create average loss labor hours for breakdown model
    create_avg_loss_labor_hours(df)

    # Get mileage per year segment for breakdown model as input features
    create_mileage_per_year_segment(df)
    print("mileage per year table done")

    # Create average labor request dealer loss code
    create_average_labor_request_dealer_loss_code(unfiltered_df, 365)
    print("average labor request table ready")

    # Create part frequency table
    create_part_frequency(unfiltered_df)
    print("start tf and cc")

    # Create mapping
    create_supporting_mapping(unfiltered_df, "")
    print("supporting part and loss code mappings are done")


def generate_precomputed_metrics_tw():
    """Function to generate precomputed metrics for Tire and Wheel (T&W)
    products.

    This function filters the master table, creates various metrics tables, and saves the results to specified locations.
    Parameters:
        None
    Returns:
        None
    """
    prod_ls = [8]
    # Get number of months look back window
    n_mon = params["n_mon"]

    # Get base tables with filtered and unfiltered data
    df, unfiltered_df = generate_shared_precomputed_metrics_by_product(prod_ls, n_mon)

    # Get supporting mapping
    df_map1 = create_supporting_mapping_tw(unfiltered_df)
    df_map1.show()
    print("supporting part and loss code mappings are done")

    # Get part price benchmark
    df_part_price = create_part_price_dev_tw(df_map1)


if __name__ == "__main__":
    generate_precomputed_metrics_vsc()
    generate_precomputed_metrics_tw()
