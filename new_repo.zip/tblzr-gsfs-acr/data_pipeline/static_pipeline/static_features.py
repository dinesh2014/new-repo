import sys
import os

notebook_path = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
sys.path.append(
    "/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)))
)
import warnings
import pandas as pd
import numpy as np
from configs.config import BaseConfig
from utils.utils import area_features_near_dealer, load_shapefile
from pyspark.sql import functions as F

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading config file
config_file = BaseConfig.PRE_COMPUTE_CONFIG
data_sources = config_file["set_up_configuration"]["data_sources"]
input_folder = data_sources["input_folder"]
sample_input_folder = data_sources["sample_input_folder"]
raw_input_folder = data_sources["raw_input_folder"]
input_tables = data_sources["input_tables"]
output_folder = data_sources["output_folder"]
output_tables = data_sources["output_tables"]
params = config_file["params"]
master_input_file = data_sources["input_tables"]["master_clean_table"]
selected_cols = config_file["selected_cols"]
filters = config_file["filters"]


def generate_geo_features():
    """This function is used to map static geo features.

    Returns:
        pd.DataFrame: the dataframe with geo features added
    """

    # Step 1) Pull Zipcode information from database
    zipcode_features = pd.read_excel(
        sample_input_folder + input_tables["geo_table"], sheet_name="ZipCodes with info"
    )
    geo_shapes_us = pd.DataFrame(
        load_shapefile(sample_input_folder + input_tables["geo_shape"])
    )

    # Step 2) Convert data format
    geo_shapes_us["ZCTA5CE10"] = geo_shapes_us["ZCTA5CE10"].astype(int)
    geo_shapes_us["INTPTLAT10"] = geo_shapes_us["INTPTLAT10"].astype(float)
    geo_shapes_us["INTPTLON10"] = geo_shapes_us["INTPTLON10"].astype(float)

    # Step 3) Assign lat-lon to all potential customer addresses
    data = geo_shapes_us[["ZCTA5CE10", "INTPTLAT10", "INTPTLON10"]]
    data.columns = ["cleaned_contract_holder_zip", "latitude", "longitude"]
    data = data.drop_duplicates(subset=["cleaned_contract_holder_zip"])

    # Step 4) Define aggregations for demographics
    features_to_agg = config_file["geo_features_aggregation"]

    # Step 5) Format column names
    zipcode_features.columns = [
        "zip_name",
        "zip_key",
        "sum_paved_meters",
        "sum_unpaved_meters",
        "pct_unpaved",
        "urbanicity",
        "count_of_car_dealer",
        "county_name",
        "county_key",
        "elevtn_feet",
    ]

    # Step 6) Assign lat-lon to zipcode features
    zipcode_features_w_latlon = zipcode_features.merge(
        geo_shapes_us,
        right_on="ZCTA5CE10",
        left_on="zip_key",
        how="left",
        validate=None,
    )
    zipcode_features_w_latlon.rename(
        columns={"INTPTLAT10": "geo_latitude", "INTPTLON10": "geo_longitude"},
        inplace=True,
    )

    # Step 7) Generate zip features using 35 miles radius aggregation
    geo_uniques = data[
        ["cleaned_contract_holder_zip", "latitude", "longitude"]
    ].drop_duplicates()

    results = geo_uniques.apply(
        lambda x: area_features_near_dealer(
            x, zipcode_features_w_latlon, features_to_agg, 35
        ),
        axis=1,
    )

    # Step 8) Replace "False" output as NaN
    results.replace(False, np.nan, inplace=True)

    # Step 9) Calculate percentage of unpaved on radius
    results["pct_unpaved"] = results.eval(
        "sum_unpaved_meters / (sum_paved_meters + sum_unpaved_meters)"
    )

    # Step 10) Rename cols that are calculated based on proximity
    results.rename(
        columns={k: f"nearby_{k.lower().replace(' ', '_')}" for k in results.columns},
        inplace=True,
    )

    # Step 11) Join nearby results with ID
    results = results.join(geo_uniques)

    # Step 12) Add county and Urban category
    geo_location_output = results.copy()
    geo_location_output = geo_location_output.merge(
        zipcode_features_w_latlon[["ZCTA5CE10", "urbanicity"]].dropna(),
        how="left",
        left_on=["cleaned_contract_holder_zip"],
        right_on=["ZCTA5CE10"],
        validate=None,
    ).drop("ZCTA5CE10", axis=1)

    if not os.path.exists(output_folder):
        os.mkdir(output_folder)

    # Step 13) Save output
    geo_location_output.to_parquet(
        output_folder + output_tables["geo_features"],
    )

    return geo_location_output


def get_weather_data():
    """Function used to load and concatenate weather data from parquet files in
    a specified folder.

    Parameters:
        None
    Returns:
        pd.DataFrame: the concatenated dataframe containing weather data
    """
    folder = f"{sample_input_folder}/weather"
    filenames = os.listdir(folder)
    filenames.sort()
    weather_data = pd.concat(
        (pd.read_parquet(f"{folder}/{filename}") for filename in filenames)
    )
    return weather_data


def generate_weather_features():
    """
    Main function used to calculate key weather features at the zipcode level and use it for loss predictions in the ML engine.
    Information is extracted from the National Risk Index data resources.
    https://hazards.fema.gov/nri/data-resources#csvDownload

    Parameters:
        None
    Returns:
        pd.DataFrame: the dataframe with calculated weather features at the zipcode level
    """
    weather_data = get_weather_data()

    cnesus_data = pd.read_csv(
        sample_input_folder + "static_input/us_tract_zipcode_mapping.csv"
    )

    # Process data to match tracts to zipcode
    weather_data["tract_fips"] = (
        "0000000000000000" + weather_data["TRACTFIPS"].astype(str)
    ).str[-11:]

    cnesus_data["geoid"] = ("0000000000000000" + cnesus_data["geoid"].astype(str)).str[
        -11:
    ]

    # Define columns to keep for ML engine
    cols = ["tract_fips"] + filters["weather_cols_to_keep"]
    cnesus_data = cnesus_data[filters["census_cols_to_keep"]]

    df = pd.merge(
        cnesus_data,
        weather_data[cols],
        left_on=["geoid"],
        right_on=["tract_fips"],
        how="left",
        validate=None,
    )

    # Output data at zipcode level
    df_res = (
        df.groupby(["zip", "city", "state"])[filters["weather_cols_to_keep"]]
        .mean()
        .reset_index()
    )

    df_res["zip"] = df_res["zip"].astype(int)

    # Save output
    df_res.to_parquet(output_folder + output_tables["weather_features"])

    return df_res


def generate_fred_index():
    """
    Function used to process FRED index data downloaded from the URL:
    https://fred.stlouisfed.org/series/PCU32621132621103.
    Parameters:
        None
    Returns:
        pd.DataFrame: the dataframe with processed FRED index data
    """
    df = pd.read_csv(sample_input_folder + input_tables["fred_index"])
    df.columns = ["date", "fred_index_price"]
    df["date"] = pd.to_datetime(df["date"])

    pdf = spark.createDataFrame(df)
    pdf = pdf.withColumn("fred_index_price", F.col("fred_index_price").cast("float"))

    # Save output
    pdf.write.mode("overwrite").parquet(output_folder + output_tables["fred_index"])

    return df


if __name__ == "__main__":
    generate_geo_features()
    generate_weather_features()
    generate_fred_index()
