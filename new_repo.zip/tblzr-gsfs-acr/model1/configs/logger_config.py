import logging
import os

from configs.config import get_env_variables

# Define the path to save the profile report:
env_vars = get_env_variables()
base_path = f"{env_vars['base_path']}/artifacts/my_logs"


def setup_logger(id_execution: dict):
    """Main function to define logger set up."""

    # Define the log file path in dbfs:
    logger_results_path = (
        f"{base_path}/{id_execution['date_folder']}/{id_execution['job_run_id']}/"
    )
    dbfs_log_file = os.path.join(logger_results_path, "inference_app.log")

    # Ensure the directory exists
    os.makedirs(logger_results_path, exist_ok=True)

    # Set up the logger
    logging.basicConfig(
        level=logging.DEBUG,  # Set the logging level
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",  # Format for log messages
        handlers=[
            logging.FileHandler(
                dbfs_log_file
            ),  # Save logs to the specified file in DBFS
            logging.StreamHandler(),  # Also output logs to console
        ],
    )

    # Reduce logging level for third-party libraries
    logging.getLogger("py4j").setLevel(logging.WARNING)
    logging.getLogger("org.apache.spark").setLevel(logging.WARNING)
    logging.getLogger("databricks.connect").setLevel(logging.WARNING)
    logging.getLogger("IPython").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("tornado").setLevel(logging.WARNING)


from configs.config import get_env_variables

# Define the path to save the profile report:
env_vars = get_env_variables()
base_path = f"{env_vars['base_path']}/artifacts/my_logs"


def setup_logger(id_execution: dict):
    """Main function to define logger set up."""

    # Define the log file path in dbfs:
    logger_results_path = (
        f"{base_path}/{id_execution['date_folder']}/{id_execution['job_run_id']}/"
    )
    dbfs_log_file = os.path.join(logger_results_path, "inference_app.log")

    # Ensure the directory exists
    os.makedirs(logger_results_path, exist_ok=True)

    # Set up the logger
    logging.basicConfig(
        level=logging.DEBUG,  # Set the logging level
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",  # Format for log messages
        handlers=[
            logging.FileHandler(
                dbfs_log_file
            ),  # Save logs to the specified file in DBFS
            logging.StreamHandler(),  # Also output logs to console
        ],
    )

    # Reduce logging level for third-party libraries
    logging.getLogger("py4j").setLevel(logging.WARNING)
    logging.getLogger("org.apache.spark").setLevel(logging.WARNING)
    logging.getLogger("databricks.connect").setLevel(logging.WARNING)
    logging.getLogger("IPython").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("tornado").setLevel(logging.WARNING)
