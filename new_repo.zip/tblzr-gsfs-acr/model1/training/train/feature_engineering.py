import warnings
from datetime import datetime

import numpy as np
import pandas as pd
from pandas.tseries.offsets import DateOffset

from configs.config import BaseConfig
from utils.utils import read_parquet
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from databricks.connect import DatabricksSession


# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

# Loading config file
prod = BaseConfig.PRODUCT_CONFIG
config_file = BaseConfig.FEATURE_ENGINEERING_CONFIG
pipeline_steps = config_file["set_up_configuration"]["pipeline_steps"]
data_sources = config_file["set_up_configuration"]["data_sources"]
filters = config_file["set_up_configuration"]["filters"]
vehicle_segment = config_file["set_up_configuration"]["vehicle_granularity"]
labor_model_granularity = config_file["set_up_configuration"]["labor_model_granularity"]
engineering_features = config_file["set_up_configuration"]["engineering_features"]
final_features = config_file["set_up_configuration"]["final_feature_list"]
lookback_window = config_file["set_up_configuration"]["feature_lookback_window"]
product_type_ls = config_file["set_up_configuration"]["product_type_ls"]
claim_to_contract_keys = config_file["set_up_configuration"]["claim_to_contract_keys"]

# Part level granularity:
part_level_granularity = engineering_features["part_level_granularity"]

# Get the running timestamp
date_time = str(datetime.now().date())

# Run session databricks:
spark = DatabricksSession.builder.getOrCreate()


def filter_out_claims_breakdown_model(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """Function used to applied advanced filters for breakdown model and scope
    columns for modelling.

    Parameters:
        df (pd.DataFrame): the dataframe form clean master table on S3

    Returns:
        pd.DataFrame: Dataframe only considering relevant claims for modelling.
    """

    data = df.copy()

    # Lower-case all features into dataframe:
    data = data.applymap(lambda x: x.lower() if isinstance(x, str) else x)

    # Strip part and breakdown description columns:
    data["sclaim_status"] = data["sclaim_status"].str.strip()
    data["sloss_code"] = data["sloss_code"].str.strip()
    data["scontract_holder_zip_code"] = data["scontract_holder_zip_code"].str.strip()

    # Clean up the zipcode code:
    data["scontract_holder_zip_code"] = data["scontract_holder_zip_code"].str[:5]

    print("Shape for data cleaning BEFORE filtering: ", df.shape)

    ########################################
    # Implement filters on BT coverage flag:
    ########################################

    data["bt_coverage_flag"] = np.where(
        (data["btcovered_flag"] == 1) | (data["btcovered_flag"] == True), 1, 0  # noqa
    )
    data = data[data["bt_coverage_flag"] == 1]
    print(f"claim-parts that pass bt_coverage_flag: {data.shape}")

    ########################################
    # Remove claims without loss code
    ########################################

    data["no_null_loss_code_flag"] = np.where(
        (~data["sloss_code"].isnull()) & (data["sloss_code"] != ""), 1, 0
    )
    data = data[data["no_null_loss_code_flag"] == 1]
    print(f"claim-parts that pass no_null_loss_code_flag: {data.shape}")

    ########################################
    # Keep claims with positive payout
    ########################################

    data["positive_camt_paid_flag"] = np.where((data["camt_paid"] > 0), 1, 0)
    data = data[data["positive_camt_paid_flag"] == 1]
    print(f"claim-parts that pass positive_camt_paid: {data.shape}")

    #######################################################
    # Consider only vehicles with full segment information:
    #######################################################

    no_car_segment_mask = (
        ~data["imodel_year"].isnull()
        & ~data["smake"].isnull()
        & ~data["smodel"].isnull()
    )
    data["no_car_segment_mask_flag"] = np.where(no_car_segment_mask, 1, 0)
    data = data[data["no_car_segment_mask_flag"] == 1]
    print(f"claim-parts that pass no_car_segment_mask: {data.shape}")

    #######################################
    # Remove denied records on paid claims:
    #######################################
    denied_records_mask = (data["iclaim_det_status_id"] == 3) & (
        data["sclaim_status"] == "p"
    )
    data["denied_records_on_paid_claims_flag"] = np.where(denied_records_mask, 1, 0)

    data = data[data["denied_records_on_paid_claims_flag"] == 0]
    print(f"claim-parts that pass denied_records_mask: {data.shape}")

    # Remove flag identifiers:
    flag_cols = [i for i in data.columns if "_flag" in i]
    data.drop(columns=flag_cols, inplace=True)
    print("Shape for data cleaning AFTER filtering: ", data.shape)

    return data


def calculate_past_events(
    df: pd.DataFrame,
    clean_master: pd.DataFrame,
    type_column: str,
    col_name: str,
    col_name_ratio: str,
) -> pd.DataFrame:

    """Function used to calculate the number of historical repairs, from the
    claim ID perspective n months before. This aggregates the metrics at make-
    model-loss code level.

    Also index column is created as base comparative between number of events for
    the same make model and loss code over the total events for the same vehicle.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)
        clean_master (pd.DataFrame): clean master table at claim level
        type_column: column used as target for count the events
        col_name: name of the calculated column
        col_name_ratio: name of the calculated ratio column

    Returns:
        pd.DataFrame: Dataframe with the new ratio and calculated column
    """

    # Create a copy
    data = df.copy()

    # Get lookback_window
    prev_months = int(config_file["set_up_configuration"]["feature_lookback_window"])

    # Assuming clean_master is a Pandas DataFrame
    # Example setup for the given variables
    # Convert column names to lower case and trim whitespace for type_column
    clean_master["smake"] = clean_master["smake"].str.lower()
    clean_master["smodel"] = clean_master["smodel"].str.lower()

    # Perform the self-join on the DataFrame
    c1 = clean_master.copy()
    c2 = clean_master.copy()

    # Adding necessary date logic
    c2["dtdate_loss_occurred_shifted"] = c2["dtdate_loss_occurred"] - pd.DateOffset(
        months=prev_months
    )


    c2 = c2[
        (c2["dtdate_loss_occurred"] > c2["dtdate_loss_occurred_shifted"])
        & (c2["dtdate_loss_occurred"] < c1["dtdate_loss_occurred"])
    ]

    # Merge dataframes on the specified keys
    merged_df = c1.merge(
        c2,
        how="left",
        left_on=[type_column, "smake", "smodel"],
        right_on=[type_column, "smake", "smodel"],
        suffixes=("", "_right"),
        validate=None,
    )

    # Filter based on additional conditions
    merged_df = merged_df[
        (merged_df["sdetail_type"] == "P") & (merged_df["sdetail_type_right"] == "P")
    ]

    # Group by the specified columns and count distinct 'iclaim_id'
    grouped_df = (
        merged_df.groupby(["smake", "smodel", type_column, "dtdate_loss_occurred"])
        .agg(**{col_name: pd.NamedAgg(column="iclaim_id_right", aggfunc="nunique")})
        .reset_index()
    )

    # Compute the col_name_ratio
    grouped_df["sum_col_name"] = grouped_df.groupby(
        ["smake", "smodel", "dtdate_loss_occurred"]
    )[col_name].transform("sum")
    grouped_df[col_name_ratio] = np.where(
        grouped_df["sum_col_name"] == 0,
        0,
        np.round(grouped_df[col_name] / grouped_df["sum_col_name"], 3),
    )

    # Drop the intermediate sum column
    past_events_freq_table = grouped_df.drop(columns=["sum_col_name"])

    # Merge claim/contract frequency at claim ID:
    data_output = data.merge(past_events_freq_table, how="left", validate=None)

    # Fill Nulls as cero for past replacements:
    data_output[col_name].fillna(0, inplace=True)
    data_output[col_name_ratio].fillna(0, inplace=True)

    # Validate we are not duplicating rows here:
    assert len(data_output) == len(df), "Duplicating rows after merge..."

    return data_output


def calculate_past_events_claimcnt(
    df: pd.DataFrame,
    type_column: list[str],
    col_name: str,
) -> pd.DataFrame:
    """This function is used to calculate the past event claim count based on
    the list of type columns.

    Parameters:
        df (pd.DataFrame): the dataframe with processed claim data
        type_column (list[str]): the list of columns as part of group by aggregation columns to calculate the past event claim
        col_name (str): the column name of past event claim count specified

    Returns:
        pd.DataFrame: the dataframe with past event claim count columns added
    """
    # Create a copy
    data = df.copy()

    # Implement group by approach:
    cols_to_keep_part = (
        vehicle_segment + ["dtdate_loss_occurred", "iclaim_id"] + type_column
    )

    # Explode the table for all dates in consideration:
    left_table = data.copy()[cols_to_keep_part]
    right_table = left_table.copy().rename(
        columns={
            "dtdate_loss_occurred": "dtdate_loss_occurred_v1",
            "iclaim_id": "iclaim_id_v1",
        }
    )
    merge_table = left_table.merge(
        right_table, on=vehicle_segment + type_column, how="left", validate=None
    )

    # Filter for only those claims where claim_date > claim_date 1:
    date_mask = (
        merge_table["dtdate_loss_occurred"] > merge_table["dtdate_loss_occurred_v1"]
    ) & (
        merge_table["dtdate_loss_occurred"] - DateOffset(months=12)
        < merge_table["dtdate_loss_occurred_v1"]
    )
    merge_table_flt = merge_table[date_mask]
    merge_table_flt.drop_duplicates(inplace=True)

    # Agg total counts and overall ratio:
    agg_table = (
        merge_table_flt.groupby(
            vehicle_segment + ["dtdate_loss_occurred"] + type_column
        )["iclaim_id_v1"]
        .nunique()
        .reset_index()
    )

    # Calculate the ratio across parts for the same segment/date frame:
    agg_table["total_vehicles_segment"] = agg_table.groupby(
        vehicle_segment + ["dtdate_loss_occurred", "sloss_code"]
    )["iclaim_id_v1"].transform("sum")

    agg_table[f"{col_name}_ratio"] = (
        agg_table["iclaim_id_v1"] / agg_table["total_vehicles_segment"]
    )
    agg_table.rename(columns={"iclaim_id_v1": col_name}, inplace=True)

    # Merge Aggregated counts with raw data:
    data_bare_bone = data.merge(agg_table, how="left", validate=None)

    # Fill Nulls as cero for past replacements:
    data_bare_bone[col_name].fillna(0, inplace=True)
    data_bare_bone[f"{col_name}_ratio"].fillna(0, inplace=True)

    # Validate no duplicating rows:
    assert len(data_bare_bone) == len(df), "duplicating rows after merge..."

    return data_bare_bone


def estimate_average_mileage_per_year(
    df: pd.DataFrame, model_age_col: str, avg_mileage_per_year_col: str
):
    """Function to estimate average mileage per year as model feature. This
    feature is indexed by the average mileage per year across all vehicles for
    the same segment.

    This denotes any drastic deviation or odd driver behavior to capture on the model.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)
        model_age_col: name of the calculated feature
        avg_mileage_per_year_col: name of the column used as a denominator for the index

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    data = df.copy()

    # Convert 'Model_Year' to datetime object
    model_year_dates = pd.to_datetime(
        data["imodel_year"].astype(int).astype(str) + "-01-01"
    )

    # Convert 'Actual_Date' to datetime object
    actual_dates = pd.to_datetime(data["dtdate_loss_occurred"])

    # Calculate age in years
    data[model_age_col] = round((actual_dates - model_year_dates).dt.days / 365, 2)

    # Calculate Average mileage per year:
    data[avg_mileage_per_year_col] = (
        data["iodometer_at_time_of_loss"] // data[model_age_col]
    )

    # Feature to add: Ratio between average mileage per vin vs vehicle segment:
    data["mileage_per_year_segment"] = data.groupby(vehicle_segment)[
        avg_mileage_per_year_col
    ].transform("mean")
    data["mileage_per_year_ratio"] = round(
        data[avg_mileage_per_year_col] / data["mileage_per_year_segment"], 4
    )

    return data


def generate_claim_detail_features(
    df: pd.DataFrame,
    df_master: pd.DataFrame,
) -> pd.DataFrame:

    """Function used to calculate overall historical claim details at series
    level and include as contextual features into the model.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)
        df_master (pd.DataFrame): dataframe at claim level used as input for calculations

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    data = df.copy()

    # Bring feature columns from config
    total_breakdowns_segment = engineering_features["claim_details"][
        "total_breakdowns_segment"
    ]
    total_breakdowns_segment_ratio = engineering_features["claim_details"][
        "total_breakdowns_segment_ratio"
    ]
    overall_historical_repairments = engineering_features["claim_details"][
        "overall_historical_repairments"
    ]
    vehicle_age = engineering_features["claim_details"]["model_age"]
    avg_mileage_per_year = engineering_features["claim_details"]["avg_mileage_per_year"]

    # Historical breakdowns by vehicle segment level:
    data = calculate_past_events(
        df=data,
        clean_master=df_master,
        type_column=part_level_granularity,
        col_name=total_breakdowns_segment,
        col_name_ratio=total_breakdowns_segment_ratio,
    )

    # Overall times a vehicle get repaired:
    data[overall_historical_repairments] = data.groupby(vehicle_segment)[
        "iclaim_id"
    ].transform("nunique")

    # Estimate average mileage per year:
    data = estimate_average_mileage_per_year(
        df=data,
        model_age_col=vehicle_age,
        avg_mileage_per_year_col=avg_mileage_per_year,
    )

    # Include claim to contract ratio:
    # Execute SQL query to generate aggregated table:
    df_claim_freq = generate_claim_freq_total(df=df_master)
    data = generate_dealer_claim_freq(data, df_claim_freq)

    # Include claim to contract ratio (by part):
    data = generate_claim_freq_by_level(
        df_feat=data, df=df_master, level=part_level_granularity
    )
    return data


def generate_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """Function used to calculate basic time features to be added into the
    model to consider seasonality patterns.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """
    data = df.copy()

    # Bring feature columns from config
    month_loss = engineering_features["time_series"]["month_loss"]
    year_loss = engineering_features["time_series"]["year_loss"]

    # Extract moth and year from the loss date:
    data["dtdate_loss_occurred"] = pd.to_datetime(data["dtdate_loss_occurred"])
    data[month_loss] = data["dtdate_loss_occurred"].dt.month
    data[year_loss] = data["dtdate_loss_occurred"].dt.year

    return data


def generate_labor_hours_ratio(df: pd.DataFrame):
    """Feature to capture labor hours for a claim compared to the average of
    hours for same claim type.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    data = df.copy()

    # Estimate the average hour label by loss type and vehicle segment:
    data["average_loss_labor_hours"] = data.groupby(
        vehicle_segment + [part_level_granularity]
    )["labor_hours"].transform("mean")

    # Labor hour ratio compared to the average by segment and loss type:
    data["claim_to_labor_hour_ratio"] = (
        data["labor_hours"] / data["average_loss_labor_hours"]
    )

    return data


def generate_price_features(df: pd.DataFrame) -> pd.DataFrame:
    """Feature to capture part price features to be tested on the ml engine.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    data = df.copy()

    # Incorporate columns:
    avg_market_price = engineering_features["price"]["avg_market_price"]
    avg_net_rate = engineering_features["price"]["avg_net_rate"]
    avg_premium_rate = engineering_features["price"]["avg_premium_rate"]

    # calculating the average market value:
    data[avg_market_price] = data.groupby(vehicle_segment)[
        "cretail_base_price"
    ].transform("mean")

    # Average net rate (considering net rate to capture vehicle segments with more risk):
    data[avg_net_rate] = data.groupby(vehicle_segment)["cnet_rate"].transform("mean")

    # Average net rate (considering net rate to capture vehicle segments with more risk):
    data[avg_premium_rate] = data.groupby(vehicle_segment)["cpremium_rate"].transform(
        "mean"
    )

    # Labor hours/Payout ratio:
    data = generate_part_price_labor(df=data)

    # Total Hours for a claim compared to average hours for the same loss (dealer behavior):
    data = generate_labor_hours_ratio(df=data)
    return data


def generate_demographics_features(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """Function used to add demographic feature to estimate part breakdown
    likelihood. Approach is aggregate geographic data using 35 miles ratio for
    each customer zipcode.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    # Generate a copy of dataframe to not affect base:
    data = df.copy()

    # Read static table:
    df_res = spark.read.parquet(data_sources["input_tables"]["geo_features"]).toPandas()
    data["scontract_holder_zip_code"] = data["scontract_holder_zip_code"].astype(int)
    df = pd.merge(
        data,
        df_res,
        left_on=["scontract_holder_zip_code"],
        right_on=["cleaned_contract_holder_zip"],
        how="left",
        validate=None,
    )

    # Validate no adding duplicates:
    assert len(data) == len(df), "Duplicates after adding demographics..."

    return df


def generate_claim_freq_total(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """The function generates dealer claim frequency, which is a requirement
    later to estimate claim to contract ratio for each dealer for selected
    number of previous months.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    # Get lookback_window
    prev_months = int(lookback_window)

    # Step 1: Calculate contract percent earned. If a dealer doesn't have contract sold, then nb_contract = 0
    df_base = df[(~df["spayee_no"].isnull()) & (df["spayee_no"] != "")][
        ["spayee_no", "dtdate_loss_occurred"]
    ].drop_duplicates()

    df_map = df[
        [
            "sdealer_number",
            "icontract_id",
            "dtcontract_eff_cancell",
            "dtcontract_effect",
            "dtcontract_expiration",
            "ctotal_earned_prem",
            "cpremium_rate",
        ]
    ].drop_duplicates(subset=["sdealer_number", "icontract_id"])

    # Rename selling dealer number to payee no
    merged = pd.merge(
        df_base,
        df_map,
        left_on="spayee_no",
        right_on=["sdealer_number"],
        how="left",
        validate=None,
    )

    # Apply filter to only include contracts earned during the lookback period
    filtered = merged[
        (merged["dtcontract_effect"] < merged["dtdate_loss_occurred"])
        & (
            merged["dtcontract_expiration"]
            > (merged["dtdate_loss_occurred"] - pd.DateOffset(months=prev_months))
        )
        & (
            (merged["dtcontract_eff_cancell"].isna())
            | (
                merged["dtcontract_eff_cancell"]
                > (merged["dtdate_loss_occurred"] - pd.DateOffset(months=prev_months))
            )
        )
    ]

    # Get the metrics to calculate the number of contracts earned
    result_step1 = (
        filtered.groupby(["spayee_no", "dtdate_loss_occurred"])
        .agg(
            nb_contract=("icontract_id", "nunique"),
            earned_prem_total=("ctotal_earned_prem", "sum"),
            prem_rate=("cpremium_rate", "sum"),
        )
        .reset_index()
    )

    # Step 2: Get paid claims in last X months prior to claim paid date
    df_pastcnt = df[(~df["spayee_no"].isnull()) & (df["spayee_no"] != "")][
        ["spayee_no", "iclaim_id", "dtdate_loss_occurred"]
    ].drop_duplicates(subset=["iclaim_id"])

    merged_step2 = pd.merge(
        result_step1,
        df_pastcnt,
        on=["spayee_no"],
        how="left",
        suffixes=("", "_a"),
        validate=None,
    )

    filtered_step2 = merged_step2[
        (merged_step2["dtdate_loss_occurred"] > merged_step2["dtdate_loss_occurred_a"])
        & (
            merged_step2["dtdate_loss_occurred_a"]
            > (merged_step2["dtdate_loss_occurred"] - pd.DateOffset(months=prev_months))
        )
    ]

    result_step2 = (
        filtered_step2.groupby(
            [
                "spayee_no",
                "dtdate_loss_occurred",
                "nb_contract",
                "earned_prem_total",
                "prem_rate",
            ]
        )
        .agg(nb_paid_claims=("iclaim_id", "nunique"))
        .reset_index()
    )

    # Step 3: Calculate dealer claim frequency
    result_step2["dealer_claim_contract_ratio"] = (
        result_step2["nb_paid_claims"]
        / (
            result_step2["earned_prem_total"]
            / result_step2["prem_rate"].replace(0, pd.NA)
        ).replace(0, pd.NA)
        / result_step2["nb_contract"]
    )

    return result_step2


def generate_dealer_claim_freq(
    df_input: pd.DataFrame, df_claim_freq: pd.DataFrame
) -> pd.DataFrame:
    """The function is used to estimate claim to contract ratio for each dealer
    for selected number of previous months.

    Parameters:
        df_input (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)
        df_claim_freq (pd.DataFrame): aggregated table for dealer claim frequency

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    # Merge claim/contract frequency at claim ID:
    data_output = df_input.merge(
        df_claim_freq[
            ["spayee_no", "dtdate_loss_occurred", "dealer_claim_contract_ratio"]
        ].drop_duplicates(subset=["spayee_no", "dtdate_loss_occurred"]),
        on=["spayee_no", "dtdate_loss_occurred"],
        how="left",
        validate=None,
    )

    # Fill Nulls as zero for past replacements:
    data_output["dealer_claim_contract_ratio"].fillna(0, inplace=True)

    # Validate we are not duplicating rows here:
    assert len(data_output) == len(df_input), "Duplicating rows after merge..."

    return data_output


def generate_claim_freq_by_level(
    df_feat: pd.DataFrame, df: pd.DataFrame, level: str
) -> pd.DataFrame:

    """The function is used to estimate claim to contract ratio at specific
    level (part/loss code) for each dealer for selected number of previous
    months.

    Parameters:
        df_feat (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)
        df (pd.DataFrame): claim master table used to estimate calculated fields
        level: column that define the extra granularity to estimate the claim to contract ratio

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """

    data = df_feat.copy()

    # Get lookback_window
    prev_months = int(lookback_window)

    # Step 1: Calculate contract percent earned. If a dealer doesn't have contract sold, then nb_contract = 0
    df_base = df[(~df["spayee_no"].isnull()) & (df["spayee_no"] != "")][
        ["spayee_no", part_level_granularity, "dtdate_loss_occurred"]
    ].drop_duplicates()

    df_map = df[
        [
            "sdealer_number",
            "icontract_id",
            "dtcontract_eff_cancell",
            "dtcontract_effect",
            "dtcontract_expiration",
            "ctotal_earned_prem",
            "cpremium_rate",
        ]
    ].drop_duplicates(subset=["sdealer_number", "icontract_id"])

    # Rename selling dealer number to payee no
    merged = pd.merge(
        df_base,
        df_map,
        left_on="spayee_no",
        right_on=["sdealer_number"],
        how="left",
        validate=None,
    )

    # Apply filter to only include contracts earned during the lookback period
    filtered = merged[
        (merged["dtcontract_effect"] < merged["dtdate_loss_occurred"])
        & (
            merged["dtcontract_expiration"]
            > (merged["dtdate_loss_occurred"] - pd.DateOffset(months=prev_months))
        )
        & (
            (merged["dtcontract_eff_cancell"].isna())
            | (
                merged["dtcontract_eff_cancell"]
                > (merged["dtdate_loss_occurred"] - pd.DateOffset(months=prev_months))
            )
        )
    ]

    # Get the metrics to calculate the number of contracts earned
    result_step1 = (
        filtered.groupby(["spayee_no", part_level_granularity, "dtdate_loss_occurred"])
        .agg(
            nb_contract=("icontract_id", "nunique"),
            earned_prem_total=("ctotal_earned_prem", "sum"),
            prem_rate=("cpremium_rate", "sum"),
        )
        .reset_index()
    )

    # Step 2: Get paid claims in last X months prior to claim paid date
    df_pastcnt = df[(~df["spayee_no"].isnull()) & (df["spayee_no"] != "")][
        ["spayee_no", part_level_granularity, "iclaim_id", "dtdate_loss_occurred"]
    ].drop_duplicates(subset=["iclaim_id", part_level_granularity])

    merged_step2 = pd.merge(
        result_step1,
        df_pastcnt,
        on=["spayee_no", part_level_granularity],
        how="left",
        suffixes=("", "_a"),
        validate=None,
    )

    filtered_step2 = merged_step2[
        (merged_step2["dtdate_loss_occurred"] > merged_step2["dtdate_loss_occurred_a"])
        & (
            merged_step2["dtdate_loss_occurred_a"]
            > (merged_step2["dtdate_loss_occurred"] - pd.DateOffset(months=prev_months))
        )
    ]

    result_step2 = (
        filtered_step2.groupby(
            [
                "spayee_no",
                part_level_granularity,
                "dtdate_loss_occurred",
                "nb_contract",
                "earned_prem_total",
                "prem_rate",
            ]
        )
        .agg(nb_paid_claims=("iclaim_id", "nunique"))
        .reset_index()
    )

    # Step 3: Calculate dealer claim frequency
    result_step2["dealer_claim_contract_ratio_by_part"] = (
        result_step2["nb_paid_claims"]
        / (
            result_step2["earned_prem_total"]
            / result_step2["prem_rate"].replace(0, pd.NA)
        ).replace(0, pd.NA)
        / result_step2["nb_contract"]
    )

    result_step2 = result_step2.drop_duplicates(
        subset=["spayee_no", "dtdate_loss_occurred", part_level_granularity]
    )

    print("Claim to ratio by parts feature preparation table was generated...")

    # Merge results with feature engineering data:
    data_output = data.merge(
        result_step2[
            claim_to_contract_keys + [level, "dealer_claim_contract_ratio_by_part"]
        ],
        on=["spayee_no", part_level_granularity, "dtdate_loss_occurred"],
        how="left",
        validate=None,
    )

    # Fill Nulls as cero for past replacements:
    data_output["dealer_claim_contract_ratio_by_part"].fillna(0, inplace=True)

    # Validate we are not duplicating rows here:
    assert len(data_output) == len(data), "Duplicating rows after merge..."

    return data_output


def generate_part_price_labor(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """His function is used to generate features to compare labor hours and
    part price.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)

    Returns:
        pd.DataFrame: Dataframe with the new columns added.
    """
    data = df.copy()

    # Get labor hours
    df_labor = read_parquet(
        data_sources["input_tables"]["final_clean_master_table"],
        cols=[
            "sdetail_type",
            "iclaim_id",
            "dtdate_loss_occurred",
            "sloss_code",
            "nreq_qty",
            "creq_unit_cost",
        ],
    ).toPandas()

    # Apply filters on labor hours
    df_labor = df_labor[(df_labor["sdetail_type"] == "L")].drop_duplicates()

    # rename labor hours column
    df_labor.rename(
        columns={"nreq_qty": "labor_hours", "creq_unit_cost": "labor_payout"},
        inplace=True,
    )

    # Aggregate labor hours by claim and loss
    df_labor = (
        df_labor.groupby(["iclaim_id", "sloss_code", "dtdate_loss_occurred"])
        .agg({"labor_hours": "sum", "labor_payout": "mean"})
        .reset_index()
    )

    # merge dataframe and labor
    data = pd.merge(data, df_labor, how="left", validate=None)

    # Validate we are not duplicating rows after join
    assert len(df) == len(data), "Duplicating rows after merge labor hours..."

    # Remove rows without labor hours:
    null_mask = ~data["labor_hours"].isnull()
    data_flt = data[null_mask]

    print(
        "Removing {}% of claims without labor hours".format(
            round(1 - (null_mask.sum() / len(data)), 2)
        )
    )

    return data_flt


def prep_cost_validation_model(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """Function used to applied advanced filters for cost validation model and
    scope columns for modelling related to labor hours model.

    Parameters:
        df (pd.DataFrame): data clean master table at claim level granularity.

    Returns:
        pd.DataFrame: Dataframe with the selected claim rows after advanced filters.
    """
    data = df.copy()

    # Clean up parts
    part_detail_type_mask = data["sdetail_type"].str.lower() == "p"
    no_part_code_mask = data["spart_no"].notnull()

    # Clean up labors
    part_detail_type_mask_labor = data["sdetail_type"].str.lower() == "l"

    # Consider only vehicles with full segment information:
    no_car_segment_mask = (
        ~data["imodel_year"].isnull()
        & ~data["smake"].isnull()
        & ~data["smodel"].isnull()
        & ~data["strim"].isnull()
    )

    data_parts = data[
        no_car_segment_mask & part_detail_type_mask & no_part_code_mask
    ].copy()

    # Start processing for labor
    data_labor = data[no_car_segment_mask & part_detail_type_mask_labor].copy()

    # Process claim detail status
    data_labor = data_labor[
        ~(
            (data_labor["sclaim_status"].str.lower().str.contains("p"))
            & (data_labor["iclaim_det_status_id"] == 3)
        )
    ]
    data_parts = data_parts[
        ~(
            (data_parts["sclaim_status"].str.lower().str.contains("p"))
            & (data_parts["iclaim_det_status_id"] == 3)
        )
    ]

    data_parts = data_parts[filters["initial_columns_cost"]]
    data_labor = data_labor[filters["initial_columns_cost"]]

    data_parts.drop_duplicates(inplace=True)
    data_labor.drop_duplicates(inplace=True)
    print("Shape for data cleaning BEFORE filtering: ", df.shape)
    print("Shape for data cleaning PARTS AFTER filtering: ", data_parts.shape)
    print("Shape for data cleaning LABOR AFTER filtering: ", data_labor.shape)
    return data_parts, data_labor


def generate_features_labor_conditions(
    data_labor_df: pd.DataFrame, modelling_grp: list[str]
):
    """This function is used to calculate features for labor hours prediction
    and aggregate the features to designed granularity level.

    Parameters:
        data_labor_df (pd.DataFrame): data clean master table at claim level granularity.
        modelling_grp: list of fields used to aggregate information

    Returns:
        pd.DataFrame: Dataframe the new calculated fields.
    """

    ## Get the labor table
    data_labor = data_labor_df.copy()

    ## create description based on detail spart_desc for labor items
    data_labor["labor_description"] = np.where(
        data_labor["spart_desc_claim_detail_history"]
        .str.lower()
        .str.contains("overhaul"),
        "overhaul",
        np.where(
            data_labor["spart_desc_claim_detail_history"]
            .str.lower()
            .str.contains("sublet|align|shortpay"),
            "manual_adjustment",
            np.where(
                data_labor["spart_desc_claim_detail_history"]
                .str.lower()
                .str.contains("diag"),
                "diagnosis",
                "normal",
            ),
        ),
    )

    ## Calculate labor hours by different types of descriptions
    data_labor_pivot = pd.pivot_table(
        data_labor,
        index=["iclaim_id", "dtdate_loss_occurred", "sloss_code"],
        columns=["labor_description"],
        values=["nauth_qty"],
        aggfunc="sum",
    )
    # Rename sum labor hours columns
    cols = data_labor_pivot.columns.tolist()
    cols = [x[1] + "_hours" for x in cols]
    data_labor_pivot.columns = list(cols)

    # Calculate the sum of claim issue hours
    data_labor_pivot["claim_issue_labor_hours"] = data_labor_pivot.sum(axis=1)
    data_labor_pivot.reset_index(inplace=True)

    # Merge in description sum labor hours columns
    data_labor = pd.merge(
        data_labor,
        data_labor_pivot,
        on=["iclaim_id", "dtdate_loss_occurred", "sloss_code"],
        how="left",
        validate=None,
    )

    # Fill null values to zero and calculate ratio
    for col in cols:
        data_labor[col] = data_labor[col].fillna(0)
        # data_labor[col + '_ratio'] = data_labor[col] / data_labor['claim_issue_labor_hours']
        # data_labor[col + '_ratio'] = data_labor[col + '_ratio'].fillna(0)

    # Calculate single event flag for descriptions
    data_labor["overhaul"] = np.where(
        data_labor["spart_desc_claim_detail_history"]
        .str.lower()
        .str.contains("overhaul"),
        1,
        0,
    )
    data_labor["sublet"] = np.where(
        data_labor["spart_desc_claim_detail_history"]
        .str.lower()
        .str.contains("sublet"),
        1,
        0,
    )
    data_labor["diagnosis"] = np.where(
        data_labor["spart_desc_claim_detail_history"].str.lower().str.contains("diag"),
        1,
        0,
    )
    data_labor["alignment"] = np.where(
        data_labor["spart_desc_claim_detail_history"].str.lower().str.contains("align"),
        1,
        0,
    )
    data_labor["shortpay"] = np.where(
        data_labor["spart_desc_claim_detail_history"]
        .str.lower()
        .str.contains("shortpay"),
        1,
        0,
    )
    data_labor["manual_adjustment"] = np.where(
        data_labor["sublet"] + data_labor["alignment"] + data_labor["shortpay"] > 0,
        1,
        0,
    )
    data_labor["served_by_seller"] = np.where(
        data_labor["spayee_no"] == data_labor["sdealer_number"], 1, 0
    )

    ## Aggregate to claim +loss level, Add loss code

    run_prod = prod["set_up_configuration"]["product"]
    if run_prod == "T&W":
        df_labor = (
            data_labor.groupby(
                [
                    "iclaim_id",
                    "dtdate_loss_occurred",
                    "sloss_code",
                    "dtpaid",
                    "sclaim_status",
                ],
                dropna=False,
            )
            .agg(
                {
                    "manual_adjustment": "max",
                    "served_by_seller": "max",
                    "overhaul": "max",
                    "clabor_rate": "max",
                    "cauth_total": "sum",
                    "cauth_unit_cost": "mean",
                    "cpremium_rate": "max",
                    "iodometer_at_time_of_loss": "max",
                    "nauth_qty": "sum",
                    "normal_hours": "mean",
                    "manual_adjustment_hours": "mean",
                    "claim_issue_labor_hours": "mean",
                    "dealer_claim_contract_ratio": "mean",
                }
            )
            .reset_index()
        )
    elif run_prod == "VSC":
        df_labor = (
            data_labor.groupby(
                [
                    "iclaim_id",
                    "dtdate_loss_occurred",
                    "sloss_code",
                    "dtpaid",
                    "sclaim_status",
                ],
                dropna=False,
            )
            .agg(
                {
                    "manual_adjustment": "max",
                    "served_by_seller": "max",
                    "overhaul": "max",
                    "clabor_rate": "max",
                    "cauth_total": "sum",
                    "cauth_unit_cost": "mean",
                    "cpremium_rate": "max",
                    "iodometer_at_time_of_loss": "max",
                    "nauth_qty": "sum",
                    "overhaul_hours": "mean",
                    "normal_hours": "mean",
                    "manual_adjustment_hours": "mean",
                    "claim_issue_labor_hours": "mean",
                    "dealer_claim_contract_ratio": "mean",
                }
            )
            .reset_index()
        )
    else:
        print("Please specify right product name!")
        exit()
    ## Clean up duplicates due to dtpaid, keep the latest

    df_labor = df_labor.sort_values("dtpaid").drop_duplicates(
        subset=["iclaim_id", "sclaim_status", "dtdate_loss_occurred", "sloss_code"],
        keep="last",
    )

    df_labor = df_labor.drop("dtpaid", axis=1).drop_duplicates()

    df_labor_attri = data_labor[
        ["iclaim_id", "sclaim_status", "dtdate_loss_occurred"] + modelling_grp
    ].drop_duplicates(subset=["iclaim_id", "dtdate_loss_occurred", "sloss_code"])

    df_labor = pd.merge(
        df_labor_attri,
        df_labor,
        on=["iclaim_id", "dtdate_loss_occurred", "sloss_code", "sclaim_status"],
        how="inner",
        validate=None,
    )

    df_labor["normal_hours_ratio"] = (
        df_labor["normal_hours"] / df_labor["claim_issue_labor_hours"]
    )
    df_labor["normal_hours_ratio"] = df_labor["normal_hours_ratio"].fillna(0)

    return df_labor


def generate_past_event_labor(
    df: pd.DataFrame,
    type_column: list[str],
    value_column: list[str],
    col_name: list[str],
    aggfunc: str,
) -> pd.DataFrame:
    """Function used to calculate the number of historical labor requests, from
    the claim ID perspective n months before. This aggregates the metrics at
    make-model-loss code level.

    Also index column is created as base comparative between number of events for
    the same make model and loss code over the total events for the same vehicle.

    Parameters:
        df (pd.DataFrame): the dataframe at model granularity (make-model-loss code agg)
        type_column: column used as target for count the events
        value_column: list of cols to aggregate
        col_name: name of the calculated column
        aggfunc: metric used to aggregate data

    Returns:
        pd.DataFrame: Dataframe with the new ratio and calculated column
    """

    # Create a copy
    data = df.copy()

    # Implement group by approach:
    cols_to_keep_part = (
        vehicle_segment
        + ["dtdate_loss_occurred", "iclaim_id"]
        + type_column
        + value_column
    )

    # Compile dictionary for rename
    value_column2 = [x + "_v1" for x in value_column]
    rename_dict = dict(zip(value_column, value_column2))

    # Explode the table for all dates in consideration:
    left_table = data.copy()[cols_to_keep_part]
    right_table = left_table.copy().rename(
        columns={
            "dtdate_loss_occurred": "dtdate_loss_occurred_v1",
            "iclaim_id": "iclaim_id_v1",
        }
        | rename_dict
    )
    merge_table = left_table.merge(
        right_table, on=vehicle_segment + type_column, how="left", validate=None
    )

    # Filter for only those claims where claim_date > claim_date 1:
    date_mask = (
        merge_table["dtdate_loss_occurred"] > merge_table["dtdate_loss_occurred_v1"]
    ) & (
        merge_table["dtdate_loss_occurred"] - DateOffset(months=12)
        < merge_table["dtdate_loss_occurred_v1"]
    )
    merge_table_flt = merge_table[date_mask]
    merge_table_flt.drop_duplicates(inplace=True)

    # Agg average value and overall ratio:
    if aggfunc == "mean":
        agg_table = (
            merge_table_flt.groupby(
                vehicle_segment + ["dtdate_loss_occurred"] + type_column
            )[value_column2]
            .mean()
            .reset_index()
        )
    elif aggfunc == "sum":
        agg_table = (
            merge_table_flt.groupby(
                vehicle_segment + ["dtdate_loss_occurred"] + type_column
            )[value_column2]
            .sum()
            .reset_index()
        )
    else:
        print("not a valid input for aggfunc!")

    rename_dict2 = dict(zip(value_column2, col_name))
    agg_table.rename(columns=rename_dict2, inplace=True)

    # Calculate the ratio across dealers for the same segment/type
    if aggfunc == "mean":
        for var in col_name:
            agg_table[f"total_{var}_segment_type"] = agg_table.groupby(
                vehicle_segment + ["dtdate_loss_occurred", "sloss_code"]
            )[var].transform("mean")
            agg_table[f"{var}_ratio"] = (
                agg_table[var] / agg_table[f"total_{var}_segment_type"]
            )
    elif aggfunc == "sum":
        for var in col_name:
            agg_table[f"total_{var}_segment_type"] = agg_table.groupby(
                vehicle_segment + ["dtdate_loss_occurred", "sloss_code"]
            )[var].transform("sum")
            agg_table[f"{var}_ratio"] = (
                agg_table[var] / agg_table[f"total_{var}_segment_type"]
            )
    else:
        print("not a valid input for aggfunc!")

    # Merge Aggregated counts with raw data:
    data_bare_bone = data.merge(agg_table, how="left", validate=None)

    # Fill Nulls as cero for past replacements:

    for var in col_name:
        data_bare_bone[var].fillna(0, inplace=True)
        data_bare_bone[f"{var}_ratio"].fillna(0, inplace=True)

    # Validate no duplicating rows:
    assert len(data_bare_bone) == len(df), "duplicating rows after merge..."

    return data_bare_bone


def aggregate_claims_to_loss_type_level(df: pd.DataFrame):
    """
    Auxiliary function used to aggregate master table that is at part level to
    claim - loss type granularity for modelling.

    Parameters:
        df (pd.DataFrame): data at claim level from claim master table

    Returns:
        pd.DataFrame: Dataframe with the aggregated level
    """

    data = df.copy()

    #  Get features to aggregate:
    features_to_agg = engineering_features["loss_code_aggregation"]
    id_features = [i for i in data if i not in features_to_agg.keys()]

    # Create bare-bone to assign aggregated columns:
    bare_bone = data[id_features].drop_duplicates()

    # calculate aggregated features:
    agg_data = (
        data.groupby(id_features, dropna=False).agg(features_to_agg).reset_index()
    )
    merge_data = bare_bone.merge(agg_data, how="left", validate=None)

    assert len(bare_bone) == len(merge_data), "duplicating rows after agg to loss level"

    return merge_data


def generate_weather_features(
    df_claims: pd.DataFrame,
) -> pd.DataFrame:
    """Auxiliary function used to plug key weather features at zipcode level
    and use it as a loss predictions in the ML engine.

    These features are calculated on the static pipeline and imported here for training
    proposes.

    Parameters:
        df_claims (pd.DataFrame): data with weather features

    Returns:
        pd.DataFrame: Dataframe with the new features added
    """

    data_claims = df_claims.copy()

    # Import features from static table:
    df_res = spark.read.parquet(
        data_sources["input_tables"]["weather_features"]
    ).toPandas()

    # Merge geo weather features with claim information at zipcode level:
    df_claims_final = df_claims.merge(
        df_res,
        left_on=["scontract_holder_zip_code"],
        right_on=["zip"],
        how="left",
        validate=None,
    )

    # Assess we are not adding duplicates right here:
    assert len(df_claims_final) == len(data_claims)

    # rename columns to be more meaningful:
    df_claims_final.rename(
        columns=engineering_features["rename_weather_features"], inplace=True
    )

    return df_claims_final


def feature_engineering_breakdown_model(
    df: pd.DataFrame, df_master: pd.DataFrame
) -> pd.DataFrame:
    """Main function used to orchestrate feature engineering steps for
    breakdown model.

    Parameters:
        df (pd.DataFrame): aggregated initial features at make-model and loss code level
        df_master (pd.Dataframe): raw claim data from clean master table

    Returns:
        pd.DataFrame: Dataframe with the full set of features for modelling
    """

    data = df.copy()

    # Aggregate table to claim-vehicle-loss type level:
    data = aggregate_claims_to_loss_type_level(data)
    print("Claims aggregation to loss type done...")

    # Include macro/ demographic features:
    data = generate_demographics_features(data)
    print("Demographics features done...")

    # Include weather features:
    data = generate_weather_features(data)
    print("Weather features done...")

    # Include Time Features:
    data = generate_time_features(data)
    print("Time features features done...")

    # Include claim details features:
    data_w_claim_features = generate_claim_detail_features(data, df_master)
    print("Claim detail features done...")

    # Include price features:
    data_w_claim_price_features = generate_price_features(data_w_claim_features)
    print("Price features done...")

    # Filter final columns to use:
    feature_engineering_output = data_w_claim_price_features[final_features]
    print("Feature engineering task completed successfully...")

    return feature_engineering_output


def feature_engineering_cost_validation(
    df_labor: pd.DataFrame, df_master: pd.DataFrame
):
    """Main function used to orchestrate feature engineering steps for cost
    model.

    Parameters:
        df_labor (pd.DataFrame): aggregated initial features at make-model and loss code level
        df_master (pd.Dataframe): raw claim data from clean master table

    Returns:
        pd.DataFrame: Dataframe with the full set of features for modelling
    """

    # Bring in data
    data_labor = df_labor.copy()

    # Generate dealer claim to contract ratio
    df_claim_freq = generate_claim_freq_total(df=df_master)
    data_labor = generate_dealer_claim_freq(data_labor, df_claim_freq)

    # Generate labor condition features and mileage, prem rate, labor hours billed, Forte labor rate
    df_labor = generate_features_labor_conditions(data_labor, labor_model_granularity)

    # Generate whether there's previous claim with the same issue in last 12 months
    df_labor = calculate_past_events_claimcnt(
        df=df_labor,
        type_column=[
            "sloss_code",
            "spayee_no",
        ],  # make + model + model year + loss code + payeeno
        col_name="issue_dealer_car_segment",
    )

    # Generate historical average labor rate, labor hours and number of parts
    df_labor = generate_past_event_labor(
        df_labor,
        type_column=["sloss_code", "spayee_no"],
        value_column=[
            "cauth_unit_cost",
            "nauth_qty",
        ],  # make + model + model year + loss code + payeeno
        col_name=["avg_prev_labor_rate", "avg_prev_labor_hours"],
        aggfunc="mean",
    )

    # Generate historical average labor rate, labor hours and number of parts
    df_labor = generate_past_event_labor(
        df_labor,
        type_column=["sloss_code", "spayee_no"],
        value_column=["cauth_total"],
        col_name=["sum_labor_cost"],
        aggfunc="sum",
    )

    # Calculate by dear cost per claim - previous total labor cost over last 12 months / previous
    # of claims for the same make,  model,  model year , loss code, and dealer
    df_labor["dealer_issue_labor_cost_per_claim"] = (
        df_labor["sum_labor_cost"] / df_labor["issue_dealer_car_segment"]
    )
    df_labor["dealer_issue_labor_cost_per_claim"] = df_labor[
        "dealer_issue_labor_cost_per_claim"
    ].fillna(0)

    # Clean up a special column
    df_labor["swheel_drive_count"] = np.where(
        df_labor["swheel_drive_count"] == "", np.nan, df_labor["swheel_drive_count"]
    )
    df_labor["swheel_drive_count"] = (
        df_labor["swheel_drive_count"].astype(float).fillna(2)
    )

    return df_labor


def main_costmodel():
    """Main function used to execute feature engineering for labor hours
    prediction model and other labor rate & part price flagging.

    Returns:
        pd.DataFrame: Dataframe with the full set of features for modelling
    """

    run_prod = prod["set_up_configuration"]["product"]
    print(
        f"*** Initializing Cost Model Feature Engineering Step for Product {run_prod} ***"
    )
    # Initialize time to tack:
    start_time = datetime.now()

    if run_prod == "VSC":
        product_type = 4
    elif run_prod == "T&W":
        product_type = 8
    else:
        print("Invalid product type!")

    print("product_type: ", product_type)

    # Load master table from database (Cleaned version):
    master_table_clean = read_parquet(
        data_sources["input_tables"]["final_clean_master_table"],
        filters["initial_columns_cost"],
        f" iproduct_type_id = {str(product_type)} ",
    )

    # Define the window specification to make sure this function can handle the cases where date column is null
    windowSpec = Window.partitionBy(
        "iclaim_id", "sclaim_status", "sdetail_type", "irecord_id"
    ).orderBy(F.col("dtpaid").desc())

    # Assign row numbers based on the window specification
    master_table_clean = master_table_clean.withColumn(
        "row_number", F.row_number().over(windowSpec)
    )

    # Filter to obtain only the rows with the maximum 'dtpaid' per group
    master_table_clean = master_table_clean.filter(F.col("row_number") == 1).drop(
        "row_number"
    )

    # Filter on paid line items only for training
    master_table_clean = master_table_clean.filter(F.col("iclaim_det_status_id") == 4)

    # Convert pyspark dataframe to pandas dataframe
    df_master = master_table_clean.toPandas()
    print(f"Clean master table loaded with shape {df_master.shape}...")

    # Create cleaned data for cost validation model
    _, data_labor = prep_cost_validation_model(df=df_master)
    print("Prepare cost base is done")

    # Generate features for cost_validation
    df_labor = feature_engineering_cost_validation(data_labor, df_master)
    print("Feautre engineering is finished")

    # Apply filter on feature engineering output. Given we have used last 12 months
    # window for some of the features, so select most recent 3 years for training
    df_labor = df_labor[
        df_labor["dtdate_loss_occurred"]
        >= pd.to_datetime(filters["cost_training_start_date"])
    ]

    # Output feature engineering to S3 path specified in config
    df_labor.to_csv(data_sources["output_s3"]["cost_output"], index=False)
    print(
        f"Save feature engineering output with data starting from {filters['cost_training_start_date']}"
    )

    # Print total time used to run this module:
    print(f"Time to finish: {datetime.now() - start_time} seconds")

    return df_labor


def load_master_table(run_prod):
    """Main function used to load master table from S3 path.

    Parameters:
        run_prod: Unique product ID identifier to filter for VSC or TW products

    Returns:
        pd.DataFrame: Dataframe with all claim information
    """

    if run_prod == "VSC":
        product_type = 4
    elif run_prod == "T&W":
        product_type = 8
    else:
        print("Invalid product type!")

    print("product_type: ", product_type)

    # Load master table from database (Cleaned version):
    master_table_clean = read_parquet(
        data_sources["input_tables"]["final_clean_master_table"],
        filters["initial_columns"],
    )

    # Filter on paid line items only for training
    master_table_clean = master_table_clean.filter(
        F.col("iclaim_det_status_id") == 4
    ).toPandas()

    print(f"Clean master table loaded with shape {master_table_clean.shape}...")

    return master_table_clean


def download_feature_engineering_input(df: pd.DataFrame):
    """
    Function used to download feature engineering input for using in postprocessing:

    Parameters:
        df: dataframe with the input for feature engineering to download

    Returns:
        pd.DataFrame: Dataframe with the removed fields
    """

    data = df.copy()
    output_dir = data_sources["output_s3"]["breakdown_feature_engineering_input"]
    data.to_csv(output_dir, index=False)
    data.drop(
        columns=["sdetail_type", "spart_no", "iclaim_det_status_id", "sclaim_status"],
        inplace=True,
    )

    return data


def store_feature_engineering_output(feature_engineering_output: pd.DataFrame):
    """
    Function used to download feature engineering output for using in postprocessing:

    Parameters:
        feature_engineering_output: dataframe with the output for feature engineering to download

    """

    output_dir = data_sources["output_s3"]["breakdown_feature_engineering_output"]
    feature_engineering_output.to_csv(output_dir, index=False)
    print("Feature Engineering output loaded into database...")


def main_breakdown():
    """Main Function used to execute feature engineering for estimate breakdown
    probabilities."""
    run_prod = prod["set_up_configuration"]["product"]
    print(
        f"*** Initializing Breakdown Model Feature Engineering Step for Product {run_prod} ***"
    )

    # Initialize time to tack:
    start_time = datetime.now()

    # Load clean master table from database:
    master_table_clean = load_master_table(run_prod)

    # Filter out claims for breakdown model:
    data_flt = filter_out_claims_breakdown_model(master_table_clean)

    # Download feature engineering input to use on postprocessing:
    data_flt = download_feature_engineering_input(data_flt)

    # Perform feature engineering for breakdown model:
    feature_engineering_output = feature_engineering_breakdown_model(
        data_flt, master_table_clean
    )

    # Store results:
    store_feature_engineering_output(feature_engineering_output)

    # Print total time used to run this module:
    print(f"Time to finish: {datetime.now() - start_time}")


def prep_cost_validation_model_tw_spark(data):
    """Function used to apply advanced filters for cost validation model and
    scope columns for modeling TW claims.

    Parameters:
        data: master table data used to apply advanced filters

    Returns:
        pd.DataFrame: Dataframe with the selected rows
    """

    print(f"Data before filtering has {data.count()} rows.")

    # Lower-case all features into dataframe
    for column in data.columns:
        if dict(data.dtypes)[column] == "string":
            data = data.withColumn(column, F.lower(F.col(column)))

    # Apply initial filters
    bt_coverage_mask = F.col("btcovered_flag") == 1
    no_part_desc_mask = (~F.col("spart_desc").isNull()) & (
        F.trim(F.col("spart_desc")) != ""
    )
    no_issue_mask = (~F.col("sdetail_desc").isNull()) & (
        F.trim(F.col("sdetail_desc")) != ""
    )

    # Clean up parts
    part_detail_type_mask = F.col("sdetail_type") == "p"
    no_part_code_mask = ~F.col("spart_no").isNull()

    part_relevant_type_mask = (
        ~F.col("ipart_id").isNull()
        & (F.col("spart_no") != "426070c080")
        & (~F.col("spart_desc").contains("valve"))
        & (F.col("cauth_total") > 0)
        & (F.col("creq_unit_cost") > 35)
    )

    # Clean up labors
    part_detail_type_mask_labor = F.col("sdetail_type") == "l"
    no_disposal_mask_labor = F.col("creq_unit_cost") >= 10

    # Consider only vehicles with full segment information
    no_car_segment_mask = (
        ~F.isnan(F.col("imodel_year"))
        & ~F.isnan(F.col("smake"))
        & ~F.isnan(F.col("smodel"))
        & ~F.isnan(F.col("strim"))
    )

    # Filter the data for parts and labor
    data_parts = data.filter(
        bt_coverage_mask
        & no_issue_mask
        & no_car_segment_mask
        & part_detail_type_mask
        & no_part_desc_mask
        & no_part_code_mask
        & part_relevant_type_mask
    ).select([col for col in filters["initial_columns_cost"]])

    data_labor = data.filter(
        bt_coverage_mask
        & no_issue_mask
        & no_car_segment_mask
        & part_detail_type_mask_labor
        & no_disposal_mask_labor
    ).select([col for col in filters["initial_columns_cost"]])

    # Process claim detail status
    data_labor = data_labor.filter(
        ~((F.col("sclaim_status").contains("p")) & (F.col("iclaim_det_status_id") == 3))
    )

    data_parts = data_parts.filter(
        ~((F.col("sclaim_status").contains("p")) & (F.col("iclaim_det_status_id") == 3))
    )

    # Strip part and breakdown description columns
    for column in ["spart_desc", "sdetail_desc", "sclaim_status"]:
        data_parts = data_parts.withColumn(column, F.trim(F.col(column)))
        data_labor = data_labor.withColumn(column, F.trim(F.col(column)))

    # Drop duplicates
    data_parts = data_parts.drop_duplicates()
    data_labor = data_labor.drop_duplicates()

    # Save to CSV
    data_labor.toPandas().to_csv(
        data_sources["output_s3"]["tire_and_wheel_labor_df"], index=False
    )
    data_parts.toPandas().to_csv(
        data_sources["output_s3"]["tire_and_wheel_part_df"], index=False
    )

    print("Shape for data cleaning BEFORE filtering: ", data.count())
    print("Shape for data cleaning PARTS AFTER filtering: ", data_parts.count())
    print("Shape for data cleaning LABOR AFTER filtering: ", data_labor.count())


def main_tire_and_wheel():
    """Main function used to orchestrate TW feature engineering execution."""

    print("*** Initializing TW Model Feature Engineering Step for Product ***")

    # Load master table from database (Cleaned version):
    master_table_clean = read_parquet(
        data_sources["input_tables"]["final_clean_master_table"],
        filters["initial_columns_cost"],
    )

    # Filter on paid line items only for training
    master_table_clean = master_table_clean.filter(F.col("iproduct_type_id") == 8)

    # Generate part and labor tables required for TW inference:
    prep_cost_validation_model_tw_spark(master_table_clean)

    print("TW feature engineering is done...")
