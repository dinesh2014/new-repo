
from datetime import datetime, timezone, timedelta
import sys
import os
notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
sys.path.append("/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path))))

from configs.config import get_env_variables

from model1.feature_engineering.features.feature_engineering import (
    main_breakdown as main_feature_engineering_breakdown,
)


# Define the path to save the profile report:
env_vars = get_env_variables()
profile_results_path = f"{env_vars['base_path']}/artifacts/acr_profile/ml_training/"
print(profile_results_path)

# Define the time difference between UTC and Central Time
ct_offset = timedelta(hours=-5)
# Get the current date and time in Central Time
date_folder = (datetime.now(timezone.utc) + ct_offset).strftime("%Y-%m-%d")

main_feature_engineering_breakdown()

# pathtocheck = main_train_breakdown()

# print(pathtocheck,"--------------------COMPLETED-------------------------")