import pytest
import pandas as pd
import tests.dummy_params_pytest as inputs

from src.ai_training_pipeline.breakdown_model import (
    apply_hot_encoding,
)


@pytest.mark.parametrize(
    "input, expected",
    [
        (inputs.hot_encode_input, inputs.hot_encode_expected),
    ],
)
def test_apply_hot_encoding(input, expected):
    pd.testing.assert_frame_equal(apply_hot_encoding(input), expected)
