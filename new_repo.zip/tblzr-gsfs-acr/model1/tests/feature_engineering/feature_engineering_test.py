import pytest
import pandas as pd
import tests.dummy_params_pytest as inputs

def aggregate_claims_to_loss_type_level(df: pd.DataFrame):
    """
    Auxiliary function used to aggregate master table that is at part level to
    claim - loss type granularity for modelling.
    """

    data = df.copy()

    #  Get features to aggregate:
    features_to_agg = {"iodometer_at_time_of_loss": "max"}

    id_features = [i for i in data if i not in features_to_agg.keys()]

    # Create bare-bone to assign aggregated columns:
    bare_bone = data[id_features].drop_duplicates()

    # calculate aggregated features:
    agg_data = (
        data.groupby(id_features, dropna=False).agg(features_to_agg).reset_index()
    )
    merge_data = bare_bone.merge(agg_data, how="left")

    assert len(bare_bone) == len(merge_data), "duplicating rows after agg to loss level"

    return merge_data

@pytest.mark.parametrize(
    "input, expected",
    [
        (inputs.aggregate_claims_input, inputs.aggregate_claims_expected),
    ],
)
def test_aggregate_claims_to_loss_type_level(input, expected):
    pd.testing.assert_frame_equal(aggregate_claims_to_loss_type_level(input), expected)


# @pytest.mark.parametrize(
#     "input, expected",
#     [
#         (inputs.generate_time_features_input, inputs.generate_time_features_expected),
#     ],
# )
# def test_generate_time_features(input, expected):
#     pd.testing.assert_frame_equal(generate_time_features(input), expected)


# @pytest.mark.parametrize(
#     "input, expected",
#     [
#         (
#             inputs.average_mileage_per_year_input,
#             inputs.average_mileage_per_year_expected,
#         ),
#     ],
# )
# def test_generate_time_features(input, expected):
#     pd.testing.assert_frame_equal(
#         estimate_average_mileage_per_year(
#             input, "vehicle_age", "mileage_per_year_ratio"
#         ),
#         expected,
#     )
