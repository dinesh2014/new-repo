from dotenv import load_dotenv
import spark

# Load variables from the .env file
load_dotenv()


class DBManager:
    """Database manager for connecting to Microsoft SQL Server."""

    # def execute_query(query_str):

    def read_table(bu_code, stage, table_name, columns: str = "*", where: str = ""):
        # bu_code = 'gsfs'
        # catalog_uc = f"cat_{bu_code}"
        rawLandingZone = f"s3://s3-{bu_code}-share/ingest/"

        df = spark.read.csv(
            path=f"{rawLandingZone}/{stage}/{table_name}",
            sep=",",
            header=True,
            inferSchema=True,
            timestampFormat="yyyy-MM-dd",
        )

        # Register the DataFrame as a temporary table
        df.createOrReplaceTempView("my_table")

        # Run a SQL query to filter a subset of data
        if where == "":
            query = f"""SELECT {columns} FROM my_table"""
        else:
            query = f"""SELECT {columns} FROM my_table WHERE {where}"""

        filtered_df = spark.sql(query)

        # Show the resulting DataFrame
        filtered_df.show()

        return filtered_df

    # def get_column_names(self, table_name):
