import logging

import cProfile
import pstats
import sys
import os
from io import StringIO

notebook_path = (
    dbutils.notebook.entry_point.getDbutils()
    .notebook()
    .getContext()
    .notebookPath()
    .get()
)
sys.path.append(
    "/Workspace" + os.path.dirname(os.path.dirname(os.path.dirname(notebook_path)))
)

import json
import sys
import base64
import gzip
import uuid
import concurrent.futures
from configs.logger_config import setup_logger

from datetime import datetime, timezone, timedelta
from configs.config import BaseConfig
from src.inference_pipeline.breakdown.main import exec_inference_breakdown_task
from src.inference_pipeline.kpi_refreshment.main import (
    exec_inference_kpi_refreshment_task,
    exec_inference_kpi_refreshment_task_tw,
)
from src.inference_pipeline.kpi_refreshment.feature_engineering import (
    generate_kpi_refreshement_features,
)
from src.inference_pipeline.labor_cost.main import exec_inference_cost_task
from src.inference_pipeline.tw_price.main import exec_inference_twprice_task
from utils.utils import save_single_file, load_intermediate_daily_files_s3, timing

from databricks.connect import DatabricksSession
from src.inference_pipeline.kpi_refreshment.feature_engineering import (
    output_claim_history,
)
from src.inference_pipeline.kpi_refreshment.flag_reminder import add_exception_reminder


config_file = BaseConfig.KPI_REFRESHMENT_CONFIG
set_up = config_file["set_up_configuration"]
data_sources = set_up["data_sources"]
output_folder = data_sources["output_folder"]
temp_input_folder = data_sources["temp_input_folder"]
output_tables = data_sources["output_tables"]
input_tables = data_sources["input_tables"]

# Define the time difference between UTC and Central Time
ct_offset = timedelta(hours=-5)

# Get the current date and time in Central Time
date_folder = (datetime.now(timezone.utc) + ct_offset).strftime("%Y-%m-%d")

# Get the job run and date folder parameter to track interim results:
id_execution = {"job_run_id": str(uuid.uuid4()), "date_folder": date_folder}

# Set up the logger using our configuration function
setup_logger(id_execution)

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Create SparkSession (Databricks)
spark = DatabricksSession.builder.getOrCreate()

# Defining spark configurations:
spark.conf.set("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2")
spark.conf.set("spark.hadoop.fs.s3a.fast.upload", "true")
spark.conf.set("spark.sql.parquet.compression.codec", "snappy")
spark.conf.set("spark.sql.parquet.enableVectorizedReader", "true")


def receive_json():
    """This function is used to retrieve API contract from system variables.

    Returns:
        JSON variable
    """

    logger.info("Start loading payload contract")
    # Retrieve API contract:
    contract_arg = sys.argv[1]

    # Decode from Base64
    base64_decoded = base64.b64decode(contract_arg)

    # Decompress with gzip
    decompressed_data = gzip.decompress(base64_decoded).decode()

    # Deserialize JSON
    contract = json.loads(decompressed_data)

    return contract


@timing
def get_ml_output(contract, id_execution, spark):
    """This function is used to execute ML engine components for VSC claims.

    Args:
        contract: dataframe with claim information
        id_execution: unique identifier of the execution
        spark: unique id for run execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    run_id = id_execution["job_run_id"]
    date_folder = id_execution["date_folder"]

    logger.info(
        f"### Executing Inference Pipeline for JobID {run_id} and Date Folder:{date_folder} ###"
    )
    # Load output from ML models

    # Execute breakdown and labor hours model
    logger.info("----------- Parallelized Run ----------------")
    with concurrent.futures.ThreadPoolExecutor() as executor:
        breakdown_model_result = executor.submit(
            exec_inference_breakdown_task, contract, id_execution
        )
        cost_model_result = executor.submit(
            exec_inference_cost_task, contract, id_execution
        )
        feature_refresh_result = executor.submit(
            generate_kpi_refreshement_features, contract, run_id
        )

    if breakdown_model_result.result() is not None:
        raise Exception(str(breakdown_model_result.result()))
    if cost_model_result.result() is not None:
        raise Exception(str(cost_model_result.result()))
    if feature_refresh_result.result() is not None:
        raise Exception(str(feature_refresh_result.result()))

    # logger.info("----------- Sequential Run ----------------")
    # exec_inference_breakdown_task(contract, id_execution)
    # exec_inference_cost_task(contract, id_execution)
    # generate_kpi_refreshement_features(contract, run_id)

    # Load the output from breakdown, part freq and cost:
    df_breakdown = load_intermediate_daily_files_s3(
        temp_input_folder + "breakdown/",
        date_folder,
        run_id,
        input_tables["breakdown"],
        spark,
    )
    df_part_freq = load_intermediate_daily_files_s3(
        temp_input_folder + "breakdown/",
        date_folder,
        run_id,
        input_tables["part_freq"],
        spark,
    )
    df_cost = load_intermediate_daily_files_s3(
        temp_input_folder + "labor_hours/",
        date_folder,
        run_id,
        input_tables["labor_hours"],
        spark,
    )

    # Generate ACR output
    df_acr_out = exec_inference_kpi_refreshment_task(
        df_breakdown, df_cost, df_part_freq, run_id
    )

    return df_acr_out


@timing
def get_ml_output_tw(contract, id_execution, spark):
    """This function is used to execute ML engine components for TW claims.

    Args:
        contract: dataframe with claim information
        id_execution: unique identifier of the execution
        spark: unique id for run execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    run_id = id_execution["job_run_id"]
    date_folder = id_execution["date_folder"]

    logger.info(
        f"### Executing Inference Pipeline for JobID {run_id} and Date Folder:{date_folder} ###"
    )
    # Load output from ML models

    logger.info("----------- Parallelized Run ----------------")
    with concurrent.futures.ThreadPoolExecutor() as executor:
        tw_model_result = executor.submit(
            exec_inference_twprice_task, contract, id_execution
        )
        feature_refresh_result = executor.submit(
            generate_kpi_refreshement_features, contract, run_id
        )

    if tw_model_result.result() is not None:
        raise Exception(str(tw_model_result.result()))
    if feature_refresh_result.result() is not None:
        raise Exception(str(feature_refresh_result.result()))

    # logger.info("----------- Sequential Run ----------------")
    # exec_inference_twprice_task(contract, id_execution)
    # generate_kpi_refreshement_features(contract, run_id)

    # Load the output from breakdown, part freq and cost:
    df_tw = load_intermediate_daily_files_s3(
        temp_input_folder + "tire_and_wheel/",
        date_folder,
        run_id,
        input_tables["tire_and_wheel"],
        spark,
    )

    # Generate ACR output
    df_acr_out = exec_inference_kpi_refreshment_task_tw(df_tw, run_id)

    return df_acr_out


@timing
def save_master_output(df_acr_out, file_format, timestamp, run_id, contract):
    """This function is used store master output for ACR on S3 bucket.

    Args:
        df_acr_out: dataframe with claim information output
        file_format: file format as parquet
        timestamp: timestamp of the execution
        run_id: unique identifier of the execution
        contract: contract dataframe

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    claim_nbr = contract["claims"][0]["sclaim_number"]
    master_output_path = f"{output_folder}{output_tables['master_table']}_{str(run_id)}_{claim_nbr}_{timestamp}.{file_format}"
    save_single_file(
        df_acr_out.drop("rob_otto_claim_flag"), master_output_path, f"{file_format}"
    )

    return master_output_path


@timing
def save_reminder(df_acr_out, file_format, timestamp, run_id, contract):
    """This function is used store reminder output for ACR on S3 bucket.

    Args:
        df_acr_out: dataframe with claim information output
        file_format: file format as parquet
        timestamp: timestamp of the execution
        run_id: unique identifier of the execution
        contract: contract dataframe

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    claim_nbr = contract["claims"][0]["sclaim_number"]
    reminder_output_path = (
        output_folder
        + output_tables["exception_reminder"]
        + f"_{str(run_id)}_{claim_nbr}_{timestamp}.{file_format}"
    )
    df_reminder = add_exception_reminder(df_acr_out)
    save_single_file(df_reminder, reminder_output_path, f"{file_format}")

    return reminder_output_path


@timing
def save_claim_history(contract, file_format, timestamp, run_id):
    """This function is used store claim history output for ACR on S3 bucket.

    Args:
        file_format: file format as parquet
        timestamp: timestamp of the execution
        run_id: unique identifier of the execution
        contract: contract dataframe

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    claim_nbr = contract["claims"][0]["sclaim_number"]
    df_claim = output_claim_history(contract)
    claim_history_output_path = (
        output_folder
        + output_tables["claim_history"]
        + f"_{str(run_id)}_{claim_nbr}_{timestamp}.{file_format}"
    )
    save_single_file(df_claim, claim_history_output_path, f"{file_format}")
    return claim_history_output_path


@timing
def inference_task_executor():
    """Main executor that run all inference tasks sequentially."""

    try:
        ###################################################
        ###### Execute Automated Claim Review Engine ######
        ###################################################

        # Receive contract from payload
        logger.info(
            "Inference Task Started Time: %s", datetime.now().strftime("%H:%M:%S")
        )
        contract = receive_json()

        # Extract product type (VSC or TW) for further execution:
        contract["contract"]["iproduct_type_id"] = contract["claims"][0][
            "iproduct_type_id"
        ]

        if int(contract["contract"]["iproduct_type_id"]) == 8:
            product = "tw"
        else:
            product = "vsc"

        if product == "vsc":
            # Initialize profiling execution:
            pr = cProfile.Profile()
            pr.enable()

            # Get the ACR outputs
            df_acr_out = get_ml_output(contract, id_execution, spark)

            # Save output
            # track time saving master_acr_output:
            file_format = "parquet"
            run_timestamp = id_execution["date_folder"]
            run_id = id_execution["job_run_id"]

            logger.info("----------- Parallelized Save ----------------")
            with concurrent.futures.ThreadPoolExecutor() as executor:
                master_output_path = executor.submit(
                    save_master_output,
                    df_acr_out,
                    file_format,
                    run_timestamp,
                    run_id,
                    contract,
                )
                reminder_output_path = executor.submit(
                    save_reminder,
                    df_acr_out,
                    file_format,
                    run_timestamp,
                    run_id,
                    contract,
                )
                claim_history_output_path = executor.submit(
                    save_claim_history, contract, file_format, run_timestamp, run_id
                )

            # logger.info("----------- Sequential Save ----------------")
            # master_output_path = save_master_output(df_acr_out, file_format, run_timestamp, run_id, contract)
            # reminder_output_path = save_reminder(df_acr_out, file_format, run_timestamp, run_id, contract)
            # claim_history_output_path = save_claim_history(contract, file_format, run_timestamp, run_id)

            # Clean up acr output dataframe
            del df_acr_out
            # Print the full path
            print(f"Master output file written to: {master_output_path.result()}")
            print(
                f"Claim history output file written to: {claim_history_output_path.result()}"
            )
            print(
                f"Exception reminder output file written to :{reminder_output_path.result()} "
            )
            print("Inference Task Finished Time:", datetime.now().strftime("%H:%M:%S"))

        elif product == "tw":
            # Initialize profiling execution:
            pr = cProfile.Profile()
            pr.enable()

            # Get the ACR outputs. Adding a try exception here for cases no output in TW:
            try:
                df_acr_out = get_ml_output_tw(contract, id_execution, spark)

                # track time saving master_acr_output:
                file_format = "parquet"
                run_timestamp = id_execution["date_folder"]
                run_id = id_execution["job_run_id"]

                logger.info("----------- Parallelized Save ----------------")
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    master_output_path = executor.submit(
                        save_master_output,
                        df_acr_out,
                        file_format,
                        run_timestamp,
                        run_id,
                        contract,
                    )
                    claim_history_output_path = executor.submit(
                        save_claim_history, contract, file_format, run_timestamp, run_id
                    )

                del df_acr_out
                # print("----------- Sequential Save ----------------")
                # master_output_path = save_master_output(df_acr_out, file_format, run_timestamp, run_id, contract)
                # claim_history_output_path = save_claim_history(contract, file_format, run_timestamp, run_id)

                # Print the full path
                print(f"Master output file written to: {master_output_path.result()}")
                print(
                    f"Claim history output file written to: {claim_history_output_path.result()}"
                )
                print(
                    "Inference Task Finished Time:", datetime.now().strftime("%H:%M:%S")
                )

            except SystemExit as e:
                logger.warning(f"SystemExit exception caught with code: {e.code}")
                spark.stop()

    finally:
        ###################################################
        ###### Execute Automated Claim Review Engine ######
        ###################################################

        if set_up["run_pipeline_profile"]:
            pr.disable()

            # Define the folder path to save results:
            run_id_profile = (
                id_execution["date_folder"] + "/" + id_execution["job_run_id"]
            )
            folder_path = set_up["profile_results_path"] + run_id_profile

            # Create unique folder path:
            dbutils.fs.mkdirs(folder_path)

            # Save profile report on date-jobid folder:
            profile_file = folder_path + "/" + "profile_data.prof"
            pr.dump_stats(profile_file)

            # Write to text file as well
            text_profile_file = folder_path + "/" + "profile_data.txt"
            stats = pstats.Stats(str(profile_file))
            stats.sort_stats("cumulative")
            s = StringIO()
            stats.stream = s
            stats.print_stats()
            profile_stats = s.getvalue()
            with open(text_profile_file, "w") as f:
                f.write(profile_stats)

            logger.info(f"Code profiling completed. Saved in {profile_file}")
            logger.info(
                "To view the profile file with snakeviz, run: `snakeviz <profile_file>`"
            )


if __name__ == "__main__":
    inference_task_executor()
