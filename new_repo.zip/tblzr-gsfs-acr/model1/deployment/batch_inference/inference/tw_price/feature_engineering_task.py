import logging
from configs.config import BaseConfig
import pyspark.sql.functions as F
from pyspark.sql.functions import (
    sum as spark_sum,
    max as spark_max,
    min as spark_min,
    avg as spark_avg,
)
from utils.utils import (
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.TW_PREDICTION_CONFIG
fe_config = config_file["feature_engineering"]

# Define intermediate configs:
interim_tables_config = config_file["intermediate_results"]["tire_and_wheel"]
interim_bucket_path = interim_tables_config["bucket_path"]


def aggregate_claims_to_loss_type_level(df: F.DataFrame, spark: object):
    """
    Aggregates data at the part level to claim-loss type granularity for modeling.
    Args:
        df (pyspark.sql.DataFrame): The DataFrame containing part-level data that needs to be aggregated.
        spark (pyspark.sql.SparkSession): Active Spark session to handle DataFrame operations including creating new DataFrames.

    Returns:
        pyspark.sql.DataFrame: DataFrame aggregated at the claim-loss type level with additional filtering applied based on product and detail types relevant for modeling.
    """

    # Define ID features and numeric features
    numeric_features = ["nreq_qty", "clabor_rate", "creq_unit_cost"]
    id_features = list(set(config_file["feature_cols"]) - set(numeric_features))

    # Create a list of aggregation expressions
    agg_exp = [
        (
            spark_max(col).alias(col)
            if agg_func == "max"
            else (
                spark_min(col).alias(col)
                if agg_func == "min"
                else spark_sum(col).alias(col)
                if agg_func == "sum"
                else spark_avg(col)
            )
        ).alias(col)
        for col, agg_func in fe_config["feature_aggregation"].items()
    ]

    # Perform group by and aggregate using the aggregation expressions
    agg_data = df.groupBy(id_features).agg(*agg_exp)

    df_out = agg_data.filter((F.lower("tw_prod_type").isin({"tire", "wheel", "m&b"})))

    return df_out


@timing
def feature_engineering(id_execution: dict, spark: object):
    """Coordinates the entire feature engineering process, transforming raw
    data from the stacking phase into structured features suitable for machine
    learning predictions. This function handles data aggregation, schema
    definition, and interim data storage.

    Args:
        id_execution (dict): Contains identifiers and metadata for tracking the execution context, such as the job run ID and execution date.
        spark (pyspark.sql.SparkSession): Active Spark session to perform data transformations and to read/write interim results.

    Returns:
        None: This function does not return any value; instead, it saves the processed data directly to an external storage system.
    """
    logger.info("** Initializing feature engineering task **")

    # Read output from stacking task:
    input_file_name = interim_tables_config["file_name"]["staking_info"]

    staking_task_output = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=input_file_name,
        spark=spark,
    )

    # Read output from stacking task:
    staking_task_output = staking_task_output.select(config_file["feature_cols"])

    # Aggregate records at claim, loss, dealer level:
    fe_output = aggregate_claims_to_loss_type_level(staking_task_output, spark)
    logger.info("Data aggregated at claim, loss, part, detail type level...")

    # Save interim output to s3:
    file_name_output = interim_tables_config["file_name"]["feature_engineering"]

    save_intermediate_daily_files_s3(
        df=fe_output,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )
