import logging
import warnings
from databricks.sdk.runtime import *

from src.inference_pipeline.tw_price.feature_engineering_task import feature_engineering
from src.inference_pipeline.tw_price.inference_task import inference_task
from src.inference_pipeline.tw_price.staking_info_task import stack_claim_information
from databricks.connect import DatabricksSession
from utils.utils import timing

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Disable warnings during execution
warnings.filterwarnings("ignore")


# Create SparkSession (run locally):
# spark = DatabricksSession.builder.profile('dbc-646f9596-0ef8').getOrCreate()

# Create SparkSession (run on Databricks):
spark = DatabricksSession.builder.getOrCreate()


@timing
def exec_inference_twprice_task(
    api_contract: dict,
    id_execution: dict,
):
    """Orchestrates the execution of the information staking, feature
    engineering, and inference tasks for tire and wheel price predictions. This
    function manages the workflow sequence for processing a claim.

    Args:
        api_contract (dict): Dictionary containing the contract details for which the predictions are to be made.
        id_execution (dict): Dictionary containing metadata such as job run identifiers and execution dates for tracking and logging purposes.

    Returns:
        None: This function does not return any value. It sequentially executes several tasks and manages the overall process.
    """
    logger.info("*** Initializing inference task for T&W engine ***")

    # Parse Json contract with claim and stack key features:
    stack_claim_information(api_contract, id_execution, spark)

    # Calculate on-fly features:
    feature_engineering(id_execution, spark)

    # Pull pre-trained model for MLFlow to generate tire and wheel prediction:
    inference_task(id_execution, spark)
