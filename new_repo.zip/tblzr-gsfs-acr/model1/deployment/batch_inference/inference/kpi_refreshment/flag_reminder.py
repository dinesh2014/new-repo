import logging
import pyspark.sql.functions as F
from pyspark.sql.functions import when, col

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)


# Define the function to create text based on checks, flags, and exception rules
def assign_text_reminder_tw(df):
    """This function is used create the text reminder text to display on the UI
    for TW.

    Args:
        df: dataframe with claim information

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Document flag text format
    flag_texts = {
        "mileage_coverage_check": """concat('The reported mileage of ',
                                            coalesce(cast(iodometer_at_time_of_loss as string), 'NA'),
                                            ' miles ',
                                            case when mileage_coverage_check = 1 then 'exceeds' else 'is within' end,
                                            ' the contract mileage limit of ',
                                            coalesce(cast(icontract_expiration_odometer as string), 'NA'),
                                            ' miles')""",
        "date_coverage_check": """concat(case when date_coverage_check = 1 then 'Exceeds ' else 'Within ' end,
                                         'term by ',
                                         coalesce(cast(days_after_expiration as string), 'NA'),
                                         ' days')""",
        "contract_claim_freq_flag": """concat(coalesce(cast(contract_claim_freq as string), '0'),
                                              ' claims on this contract in last 12 months')""",
        "customer_claim_freq_flag": """concat(coalesce(cast(customer_claim_freq as string), '0'),
                                              ' claims by this customer across contracts in last 12 months')""",
        "post_signature_period_flag": """concat('Contract is ',
                                               coalesce(cast(post_signature_period as string), 'NA'),
                                               ' days old')""",
        "pre_tenure_period_flag": """concat(coalesce(cast(pre_tenure_period as string), 'NA'),
                                            ' days to contract expiration')""",
        "mileage_since_last_time_flag": """concat(coalesce(cast(mileage_since_last_time as string), 'NA'),
                                                  ' miles since last claim')""",
        "creq_total_flag": """concat(case when creq_total_flag = 1 then 'High ' else 'Typical ' end,
                                 'total claim amount')""",
        "dealer_claim_to_contract_ratio_flag": """concat(case when dealer_claim_to_contract_ratio_flag=1 then 'Heightened claims submitted to contracts earned ratio in the last 1 year' else '' end)""",
        "dealer_avg_payout_per_claim_flag": """concat(case when dealer_avg_payout_per_claim_flag=1 then 'Dealer cost per T&W repair is above average' else '' end)""",
        "dealer_issue_repair_freq_flag": """concat(case when dealer_issue_repair_freq_flag =1 then 'Heightened failure rate at the dealer location' else  '' end)""",
        "mb_prediction_flag": """concat(case when mb_prediction_flag=1 then 'M&B menu pricing billed exceeds historical average: Validate menu pricing is being applied.' else '' end)""",
        "mb_deviation_flag": """concat(case when mb_deviation_flag=1 then 'M&B menu pricing as deviation is observed from industry benchmark data' else '' end)""",
        "nb_parts_flag": """concat(case when nb_parts_flag=1 then 'Number of parts billed is high compared to historical number of parts requested' else '' end)""",
        "part_req_total_flag": """concat(case when part_req_total_flag=1 then 'Total cost of parts billed is high compared to historical cost of parts requested ' else '' end)""",
        "part_price_prediction_flag": """concat(case when part_price_prediction_flag=1 then 'Validate part pricing as variation is observed from historical data' else '' end)""",
        "part_price_deviation_flag": """concat(case when part_price_deviation_flag=1 then 'Validate part pricing as deviation is observed from industry benchmark data' else '' end)""",
        "part_individual_count_flag": """concat(case when part_individual_count_flag=1 then 'Review necessity of requested part quantity for the repair' else '' end)""",
        # Adding reminder flags for those at claim level:
        "part_req_total_cost_flag_claim_level": """concat('Total cost of parts billed is ',
                      case when part_req_total_cost_flag_claim_level=1 then 'high.Validate all parts being requested are required for the needed repair' else 'typical' end
                      )
            """,
        "part_individual_qty_flag_claim_level": """concat(case when part_individual_qty_flag_claim_level=1 then 'Review necessity of all requested parts' else 'Parts likely necessary' end,
                ' for the repair')""",
        "unique_part_count_flag_claim_level": """concat('Number of parts billed is ',
                      case when unique_part_count_flag_claim_level=1 then 'high. Validate all parts being requested are required for the needed repair' else 'typical' end
                      )
            """,
        "dealer_claim_to_contract_ratio_flag_claim_level": """concat(case when dealer_claim_to_contract_ratio_flag_claim_level=1 then 'Heightened' else 'Typical' end,
                ' claims submitted to contracts earned ratio in the last 1 year')""",
        "dealer_avg_payout_per_claim_flag_claim_level": """concat('Dealer cost per T&W repair is ',
                                                  case when dealer_avg_payout_per_claim_flag_claim_level=1 then 'above average' else 'typical' end)""",
        "dealer_issue_repair_freq_flag_claim_level": """concat(case when dealer_issue_repair_freq_flag_claim_level =1 then 'Heightened' else 'Typical' end,
                                               ' failure rate at the dealer location')""",
        "part_price_deviation_flag_claim_level": """concat(case when part_price_deviation_flag_claim_level=1 then 'Validate part pricing as deviation is observed from ' else 'Typical tire or wheel pricing based on' end,
                                           ' industry benchmark data')""",
        "mb_prediction_flag_claim_level": """concat(case when mb_prediction_flag_claim_level=1 then 'M&B menu pricing billed exceeds historical average: Validate ' else 'M&B menu pricing billed within historical average, ' end,
                                           'menu pricing is being applied.')""",
        "mb_deviation_flag_claim_level": """concat(case when mb_deviation_flag_claim_level=1 then 'M&B menu pricing as deviation is observed from' else 'Typical part pricing based on' end,
                                          ' industry benchmark data')""",
        "part_price_prediction_flag_claim_level": """concat(case when part_price_prediction_flag_claim_level=1 then 'Validate part pricing as variation is observed from' else 'Typical part pricing based on' end,
                                          ' historical data')""",
    }

    # Use selectExpr to batch apply transformations and reduce logical plan complexity
    select_expr = ["*"]  # include all original columns
    select_expr += [
        f"{text_template} AS {old_col}_text"
        for old_col, text_template in flag_texts.items()
    ]
    # Apply all transformations at once
    df = df.selectExpr(select_expr)

    # Add additional placeholder columns
    df = (
        df.withColumn("breakdown_propensity_flag_text", F.lit(None).cast("string"))
        .withColumn("claim_per_msrp_flag_text", F.lit(None).cast("string"))
        .withColumn("labor_hours_prediction_flag_text", F.lit(None).cast("string"))
        .withColumn("labor_per_part_cost_flag_text", F.lit(None).cast("string"))
        .withColumn("labor_rate_deviation_flag_text", F.lit(None).cast("string"))
        .withColumn("labor_rate_variation_flag_text", F.lit(None).cast("string"))
        .withColumn("part_price_variation_flag_text", F.lit(None).cast("string"))
        .withColumn("requester_state_flag_text", F.lit(None).cast("string"))
        .withColumn(
            "labor_to_part_cost_ratio_flag_claim_level_text", F.lit(None).cast("string")
        )
        .withColumn(
            "labor_hours_prediction_flag_claim_level_text", F.lit(None).cast("string")
        )
        .withColumn(
            "labor_rate_deviation_flag_claim_level_text", F.lit(None).cast("string")
        )
        .withColumn(
            "labor_rate_variation_flag_claim_level_text", F.lit(None).cast("string")
        )
        .withColumn(
            "part_price_variation_flag_claim_level_text", F.lit(None).cast("string")
        )
    )

    logger.info("Text reminder is generated for flags and checks")
    return df


def assign_text_reminder(df):
    """This function is used create the text reminder text to display on the UI
    for VSC.

    Args:
        df: dataframe with claim information

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Document flag text format
    flag_texts = {
        "mileage_coverage_check": """concat('The reported mileage of ',
                                            coalesce(cast(iodometer_at_time_of_loss as string), 'NA'),
                                            ' miles ',
                                            case when mileage_coverage_check = 1 then 'exceeds' else 'is within' end,
                                            ' the contract mileage limit of ',
                                            coalesce(cast(icontract_expiration_odometer as string), 'NA'),
                                            ' miles')""",
        "date_coverage_check": """
                concat(
                    case
                        when date_coverage_check = 1
                        then concat('Exceeds ', coalesce(cast(days_after_expiration as string), 'NA'), ' days')
                        else 'Within contract term'
                    end
                )
            """,
        "contract_claim_freq_flag": """concat(coalesce(cast(contract_claim_freq as string), '0'),
                                              ' claims on this contract in last 12 months')""",
        "customer_claim_freq_flag": """concat(coalesce(cast(customer_claim_freq as string), '0'),
                                              ' claims by this customer across contracts in last 12 months')""",
        "post_signature_period_flag": """concat('Contract is ',
                                               coalesce(cast(post_signature_period as string), 'NA'),
                                               ' days old')""",
        "pre_tenure_period_flag": """concat(coalesce(cast(pre_tenure_period as string), 'NA'),
                                            ' days to contract expiration')""",
        "mileage_since_last_time_flag": """concat(coalesce(cast(mileage_since_last_time as string), 'NA'),
                                                  ' miles since last claim')""",
        "dealer_claim_to_contract_ratio_flag": """concat(case when dealer_claim_to_contract_ratio_flag=1 then 'Heightened claims submitted to contracts earned ratio in the last 1 year' else '' end)""",
        "dealer_avg_payout_per_claim_flag": """concat(case when dealer_avg_payout_per_claim_flag=1 then 'Cost Per Vehicle Repairs (CPVR) is above average' else '' end)""",
        "requester_state_flag": """concat('Review of the dealer''s location is ',
                                          case when requester_state_flag =1 then 'suggested' else 'not required' end)""",
        "claim_per_msrp_flag": """concat(case when claim_per_msrp_flag=1 then 'High' else 'Typical' end,
                                     ' historical claims payout on this contract based on % of MSRP')""",
        "creq_total_flag": """concat(case when creq_total_flag = 1 then 'High ' else 'Typical ' end,
                                 'total claim amount')""",
        "dealer_issue_repair_freq_flag": """concat(case when dealer_issue_repair_freq_flag =1 then 'Heightened claim submission error rate' else '' end)""",
        "breakdown_propensity_flag": """concat(case when breakdown_propensity_flag = 1 then 'Breakdown propensity is likely low' else '' end)""",
        "labor_hours_prediction_flag": """concat(case when labor_hours_prediction_flag=1 then 'Labor hours billed exceeds historical average: Validate source of labor and time requested' else '' end)""",
        "labor_per_part_cost_flag": """concat(case when labor_per_part_cost_flag=1 then 'Labor to part cost ratio billed exceeds historical average' else '' end)""",
        "labor_rate_variation_flag": """concat(case when labor_rate_variation_flag=1 then 'Labor rate requested exceeds historical data' else '' end)""",
        "labor_rate_deviation_flag": """concat(case when labor_rate_deviation_flag=1 then 'Labor rate requested exceeds market guidelines' else '' end)""",
        "nb_parts_flag": """concat(case when nb_parts_flag=1 then 'Number of parts billed is high compared to historical number of parts requested' else '' end)""",
        "part_req_total_flag": """concat(case when part_req_total_flag=1 then 'Total cost of parts billed is high compared to historical cost of parts requested ' else '' end)""",
        "part_price_variation_flag": """concat(case when part_price_variation_flag=1 then 'Validate parts pricing variation from historical data' else '' end)""",
        "part_price_deviation_flag": """concat(case when part_price_deviation_flag=1 then 'Validate parts pricing and check for markup or handling fees based on industry benchmark data' else '' end)""",
        "part_individual_count_flag": """concat(case when part_individual_count_flag=1 then 'Review necessity of requested part quantity for the repair' else '' end)""",
        # Adding text reminder for claim level flags:
        "breakdown_propensity_flag_claim_level": """concat('Breakdown propensity is ',
                                           case when breakdown_propensity_flag_claim_level = 1 then 'likely low' else 'typical' end)""",
        "labor_to_part_cost_ratio_flag_claim_level": """concat(case when labor_to_part_cost_ratio_flag_claim_level=1 then 'Labor to part cost ratio billed exceeds historical average: Validate' else 'Labor to part cost ratio billed within historical average: No action suggested on' end,
                                                     ' source of labor and time requested')""",
        "part_req_total_cost_flag_claim_level": """concat('Total cost of parts billed is ',
                      case when part_req_total_cost_flag_claim_level=1 then 'high.Validate all parts being requested are required for the needed repair' else 'typical' end
                      )
            """,
        "part_individual_qty_flag_claim_level": """concat(case when part_individual_qty_flag_claim_level=1 then 'Review necessity of all requested parts' else 'Parts likely necessary' end,
                    ' for the repair')""",
        "unique_part_count_flag_claim_level": """concat('Number of parts billed is ',
                      case when unique_part_count_flag_claim_level=1 then 'high. Validate all parts being requested are required for the needed repair' else 'typical' end
                      )
            """,
        "dealer_claim_to_contract_ratio_flag_claim_level": """concat(case when dealer_claim_to_contract_ratio_flag_claim_level=1 then 'Heightened' else 'Typical' end,
                    ' claims submitted to contracts earned ratio in the last 1 year')""",
        "dealer_avg_payout_per_claim_flag_claim_level": """concat('Cost Per Vehicle Repairs (CPVR) is ',
                                                  case when dealer_avg_payout_per_claim_flag_claim_level=1 then 'above average' else 'typical' end)""",
        "dealer_issue_repair_freq_flag_claim_level": """concat(case when dealer_issue_repair_freq_flag_claim_level =1 then 'Heightened ' else 'Typical ' end,
                                               'claim submission error rate')""",
        "labor_hours_prediction_flag_claim_level": """concat(case when labor_hours_prediction_flag_claim_level=1 then 'Labor hours billed exceeds historical average: Validate' else 'Labor hours billed within historical average: No action suggested on' end,
                                              ' source of labor and time requested')""",
        "labor_rate_deviation_flag_claim_level": """concat('Labor rate requested ',
                                           case when labor_rate_deviation_flag_claim_level=1 then 'exceeds' else 'falls within' end,
                                           ' market guidelines')""",
        "labor_rate_variation_flag_claim_level": """concat('Labor rate requested ',
                                           case when labor_rate_variation_flag_claim_level=1 then 'exceeds' else 'falls within' end,
                                           ' historical data')""",
        "part_price_deviation_flag_claim_level": """concat(case when part_price_deviation_flag_claim_level=1 then 'Validate parts pricing and check for markup or handling fees' else 'Typical parts pricing' end,
                                           ' based on industry benchmark data')""",
        "part_price_variation_flag_claim_level": """concat(case when part_price_variation_flag_claim_level=1 then 'Validate' else 'Typical' end,
                                          ' parts pricing variation from historical data')""",
    }

    # Use selectExpr to batch apply transformations and reduce logical plan complexity
    select_expr = ["*"]  # include all original columns
    select_expr += [
        f"{text_template} AS {old_col}_text"
        for old_col, text_template in flag_texts.items()
    ]
    # Apply all transformations at once
    df = df.selectExpr(select_expr)

    logger.info("Text reminder is generated for flags and checks")
    return df


def add_exception_reminder(df_input):
    """This function is used create the text exception reminder text to display
    on the UI.

    Args:
        df_input: dataframe with claim information

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    reminder_dict = {
        "do_dealer_claim_flag": "DO Dealer Claim: This claim is from a DO dealer that may exceed the payout threshold",
        "triton_flag": "Triton Dealer identified: Requires special handling",
        "30days_at_selling_dealer_flag": "Early claim at Selling Dealer: Claims within 30 days of contract start are eligible for 75% payout",
        "limited_warranty_flag": "Limited Warranty claim check: Must return to selling dealer for repairs",
        "rob_otto_claim_flag": "High-value claim notification: Claims over $3000 require team lead notification prior to approval",
        "warranty_limit_flag": "Limit of Liability reached: Total payout of claims meets or exceeds maximum coverage amount",
    }

    excp_ls = list(reminder_dict.keys())

    # select columns needed
    df = df_input.select(["sclaim_number", "scontract_no"] + excp_ls)

    # Group and aggregate data
    df_agg = df.groupBy("sclaim_number", "scontract_no").agg(
        *[F.max(col(column)).alias(column) for column in excp_ls]
    )
    df_agg.persist()
    df_agg.count()

    # Assign text based on each flag, exception rule
    for flag, reminder in reminder_dict.items():
        df_agg = df_agg.withColumn(
            flag + "_text", when(col(flag) > 0, F.lit(reminder)).otherwise(None)
        )

    # Select required columns only once to minimize transformations
    required_columns = ["sclaim_number", "scontract_no"] + [
        flag + "_text" for flag in excp_ls
    ]
    df_out = df_agg.select(*required_columns)

    return df_out
