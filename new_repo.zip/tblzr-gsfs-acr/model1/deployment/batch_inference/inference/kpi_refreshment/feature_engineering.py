import logging
import pyspark.sql.functions as F
from pyspark.sql.functions import col, when, datediff
from configs.config import BaseConfig
from utils.utils import (
    read_parquet,
    generate_threshold_flag_greater,
    generate_threshold_flag_smaller,
    format_contract_sdf,
    timing,
)

from src.inference_pipeline.breakdown.staking_info_task import retrieve_api_contract
from pyspark.sql.types import FloatType

from databricks.connect import DatabricksSession
from datetime import datetime

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Create SparkSession
spark = DatabricksSession.builder.getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", 1)

# Loading config file
config_file = BaseConfig.KPI_REFRESHMENT_CONFIG
set_up_config = config_file["set_up_configuration"]
data_sources = set_up_config["data_sources"]

input_folder = data_sources["input_folder"]
raw_input_folder = data_sources["raw_input_folder"]
input_tables = data_sources["input_tables"]
json_path = input_tables["json_path"]
output_folder = data_sources["output_folder"]
output_tables = data_sources["output_tables"]

# Get params
# Get benchmarks and thresholds from config
benchmark = config_file["benchmark"]
selected_cols = config_file["selected_cols"]
customer_level = selected_cols["customer_level"]
initial_cols = selected_cols["initial_cols"]
contract_cols = selected_cols["contract_cols"]
contract_precomp_cols = selected_cols["contract_precomp_cols"]
dealer_precomp_cols = selected_cols["dealer_precomp_cols"]
customer_precomp_cols = selected_cols["customer_precomp_cols"]
dealer_issue_precomp_cols = selected_cols["dealer_issue_precomp_cols"]
today_date = datetime.now().strftime("%Y-%m-%d")


def get_claim_loss_part_base(df, prod):
    """This function is used to get claim + loss code level base.

    Args:
        df: spark dataframe with TW model results

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if prod == "tw":
        initial_cols_use = list(initial_cols) + ["is_tec"]
    else:
        initial_cols_use = list(initial_cols)

    df_base = df.select(initial_cols_use).dropDuplicates(
        subset=["sclaim_number", "sloss_code", "spart_no"]
    )

    return df_base


def get_vin_info(df, df_contract_car_config):
    """This function is used to get vin information from preloaded tables.

    Args:
        df: spark dataframe with TW model results
        df_contract_car_config: preloaded table with vin info

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Load contract car configuration pre_comp table

    # Filter on the contracts in payload
    df_out = df.join(df_contract_car_config, on=["scontract_no"], how="left")
    return df_out


def get_claim_cost_kpis(df_base, df, prod, benchmark):
    """This function is used to calculate different sums of total cost, labor
    cost and part cost at claim loss code.

    Args:
        df_base: base df with claim level details
        df: df with aggregated metrics to compute
        prod: prod time (TW /VSC)
        benchmark: Threshold

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_aggregated = df.groupBy("sclaim_number", "sloss_code").agg(
        F.expr(
            "count(distinct case when sdetail_type like '%P%' then spart_no else null end) as nb_parts"
        ),
        F.expr(
            "sum(case when sdetail_type == 'P' then cext_total_amt else 0 end) as part_req_total"
        ),
        F.expr(
            "sum(case when sdetail_type == 'L' then cext_total_amt else 0 end) as labor_req_total"
        ),
    )

    # Merge
    df_out = df_base.join(df_aggregated, on=["sclaim_number", "sloss_code"], how="left")

    # get req_total
    df_req_total = df.groupBy("sclaim_number").agg(
        F.sum("cext_total_amt").alias("creq_total")
    )
    df_out = df_out.join(df_req_total, on=["sclaim_number"], how="left")

    # Calculate metrics
    df_out = df_out.withColumn(
        "labor_per_part_cost", col("labor_req_total") / col("part_req_total")
    )

    # Generate KPIs and thresholds
    df_out = generate_threshold_flag_greater(
        df_out, "creq_total", benchmark["financial_risk"]["creq_total"]
    )

    if prod == "tw":
        df_out = df_out.withColumn(
            "labor_per_part_cost_flag", F.lit(2)
        ).withColumn(  # not enough information for labor per part cost
            "labor_per_part_cost_threshold", F.lit(None).cast(FloatType())
        )  # no threshold exists

    else:
        df_out = generate_threshold_flag_greater(
            df_out,
            "labor_per_part_cost",
            benchmark["financial_risk"]["labor_per_part_cost"],
        )

    return df_out


def get_make_issue_loss(df, df_make_issue_benchmark_precomp, benchmark):
    """This function is used to calculate metrics at make-issue-loss_code
    level.

    Args:
        df: base df with claim level details
        df_make_issue_benchmark_precomp: df with aggregated metrics to compute
        benchmark: Threshold

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Load pre-compute make + issue type benchmark/threshold information

    df_out = df
    bound = benchmark["bound"]

    # Merge part threshold in
    df_out = df_out.join(
        df_make_issue_benchmark_precomp, on=["smake", "sloss_code"], how="left"
    )

    # nb_parts_flag Threshold
    df_out = df_out.withColumn(
        "nb_parts_flag",
        when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["nb_parts"]))
            & (col("nb_parts") > col("nb_parts_threshold")),
            1,
        )
        .when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["nb_parts"]))
            & (col("nb_parts") <= col("nb_parts_threshold")),
            0,
        )
        .otherwise(2),
    )

    # part_req_total_flag Threshold
    df_out = df_out.withColumn(
        "part_req_total_flag",
        when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["part_req_total"]))
            & (col("part_req_total") > col("part_req_total_threshold")),
            1,
        )
        .when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["part_req_total"]))
            & (col("part_req_total") <= col("part_req_total_threshold")),
            0,
        )
        .otherwise(2),
    )

    return df_out


def get_contract_kpis(df):
    """This function is used to bring in metrics from contract table.

    Args:
        df: base df with claim level details

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_out = df
    # Add new columns with conditional logic
    df_out = (
        df_out.withColumn(
            "mileage_coverage_check",
            when(
                col("iodometer_at_time_of_loss") > col("icontract_expiration_odometer"),
                1,
            ).otherwise(0),
        )
        .withColumn(
            "miles_to_expiration",
            col("icontract_expiration_odometer") - col("iodometer_at_time_of_loss"),
        )
        .withColumn(
            "date_coverage_check",
            when(
                col("dtdate_loss_occurred") > col("dtcontract_expiration"), 1
            ).otherwise(0),
        )
        .withColumn(
            "miles_since_sales",
            col("iodometer_at_time_of_loss") - col("icontract_sale_odometer"),
        )
        .withColumn(
            "days_since_sales",
            F.datediff(col("dtdate_loss_occurred"), col("dtcontract_sale_date")),
        )
    )

    df_out = df_out.withColumn(
        "days_after_expiration",
        when(
            F.datediff(col("dtdate_loss_occurred"), col("dtcontract_expiration")) > 0,
            F.datediff(col("dtdate_loss_occurred"), col("dtcontract_expiration")),
        ).otherwise(None),
    )

    return df_out


def get_contract_precal_kpis(df, prod, benchmark):
    """This function is used to bring in metrics from precomputed contract
    tables.

    Args:
        df: base df with claim level details
        prod: product type
        benchmark: boundary for flagging a claim

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_out = df

    # Calculate mileage since last time
    df_out = df_out.withColumn(
        "mileage_since_last_time",
        col("iodometer_at_time_of_loss") - col("latest_mileage_at_loss"),
    )

    df_out = df_out.withColumn(
        "claim_per_msrp",
        col("contract_prev_claim_payout") / col("cvehicle_purchase_price"),
    )

    df_out = df_out.withColumn(
        "req_total_vs_sales", col("creq_total") / col("cvehicle_purchase_price")
    )

    df_out = df_out.na.fill({"contract_prev_claim_payout": 0})
    df_out = df_out.withColumn(
        "remaining_limit",
        col("cvehicle_purchase_price") - col("contract_prev_claim_payout"),
    )

    # Rename column name for clarity
    df_out = df_out.withColumnRenamed(
        "contract_prev_paid_claims_cnt", "contract_claim_freq"
    )

    # Generate flag based on threshold
    df_out = generate_threshold_flag_smaller(
        df_out,
        "mileage_since_last_time",
        benchmark["client_risk"]["mileage_since_last_time"],
    )
    if prod == "tw":
        df_out = df_out.withColumn(
            "claim_per_msrp_threshold", F.lit(None).cast(FloatType())
        ).withColumn("claim_per_msrp_flag", F.lit(2))  ## not enough information
    else:
        df_out = generate_threshold_flag_greater(
            df_out, "claim_per_msrp", benchmark["financial_risk"]["claim_per_msrp"]
        )

    # Generate another flag based on threshold
    df_out = generate_threshold_flag_greater(
        df_out, "contract_claim_freq", benchmark["client_risk"]["contract_claim_freq"]
    )

    return df_out


def get_customer_claim_freq(df, df_customer, benchmark):
    """This function is used to bring in metrics from precomputed customer
    tables.

    Args:
        df: base df with claim level details
        df_customer: dataframe with customer details
        benchmark: boundary for flagging a claim

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_out = df.join(df_customer, on=customer_level, how="left")

    # Rename column name
    df_out = df_out.withColumnRenamed(
        "customer_prev_paid_claims_cnt", "customer_claim_freq"
    )

    # Generate flag based on threshold
    df_out = generate_threshold_flag_greater(
        df_out, "customer_claim_freq", benchmark["client_risk"]["customer_claim_freq"]
    )

    return df_out


def get_contract_claim_date_range(df_input, benchmark):
    """This function is used to bring in contract claim date range flags.

    Args:
        df_input: base df with claim level details
        benchmark: boundary for flagging a claim

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Load input daraframe
    df_out = df_input
    # Calculate date differences in days
    df_out = df_out.withColumn(
        "post_signature_period",
        datediff(col("dtdate_loss_occurred"), col("dtcontract_effect")),
    ).withColumn(
        "pre_tenure_period",
        datediff(col("dtcontract_expiration"), col("dtdate_loss_occurred")),
    )

    # Generate flags based on thresholds
    df_out = generate_threshold_flag_smaller(
        df_out,
        "post_signature_period",
        benchmark["client_risk"]["post_signature_period"],
    )

    df_out = generate_threshold_flag_smaller(
        df_out, "pre_tenure_period", benchmark["client_risk"]["pre_tenure_period"]
    )

    return df_out


def get_dealer_precal_kpis(df, df_dealer, benchmark):
    """Process dealer data and compute metrics based on precomputed dealer
    data.

    Parameters:
    df (DataFrame): DataFrame containing the original dealer data.
    df_dealer_precomp (DataFrame): DataFrame with precomputed dealer metrics.
    benchmark (dict): Dictionary containing threshold values for metrics.

    Returns:
    DataFrame: A DataFrame with dealer metrics and computed flags.
    """
    df_out = df.join(df_dealer, on=["spayee_no"], how="left")

    # Generate flags based on thresholds from a benchmark dictionary

    df_out = generate_threshold_flag_greater(
        df_out,
        "dealer_claim_to_contract_ratio",
        benchmark["requestor_risk"]["dealer_claim_to_contract_ratio"],
    )

    df_out = generate_threshold_flag_greater(
        df_out,
        "dealer_avg_payout_per_claim",
        benchmark["requestor_risk"]["dealer_avg_payout_per_claim"],
    )

    return df_out


def get_requester_state_flag(df, df_state_precomp=None):
    """This function is used to map those states from dealers to flab.

    Args:
        df: base df with claim level details
        df_state_precomp: define if bring states from pre-compute tables

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # This function is used to load requester state lists and calculate flags

    if df_state_precomp is None:
        # Load requester state list
        df_state_precomp = read_parquet(input_folder + input_tables["state_precomp"])

    df_out = df
    # Collect unique states into a list for later checking
    df_out = df_out.join(df_state_precomp, "spayee_state", how="left")

    return df_out


# Calculate repair freq at dealer + issue code level
def get_repair_freq(df, df_dealer_issue_precomp, benchmark):
    """This function is used to bring in dealer repair frequency flags at
    dealer + issue type level.

    Args:
        df: base df with claim level details
        df_dealer_issue_precomp: precomputed table
        benchmark: boundary for flag logic

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Bring in dealer + issue type level pre-computed metrics
    threshold_percentile = benchmark["requestor_risk"]["dealer_issue_repair_freq"]

    # Merge precomp with API contract
    df_out = df.join(
        df_dealer_issue_precomp, on=["spayee_no", "sloss_code"], how="left"
    )
    # Generate dynamic benchmark based on historical volume
    # Calculate flag based on thresholds
    df_out = df_out.withColumn(
        "dealer_issue_repair_freq_threshold",
        F.lit(col(f"dealer_issue_repair_freq_{threshold_percentile}")),
    )

    bound = benchmark["bound"]["dealer_issue_repair_freq"]

    # Generate flag
    df_out = df_out.withColumn(
        "dealer_issue_repair_freq_flag",
        when(
            (col("dealer_issue_prev_paid_claims_cnt") > F.lit(bound))
            & (
                col("dealer_issue_repair_freq")
                > col("dealer_issue_repair_freq_threshold")
            ),
            1,
        )
        .when(
            (col("dealer_issue_prev_paid_claims_cnt") > F.lit(bound))
            & (
                col("dealer_issue_repair_freq")
                <= col("dealer_issue_repair_freq_threshold")
            ),
            0,
        )
        .otherwise(2),
    )
    # Generate output
    df_out = df_out.drop(f"dealer_issue_repair_freq_{threshold_percentile}")

    return df_out


def get_part_individual_kpis(df_prior, df):
    """This function is used to load part individual data and calculate metrics
    at parts + make + issue type level.

    Args:
        df_prior: precomputed table
        df: base dataframe

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Define granularity level
    grp_level = [
        "sclaim_number",
        "spart_no",
        "smake",
        "sloss_code",
        "smanufacturer_code",
    ]

    # Select granularity level information from API contract master table

    df_out = (
        df.select(["sdetail_type", "nreq_qty", "creq_unit_cost"] + grp_level)
        .filter(col("sdetail_type").contains("P"))
        .groupby(grp_level)
        .agg(
            F.sum(col("nreq_qty")).alias("part_individual_count"),
            F.max(col("creq_unit_cost")).alias("part_price"),
        )
    )

    df_out = df_prior.join(df_out, on=grp_level, how="left")

    return df_out


def get_part_individual_flag(df_prior, benchmark):
    """This function is used to calculate part level individual metrics and
    compare against part + make + issue level thresholds.

    Args:
        df_prior: precomputed table
        benchmark: boundary for flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Bring in threshold/benchmark
    benchmark_qty = benchmark["financial_risk"]["part_individual_count"]

    # Start defining flags:
    df_out = df_prior.withColumn(
        "part_individual_count_threshold", F.lit(int(benchmark_qty))
    )
    df_out = df_out.withColumn(
        "part_individual_count_flag",
        when(
            (col("part_individual_count") > col("part_individual_count_threshold")),
            1,
        )
        .when(
            (col("part_individual_count") <= col("part_individual_count_threshold")),
            0,
        )
        .otherwise(2),
    )

    return df_out


def get_part_price_variation_kpis(df_prior, df_part_price_variation_precomp, benchmark):
    """This function is used to load part individual data and calculate part
    price variation metrics.

    Args:
        df_prior: precomputed table
        df_part_price_variation_precomp: preloaded table with variation info
        benchmark: boundary for flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Merge in part price variation historical median
    df_out = df_prior.join(
        df_part_price_variation_precomp,
        on=["smake", "sloss_code", "spart_no"],
        how="left",
    )

    # Create flags for part price variation
    df_out = df_out.withColumn(
        "part_price_variation_benchmark", col("median_part_price")
    ).withColumn(
        "part_price_variation",
        (col("part_price") - col("median_part_price")) / col("median_part_price"),
    )
    threshold_var = benchmark["financial_risk"]["part_price_variation"]
    df_out = df_out.withColumn(
        "part_price_variation_threshold", F.lit(threshold_var)
    ).withColumn(
        "part_price_variation_flag",
        when(
            (col("part_price_variation") > F.lit(threshold_var))
            & (col("part_price") > 10),
            1,
        ).otherwise(0),
    )

    return df_out


def get_part_price_deviation_kpis(
    df_prior, df_part_price_deviation_precomp, prod, benchmark
):
    """This function is used to load part individual data and calculate part
    price deviation.

    Args:
        df_prior: precomputed table
        df_part_price_deviation_precomp: preloaded table with variation info
        prod: product type
        benchmark: boundary for flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if prod == "tw":
        #########################################################
        # [Start] Temporal solution for mapping forte variation:
        #########################################################

        # Create an upper case cols for base df:
        df_prior = df_prior.withColumn("spart_no_upper", F.upper(df_prior["spart_no"]))

        # Create an upper case cols for precomp df:
        df_part_price_deviation_precomp = df_part_price_deviation_precomp.withColumn(
            "spart_no_upper", F.upper(df_part_price_deviation_precomp["spart_no"])
        )

        # merge actr with col to use:
        cols_to_select_deviation_precomp = [
            "spart_no_upper",
            "tw_prod_type",
            "cdealer_cost",
            "cretail_cost",
        ]

        df_out = df_prior.join(
            df_part_price_deviation_precomp.select(cols_to_select_deviation_precomp),
            on=["spart_no_upper"],
            how="left",
        )

        # remove temporal column:
        df_out.drop(*["spart_no_upper"])

        #########################################################
        # [End] Temporal solution for mapping forte variation:
        #########################################################

        # Create flags for part price deviation
        threshold_tire = float(
            benchmark["financial_risk"]["part_price_deviation"]["tec"]["tire"]
        )
        threshold_wheel = float(
            benchmark["financial_risk"]["part_price_deviation"]["tec"]["wheel"]
        )

        df_out = (
            df_out.withColumn(
                "part_price_deviation_benchmark",
                when(
                    (col("is_tec") == 1) & (col("tw_prod_type") == "tire"),
                    col("cdealer_cost"),
                ).otherwise(
                    when(
                        (col("is_tec") == 1) & (col("tw_prod_type") == "wheel"),
                        col("cdealer_cost"),
                    ).otherwise(col("cretail_cost"))
                ),
            )
            .withColumn(
                "part_price_deviation",
                (col("part_price") - col("part_price_deviation_benchmark"))
                / col("part_price_deviation_benchmark"),
            )
            .withColumn(
                "part_price_deviation_threshold",
                when(
                    (col("is_tec") == 1) & (col("tw_prod_type") == "tire"),
                    F.lit(threshold_tire),
                ).otherwise(
                    when(
                        (col("is_tec") == 1) & (col("tw_prod_type") == "wheel"),
                        F.lit(threshold_wheel),
                    ).otherwise(F.lit(0))
                ),
            )
            .withColumn(
                "part_price_deviation_flag",
                when(
                    col("part_price_deviation") > col("part_price_deviation_threshold"),
                    F.lit(1),
                ).otherwise(
                    when(col("part_price_deviation").isNull(), F.lit(2)).otherwise(
                        F.lit(0)
                    )
                ),
            )
        )

    else:
        df_out = df_prior.join(
            df_part_price_deviation_precomp,
            on=["smanufacturer_code", "spart_no"],
            how="left",
        )
        # Create flags for part price deviation
        df_out = df_out.withColumn(
            "part_price_deviation_benchmark", col("cretail_cost")
        ).withColumn(
            "part_price_deviation",
            (col("part_price") - col("cretail_cost")),
        )
        threshold_dev = benchmark["financial_risk"]["part_price_deviation"]
        df_out = df_out.withColumn(
            "part_price_deviation_threshold", F.lit(threshold_dev)
        ).withColumn(
            "part_price_deviation_flag",
            when(col("part_price_deviation") > F.lit(threshold_dev), 1).otherwise(0),
        )

        df_out = df_out.drop("median_part_price", "cretail_cost")
    return df_out


def get_dealer_issue_make_kpis(
    df,
    df_labor_rate_deviation_precomp,
    df_labor_rate_variation_precomp,
    prod,
    benchmark,
):
    """This function is used generate dealer issue make level KPIs.

    Args:
        df: base df where calculations are being added
        df_labor_rate_deviation_precomp: preloaded table with deviation info
        df_labor_rate_variation_precomp: preloaded table with variation info
        prod: product type
        benchmark: boundary for flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if prod == "tw":
        grp_level = ["sclaim_number", "spayee_no", "smake", "sloss_code", "is_tec"]
    else:
        grp_level = ["sclaim_number", "spayee_no", "smake", "sloss_code"]

    # Filtering for detail type 'L' and performing aggregation
    df_out = (
        df.filter(col("sdetail_type").contains("L"))
        .groupby(grp_level + ["spayee_type", "sservice_center_type"])
        .agg(F.max(col("creq_unit_cost")).alias("labor_rate"))
    )

    # Determine 'sparent_type_code' based on service center type or payee type
    df_out = df_out.withColumn(
        "sparent_type_code",
        when(
            (col("sservice_center_type").contains("D"))
            | (col("spayee_type").contains("D")),
            "SLR",
        ).otherwise("SVC"),
    )

    if prod == "tw":
        df_out = (
            df_out.withColumn(
                "mb_deviation_benchmark",
                when(
                    col("is_tec") == 1,
                    F.lit(float(benchmark["financial_risk"]["mb_deviation"])),
                ).otherwise(F.lit(None).cast(FloatType())),
            )
            .withColumn(
                "mb_deviation",
                (col("labor_rate") - col("mb_deviation_benchmark"))
                / col("mb_deviation_benchmark"),
            )
            .withColumn("mb_deviation_threshold", F.lit(0))
            .withColumn(
                "mb_deviation_flag",
                when(col("mb_deviation") > col("mb_deviation_threshold"), 1)
                .when(col("mb_deviation") <= col("mb_deviation_threshold"), 0)
                .otherwise(0),
            )
            .withColumn("labor_rate_variation", F.lit(None).cast(FloatType()))
            .withColumn("labor_rate_variation_flag", F.lit(2))
            .withColumn("labor_rate_variation_benchmark", F.lit(None).cast(FloatType()))
            .withColumn("labor_rate_variation_threshold", F.lit(None).cast(FloatType()))
            .withColumn("labor_rate_deviation", F.lit(None).cast(FloatType()))
            .withColumn("labor_rate_deviation_flag", F.lit(2))
            .withColumn("labor_rate_deviation_benchmark", F.lit(None).cast(FloatType()))
            .withColumn("labor_rate_deviation_threshold", F.lit(None).cast(FloatType()))
        )
    else:
        # Joining with precomputed labor rate deviation
        df_out = df_out.join(
            df_labor_rate_deviation_precomp, ["sparent_type_code", "spayee_no"], "left"
        )

        # Adding benchmark columns for labor rate deviation
        threshold_dev = benchmark["financial_risk"]["labor_rate_deviation"]
        df_out = df_out.withColumn("labor_rate_deviation_benchmark", col("clabor_rate"))
        df_out = df_out.withColumn(
            "labor_rate_deviation_threshold", F.lit(threshold_dev)
        )
        df_out = df_out.withColumn(
            "labor_rate_deviation",
            (col("labor_rate") - col("labor_rate_deviation_benchmark"))
            / col("labor_rate_deviation_benchmark"),
        )
        df_out = df_out.withColumn(
            "labor_rate_deviation_flag",
            (col("labor_rate_deviation") > col("labor_rate_deviation_threshold")).cast(
                "integer"
            ),
        )

        # Join with labor rate variation historical data
        df_out = df_out.join(
            df_labor_rate_variation_precomp,
            ["sloss_code", "smake", "spayee_no"],
            "left",
        )

        # Create flags for labor rate variation
        df_out = df_out.withColumn(
            "labor_rate_variation_benchmark", col("median_labor_rate")
        )
        df_out = df_out.withColumn(
            "labor_rate_variation",
            (col("labor_rate") - col("median_labor_rate")) / col("median_labor_rate"),
        )
        threshold_pct = benchmark["financial_risk"]["labor_rate_variation"]
        df_out = df_out.withColumn(
            "labor_rate_variation_threshold", F.lit(threshold_pct)
        )
        df_out = df_out.withColumn(
            "labor_rate_variation_flag",
            when(col("labor_rate_variation") > F.lit(threshold_pct), 1).otherwise(0),
        )

    # Drop unnecessary columns to clean up the DataFrame
    df_out = df_out.drop(
        "median_labor_rate", "clabor_rate", "sparent_type_code", "is_tec"
    )

    return df_out


def add_mapping(df, df_loss_code_mapping, df_part_no_mapping, prod):
    """This function is used to add mapping between loss code and part no.

    Args:
        df: base df where calculations are being added
        df_loss_code_mapping: preloaded table with deviation info
        df_part_no_mapping: preloaded table with variation info
        prod: product type

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_out = df.join(df_loss_code_mapping, "sloss_code", "left")
    if prod == "tw":
        df_out = df_out.join(df_part_no_mapping, on=["spart_no"], how="left")
    else:
        df_out = df_out.join(df_part_no_mapping, on=["smake", "spart_no"], how="left")
    return df_out


def flag_exception(df_input, df_do=None):
    """This function is used to flag exceptions and coverage based on business
    rules.

    Args:
        df_input: base df where calculations are being added
        df_do: None

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df = df_input
    excep = config_file["coverage_and_exceptions"]

    # Configuration thresholds and lists (these need to be set up in your environment)
    early_contract_threshold = excep["early_contract_threshold"]
    contract_type_ls = excep["limited_warranty_contracts"]
    rob_otto_dealer = excep["rob_otto"]

    # Pay 75% for claims within 30 days if at selling dealer
    df = df.withColumn(
        "30days_at_selling_dealer_flag",
        when(
            (col("post_signature_period") <= early_contract_threshold)
            & (col("spayee_no") == col("sdealer_number")),
            1,
        ).otherwise(0),
    )

    # Special handling for Triton group by looking at last two letters with TP
    df = df.withColumn(
        "triton_flag", when(col("sdealer_number").substr(-2, 2) == "TP", 1).otherwise(0)
    )

    # Limited warranty
    df = df.withColumn(
        "limited_warranty_flag",
        when(col("icontract_type").cast("integer").isin(contract_type_ls), 1).otherwise(
            0
        ),
    )

    # DO dealer claims are following dollar threshold
    if df_do is None:
        df_do = read_parquet(input_folder + input_tables["do_dealer_list"], None)

    df_out = df.join(df_do, "sdealer_number", "left")
    df_out = df_out.withColumn(
        "do_dealer_claim_flag",
        when(
            (col("creq_total") >= col("do_threshold"))
            & (col("do_threshold").isNotNull()),
            1,
        ).otherwise(0),
    )

    df_out = df_out.drop("do_threshold", "icontract_type")

    # Limited warranty limit reach
    df_out = df_out.withColumn(
        "warranty_limit_flag", when(col("claim_per_msrp") > 1, 1).otherwise(0)
    )

    # Rob otto and creq_total > 3000
    df_out = df_out.withColumn(
        "rob_otto_claim_flag",
        when(
            (col("creq_total") >= F.lit(3000))
            & (col("sdealer_number").isin(rob_otto_dealer)),
            1,
        ).otherwise(0),
    )
    return df_out


def output_claim_history(json_contract):
    """This function is used to output the claim history for a given contract.

    Args:
        json_contract: json contract

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Get contract no
    contract_no = json_contract["contract"]["scontract_no"]
    iproduct_type_id = int(json_contract["contract"]["iproduct_type_id"])

    if iproduct_type_id == 8:
        # Filter preloaded claim history table by contract no. It's partitioned by contract no during generation
        df_claim_history = spark.read.table("global_temp.df_claim_history_tw").filter(
            col("scontract_no") == contract_no
        )
    else:
        # Filter preloaded claim history table by contract no. It's partitioned by contract no during generation
        df_claim_history = spark.read.table("global_temp.df_claim_history").filter(
            col("scontract_no") == contract_no
        )

    return df_claim_history


def add_cc_tf(df, df_tech_found=None, df_customer_comp=None):
    """This function is used to add technical found and customer compliant.

    Args:
        df: json contract: base df with claim info
        df_tech_found: binary to do tech comparison
        df_customer_comp: binary to do customer comparison

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if df_tech_found is None:
        df_tech_found = read_parquet(input_folder + input_tables["tech_found"], None)
    if df_customer_comp is None:
        df_customer_comp = read_parquet(
            input_folder + input_tables["customer_comp"], None
        )

    df = df.join(df_tech_found, on=["sclaim_number"], how="left")
    df = df.join(df_customer_comp, on=["sclaim_number"], how="left")
    # Dictionary with column names and their fill values
    fill_values = {
        "tech_found": 0,  # Fill nulls in 'feature1' with 0
        "customer_comp": 0,  # Fill nulls in 'feature2' with 1.0
    }

    # Fill missing values in the specified columns
    df_filled = df.fillna(fill_values)

    return df_filled


def create_base_info(json_contract, run_id, prod):
    """This function is used to create the base info and output intermediate
    file.

    Args:
        json_contract: contract from claim requested
        run_id: unique ID for execution
        prod: product type

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Retrieve api contract
    df = retrieve_api_contract(json_contract, spark)

    # Convert date columns to dt format from payload
    df = format_contract_sdf(df)

    # Bring in master contract car configuration information
    contract_ls = json_contract["contract"]["scontract_no"]
    contract_str = f"'{str(contract_ls)}'"

    if prod == "tw":
        df_contract_car_config = spark.sql(
            f"""SELECT * FROM global_temp.df_contract_car_config_tw WHERE scontract_no IN ({contract_str})"""
        )
    else:
        df_contract_car_config = spark.sql(
            f"""SELECT * FROM global_temp.df_contract_car_config WHERE scontract_no IN ({contract_str})"""
        )

    # Join back. Notice that if T&W, then it has 1 additional column is_Tec to differentiate TEC vs. non-TEC
    df = get_vin_info(df, df_contract_car_config)

    # Save intermediate file to clean up memory
    df.repartition(1).write.mode("overwrite").option("compression", "snappy").parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_base",
    )


def aggregate_base(run_id, prod, benchmark):
    """This function is used to aggregate the base info and output intermediate
    file.

    Args:
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary for flag


    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Load input from last step
    df = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_base"
    )

    # Get base
    df_base = get_claim_loss_part_base(df, prod)

    # Load claim level base information from API contract. This step
    # returns a claim + make + sloss_code level information
    df_w_claim_cost = get_claim_cost_kpis(df_base, df, prod, benchmark)

    # Output intermediate file
    df_w_claim_cost.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/aggregate_base",
    )


def map_contract(run_id, prod, benchmark):
    """This function is used to map the contract info and output intermediate
    file.

    Args:
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary for flag


    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_claim_cost = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/aggregate_base"
    )
    # Add contract related pre-compute
    df_w_contract = get_contract_kpis(df_w_claim_cost)

    # Calculate flags based on contract and claim dates
    df_contract_claim_dates = get_contract_claim_date_range(df_w_contract, benchmark)

    # Calculate flags based on contract level pre-computed metrics
    df_w_precomp_contracts = get_contract_precal_kpis(
        df_contract_claim_dates, prod, benchmark
    )

    # Output intermediate file
    df_w_precomp_contracts.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/map_contract",
    )


def map_customer(json_contract, run_id, prod, benchmark):
    """This function is used to map the contract info and output intermediate
    file.

    Args:
        json_contract: json from claim requested
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary for flag


    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_precomp_contracts = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/map_contract"
    )
    # Calculate flags based on customer level pre-computed metrics
    customer_fname = f" '{json_contract['customer']['scontract_holder_fname']}' "
    customer_lname = f" '{json_contract['customer']['scontract_holder_lname']}' "
    customer_email = f" '{json_contract['customer']['scontract_holder_email']}' "

    if prod == "tw":
        df_customer = spark.sql(
            f"""SELECT * FROM global_temp.df_customer_tw WHERE scontract_holder_fname IN ({customer_fname}) AND scontract_holder_lname IN ({customer_lname}) AND scontract_holder_email IN ({customer_email})"""
        )
    else:
        df_customer = spark.sql(
            f"""SELECT * FROM global_temp.df_customer WHERE scontract_holder_fname IN ({customer_fname}) AND scontract_holder_lname IN ({customer_lname}) AND scontract_holder_email IN ({customer_email})"""
        )

    df_w_customer_precomp = get_customer_claim_freq(
        df_w_precomp_contracts, df_customer, benchmark
    )

    # Output intermediate file
    df_w_customer_precomp.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/df_w_precomp_contracts",
    )


def map_dealer_state(spayee_no, run_id, prod, benchmark):
    """This function is used to map dealer and state info and output
    intermediate file.

    Args:
        spayee_no: dealer number
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary for flag


    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_customer_precomp = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/df_w_precomp_contracts"
    )
    # Calculate flags based on dealer level pre-computed metrics

    dealer_cols = ",".join(dealer_precomp_cols)
    if prod == "tw":
        df_dealer = spark.sql(
            f"""SELECT {dealer_cols} FROM global_temp.df_dealer_tw WHERE spayee_no IN ({spayee_no})"""
        )
    else:
        df_dealer = spark.sql(
            f"""SELECT {dealer_cols} FROM global_temp.df_dealer WHERE spayee_no IN ({spayee_no})"""
        )

    df_w_dealer_precomp = get_dealer_precal_kpis(
        df_w_customer_precomp, df_dealer, benchmark
    )

    # Calculate flags based on requester states
    if prod == "tw":
        df_state_precomp = spark.sql("SELECT * FROM global_temp.df_state_precomp_tw")
    else:
        df_state_precomp = spark.sql("SELECT * FROM global_temp.df_state_precomp")

    df_w_requester_state = get_requester_state_flag(
        df_w_dealer_precomp, df_state_precomp
    )

    # Output intermediate file
    df_w_requester_state.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/dealer_state",
    )


def map_dealer_issue(sloss_code, spayee_no, run_id, prod, benchmark):
    """This function is used to map dealer and issue info and output
    intermediate file.

    Args:
        sloss_code: loss code
        spayee_no: dealer number
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary for flag


    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_requester_state = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/dealer_state"
    )

    # Calculate flags based on dealer + issue type level pre-computed metrics
    threshold_percentile = benchmark["requestor_risk"]["dealer_issue_repair_freq"]
    filtered_cols = ",".join(
        dealer_issue_precomp_cols + [f"dealer_issue_repair_freq_{threshold_percentile}"]
    )

    if prod == "tw":
        df_dealer_issue_precomp = spark.sql(
            f"""SELECT {filtered_cols} FROM global_temp.df_dealer_issue_precomp_tw WHERE sloss_code IN ({sloss_code}) AND spayee_no IN ({spayee_no})"""
        )
    else:
        df_dealer_issue_precomp = spark.sql(
            f"""SELECT {filtered_cols} FROM global_temp.df_dealer_issue_precomp WHERE sloss_code IN ({sloss_code}) AND spayee_no IN ({spayee_no})"""
        )

    df_w_repairs = get_repair_freq(
        df_w_requester_state, df_dealer_issue_precomp, benchmark
    )

    # output intermediate file
    df_w_repairs.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/df_w_repairs",
    )


def map_dealer_repair(sloss_code, run_id, prod, benchmark):
    """This function is used map dealer and repair information and output
    intermediate file.

    Args:
        sloss_code: loss code
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary for flag


    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_repairs = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/df_w_repairs"
    )
    # Add make issue loss
    # Get precomp labor cost benchmark
    threhsold_benchmark = benchmark["financial_risk"]["part_req_total"]
    threhsold_benchmark2 = benchmark["financial_risk"]["nb_parts"]
    filtered_cols = ",".join(
        [
            "smake",
            "sloss_code",
            f"nb_parts_{threhsold_benchmark2}  nb_parts_threshold",
            f"part_req_total_{threhsold_benchmark}  part_req_total_threshold",
            "make_issue_prev_paid_claims_cnt",
        ]
    )

    if prod == "tw":
        df_make_issue_benchmark_precomp = spark.sql(
            f"""SELECT {filtered_cols} FROM global_temp.df_make_issue_benchmark_precomp_tw WHERE sloss_code IN ({sloss_code})"""
        )
    else:
        df_make_issue_benchmark_precomp = spark.sql(
            f"""SELECT {filtered_cols} FROM global_temp.df_make_issue_benchmark_precomp WHERE sloss_code IN ({sloss_code})"""
        )

    df_w_make_issue = get_make_issue_loss(
        df_w_repairs, df_make_issue_benchmark_precomp, benchmark
    )

    # Output intermediate files
    df_w_make_issue.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/make_issue_repairs",
    )


def map_part_price_flag(run_id):
    """This function is used to map part price flag and output intermediate
    file.

    Args:
        run_id: unique ID for execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_make_issue = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/make_issue_repairs"
    )
    df = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_base"
    )

    df_w_part = get_part_individual_kpis(df_w_make_issue, df)

    # Output intermediate file
    df_w_part.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price",
    )


def map_part_price_benchmark(run_id, benchmark):
    """This function is used to map part price and repair information and
    output intermediate file.

    Args:
        run_id: unique ID for execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_part = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price"
    )

    df_w_part_benchmark = get_part_individual_flag(df_w_part, benchmark)

    # output intermediate file
    df_w_part_benchmark.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_benchmark",
    )


def map_part_price_variation(run_id):
    """This function is used to map part price and repair information and
    output intermediate file.

    Args:
        run_id: unique ID for execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_part_benchmark = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_benchmark"
    )

    df_w_part_variation = (
        df_w_part_benchmark.withColumn(
            "part_price_variation", F.lit(None).cast("float")
        )
        .withColumn("part_price_variation_threshold", F.lit(None).cast("float"))
        .withColumn("part_price_variation_benchmark", F.lit(None).cast("string"))
        .withColumn("part_price_variation_flag", F.lit(2))
    )

    # output intermediate file
    df_w_part_variation.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_variation",
    )


def map_part_price_deviation(run_id, prod, benchmark):
    """This function is used to map part price and repair information and
    output intermediate file.

    Args:
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_part_variation = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_variation"
    )

    df_part_price_deviation_precomp = spark.sql(
        """ SELECT * FROM global_temp.df_part_price_deviation_precomp_tw"""
    )

    df_w_part_price_deviation = get_part_price_deviation_kpis(
        df_w_part_variation, df_part_price_deviation_precomp, prod, benchmark
    )
    # output intermediate file
    df_w_part_price_deviation.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_deviation",
    )


def map_labor_rate(run_id, prod, benchmark):
    """This function is used to map labor rate information and output
    intermediate file.

    Args:
        run_id: unique ID for execution
        prod: product type
        benchmark: boundary

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_part = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_deviation"
    )
    df = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_base"
    )
    # Get labor rate related kpis

    if prod == "tw":
        df_labor_rate_deviation_precomp = None
        df_labor_rate_variation_precomp = None
    else:
        df_labor_rate_deviation_precomp = spark.sql(
            """SELECT * FROM global_temp.df_labor_rate_deviation_precomp"""
        )
        df_labor_rate_variation_precomp = spark.sql(
            """SELECT * FROM global_temp.df_labor_rate_variation_precomp"""
        )

    df_labor_rate_kpis = get_dealer_issue_make_kpis(
        df,
        df_labor_rate_deviation_precomp,
        df_labor_rate_variation_precomp,
        prod,
        benchmark,
    )
    # Merge in labor rate kpis
    df_w_labor_rate_kpis = df_w_part.join(
        df_labor_rate_kpis,
        on=[
            "sclaim_number",
            "spayee_no",
            "smake",
            "sloss_code",
            "spayee_type",
            "sservice_center_type",
        ],
        how="left",
    )

    # Output intermediate file
    df_w_labor_rate_kpis.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/labor_rate",
    )


def map_exception(json_contract, run_id, prod):
    """This function is used to map exception information and output
    intermediate file.

    Args:
        json_contract: json contract
        run_id: unique ID for execution
        prod: product type

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_labor_rate_kpis = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/labor_rate"
    )

    # Merge in exception rules and special handle
    df_do = spark.sql("""SELECT * FROM global_temp.df_do""")
    df_w_exceptions = flag_exception(df_w_labor_rate_kpis, df_do)

    # Bring in mapping description fields like spart_desc and sdetail_desc
    if prod == "tw":
        df_raw_mapping = spark.sql(
            """SELECT * FROM global_temp.df_part_no_mapping_tw"""
        )

        df_loss_code_mapping = df_raw_mapping.select(
            "sloss_code", "sdetail_desc"
        ).dropDuplicates(subset=["sloss_code"])
        df_part_no_mapping = df_raw_mapping.select(
            "spart_no", "spart_desc"
        ).dropDuplicates(subset=["spart_no"])
    else:
        df_loss_code_mapping = spark.sql(
            """SELECT * FROM global_temp.df_loss_code_mapping"""
        )
        df_part_no_mapping = spark.sql(
            """SELECT * FROM global_temp.df_part_no_mapping"""
        )

    df_w_desc = add_mapping(
        df_w_exceptions, df_loss_code_mapping, df_part_no_mapping, prod
    )

    # Add tech found and customer complaints
    sclaim_number = f" '{json_contract['claims'][0]['sclaim_number']}' "

    if prod == "tw":
        df_tech_found = spark.sql(
            f"""SELECT * FROM global_temp.df_tech_found_tw WHERE sclaim_number IN ({sclaim_number})"""
        )
        df_customer_comp = spark.sql(
            f"""SELECT * FROM global_temp.df_customer_comp_tw WHERE sclaim_number IN ({sclaim_number})"""
        )
    else:
        df_tech_found = spark.sql(
            f"""SELECT * FROM global_temp.df_tech_found WHERE sclaim_number IN ({sclaim_number})"""
        )
        df_customer_comp = spark.sql(
            f"""SELECT * FROM global_temp.df_customer_comp WHERE sclaim_number IN ({sclaim_number})"""
        )

    df_cc_tech = add_cc_tf(df_w_desc, df_tech_found, df_customer_comp)

    # Add Rob Otto

    # Remove unnecessary columns
    df_out = df_cc_tech.drop(
        "sdealer_number",
        "spayee_type",
        "sservice_center_type",
        "scontract_holder_email",
        "latest_mileage_at_loss",
        "spayee_state",
        "dtcontract_sale_date",
        "icontract_sale_odometer",
        "dtcontract_effect",
        "labor_req_total",
        "dealer_issue_prev_paid_claims_cnt",
        "cdealer_cost",
        "is_tec",
        "cretail_cost",
        "tw_prod_type",
        "make_issue_prev_paid_claims_cnt",
    ).dropDuplicates()

    # Output intermediate file
    df_out.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_kpi",
    )


def identify_product(json_contract):
    """This function is used to identify product type.

    Args:
        json_contract: json contract

    Returns:
        product type mapping
    """

    # Get product type information. If 8, then t&W otherwise VSC
    product_type = int(json_contract["contract"]["iproduct_type_id"])

    if product_type == 8:
        product = "tw"
    elif product_type == 4:
        product = "vsc"
    else:
        product = "other"
    return product


def map_dealer_info(run_id, benchmark):
    """This function is used to identify product type.

    Args:
        run_id: unique ID identifier for the execution
        benchmark: boundary for the flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_customer_precomp = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/df_w_precomp_contracts"
    )
    df_dealer_master = spark.sql("""SELECT * FROM global_temp.df_dealer_master""")
    df_state_precomp = spark.sql("""SELECT * FROM global_temp.df_state_precomp""")

    threhsold_benchmark = benchmark["financial_risk"]["part_req_total"]
    threhsold_benchmark2 = benchmark["financial_risk"]["nb_parts"]
    filtered_cols = ",".join(
        [
            "smake",
            "sloss_code",
            f"nb_parts_{threhsold_benchmark2}  nb_parts_threshold",
            f"part_req_total_{threhsold_benchmark}  part_req_total_threshold",
            "make_issue_prev_paid_claims_cnt",
        ]
    )
    df_make_issue_benchmark_precomp = spark.sql(
        f"""SELECT {filtered_cols} FROM global_temp.df_make_issue_benchmark_precomp"""
    )

    df_master_info = (
        df_w_customer_precomp.join(df_state_precomp, on="spayee_state", how="left")
        .join(df_dealer_master, on=["spayee_no", "sloss_code"], how="left")
        .join(df_make_issue_benchmark_precomp, on=["smake", "sloss_code"], how="left")
    )

    # Dealer Step Flags
    df_master_info = generate_threshold_flag_greater(
        df_master_info,
        "dealer_claim_to_contract_ratio",
        benchmark["requestor_risk"]["dealer_claim_to_contract_ratio"],
    )

    df_master_info = generate_threshold_flag_greater(
        df_master_info,
        "dealer_avg_payout_per_claim",
        benchmark["requestor_risk"]["dealer_avg_payout_per_claim"],
    )

    # Dealer Repair Flag
    threshold_percentile = benchmark["requestor_risk"]["dealer_issue_repair_freq"]
    bound = benchmark["bound"]
    df_master_info = (
        df_master_info.withColumn(
            "dealer_issue_repair_freq_threshold",
            F.lit(col(f"dealer_issue_repair_freq_{threshold_percentile}")),
        )
        .withColumn(
            "dealer_issue_repair_freq_flag",
            F.expr(
                f"""
        CASE
            WHEN dealer_issue_prev_paid_claims_cnt > {bound["dealer_issue_repair_freq"]}
                 AND dealer_issue_repair_freq > dealer_issue_repair_freq_threshold THEN 1
            WHEN dealer_issue_repair_freq <= dealer_issue_repair_freq_threshold
                AND dealer_issue_prev_paid_claims_cnt > {bound["dealer_issue_repair_freq"]} THEN 0
            ELSE 2
        END
        """
            ),
        )
        .drop(f"dealer_issue_repair_freq_{threshold_percentile}")
    )

    # nb_parts_flag Threshold
    df_master_info = df_master_info.withColumn(
        "nb_parts_flag",
        when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["nb_parts"]))
            & (col("nb_parts") > col("nb_parts_threshold")),
            1,
        )
        .when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["nb_parts"]))
            & (col("nb_parts") <= col("nb_parts_threshold")),
            0,
        )
        .otherwise(2),
    )

    # part_req_total_flag Threshold
    df_master_info = df_master_info.withColumn(
        "part_req_total_flag",
        when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["part_req_total"]))
            & (col("part_req_total") > col("part_req_total_threshold")),
            1,
        )
        .when(
            (col("make_issue_prev_paid_claims_cnt") > F.lit(bound["part_req_total"]))
            & (col("part_req_total") <= col("part_req_total_threshold")),
            0,
        )
        .otherwise(2),
    )

    df_master_info.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/make_issue_repairs",
    )


def map_part_info(run_id, benchmark):
    """This function is used to map part details.

    Args:
        run_id: unique ID identifier for the execution
        benchmark: boundary for the flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df_w_make_issue = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/make_issue_repairs"
    )
    df = spark.read.parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/feature_base"
    )

    # Define granularity level
    first_grp_level = [
        "sclaim_number",
        "spart_no",
        "smake",
        "sloss_code",
        "smanufacturer_code",
    ]

    # Select granularity level information from API contract master table
    df_first_group_level = (
        df.select(["sdetail_type", "nreq_qty", "creq_unit_cost"] + first_grp_level)
        .filter(col("sdetail_type").contains("P"))
        .groupby(first_grp_level)
        .agg(
            F.sum(col("nreq_qty")).alias("part_individual_count"),
            F.max(col("creq_unit_cost")).alias("part_price"),
        )
    )

    df_part_price_deviation_precomp = spark.sql(
        """SELECT * FROM global_temp.df_part_price_deviation_precomp"""
    )

    df_parts_master = spark.sql("""SELECT * FROM global_temp.df_parts_master""")

    ###########################################################################
    ###########################################################################
    # Temporal Fix: Create an upper case column to match data

    # Create an upper case cols for base df:
    df_w_make_issue = df_w_make_issue.withColumn(
        "spart_no_upper", F.upper(df_w_make_issue["spart_no"])
    )
    df_w_make_issue = df_w_make_issue.withColumn(
        "smanufacturer_code_upper", F.upper(df_w_make_issue["smanufacturer_code"])
    )

    # Create an upper case cols for precomp df:
    df_part_price_deviation_precomp = df_part_price_deviation_precomp.withColumn(
        "spart_no_upper", F.upper(df_part_price_deviation_precomp["spart_no"])
    )
    df_part_price_deviation_precomp = df_part_price_deviation_precomp.withColumn(
        "smanufacturer_code_upper",
        F.upper(df_part_price_deviation_precomp["smanufacturer_code"]),
    )

    # merge actr with col to use:
    cols_to_select_deviation_precomp = [
        "spart_no_upper",
        "smanufacturer_code_upper",
        "cdealer_cost",
        "cretail_cost",
    ]

    df_master = df_w_make_issue.join(
        df_part_price_deviation_precomp.select(cols_to_select_deviation_precomp),
        on=["smanufacturer_code_upper", "spart_no_upper"],
        how="left",
    )

    # Remove temporal upper case columns:
    df_master.drop(*["smanufacturer_code_upper", "spart_no_upper"])

    ###########################################################################
    ###########################################################################

    df_master = df_master.join(
        df_first_group_level, on=first_grp_level, how="left"
    ).join(df_parts_master, on=["spart_no", "smake", "sloss_code"], how="left")

    threshold_var = benchmark["financial_risk"]["part_price_variation"]
    threshold_dev = benchmark["financial_risk"]["part_price_deviation"]

    # Estimate part_individual_count_flag:
    df_master = df_master.withColumn(
        "part_individual_count_flag",
        when(
            (col("part_individual_count") > col("part_individual_count_threshold")),
            1,
        )
        .when(
            (col("part_individual_count") <= col("part_individual_count_threshold")),
            0,
        )
        .otherwise(2),
    )

    df_master = (
        df_master.withColumn("part_price_variation_benchmark", col("median_part_price"))
        .withColumn(
            "part_price_variation",
            (col("part_price") - col("median_part_price")) / col("median_part_price"),
        )
        .withColumn("part_price_variation_threshold", F.lit(threshold_var))
        .withColumn(
            "part_price_variation_flag",
            F.expr(
                f"CASE WHEN part_price_variation > {threshold_var} AND "
                f"part_price > 10 THEN 1 ELSE 0 END"
            ),
        )
        .withColumn("part_price_deviation_benchmark", col("cretail_cost"))
        .withColumn(
            "part_price_deviation",
            (col("part_price") - col("cretail_cost")) / col("cretail_cost"),
        )
        .withColumn("part_price_deviation_threshold", F.lit(threshold_dev))
        .withColumn(
            "part_price_deviation_flag",
            F.expr(
                f"CASE WHEN part_price_deviation > {threshold_dev} THEN 1 ELSE 0 END"
            ),
        )
        .drop("median_part_price", "cretail_cost")
    )

    df_master.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/part_price_deviation",
    )


@timing
def generate_kpi_refreshement_features(json_contract, run_id):
    """This function is used to calculate the kpis on ACR tool.

    Args:
        run_id: unique ID identifier for the execution
        benchmark: boundary for the flag

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # try:
    prod = identify_product(json_contract)

    if prod == "tw":
        benchmark = config_file["benchmark_tw"]
        sloss_code_ls = list(
            set(
                [
                    json_contract["claims"][x]["sloss_code"]
                    for x in range(len(json_contract["claims"]))
                ]
            )
        )
        sloss_code = ",".join(["'" + str(x) + "'" for x in sloss_code_ls])
        spayee_no = f" '{json_contract['dealer']['spayee_no']}' "

        # Do kpis computation:
        create_base_info(json_contract, run_id, prod)

        # TODO to move into base info function
        # Load, filter and save the intermediate file
        df = spark.read.parquet(
            data_sources["intermediate_output_folder"]
            + str(today_date)
            + "/"
            + str(run_id)
            + "/feature_base"
        )

        # Filter out disposal fees
        df = df.filter(
            ~((col("creq_unit_cost") <= 10) | (col("spart_no").like("%disp%")))
        )

        df.repartition(1).write.mode("overwrite").option(
            "compression", "snappy"
        ).parquet(
            data_sources["intermediate_output_folder"]
            + str(today_date)
            + "/"
            + str(run_id)
            + "/feature_base",
        )

        aggregate_base(run_id, prod, benchmark)
        map_contract(run_id, prod, benchmark)
        map_customer(json_contract, run_id, prod, benchmark)
        map_dealer_state(spayee_no, run_id, prod, benchmark)
        map_dealer_issue(sloss_code, spayee_no, run_id, prod, benchmark)
        map_dealer_repair(sloss_code, run_id, prod, benchmark)
        map_part_price_flag(run_id)
        map_part_price_benchmark(run_id, benchmark)
        map_part_price_variation(run_id)
        map_part_price_deviation(run_id, prod, benchmark)
        map_labor_rate(run_id, prod, benchmark)
        map_exception(json_contract, run_id, prod)
        return None
    else:
        benchmark = config_file["benchmark"]
        create_base_info(json_contract, run_id, prod)  # One Join on 'contract no' level
        aggregate_base(
            run_id, prod, benchmark
        )  # Simplify One Join, current three joins, two on 'sclaim_number', "sloss_code", one on 'sclaim_number'
        map_contract(run_id, prod, benchmark)  # No Joins Find
        map_customer(
            json_contract, run_id, prod, benchmark
        )  # One Customer JOIN on customer level CANNOT SIMPLIFY
        map_dealer_info(run_id, benchmark)
        map_part_info(run_id, benchmark)
        map_labor_rate(run_id, prod, benchmark)  # "smanufacturer_code", "spart_no"
        map_exception(json_contract, run_id, prod)

    # except Exception as e:
    #     return e
