import logging

from configs.config import BaseConfig
from utils.utils import (
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

from pyspark.sql.window import Window
from pyspark.sql.functions import (
    when,
    unix_timestamp,
    lit,
    concat as spark_concat,
    year,
    month,
    col,
    to_date,
    count,
    round,
    sum as spark_sum,
    max as spark_max,
    min as spark_min,
    avg as spark_avg,
)


# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_FEATURE_ENGINEERING_CONFIG
set_up_config = config_file["set_up_configuration"]["breakdown"]
fe_config = set_up_config["feature_engineering"]

# Define intermediate configs:
interim_tables_config = set_up_config["intermediate_results"]
interim_bucket_path = interim_tables_config["bucket_path"]


def aggregate_claims_to_loss_type_level(df):
    """Aggregates data at part level to claim-loss type granularity for
    modeling.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame at part level.

    Returns:
        pyspark.sql.DataFrame: Aggregated DataFrame at claim-loss type granularity.
    """

    # Define ID features:
    id_features = [
        i for i in df.columns if i not in fe_config["loss_code_aggregation"].keys()
    ]

    # Create bare-bone to assign aggregated columns:
    bare_bone = df.select(id_features).dropDuplicates()

    # Create a list of aggregation expressions
    agg_exp = [
        (
            spark_max(col)
            if agg_func == "max"
            else spark_min(col)
            if agg_func == "min"
            else spark_avg(col)
        ).alias(col)
        for col, agg_func in fe_config["loss_code_aggregation"].items()
    ]

    # Perform group by and aggregate using the aggregation expressions
    agg_data = df.groupBy(id_features).agg(*agg_exp)

    # Match results with bare-bone:
    merge_data = bare_bone.join(agg_data, on=id_features, how="left")

    # Check if the counts are equal
    if bare_bone.count() != merge_data.count():
        raise AssertionError("Adding duplicates on aggregate_claims_to_loss_type_level")

    return merge_data


def generate_time_features(df):
    """Generates time-based features from date columns.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: DataFrame with additional time-based features.
    """

    # Convert date column into date type
    df = df.withColumn(
        fe_config["raw_fields"]["date_loss_occurred"],
        to_date(df[fe_config["raw_fields"]["date_loss_occurred"]], "dd-MM-yyyy"),
    )

    # Extract year and month of loss
    df = df.withColumn(
        fe_config["features_dict"]["month_loss"],
        month(df[fe_config["raw_fields"]["date_loss_occurred"]]),
    )
    df = df.withColumn(
        fe_config["features_dict"]["year_loss"],
        year(df[fe_config["raw_fields"]["date_loss_occurred"]]),
    )

    return df


def calculate_vehicle_age(df):
    """Estimates the age of the vehicle based on the date of loss and model
    year.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: DataFrame with vehicle age calculated.
    """

    # Convert model year into date type:
    model_year_dt = df.withColumn(
        "model_year_dt",
        spark_concat(df[fe_config["raw_fields"]["model_year"]], lit("-01-01")),
    ).withColumn("model_year_dt", to_date("model_year_dt", "yyyy-MM-dd"))

    # Create a new dataframe with difference in years
    df = model_year_dt.withColumn(
        fe_config["features_dict"]["vehicle_age"],
        round(
            (
                unix_timestamp(
                    df[fe_config["raw_fields"]["date_loss_occurred"]], "yyyy-MM-dd"
                )
                - unix_timestamp("model_year_dt", "yyyy-MM-dd")
            )
            / (365 * 24 * 60 * 60),
            2,
        ),
    )

    # Drop the unnecessary column
    df = df.drop("model_year_dt")

    return df


def calculate_mileage_yr_ratio(df):
    """Calculates the mileage per year ratio for vehicles.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: DataFrame with mileage per year ratio calculated.
    """

    # Calculate Average mileage per year:
    df = df.withColumn(
        fe_config["features_dict"]["avg_mileage_yr"],
        (
            col(fe_config["raw_fields"]["mileage_at_loss"])
            / col(fe_config["features_dict"]["vehicle_age"])
        ),
    )

    # Ratio between average mileage per vin vs vehicle segment:
    df = df.withColumn(
        fe_config["features_dict"]["mileage_yr_ratio"],
        round(
            col(fe_config["features_dict"]["avg_mileage_yr"])
            / col("mileage_per_year_segment"),
            4,
        ),
    )

    return df


def calculate_claim_to_labor_ratio(df):
    """Calculates the ratio of total labor hours for a claim compared to
    average hours for similar loss types.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: DataFrame with calculated labor ratio.
    """

    # Calculate total labor hours by loss type:
    labor_mask = df.filter(df[fe_config["raw_fields"]["detail_type"]] == "L")

    labor_hours_loss = labor_mask.groupBy(fe_config["raw_fields"]["loss_code"]).agg(
        spark_sum(fe_config["raw_fields"]["quantity_required"]).alias(
            fe_config["features_dict"]["labor_hours"]
        )
    )

    # Map to raw data:
    df_merge = df.join(
        labor_hours_loss, on=fe_config["raw_fields"]["loss_code"], how="left"
    )

    # Labor hour ratio compared to the average by segment and loss type:
    df_merge = df_merge.withColumn(
        fe_config["features_dict"]["claims_to_labor_ratio"],
        col(fe_config["features_dict"]["labor_hours"])
        / col("average_loss_labor_hours"),
    )

    return df_merge


def calculate_total_payout(df):
    """Calculates the total payout for claims at the loss code level.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: DataFrame with total payout calculated.
    """

    # Define a window specification for the groupBy operation
    window_spec = Window.partitionBy(fe_config["raw_fields"]["loss_code"])

    # Calculate total claim payout by loss code using sum over the window
    df = df.withColumn(
        fe_config["features_dict"]["total_claim_payout"],
        spark_sum(fe_config["raw_fields"]["req_payout"]).over(window_spec),
    )

    return df


def print_null_fe(df):
    """Prints columns with null values after feature engineering.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        None: Function does not return a value but prints output.
    """
    # Compute the sum of null values for each column
    null_counts = df.select(
        [count(when(col(c).isNull(), c)).alias(c) for c in df.columns]
    )

    # Collect the counts as a dictionary
    null_counts_dict = null_counts.collect()[0].asDict()

    # Identify columns with nulls greater than zero
    columns_with_nulls = {k: v for k, v in null_counts_dict.items() if v > 0}

    # Display columns with their respective number of nulls
    logger.warning("Printing cols with nulls:\n %s", columns_with_nulls)


def generate_output_claim_level(df):
    """Prepares final claim-level output for the model by removing part-level
    details.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: Claim-level DataFrame.
    """
    # Define columns to exclude that are at part/labor level:
    cols_to_exclude = [
        fe_config["raw_fields"]["detail_type"],
        fe_config["raw_fields"]["quantity_required"],
        fe_config["raw_fields"]["req_payout"],
    ]

    # Identify columns with nulls greater than zero
    print_null_fe(df)

    # Combining multiple transformations
    final_df = (
        df.drop(*cols_to_exclude)
        .dropDuplicates()
        .na.fill(0)
        .withColumn("strim", when(col("strim") == "", "-").otherwise(col("strim")))
    )

    # Check if the counts are equal
    if final_df.count() != df.select("sloss_code").distinct().count():
        raise AssertionError("Missmatch in expected output rows...")

    return final_df


def calculate_on_fly_features(df):
    """Calculates features dynamically during runtime for model feeding.

    Args:
        df (pyspark.sql.DataFrame): Input DataFrame.

    Returns:
        pyspark.sql.DataFrame: DataFrame with on-the-fly features added.
    """

    # Calculate month and year loss:
    df_w_ts = generate_time_features(df)

    # Calculate vehicle age:
    df_w_ts_ve = calculate_vehicle_age(df_w_ts)

    # Calculate mileage per year ratio:
    df_w_ts_ve_myr = calculate_mileage_yr_ratio(df_w_ts_ve)

    # Calculate claim to labor hour ratio:
    df_w_ts_ve_myr_lhr = calculate_claim_to_labor_ratio(df_w_ts_ve_myr)

    # Estimate total cost requested (Labor + Part):
    df_w_ts_ve_myr_lhr_tc = calculate_total_payout(df_w_ts_ve_myr_lhr)

    return df_w_ts_ve_myr_lhr_tc


@timing
def feature_engineering(id_execution: dict, spark: object):
    """Orchestrate the feature engineering process, from raw data to prepared
    features.

    Args:
        id_execution (dict): Execution IDs for tracking purposes.
        spark (object): Spark session object.

    Returns:
        None: Function orchestrates feature engineering but does not return a value.
    """
    logger.info("** Initializing feature engineering task **")

    # Read output from stacking task:
    input_file_name = interim_tables_config["file_name"]["staking_info"]

    staking_task_output = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=input_file_name,
        spark=spark,
    )

    # Read output from stacking task:
    staking_task_output = staking_task_output.select(
        set_up_config["required_fields"]
    ).dropDuplicates()

    # Aggregate claim info at claim-loss type level:
    claim_loss_df = aggregate_claims_to_loss_type_level(staking_task_output)
    logger.info("Claim aggregation to claim-loss level is done...")

    # Calculate on fly features:
    fe_output = calculate_on_fly_features(claim_loss_df)
    logger.info("On fly features engineering is done...")

    # Match exact same schema and column order:
    final_fe_output = generate_output_claim_level(fe_output)
    logger.info("ML engine schema matching step is done...")

    # Save interim output to s3:
    file_name_output = interim_tables_config["file_name"]["feature_engineering"]

    save_intermediate_daily_files_s3(
        df=final_fe_output,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )
