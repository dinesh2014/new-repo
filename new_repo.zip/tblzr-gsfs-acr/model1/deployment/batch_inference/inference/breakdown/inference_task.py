# Native python libraries:
import logging
import numpy as np
from sklearn.linear_model import LogisticRegression
from mlflow.exceptions import RestException
from utils.utils import (
    loading_temporal_views,
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
    add_missing_columns,
)

# Pyspark requirements:
from pyspark.sql import Window, Row
import pyspark.sql.functions as F
import pyspark.sql.types as T
from configs.config import BaseConfig

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_BREAKDOWN_CONFIG
set_up_config = config_file["set_up_configuration"]["breakdown"]
ml_registry_config = set_up_config["model_registry"]
serving_config = set_up_config["serving"]

# Define intermediate configs:
interim_tables_config = set_up_config["intermediate_results"]
interim_bucket_path = interim_tables_config["bucket_path"]


@timing
def return_closest_boundary(df):
    """Identifies the closest boundary for each probability in the DataFrame.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing probability values and their respective bounds.

    Returns:
        pyspark.sql.DataFrame: DataFrame with only the rows that contain the closest boundary to each probability.
    """

    # Define a UDF to find the closest boundary
    df_with_distances = df.withColumn(
        "distance",
        F.expr(
            """
                case
                when probabilities between lower_bound and upper_bound then 0
                when abs(probabilities - lower_bound) < abs(probabilities - upper_bound) then abs(probabilities - lower_bound)
                when abs(probabilities - lower_bound) >= abs(probabilities - upper_bound) then abs(probabilities - upper_bound)
                else -1
                end
            """
        ),
    )

    # Adding a row number within each sloss_code for ordering
    window_spec = Window.partitionBy("sloss_code").orderBy(F.col("distance"))

    df_with_row_number = df_with_distances.withColumn(
        "row_number", F.row_number().over(window_spec)
    )

    # Filtering to get the minimum distance (closest boundary)
    selected_boundaries = df_with_row_number.filter(F.col("row_number") == 1)

    # Select the columns you need from the selected_boundaries DataFrame
    selected_boundaries_final = selected_boundaries

    return selected_boundaries_final


@timing
def normalize_features(df, scaler_params_dict):
    """Normalizes features in the DataFrame based on provided scaling
    parameters.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing features to be normalized.
        scaler_params_dict (dict): Dictionary containing mean and standard deviation for each feature.

    Returns:
        pyspark.sql.DataFrame: DataFrame with normalized features.
    """
    # Iterate over the keys in the dictionary
    for feature, params in scaler_params_dict.items():
        # Check if the DataFrame has this feature
        if feature in df.columns:
            logger.info("Scaling feature: %s", feature)

            # Calculate the mean and standard deviation
            mean = params.get("mean", 0)
            std_dev = params.get("std_dev", 1)

            # Replace dealer feature to average dealer to control for dealer behavior:
            if feature in set_up_config["features_to_set_to_average"]:
                logger.info("** Setting feature to average **")
                df = df.withColumn(feature, F.lit(mean))

                # Subtract the mean and divide by the standard deviation
                df = df.withColumn(feature, (F.col(feature) - mean) / std_dev)
            else:
                # Subtract the mean and divide by the standard deviation
                df = df.withColumn(feature, (F.col(feature) - mean) / std_dev)
    return df


# Define the recursive function
def row_to_dict(row):
    """Recursively converts a PySpark Row object into a nested dictionary.

    Args:
        row (Row): PySpark Row object to be converted.

    Returns:
        dict: Nested dictionary representation of the PySpark Row.
    """
    if isinstance(row, Row):
        return {k: row_to_dict(v) for k, v in row.asDict().items()}
    elif isinstance(row, list):
        return [row_to_dict(i) for i in row]
    else:
        return row


@timing
def estimate_value_at_risk(
    predictions,
    base_table,
    make: str,
    model: str,
    spark: object,
):
    """Estimates the value at risk based on predictions, comparing with
    baseline data and specific vehicle characteristics.

    Args:
        predictions (pyspark.sql.DataFrame): DataFrame containing the prediction probabilities.
        base_table (pyspark.sql.DataFrame): DataFrame containing the base data with original claim details.
        make (str): Vehicle make to filter data.
        model (str): Vehicle model to filter data.
        spark (pyspark.sql.SparkSession): Active Spark session.

    Returns:
        pyspark.sql.DataFrame: DataFrame containing the risk evaluated data.
    """

    # Define filter to reduce time computation:
    make_model_filter = f"smake = '{make}' AND smodel = '{model}'"

    # Read the risk tier table from S3:
    tier_risk_table = loading_temporal_views(
        table_name=set_up_config["data_source"]["risk_tiers_output"]["table_name"],
        cols_to_pull=set_up_config["data_source"]["risk_tiers_output"][
            "columns_to_pull"
        ],
        value_filter=make_model_filter,
        spark=spark,
    )

    # Set upper case cols to match with risk tier output:
    risk_tier_keys = ["smake", "smodel", "sloss_code"]
    tier_risk_table = tier_risk_table.select(
        *[
            F.upper(F.col(c)).alias(c) if c in risk_tier_keys else F.col(c)
            for c in tier_risk_table.columns
        ]
    )

    # Create monotonic index for base and prediction to match:
    window = Window.orderBy(F.monotonically_increasing_id())
    predictions = predictions.withColumn("index", F.row_number().over(window) - 1)
    base_table = base_table.withColumn("index", F.row_number().over(window) - 1)

    # Keep only claims with loss used on training:
    loss_code_map = [
        row["sloss_code"]
        for row in base_table.select("sloss_code").distinct().collect()
        if row["sloss_code"] in predictions.columns
    ]

    # Filter rows in base df:
    base_table = base_table.filter(F.col("sloss_code").isin(loss_code_map))
    index_code_map = [
        row["index"] for row in base_table.select("index").distinct().collect()
    ]
    predictions = predictions.filter(F.col("index").isin(index_code_map))

    if base_table.count() == 0:
        logger.warning(
            "** Generating default UNKNOWN predictions for empty loss code-class match ***"
        )

        # Providing JSON message to simulate rest error:
        json_error = {
            "status_code ": 404,
            "error_code": "RESOURCE_NOT_FOUND",
            "message": "Empty resulting dataframe after loss code-class match.",
        }
        raise RestException(json_error)

    # Join base table with predictions to quick manipulation:
    base_table = base_table.join(
        predictions, base_table["index"] == predictions["index"], how="left"
    )
    base_table = base_table.drop("index")

    # Access the column from joined_df
    def select_column(row):
        return row[row["sloss_code"]]

    # Assign probabilities dynamically depending on index and loss code:
    udf_select_column = F.udf(select_column, T.FloatType())
    base_table = base_table.withColumn(
        "probabilities",
        udf_select_column(F.struct([base_table[x] for x in base_table.columns])),
    )

    # Remove prediction columns:
    base_table = base_table.drop(*predictions.columns)

    # Map risk tier values by loss
    base_table_risk_tiers = base_table.join(
        tier_risk_table, on=risk_tier_keys, how="left"
    )

    # create two cols depending on min, max boundaries:
    base_table_risk_tiers = base_table_risk_tiers.withColumn(
        "lower_bound", F.col("lift_probs_cut_boundaries").getItem(0)
    )

    base_table_risk_tiers = base_table_risk_tiers.withColumn(
        "upper_bound", F.col("lift_probs_cut_boundaries").getItem(1)
    )

    # Keep only risk tiers where probability is within boundaries / closest to boundaries:
    fe_output_risk_tiers_final = return_closest_boundary(base_table_risk_tiers)

    #########################################
    # Estimate Value At Risk ################
    #########################################

    # Generate the break-even for each risk tier:
    COST_PER_CLAIM = 15.38
    DENIED_RATE = 0.05

    base_table_risk_tiers = estimate_break_even_threshold(
        df=fe_output_risk_tiers_final,
        cost_per_claim=COST_PER_CLAIM,
        denied_rate=DENIED_RATE,
    )

    return base_table_risk_tiers


def estimate_break_even_threshold(df, cost_per_claim, denied_rate):
    """Calculates the break-even threshold for each risk tier based on cost per
    claim and denied rate.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing risk tier data.
        cost_per_claim (float): Cost per claim used in break-even calculation.
        denied_rate (float): Denied rate used in break-even calculation.

    Returns:
        pyspark.sql.DataFrame: DataFrame with break-even thresholds calculated.
    """
    # # Calculate break-even breakdown
    df = df.withColumn(
        "breakeven_breakdown", F.expr(f"{cost_per_claim} / (hit_rate * {denied_rate})")
    )

    risk_tier = "risk_tier"

    df = df.withColumn(
        "var_anomaly_flag_breakdown",
        F.when(F.col(risk_tier) == 1, 1).otherwise(
            F.when(F.col(risk_tier) == 2, 0).otherwise(
                F.when(F.col(risk_tier) == 3, 0).otherwise(2)
            )
        ),
    )

    return df


@timing
def filter_final_breakdown_cols(breakdown_output_df):
    """Filters and renames columns in the breakdown output DataFrame according
    to configuration.

    Args:
        breakdown_output_df (pyspark.sql.DataFrame): DataFrame containing breakdown data to be formatted.

    Returns:
        pyspark.sql.DataFrame: Formatted and filtered DataFrame.
    """
    # Rename columns
    for old_col, new_col in set_up_config["rename_final_cols"].items():
        breakdown_output_df = breakdown_output_df.withColumnRenamed(old_col, new_col)

    # Select final columns
    selected_cols = set_up_config["select_final_cols"]
    breakdown_output_df = breakdown_output_df.select(*selected_cols)

    return breakdown_output_df


@timing
def inference_task(id_execution: dict, spark: object):
    """Conducts the breakdown inference task using a hosted model in MLFlow.

    Args:
        id_execution (dict): Execution IDs for tracking purposes.
        spark (pyspark.sql.SparkSession): Active Spark session.

    Returns:
        None: The function orchestrates the inference task but does not return a value.
    """
    logger.info("** Initializing breakdown inference task **")

    # Read output from feature engineering task:
    df_model_params = spark.sql("""select * from global_temp.df_breakdown_model""")
    input_file_name = interim_tables_config["file_name"]["feature_engineering"]

    fe_output = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=input_file_name,
        spark=spark,
    )

    try:
        # Retrieve model signature from MLFlow:
        df_prediction_features = fe_output.join(
            df_model_params, on=["smake", "smodel"], how="inner"
        )

        one_hot_encoded_columns = [
            "smake",
            "smodel",
            "snew_used",
            "sbody_style",
            "sfuel",
            "sdriving_type",
            "spayee_state",
            "urbanicity",
            "strim",
        ]

        for col in one_hot_encoded_columns:
            if col not in fe_output.columns:
                continue
            entries = list(fe_output.select(col).distinct().toPandas()[col])

            # Create dummy features in lower case to match with expected model features
            for entry in entries:
                df_prediction_features = df_prediction_features.withColumn(
                    f"{col}_{entry.lower()}",
                    F.expr(f"case when {col} == '{entry}' then 1 else 0 end"),
                )

        # Scale features using standard scaler method during training set:
        first_row = df_prediction_features.first()

        # Extract and convert the dictionary from the 'sclaler_params' column of the first row
        scaler_params_dict = row_to_dict(first_row["scaler_params"])

        # Normalize features in the DataFrame
        df_prediction_features = normalize_features(
            df_prediction_features, scaler_params_dict
        )

        # Define params and fit Logit engine:
        first_row = df_prediction_features.first()
        model = LogisticRegression(**{"multi_class": "ovr"})
        model.coef_ = np.array(first_row["coefficients"])
        model.intercept_ = np.array(first_row["intercept"])
        model.classes_ = np.array(first_row["classes"])

        pred_x = np.array(
            [
                first_row[feat] if feat in df_prediction_features.columns else 0
                for feat in first_row["features"]
            ]
        ).reshape(1, -1)

        probability_results = model.predict_proba(pred_x)

        predictions = (
            spark.createDataFrame(
                probability_results, [str(i) for i in first_row["classes"]]
            )
            .withColumn(
                "index",
                F.explode(
                    F.array([F.lit(x) for x in range(df_prediction_features.count())])
                ),
            )
            .drop("index")
        )

        # Assign probabilities, quartile cuts and risk segment:
        output_inference = estimate_value_at_risk(
            predictions=predictions,
            base_table=fe_output,
            make=first_row["smake"].lower(),
            model=first_row["smodel"].lower(),
            spark=spark,
        )

        # Filter relevant cols for KPI module:
        output_inference = filter_final_breakdown_cols(output_inference)
        logger.info("Output_Inference Results Count: %s", output_inference.count())

        # Save output to S3:
        save_intermediate_daily_files_s3(
            df=output_inference,
            s3_bucket=interim_bucket_path,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config["file_name"]["breakdown_inference"],
        )

        logger.info("Assigning risk tier and other metrics to output...")
        logger.info("** Inference task completed **")

    except Exception as e:
        logger.warning("Exception in BreakDown Modelling: %s", e)
        output_inference = add_missing_columns(
            fe_output, set_up_config["select_final_cols"]
        )

        # Save output to S3:
        save_intermediate_daily_files_s3(
            df=output_inference,
            s3_bucket=interim_bucket_path,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config["file_name"]["breakdown_inference"],
        )
