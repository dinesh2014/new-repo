import logging

from configs.config import BaseConfig
from pyspark.sql import Window
from utils.utils import (
    loading_temporal_views,
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

from utils.data_schemas import (
    customer_schema,
    dealer_schema,
    contract_schema,
    claims_contract_schema,
)

from pyspark.sql.functions import (
    monotonically_increasing_id,
    explode,
    array,
    lit,
    when,
    row_number,
)

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_STAKING_INFO_CONFIG
set_up_config = config_file["set_up_configuration"]

# referential and precomputed table config:
referential_tables_config = set_up_config["referential_tables"]
pre_calc_tables_config = set_up_config["pre_computed_tables"]
interim_tables_config = set_up_config["intermediate_results"]["breakdown"]
interim_bucket_path = interim_tables_config["bucket_path"]


def flatten_json(json_data, spark):
    """Flattens JSON data into a Spark DataFrame with combined information from
    related entities such as claims, dealers, customers, and contracts.

    Args:
        json_data (dict): The JSON data containing nested structures to flatten.
        spark (pyspark.sql.SparkSession): The active Spark session used to create DataFrames.

    returns:
        spark.DataFrame: Output with the contract information
    """

    # Extract claims
    claims_data = json_data["claims"]
    num_claims = len(claims_data)

    # Create DataFrame for claims
    window = Window.orderBy(monotonically_increasing_id())
    df_claims = spark.createDataFrame(
        claims_data, schema=claims_contract_schema
    ).withColumn("index", row_number().over(window) - 1)

    # Create independent dataframes for dealer:
    df_dealer = spark.createDataFrame(
        [json_data["dealer"]], schema=dealer_schema
    ).withColumn("index", explode(array([lit(x) for x in range(num_claims)])))

    # Create independent dataframes for customer:
    df_customer = spark.createDataFrame(
        [json_data["customer"]], schema=customer_schema
    ).withColumn("index", explode(array([lit(x) for x in range(num_claims)])))

    # Create independent dataframes for contract:
    df_contract = spark.createDataFrame(
        [json_data["contract"]], schema=contract_schema
    ).withColumn("index", explode(array([lit(x) for x in range(num_claims)])))

    # Join all dataframes:
    api_contract_df = (
        df_claims.join(df_dealer, on="index", how="left")
        .join(df_customer, on="index", how="left")
        .join(df_contract, on="index", how="left")
    )

    # remove index column:
    api_contract_df = api_contract_df.drop("index")

    return api_contract_df


def retrieve_api_contract(json_contract: dict, spark: object):
    """Converts a JSON object into a Spark DataFrame by flattening its
    structure and integrating nested data.

    Args:
        json_contract (dict): JSON data representing the contract details.
        spark (pyspark.sql.SparkSession): Active Spark session for DataFrame operations.

    returns:
    spark.DataFrame: Output with the contract information
    """

    # Convert JSON into dataframe:
    contract_df = flatten_json(json_contract, spark)

    return contract_df


def map_contract_reference_columns(
    api_contract,
    spark,
):
    """Enhances an API contract DataFrame with additional contract details from
    a referential data source.

    Args:
        api_contract (pyspark.sql.DataFrame): The DataFrame containing initial API contract data.
        spark (pyspark.sql.SparkSession): Spark session used to access external data sources.

    returns:
        spark.DataFrame: Output with the contract information and referential features
    """

    # Define column used for filtering:
    contract_column = "scontract_no"

    # Define filter to reduce time computation:
    contract_no = api_contract.select(contract_column).first()[contract_column]
    contract_filter = f"{contract_column} = '{contract_no}'"

    # Read contract form temp view clean master table:
    referential_table = loading_temporal_views(
        table_name=referential_tables_config["tables"]["contracts"],
        cols_to_pull=set_up_config["required_fields"]["contracts"],
        value_filter=contract_filter,
        spark=spark,
    ).dropDuplicates()

    if referential_table.count() == 0:
        raise ValueError("[ERROR]: No contract found in referential table...")

    # Extract required columns:
    data_w_contract = api_contract.join(
        referential_table, on=contract_column, how="left"
    )

    return data_w_contract


def map_referential_features(
    api_contract,
    id_execution,
    spark: object,
):
    """Pulls required fields from external data sources to enrich the given
    DataFrame with referential data.

    Args:
        api_contract (pyspark.sql.DataFrame): DataFrame to be enriched with referential data.
        id_execution (dict): Execution identifiers for the process.
        spark (pyspark.sql.SparkSession): Spark session to execute data loading and transformations.
    """

    # Map contract information:
    data_w_contract_vin = map_contract_reference_columns(api_contract, spark)

    # Save interim outputs into S3:
    file_name = interim_tables_config["file_name"]["map_referential_features"]

    save_intermediate_daily_files_s3(
        df=data_w_contract_vin,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name,
    )


def assign_global_vars(
    df,
):
    """Assigns global variables based on specific DataFrame columns for use in
    filtering and further processing.

    Args:
        df (pyspark.sql.DataFrame): DataFrame from which global variables are derived.
    """

    # Assign model year as global var:
    set_up_config["global_variables"]["model_year"] = df.select("imodel_year").first()[
        "imodel_year"
    ]

    # Assign make global var:
    set_up_config["global_variables"]["make"] = df.select("smake").first()["smake"]

    # Assign model as global var:
    set_up_config["global_variables"]["model"] = df.select("smodel").first()["smodel"]

    # Assign dealer as global var:
    set_up_config["global_variables"]["dealer"] = df.select("spayee_no").first()[
        "spayee_no"
    ]

    # Assign global variable for spayee_zip_code:
    set_up_config["global_variables"]["customer_zip_code"] = df.select(
        "scontract_holder_zip_code"
    ).first()["scontract_holder_zip_code"]


def map_claim_to_contract_ratio(
    base_df,
    spark: object,
):
    """Maps claim to contract ratios for a DataFrame based on predefined global
    variables and external data.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame containing claim data.
        spark (pyspark.sql.SparkSession): Spark session to access external data for mapping.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["dealer_level"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["dealer_level"]["columns_to_pull"]

    # Define filter:
    filter_str = f"spayee_no = '{set_up_config['global_variables']['dealer']}'"

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )
    # Rename_columns:
    table = table.withColumnRenamed(
        "dealer_claim_to_contract_ratio", "dealer_claim_contract_ratio"
    )

    # Merge the dataframes:
    base_df = base_df.join(table, on=["spayee_no"], how="left")

    return base_df


def map_mileage_per_year_segment(
    base_df,
    spark: object,
):
    """Enriches the DataFrame with mileage per year data segmented by vehicle
    make and model from external sources.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to be enriched with mileage data.
        spark (pyspark.sql.SparkSession): Spark session used to query external data sources.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """
    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["mileage_per_year"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["mileage_per_year"][
        "columns_to_pull"
    ]

    # Define filter:
    filter_str = (
        f"smake = '{set_up_config['global_variables']['make']}' AND "
        f"smodel = '{set_up_config['global_variables']['model']}'"
    )

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Merge the dataframes:
    base_df = base_df.join(table, on=["smake", "smodel", "imodel_year"], how="left")

    return base_df


def map_claim_to_labor_hour_ratio(
    base_df,
    spark: object,
):
    """Appends labor hour ratios to the DataFrame based on claim data and
    averages from external references.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame containing claims to be enhanced with labor hour ratios.
        spark (pyspark.sql.SparkSession): Spark session to access external labor hour data.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["average_loss_labor_hours"][
        "table_name"
    ]
    cols_to_pull = pre_calc_tables_config["tables"]["average_loss_labor_hours"][
        "columns_to_pull"
    ]

    # Define filter:
    filter_str = (
        f"smake = '{set_up_config['global_variables']['make']}' AND "
        f"smodel = '{set_up_config['global_variables']['model']}' AND "
        f"imodel_year = {set_up_config['global_variables']['model_year']}"
    )

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Merge the dataframes:
    base_df = base_df.join(
        table, on=["smake", "smodel", "imodel_year", "sloss_code"], how="left"
    )

    return base_df


def map_geo_features(
    base_df,
    spark: object,
):
    """Maps geographical features to the DataFrame based on zip code matching
    from external data sources.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to be enhanced with geographical features.
        spark (pyspark.sql.SparkSession): Spark session to access external geographical data.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["geo_features_table"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["geo_features_table"][
        "columns_to_pull"
    ]

    # Define filter:
    filter_str = f"cleaned_contract_holder_zip = '{set_up_config['global_variables']['customer_zip_code']}'"

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Merge the dataframes:
    base_df = base_df.join(
        table,
        base_df.scontract_holder_zip_code == table.cleaned_contract_holder_zip,
        how="left",
    )

    return base_df


def map_weather_features(
    base_df,
    spark: object,
):
    """Enhances the DataFrame with weather-related data based on geographic
    locations from external sources.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to be enriched with weather features.
        spark (pyspark.sql.SparkSession): Spark session to access external weather data.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["weather_features_table"][
        "table_name"
    ]
    cols_to_pull = pre_calc_tables_config["tables"]["weather_features_table"][
        "columns_to_pull"
    ]

    # Define filter:
    filter_str = f"zip = '{set_up_config['global_variables']['customer_zip_code']}'"

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # rename columns:
    for old_name, new_name in set_up_config["rename_weather_features"].items():
        table = table.withColumnRenamed(old_name, new_name)

    # Merge the dataframes:
    base_df = base_df.join(
        table, base_df.scontract_holder_zip_code == table.zip, how="left"
    )

    return base_df


def map_pre_computed_features(
    id_execution,
    spark: object,
):
    """Integrates pre-computed features into the API contract data based on
    mappings defined in external configurations.

    Args:
        id_execution (dict): Execution identifiers for tracking and process management.
        spark (pyspark.sql.SparkSession): Spark session to load and map features.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """

    # Read interim parquet file from S3:
    file_name_input = interim_tables_config["file_name"]["map_referential_features"]

    api_contract_df = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_input,
        spark=spark,
    )

    # define global variables:
    assign_global_vars(api_contract_df)
    logger.info("Global variables assigned...")

    # Map dealer features:
    api_contract_df = map_claim_to_labor_hour_ratio(api_contract_df, spark)
    logger.info("Mapping pre-compute dealer features...")

    # Map vehicle features:
    api_contract_df = map_mileage_per_year_segment(api_contract_df, spark)
    logger.info("Mapping pre-compute customer features...")

    # Map contract features:
    api_contract_df = map_claim_to_contract_ratio(api_contract_df, spark)
    logger.info("Mapping pre-compute contract features...")

    # Map geo features:
    api_contract_df = map_geo_features(api_contract_df, spark)
    logger.info("Mapping pre-compute demographics  features...")

    # Map Weather:
    api_contract_df = map_weather_features(api_contract_df, spark)
    logger.info("Mapping pre-compute demographics  features...")

    # Write interim output to s3:
    file_name_output = interim_tables_config["file_name"]["map_pre_computed_features"]

    save_intermediate_daily_files_s3(
        df=api_contract_df,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )

    return api_contract_df


def map_part_frequency_ratio(
    id_execution,
    spark: object,
):
    """Calculates and maps part frequency ratios to the DataFrame using pre-
    defined configurations and external data sources.

    Args:
        id_execution (dict): Execution identifiers for tracking and mapping processes.
        spark (pyspark.sql.SparkSession): Spark session to execute data retrieval and mapping.

    returns:
        spark.DataFrame: Output with the pre-computed filed
    """

    # Read interim parquet from S3:
    file_name_input = interim_tables_config["file_name"]["map_pre_computed_features"]

    base_df = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_input,
        spark=spark,
    )

    # Pull clean master table (referential)
    table_name = pre_calc_tables_config["tables"]["part_frequency_table"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["part_frequency_table"][
        "columns_to_pull"
    ]

    # Construct the filtering string:
    filter_str = (
        f"smake = '{set_up_config['global_variables']['make']}' AND "
        f"smodel = '{set_up_config['global_variables']['model']}'"
    )

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Convert loss_code to str:
    table = table.na.drop(subset=["breakdown_part_freq"])
    base_df = base_df.join(
        table, on=["smake", "smodel", "sloss_code", "spart_no"], how="left"
    )

    # Implement flag:
    base_df = base_df.withColumn(
        "part_freq_flag",
        when(
            (base_df["breakdown_part_freq"] <= 0.05) & (base_df["creq_unit_cost"] > 10),
            1,
        ).otherwise(0),
    )

    # Select final columns:
    base_df = base_df.select(set_up_config["final_cols_part_frequency"])

    # Save interim output to s3:
    file_name_output = interim_tables_config["file_name"]["part_frequency_ratio"]

    save_intermediate_daily_files_s3(
        df=base_df,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )

    return base_df


@timing
def stack_claim_information(json_contract, id_execution, spark):
    """Coordinates the execution of data retrieval and mapping tasks for claim
    information, transforming JSON input into enriched DataFrame formats
    suitable for analysis.

    Args:
        json_contract (dict): JSON contract containing claim information.
        id_execution (dict): Dictionary with execution identifiers.
        spark (pyspark.sql.SparkSession): Active Spark session for data handling and transformations.

    Returns: None
    """
    logger.info("** Initializing staking info task **")

    # Retrieve API contract information:
    api_contract = retrieve_api_contract(json_contract, spark)
    logger.info("API contract parse correctly...")

    # Map referential columns from S3:
    map_referential_features(api_contract, id_execution, spark)
    logger.info("Referential features included into pipeline...")

    # Map pre-computed columns from S3:
    map_pre_computed_features(id_execution, spark)
    logger.info("Pre-computed features included into pipeline...")

    # Generate part frequency ratio:
    map_part_frequency_ratio(id_execution, spark)
    logger.info("Generating part frequency ratio...")
