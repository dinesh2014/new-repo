import logging
from configs.config import BaseConfig
import pyspark.sql.functions as F
from pyspark.sql.functions import (
    col,
    count,
    when,
    sum as spark_sum,
    max as spark_max,
    min as spark_min,
    avg as spark_avg,
)

from utils.utils import (
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_FEATURE_ENGINEERING_CONFIG
set_up_config = config_file["set_up_configuration"]["cost_assessment"]
fe_config = set_up_config["feature_engineering"]

# Define intermediate configs:
interim_tables_config = set_up_config["intermediate_results"]
interim_bucket_path = interim_tables_config["bucket_path"]


def aggregate_claims_to_loss_type_level(df: F.DataFrame):
    """Aggregates data to loss type granularity for modeling purposes by
    applying various aggregation functions.

    Args:
        df (F.DataFrame): Input DataFrame containing part-level data to be aggregated.

    Returns:
        F.DataFrame: DataFrame aggregated to claim - loss type granularity.
    """

    # Define ID features:
    id_features = [
        i for i in df.columns if i not in fe_config["feature_aggregation"].keys()
    ]

    # Create bare-bone to assign aggregated columns:
    bare_bone = df.select(id_features).dropDuplicates()

    # Create a list of aggregation expressions
    agg_exp = [
        (
            spark_max(col)
            if agg_func == "max"
            else (
                spark_min(col)
                if agg_func == "min"
                else spark_sum(col)
                if agg_func == "sum"
                else spark_avg(col)
            )
        ).alias(col)
        for col, agg_func in fe_config["feature_aggregation"].items()
    ]

    # Perform group by and aggregate using the aggregation expressions
    agg_data = df.groupBy(id_features).agg(*agg_exp)

    # Match results with bare-bone:
    merge_data = bare_bone.join(agg_data, on=id_features, how="left")

    assert (
        bare_bone.count() == merge_data.count()
    ), "Adding duplicates on aggregate_claims_to_loss_type_level"

    # rename aggregated columns:
    merge_data = merge_data.withColumnRenamed("nreq_qty", "labor_hours_req")

    return merge_data


def calculate_labor_hour_deviation(
    df: F.DataFrame,
) -> F.DataFrame:
    """Calculates the deviation of labor hours from a predefined baseline.

    Args:
        df (F.DataFrame): DataFrame containing labor hours data for deviation calculation.

    Returns:
        F.DataFrame: DataFrame with labor hours deviation added as a new column.
    """
    # Calculate deviation to baseline:
    df = df.withColumn("labor_hours_prediction_threshold", F.lit(0.03))

    df = df.withColumn(
        "deviation_to_baseline",
        (col("labor_hours_req") - col("labor_hours_prediction"))
        / col("labor_hours_prediction"),
    )

    return df


def calculate_on_fly_features(df: F.DataFrame, baseline_df) -> F.DataFrame:
    """Calculates dynamic features on-the-fly to be fed into the machine
    learning engine.

    Args:
        df (F.DataFrame): DataFrame containing data to calculate features on.
        baseline_df (F.DataFrame): DataFrame containing baseline data to reference during feature calculation.

    Returns:
        F.DataFrame: DataFrame with on-the-fly features calculated.
    """

    return df


def generate_output_claim_level(df: F.DataFrame) -> F.DataFrame:
    """Prepares the final DataFrame with claims and loss information by
    cleaning null values.

    Args:
        df (F.DataFrame): DataFrame to be processed and cleaned of null values.

    Returns:
        F.DataFrame: Cleaned DataFrame ready to be used as model input.
    """
    # Compute the sum of null values for each column
    null_counts = df.select(
        [count(when(col(c).isNull(), c)).alias(c) for c in df.columns]
    )

    # Collect the counts as a dictionary
    null_counts_dict = null_counts.collect()[0].asDict()

    # Identify columns with nulls greater than zero
    columns_with_nulls = {k: v for k, v in null_counts_dict.items() if v > 0}

    # Display columns with their respective number of nulls
    logger.info("Printing cols with nulls:\n %s", columns_with_nulls)

    final_df = df.fillna(0)

    return final_df


@timing
def feature_engineering(id_execution: dict, spark: object):
    """Conducts the entire feature engineering process, managing data
    aggregation, on-the-fly feature calculation, and preparing the dataset for
    machine learning modeling.

    Args:
        id_execution (dict): Dictionary containing execution identifiers and metadata for tracking.
        spark (object): Active Spark session to handle data operations.

    Returns:
        None: This function orchestrates feature engineering and does not return any value directly.
    """
    logger.info("** Initializing feature engineering task **")

    # Read output from stacking task:
    input_file_name = interim_tables_config["file_name"]["staking_info"]

    staking_task_output_df = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=input_file_name,
        spark=spark,
    )

    staking_task_output = staking_task_output_df

    # Read output from stacking task:
    staking_task_output = staking_task_output.select(
        set_up_config["required_fields"]
    ).dropDuplicates()

    # Aggregate records at claim, loss, dealer level:
    aggregated_data = aggregate_claims_to_loss_type_level(staking_task_output)
    logger.info("Data aggregated at claim, loss, dealer level...")

    # Calculate on fly features:
    fe_on_fly_output = calculate_on_fly_features(
        aggregated_data, staking_task_output_df
    )
    logger.info("On fly features engineering is done...")

    # Match exact same schema and column order:
    fe_output = generate_output_claim_level(fe_on_fly_output)
    logger.info("ML engine schema matching step is done...")

    # Save interim output to s3:
    file_name_output = interim_tables_config["file_name"]["feature_engineering"]

    save_intermediate_daily_files_s3(
        df=fe_output,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )
