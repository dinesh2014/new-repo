from functools import wraps
import json
import time
import logging

import os
import glob
import shap
import pickle


import numpy as np
import pandas as pd

from matplotlib import pyplot as plt

from databricks.sdk.runtime import *
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, expr, to_date, when
from pyspark.sql.types import StringType

from pyspark.sql.utils import AnalysisException, IllegalArgumentException
from py4j.protocol import Py4JJavaError

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)


def haversine(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance between one point on the earth
    (lat1, lon1) and an array of points (lat2, lon2).

    Parameters:
    - lat1, lon1: Latitude and Longitude of the reference point (in decimal degrees)
    - lat2, lon2: Pandas Series or array-like, Latitude and Longitude of comparison points (in decimal degrees)

    Returns:
    - distances: Pandas Series with the distance between the reference point and each comparison point, in miles.
    """
    # Convert decimal degrees to radians
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])

    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    c = 2 * np.arcsin(np.sqrt(a))

    # 3959 miles is the radius of the Earth
    miles = 3959 * c
    return miles


def area_features_near_dealer(dealer, geo, features_actions, radius):
    distances_full = haversine(
        dealer["latitude"],
        dealer["longitude"],
        geo["geo_latitude"],
        geo["geo_longitude"],
    )
    nearby = geo.loc[distances_full <= radius, [*features_actions]]
    return nearby.agg(features_actions)


def generate_sql_list(list_: list) -> str:
    """Function that return an inside list value concatenation, to be used as a
    sql query input.

    :param list_:
    :return:
    """

    str_list = ", ".join(map(lambda x: f"'{x}'", list_))

    return str_list


def shap_summary(
    x_test: pd.DataFrame,
    shap_values: np.ndarray,
    feature_name,
    features_include,
):
    X = x_test.copy()

    label = f"Feature {feature_name}"
    logger.info(label)
    file_label = f"{feature_name}"
    file_name = f"SUMMARY_{file_label}_shap.png"
    plt.ioff()
    plt.figure()

    # Get al index numbers
    feature_indexes = [X.columns.get_loc(feature) for feature in features_include]
    if isinstance(shap_values, list):
        filtered_shaps = [values[:, feature_indexes] for values in shap_values]
    else:
        filtered_shaps = shap_values[:, feature_indexes]

    filtered_X = X[features_include]
    shap.summary_plot(filtered_shaps, filtered_X, show=False)
    plt.title(feature_name)
    plt.savefig(
        f"../data/processed/shap_analysis/{file_name}", bbox_inches="tight", dpi=300
    )
    plt.close()
    plt.ion()


def apply_hot_encoding(df: pd.DataFrame, cols: list[str]):
    """Function used to Hot-Encode categorical features in Wide format."""
    data = df.copy()

    # Implement hot encoding for non-ordinal features:
    data_hot_encoded = pd.get_dummies(data, columns=cols)

    return data_hot_encoded


def load_specific_model(pickle_file_path, model_key):
    """Load a specific model from a pickle file.

    Parameters:
    - pickle_file_path: str, the path to the pickle file.
    - model_key: str, the key corresponding to the model to load.

    Returns:
    - The requested model object if found; None otherwise.
    """
    try:
        with open(pickle_file_path, "rb") as file:
            models_dict = pickle.load(file)
            if model_key in models_dict:
                logger.info("Model %s loaded successfully.", model_key)
                return models_dict[model_key]
            else:
                logger.warning("Model %s not found in the file.", model_key)
                return None
    except FileNotFoundError:
        logger.warning("Pickle file not found.")
        return None
    except Exception as e:
        logger.warning("An error occurred while loading the model: %s", e)
        return None


def read_parquet(file_path, cols=None, value_filter=None):
    if (cols != None) & (value_filter != None):
        spark_df = spark.read.parquet(file_path).filter(value_filter).select(cols)
    elif (cols != None) & (value_filter == None):
        spark_df = spark.read.parquet(file_path).select(cols)
    elif (cols == None) & (value_filter != None):
        spark_df = spark.read.parquet(file_path).filter(value_filter)
    else:
        spark_df = spark.read.parquet(file_path)
    return spark_df


def generate_benchmark(
    df_input: F.DataFrame,
    group_by: list[str],
    benchmark_metrics: list[str],
    pre_comp_level: str,
):
    # List of quantiles to calculate
    quantiles = [0.75, 0.90, 0.95]

    # Create a dictionary to hold the aggregation expressions using the percentile_approx function directly
    expressions = [
        expr(
            f"percentile_approx({column}, array({', '.join(map(str, quantiles))}))[0] AS {column}_{int(quantile * 100)}"
        )
        for column in benchmark_metrics
        for quantile in quantiles
    ]

    # Group by the specified columns and aggregate using the expressions
    distribution = df_input.groupBy(*group_by).agg(*expressions)

    # Add pre-compute metric level
    distribution = distribution.withColumn(pre_comp_level, lit(pre_comp_level))

    return distribution


def flatten_json(json_data):
    """Flatten JSON data into a dictionary with flattened keys."""

    # Extract claims
    claims_data = json_data["claims"]

    # Create DataFrame for claims
    df_claims = pd.DataFrame(claims_data)

    # Repeat other information for the number of claims
    num_claims = len(claims_data)
    other_info = {
        key: [json_data[key]] * num_claims for key in ("dealer", "customer", "contract")
    }

    # Concatenate all DataFrames along columns
    api_contract_df = pd.concat(
        [df_claims] + [pd.DataFrame(other_info[i]) for i in other_info.keys()], axis=1
    )

    return api_contract_df


def retrieve_api_contract(json_path) -> pd.DataFrame:
    """Function used to retrieve and set API contract into dataframe for quick
    manipulation."""

    # Retrieve API contract:

    # Open the JSON file and load its contents
    with open(json_path, "r") as file:
        api_contract = json.load(file)

    # Convert JSON into dataframe:
    contract_df = flatten_json(api_contract)

    sdf = spark.createDataFrame(contract_df)

    return sdf


def format_contract_sdf(contract_sdf):
    """This function is used to clean up data format for contract sdf."""
    # Convert date string to date in sdf
    contract_sdf = contract_sdf.withColumn(
        "dtdate_loss_occurred", to_date(col("dtdate_loss_occurred"), "dd-MM-yyyy")
    )
    # contract_sdf = contract_sf.withColumn("sloss_code",
    #                                      col("sloss_code").cast("integer"))
    return contract_sdf


def generate_threshold_flag_greater(df: F.DataFrame, feat: str, threshold: float):
    df = df.withColumn(feat + "_threshold", F.lit(threshold)).withColumn(
        feat + "_flag", F.when(df[feat] > threshold, 1).otherwise(0)
    )
    return df


def generate_threshold_flag_smaller(df: F.DataFrame, feat: str, threshold: float):
    df = df.withColumn(feat + "_threshold", F.lit(threshold)).withColumn(
        feat + "_flag", F.when(df[feat] < threshold, 1).otherwise(0)
    )
    return df


def save_output(df, output_path, partition_ls):
    df.write.partitionBy(*partition_ls or []).parquet(output_path, mode="overwrite")
    # df.wirte.format("parquet").mode("overwrite").partitionBy(*partition_ls or []).save(output_path)


def haversine(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance between one point on the earth
    (lat1, lon1) and an array of points (lat2, lon2).

    Parameters:
    - lat1, lon1: Latitude and Longitude of the reference point (in decimal degrees)
    - lat2, lon2: Pandas Series or array-like, Latitude and Longitude of comparison points (in decimal degrees)

    Returns:
    - distances: Pandas Series with the distance between the reference point and each comparison point, in miles.
    """
    # Convert decimal degrees to radians
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])

    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    c = 2 * np.arcsin(np.sqrt(a))

    # 3959 miles is the radius of the Earth
    miles = 3959 * c
    return miles


def area_features_near_dealer(dealer, geo, features_actions, radius):
    distances_full = haversine(
        dealer["latitude"],
        dealer["longitude"],
        geo["geo_latitude"],
        geo["geo_longitude"],
    )
    nearby = geo.loc[distances_full <= radius, [*features_actions]]
    return nearby.agg(features_actions)


def load_shapefile(filepath):
    """Load a shapefile into a GeoDataFrame.

    Args:
    filepath (str): The file path to the .shp file of the shapefile.

    Returns:
    GeoDataFrame: A GeoDataFrame containing the geometry and attributes of the shapefile.
    """
    import geopandas as gpd

    # Load the shapefile
    gdf = gpd.read_file(filepath)

    # Display the first few rows to show attributes and geometry
    logger.info("Preview of the GeoDataFrame:")
    logger.info(gdf.head())
    
    return gdf


def save_single_file(df, output_path, file_format="json"):
    """This function saves a single parquet file from a dataframe.

    The output path requires to have .parquet extension at the end.
    """

    # Get the output folder from full output path
    output_folder = output_path.replace(f".{file_format}", "")

    # Make sure single partition for the output file
    if file_format == "json":
        df.fillna("").repartition(1).write.format(file_format).mode("overwrite").option(
            "ignoreNullFields", False
        ).save(output_folder)
    elif file_format == "csv":
        df.repartition(1).write.format(file_format).option("delimiter", "|").option(
            "header", "true"
        ).mode("overwrite").save(output_folder)

    else:
        df.repartition(1).write.format(file_format).mode("overwrite").save(
            output_folder
        )

    # Rename the output Parquet file
    part_files = glob.glob(f"{output_folder}/part-*.{file_format}")

    if part_files:
        os.rename(part_files[0], output_path)
        logger.info("Single output file was saved.")
    else:
        logger.warning("No part files found to rename.")


def spark_get_dummies(df):

    # Get string columns
    start_time = time.time()
    string_columns = [
        field.name
        for field in df.schema.fields
        if isinstance(field.dataType, StringType)
    ]
    logger.info(
        "****** Time to get string_columns: %s seconds *****", time.time() - start_time
    )

    # Get non-string columns
    start_time = time.time()
    keys = list(set(df.columns) - set(string_columns))
    logger.info("****** Time to get keys: %s seconds *****", time.time() - start_time)

    # Create one-hot encoding expressions for each distinct value in string columns
    start_time = time.time()
    expressions = []
    for col_name in string_columns:
        distinct_values = df.select(col(col_name)).distinct().collect()
        for val_row in distinct_values:
            val = val_row[0]
            expressions.append(
                when(col(col_name) == val, 1).otherwise(0).alias(f"{col_name}_{val}")
            )
    logger.info(
        "****** Time to get expressions: %s seconds *****", time.time() - start_time
    )

    # Select non-string columns and one-hot encoded columns
    start_time = time.time()
    df_final = df.select(keys + expressions)
    logger.info(
        "****** Time to get df_final: %s seconds *****", time.time() - start_time
    )

    return df_final


def loading_temporal_views(
    table_name: str,
    cols_to_pull: list,
    value_filter: str,
    spark: object,
):
    """Auxiliar function used to load a temporal table created and loaded into
    cluster to speed up computation."""

    # Define SQL query statement:

    sql_query = f"""
    SELECT DISTINCT {', '.join(cols_to_pull)}
    FROM global_temp.{table_name}
    WHERE {value_filter}
    """
    # Import table into process:
    temp_table = spark.sql(sql_query)

    return temp_table


def save_intermediate_daily_files_s3(
    df: F.DataFrame,
    s3_bucket: str,
    date_folder: str,
    job_run_id: str,
    file_name: str,
):
    """Function used to save intermediate files into S3 bucket."""
    # Construct the full path to the file
    file_path = s3_bucket + f"/{date_folder}/{job_run_id}/{file_name}"

    try:

        start_time = time.time()

        # Save dataframe into S3:
        df.write.mode("overwrite").option("compression", "snappy").parquet(file_path)
        logger.info(
            f"Elapsed time for save {file_name} intermediate file: %s seconds",
            time.time() - start_time,
        )

    except AnalysisException as e:
        # Handle file not found or incorrect path errors
        if "Path does not exist" in str(e):
            logger.warning("Error: The file %s does not exist.", file_path)
        else:
            logger.warning("AnalysisException error occurred: %s", e)

        # Re rise the error:
        raise AnalysisException

    except Py4JJavaError as e:
        if "Insufficient privileges" in str(e):
            logger.warning(
                "Error: Insufficient privileges for accessing %s. Check permissions.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise Py4JJavaError

    except IllegalArgumentException as e:
        # Handle various PySpark argument errors (possibly including S3 authentication issues)
        if "Unable to find the catalog" in str(e):
            logger.warning(
                "Error: Authentication failed for accessing %s. Check your credentials.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise IllegalArgumentException

    except Exception as e:
        # Handle other exceptions
        logger.warning("An unexpected error occurred: %s", e)

        # Re rise the error:
        raise Exception


def load_intermediate_daily_files_s3(
    s3_bucket: str, date_folder: str, job_run_id: str, file_name: str, spark: object
):
    """Function used to load intermediate files from S3 bucket."""

    # Construct the full path to the file
    file_path = s3_bucket + f"/{date_folder}/{job_run_id}/{file_name}"

    try:

        # Try to read the parquet file
        loaded_table = spark.read.parquet(file_path)

        return loaded_table

    except AnalysisException as e:
        # Handle file not found or incorrect path errors
        if "Path does not exist" in str(e):
            logger.warning("Error: The file %s does not exist.", file_path)
        else:
            logger.warning("AnalysisException error occurred: %s", e)

        # Re rise the error:
        raise AnalysisException

    except Py4JJavaError as e:
        if "Insufficient privileges" in str(e):
            logger.warning(
                "Error: Insufficient privileges for accessing %s. Check permissions.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise Py4JJavaError

    except IllegalArgumentException as e:
        # Handle various PySpark argument errors (possibly including S3 authentication issues)
        if "Unable to find the catalog" in str(e):
            logger.warning(
                "Error: Authentication failed for accessing %s. Check your credentials.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise IllegalArgumentException

    except Exception as e:
        # Handle other exceptions
        logger.warning("An unexpected error occurred: %s", e)

        # Re rise the error:
        raise Exception


def timing(f):
    @wraps(f)
    def wrap(*args, **kw):
        ts = time.time()
        result = f(*args, **kw)
        te = time.time()
        logger.debug(
            "------------------------TIME CALCULATION FOR FUNCTION:%r TOOK: %2.4f sec -----------------------",
            f.__name__,
            te - ts,
        )
        return result

    return wrap


def add_missing_columns(df, columns):
    """Adds missing columns to a DataFrame and fills them with NaN values.

    Parameters:
        df (spark.DataFrame): The DataFrame to which missing columns will be added.
        columns (list): A list of column names to be added if they are not already present.

    Returns:
        spark.DataFrame: The DataFrame with missing columns added and filled with NaN values.
    """

    existing_columns = df.columns
    columns_to_add = [col for col in columns if col not in existing_columns]

    if columns_to_add:
        for col_name in columns_to_add:
            df = df.withColumn(
                col_name, F.lit(float("nan"))
            )  # Assuming NaN values are desired

    return df.select(columns)


def trim_all_string_columns(df):
    new_cols = []
    for field in df.schema.fields:
        if isinstance(field.dataType, StringType):
            new_cols.append(F.trim(F.col(field.name)).alias(field.name))
        else:
            new_cols.append(F.col(field.name))
    df = df.select(*new_cols)
    return df


def create_claim_flag_computation(
    df,
    col_name: str,
    new_col_name: str,
):
    """Function used to set the maximum value (flag) across loss codes to
    capture flags at claim level."""

    # Step 1: Aggregate to check if at least one record has a 1
    max_value = df.agg(
        F.max(F.when(F.col(col_name) == 2, 0).otherwise(F.col(col_name)))
    ).collect()[0][0]

    # Step 2: Add a new column with the result
    df_with_new_column = df.withColumn(
        f"{new_col_name}", lit(1 if max_value == 1 else 0)
    )

    return df_with_new_column
