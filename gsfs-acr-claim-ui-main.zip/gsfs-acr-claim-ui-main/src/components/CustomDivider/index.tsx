export { default } from "./CustomDivider";
