import { describe, it, expect, afterEach } from "vitest";
import { Card } from "@nextui-org/react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";

import MainCardBody, { MainCardBodyProps } from "./MainCardBody";

describe("MainCardBody component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Open highlight modal on click", () => {
    const props: MainCardBodyProps = {
      open: true,
      checks: {
        passed: [{ title: "Titulo", description: "A description" }],
        failed: [],
      },
    };
    render(
      <Card>
        <MainCardBody {...props} />
      </Card>,
    );

    const checkButton = screen.getByTestId("passed_check_0");

    expect(checkButton).toBeInTheDocument();
    fireEvent.click(checkButton);
    expect(screen.getByTestId("modal")).toBeInTheDocument();
  });
});
