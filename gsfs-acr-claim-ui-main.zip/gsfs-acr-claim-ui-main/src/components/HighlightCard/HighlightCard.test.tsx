import { describe, it, expect, afterEach } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";

import HighlightCard, { HighlightCardProps } from "./HighlightCard";

describe("HighlightCard component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Should render HighlightCard component", () => {
    const props: HighlightCardProps = {
      section: "A section",
      highlight: "A highlight",
      title: "Customer",
      secondary: false,
    };
    render(<HighlightCard {...props} />);
    
    expect(screen.getByTestId("highlight_card")).toBeInTheDocument();
  });

  it("Should open/close modal on HighlightCard header button click when it has checks", () => {
    const props: HighlightCardProps = {
      section: "A section",
      highlight: "A highlight",
      title: "Customer",
      secondary: false,
      checks: {
        passed: [
          {
            title: "Some title",
            description: "Some description",
          },
        ],
        failed: [],
      },
    };
    render(<HighlightCard {...props} />);

    // expect(screen.getByTestId("highlight_card_button")).toBeInTheDocument();

    const mainCard = screen.getByTestId("main_card__body");
    const button = screen.getByTestId("highlight_card_button");
  
    expect(mainCard.ariaHidden).equals("true");
    fireEvent.click(button);
    expect(mainCard.ariaHidden).equal("false");
    fireEvent.click(button);
    expect(mainCard.ariaHidden).equal("true");
  });
});
