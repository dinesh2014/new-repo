import { ReactNode } from "react";
import clsx from "clsx";

/**
 * Props for the SideBar component.
 */
interface SideBarProps {
  open: boolean;
  hideOverlay?: boolean;
  onClose?: () => void;
  children: ReactNode;
}

/**
 * Renders a sidebar component.
 *
 * @component
 * @param {SideBarProps} props - The component props.
 * @param {boolean} props.open - Determines if the sidebar is open or closed.
 * @param {ReactNode} props.children - The content to be rendered inside the sidebar.
 * @param {boolean} [props.hideOverlay=false] - Determines if the overlay should be hidden.
 * @param {Function} props.onClose - The function to be called when the sidebar is closed.
 * @returns {JSX.Element} The rendered sidebar component.
 */
const SideBar = ({
  open,
  children,
  hideOverlay = false,
  onClose,
}: SideBarProps) => {
  return (
    <>
      {open && !hideOverlay && (
        <button
          data-testid="overlay"
          onClick={onClose}
          onKeyDown={onClose}
          className="bg-black z-30 fixed inset-0 opacity-60"
        />
      )}
      <aside
        data-testid="sidebar"
        className={clsx(
          "fixed inset-0 z-30 w-64 bg-slate-500 transition-all ease-in-out duration-300 transform",
          `${open ? "translate-x-0" : "-translate-x-full"}`,
        )}
      >
        {children}
      </aside>
    </>
  );
};

export default SideBar;
