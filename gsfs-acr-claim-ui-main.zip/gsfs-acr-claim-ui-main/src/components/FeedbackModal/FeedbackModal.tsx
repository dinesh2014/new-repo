import {
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Textarea,
  Divider,
} from "@nextui-org/react";
import { useEffect, useState } from "react";
import {
  FeedbackObjProps,
  FeedbackDataProps,
} from "../../api/core/post-feedback";
import Globals from "../../globals";
import { initialFeedbackData } from "../../utils/constants";

/**
 * Props for the FeedbackModal component.
 */
export interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenChange: () => void;
  isPending: boolean;
  isSuccess: boolean;
  onSubmit: (finalFeedbackData: FeedbackDataProps) => void;
  claimNumber: string;
  iproduct_type_id: number;
}

/**
 * FeedbackModal component displays a modal for users to provide feedback.
 *
 * @component
 * @param {FeedbackModalProps} props - The component props.
 * @param {Function} props.onOpen - Callback function to handle modal open event.
 * @param {boolean} props.isOpen - Determines whether the modal is open or closed. Default is `false`.
 * @param {Function} props.onClose - Callback function to handle modal close event.
 * @param {Function} props.onOpenChange - Callback function to handle modal open/close event.
 * @param {boolean} props.isPending - Determines whether the feedback submission is pending.
 * @param {boolean} props.isSuccess - Determines whether the feedback submission is successful.
 * @param {boolean} props.isError - Determines whether the feedback submission is error or not.
 * @param {Function} props.onSubmit - Callback function to handle feedback submission.
 * @param {string} props.claimNumber - The claim number associated with the feedback.
 * @param {number} props.iproduct_type_id - The product associated with the claim.
 * @returns {JSX.Element} The FeedbackModal component.
 */
const FeedbackModal = ({
  isOpen = false,
  onClose,
  onOpenChange,
  isPending,
  isSuccess,
  onSubmit,
  claimNumber,
  iproduct_type_id,
}: FeedbackModalProps) => {
  const [feedbackData, setFeedbackData] = useState(initialFeedbackData);
  

  const handleTextInput = (index: number, textValue: string) => {
    setFeedbackData((prevFeedbackData) => {
      const updatedFeedbackData = [...prevFeedbackData];
      updatedFeedbackData[index].text = textValue;
      return updatedFeedbackData;
    });
  };

  useEffect(() => {
    if (iproduct_type_id == 8) {
      const updatedFeedbackData = feedbackData;
      updatedFeedbackData[3].visible = false;
      setFeedbackData(updatedFeedbackData);
    }
  }, []);

  const feedbackIsReadyToSubmit = feedbackData.some(
    (item: FeedbackObjProps) =>
      item.type && item.text && item.visible && item.order,
  );

  let buttonColor: "secondary" | "primary" | "default" | "success" | "warning" | "danger" | undefined;
  if (isPending) {
    buttonColor = "secondary";
  } else if (feedbackIsReadyToSubmit) {
    buttonColor = "primary";
  } else {
    buttonColor = "default";
  }

  function transformArrayToObject(arr: FeedbackObjProps[]) {
    const result: { [key: string]: string | boolean } = {
      claim_id: claimNumber,
      user_email: Globals.user || "undefined@email.com",
      thumbs_up_flag: false,
      thumbs_down_flag: true,
    };
    arr.forEach((item: FeedbackObjProps) => {
      result[`feedback_type_${item.order}`] = item.type;
      result[`feedback_text_${item.order}`] = item.text;
    });
    return result;
  }

  const onSubmitFeedback = () => {
    const finalFeedbackData = transformArrayToObject(feedbackData);
    onSubmit(finalFeedbackData);
  };

  useEffect(() => {
    if (isSuccess) {
      onClose();
    }
  }, [isSuccess]);

  return (
    <Modal
      size="lg"
      isOpen={isOpen}
      onOpenChange={onOpenChange}
    >
      <ModalContent>
        <ModalHeader data-testid="feedback_modal__header">
          <span className="text-lg">What did not work for you?</span>
        </ModalHeader>
        <div className="px-6 pb-4">
          <Divider />
        </div>
        <ModalBody>
          {feedbackData
            .filter((feedback) => feedback.visible)
            .map((i, index) => {
              const key = `feedback-${i.type}-${index}`;
              return (
                <Textarea
                  key={key}
                  id={`${i.type}_textarea`}
                  variant="bordered"
                  radius="sm"
                  label={`${i.type}`}
                  onChange={(e) => handleTextInput(index, e.target.value)}
                  maxLength={2000}
                  maxRows={5}
                />
              );
            })}
        </ModalBody>
        <ModalFooter>
          <div className={isPending ? "animate-pulse" : ""}>
            <Button
              data-testid="feedback_modal__submit_button"
              aria-disabled={!feedbackIsReadyToSubmit || isPending}
              variant="flat"
              color={buttonColor}
              disabled={!feedbackIsReadyToSubmit || isPending}
              onClick={onSubmitFeedback}
            >
              {isPending ? "Submitting..." : "Submit"}
            </Button>
          </div>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default FeedbackModal;
