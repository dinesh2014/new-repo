import { useEffect } from "react";
import { toast } from "react-toastify";
import { FaFlag , FaRegThumbsUp} from "react-icons/fa6";
import clsx from "clsx";
import {
  Avatar,
  ModalContent,
  ModalBody,
  ModalFooter,
  Button,
  Divider,
} from "@nextui-org/react";
import { useMutation } from "@tanstack/react-query";
import {
  FeedbackDataProps,
  postFeedback,
} from "../../api/core/post-claire-feedback";

/**
 * Component for rendering the Part Loss section.
 * @param {Object} agent1Query - The query result for agent 1.
 * @param {Function} mutation - The mutation function for submitting feedback.
 * @param {Function} submitFeedback - The function for submitting feedback.
 * @returns {JSX.Element} JSX element representing the Part Loss section.
 */
const PartLoss = ({ agent1Query, submitFeedback }: any) => {
  const data = agent1Query.data;

  const get_recommendation = (item: any, recommendation: string) => {
    if (recommendation === "category_does_not_match") {
      const {
        predicted_loss_category,
        assigned_loss_category,
        assigned_loss_code_description,
        assigned_loss_code,
      } = item;
      return (
        <>
          This part may better align to the <b>{predicted_loss_category}</b>{" "}
          Loss Category and <b>may not be needed for this repair</b>.It&apos;s
          currently{" "}
          <b>{assigned_loss_category} - {assigned_loss_code_description} ({assigned_loss_code})</b>
        </>
      );
    }
    if (recommendation === "not_matched") {
      const {
        predicted_loss_category,
        assigned_loss_category,
        assigned_loss_code_description,
        assigned_loss_code,
      } = item;
      return (
        <>
          This part may better align to the <b>{predicted_loss_category}</b>{" "}
          Loss Category and <b>may not be needed for this repair</b>. It&apos;s
          currently{" "}
          <b>
            {assigned_loss_category} - {assigned_loss_code_description} (
            {assigned_loss_code})
          </b>
        </>
      );
    }
    if (recommendation === "predicted_loss_code_not_covered") {
      const {
        predicted_loss_code,
        predicted_loss_category,
        assigned_loss_code,
        assigned_loss_code_description,
        assigned_loss_category,
      } = item;
      return (
        <>
          This part may better align to{" "}
          <b>
            {`${predicted_loss_code} - ${predicted_loss_category}`}
          </b>{` and therefore <b>not be covered</b> under this plan. It&apos;s
          currently`}
          
          <b>{`${assigned_loss_category} - ${assigned_loss_code_description} ${assigned_loss_code}`}</b>
        </>
      );
    }
  };

  return (
    <div
      id="part-loss-mapping-section"
      className="grid grid-flow-row auto-rows-max gap-2 w-full"
    >
      <p
        id="part-loss-mapping-section-title"
        className="text-2xl font-bold"
      >
        Part to Loss Category/Code mapping
      </p>
      {data.claim_event_part_details.map((item: any) => {
        return (
          <div
            id="part-loss-items"
            key={item.claim_event_part_details_id + " | " + item.part_number}
            className="grid grid-flow-row auto-rows-max gap-2"
          >
            <div
              id="title-code"
              className="grid grid-flow-col gap-2 justify-start"
            >
              <p className="text-lg font-bold capitalize text-gsfs-blue-800">
                {item.part_description}
              </p>
              <p className="text-lg font-bold text-gsfs-blue-800">
                {"(#" + item.part_number + ")"}
              </p>
            </div>
            <div
              id="row"
              className="grid grid-flow-col gap-2 justify-between items-center"
            >
              <div
                id="fields-row"
                className="grid grid-cols-8 gap-2 border-s-4 border-gsfs-blue-800 w-full"
              >
                <div
                  id="feedback_button"
                  className={clsx(
                    "col-span-6 ps-2",
                    "border-s-1 border-slate-300 h-full ps-4",
                  )}
                >
                  {get_recommendation(item, item.recommendation)}
                </div>
              </div>
              <div
                id="feedback_button"
                className={clsx(
                  "col-span-1 ps-2",
                  "border-s-1 border-slate-300 h-full ps-4", //remove to hide border after reinserting item-text rationale part
                )}
              >
                <Button
                  isIconOnly
                  data-testid="feedback_button_thumbsUp"
                  aria-label="approve recommendation"
                  className="rounded-full bg-gsfs-blue-800 shadow-none"
                  onClick={() =>
                    submitFeedback({
                      prediction_id: item.prediction_id,
                      agent_type: 1,
                      is_feedback_thumbs_up: true,
                      user_feedback_text: null,
                    })
                  }
                >
                  <FaRegThumbsUp className="text-white text-xl " />
                </Button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const naFilters = [
  "N/A",
  "n/a",
  "NA",
  "na",
  "Not Applicable",
  "Not applicable",
  "not applicable",
];

/**
 * Component for rendering the Key Observations section.
 * @param {Object} agent2Query - The query result for agent 2.
 * @param {Function} mutation - The mutation function for submitting feedback.
 * @param {Function} submitFeedback - The function for submitting feedback.
 * @returns {JSX.Element} JSX element representing the Key Observations section.
 */
const KeyObservations = ({ agent2Query, submitFeedback }: any) => {
  const data = agent2Query.data;
  return (
    <div
      id="key-observations-section"
      className="grid grid-flow-row auto-rows-max gap-2 w-full"
    >
      <p
        id="ko-section-title"
        className="text-2xl font-bold"
      >
        Key observations and follow-up questions
      </p>
      <div className="grid grid-flow-row auto-rows-max gap-10">
        {data.claim_event_part_details.map((item: any) => {
          const fup_customer = item.follow_up_questions_for_customer;
          const fup_technician = item.follow_up_questions_for_technician;
          const partPrice =
            typeof item.part_price === "number" && item.part_price != 0;
          let classificationChipText = "";
          if (
            item.level_one_classification &&
            !naFilters.includes(item.level_one_classification) &&
            item.level_one_classification !== null
          ) {
            classificationChipText =
              classificationChipText + item.level_one_classification;
          }
          if (
            item.level_two_classification &&
            !naFilters.includes(item.level_two_classification) &&
            item.level_two_classification !== null
          ) {
            classificationChipText =
              classificationChipText + " - " + item.level_two_classification;
          }
          if (
            item.level_three_classification &&
            !naFilters.includes(item.level_three_classification) &&
            item.level_three_classification !== null
          ) {
            classificationChipText =
              classificationChipText + " - " + item.level_three_classification;
          }
          return (
            <div
              id="ko-item"
              key={item.claim_event_part_details_id + " | " + item.part_number}
              className="grid grid-flow-row auto-rows-max gap-2"
            >
              <div
                id="title-code"
                className="grid grid-flow-col gap-2 justify-start items-center"
              >
                <p className="text-lg font-bold capitalize text-gsfs-blue-800">
                  {item.part_description}
                </p>
                <p className="text-lg font-bold text-gsfs-blue-800">
                  {"(#" + item.part_number + ")"}
                </p>
                {partPrice && (
                  <p className="text-lg font-bold text-gray-500">
                    {"($" + item.part_price + ")"}
                  </p>
                )}
                {classificationChipText && (
                  <div className="border-1 border-gsfs-blue-800 lowercase rounded-full bg-gsfs-blue-200 h-min px-2 py-0.5">
                    <p className="text-xs text-gsfs-blue-800">
                      {classificationChipText}
                    </p>
                  </div>
                )}
                {item.contractual_section_confidence_score >= 85 && (
                  <>
                    <FaFlag
                      size={16}
                      className="text-red-500"
                    />
                    <div className="text-xs font-semibold text-gsfs-blue-800 capitalize">
                      High Contractual Exclusion Potential
                    </div>
                  </>
                )}
              </div>
              <div
                id="fields-row"
                className="grid grid-flow-col gap-2 justify-start items-center border-s-4 border-gsfs-blue-800 h-full"
              >
                <div
                  id="fields-row"
                  className="grid grid-flow-row auto-rows-max gap-6 w-full px-6 h-full border-e-1 border-slate-300"
                >
                  <div
                    id="rec-text"
                    className="grid grid-flow-row auto-rows-max"
                  >
                    <p className="font-semibold">Recommendation</p>
                    <p className="text-sm">{item.recommendation}</p>
                  </div>
                  <Divider className="bg-slate-300 h-[1px] w-full" />
                  <div
                    id="fup-questions"
                    className="grid grid-cols-2 h-full gap-6 justify-start w-full"
                  >
                    <div
                      id="fup-customer"
                      className="grid grid-flow-row auto-rows-max h-full border-e-1 border-slate-300 pe-4 gap-1"
                    >
                      <p className="font-semibold">
                        Follow-up questions for customer
                      </p>
                      <div className="list-disc space-y-2">
                        {fup_customer?.map((q: any, index: any) => {
                          const key = `fup_customer-${q}-${index}`;
                          return (
                            <li
                              className="text-sm italic"
                              key={key}
                            >
                              {q}
                            </li>
                          );
                        })}
                      </div>
                    </div>
                    <div
                      id="fup-technician"
                      className="grid grid-flow-row auto-rows-max h-full gap-1"
                    >
                      <p className="font-semibold">
                        Follow-up questions for technician
                      </p>
                      <div className="list-disc space-y-2">
                        {fup_technician?.map((q: any, index: any) => {
                          const key = `fup_technician-${q}-${index}`;
                          return (
                            <li
                              className="text-sm italic"
                              key={key}
                            >
                              {q}
                            </li>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  id="feedback_button"
                  className="ps-2"
                >
                  <Button
                    isIconOnly
                    data-testid="feedback_button_thumbsUp"
                    aria-label="approve recommendation"
                    className="rounded-full bg-gsfs-blue-800 shadow-none"
                    onClick={() =>
                      submitFeedback({
                        prediction_id: item.prediction_id,
                        agent_type: 2,
                        is_feedback_thumbs_up: true,
                        user_feedback_text: null,
                      })
                    }
                  >
                    <FaRegThumbsUp className="text-white text-xl " />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/**
 * Component for rendering the Claire Modal.
 * @param {Object} agent1Query - The query result for agent 1.
 * @param {Object} agent2Query - The query result for agent 2.
 * @returns {JSX.Element} JSX element representing the Claire Modal.
 */
const ClaireModal = ({ agent1Query, agent2Query }: any) => {
  const mutation = useMutation({
    mutationFn: (feedbackData: FeedbackDataProps) => postFeedback(feedbackData),
  });

  /**
   * Function for submitting feedback.
   * @param {FeedbackDataProps} finalFeedbackData - The final feedback data to be submitted.
   */
  const submitFeedback = (finalFeedbackData: FeedbackDataProps) => {
    mutation.mutate(finalFeedbackData);
  };

  /**
   * Function for displaying toast notifications.
   * @param {number} type - The type of notification.
   * @param {string} msg - The message to be displayed.
   */
  const notify = (
    type: "success" | "error" | "warn" | "info",
    msg?: string,
  ) => {
    type === "success" && toast.success(msg ?? "Success!", {});

    type === "error" &&
      toast.error(msg ?? "Something went wrong. Try again later.", {});

    type === "warn" && toast.warn(msg ?? "Warning!", {});

    type === "info" && toast.info(msg ?? "Info!", {});
  };

  useEffect(() => {
    if (mutation.isSuccess) {
      notify("success", "Feedback saved!");
    }
    if (mutation.isError) {
      notify("error", "Something went wrong. Please, try again later.");
    }
  }, [mutation.isSuccess, mutation.isError]);
  return (
    
    <ModalContent className="p-4">
      {(onClose) => (
        <>
          <div className="flex flex-col absolute z-40 top-[-36px] right-[-36px] bg-blue-100 border-2 border-yellow-400 rounded-full w-[92px] h-[92px] absolute cursor-pointer">
            <Avatar
              showFallback
              onClick={onClose}
              fallback={<div className="w-100 h-100">Claire</div>}
              alt="Claire Avatar"
              src="img/claire-avatar-md.jpeg"
              className="w-[88px] h-[88px] bg-blue-100 text-xl"
            />
          </div>
          <ModalBody>
            <div className="grid grid-flow-row auto-rows-max gap-8 justify-items-center">
              <div className="bg-gsfs-blue-200 rounded-lg p-3 w-full">
                <p className="text-md">
                    Hi! I&apos;m <b>Claire</b>, your claims review assistant.
                  {agent1Query.isSuccess || agent2Query.isSuccess
                    ? " Here are my observations:"
                    : " I'm still reviewing the claim. Try again later to see my observations."}
                </p>
              </div>
              {agent1Query.isSuccess && (
                <>
                  <Divider className="bg-slate-300 h-[1px] w-3/5" />
                  <PartLoss
                    agent1Query={agent1Query}
                    submitFeedback={submitFeedback}
                  />
                </>
              )}
              {agent2Query.isSuccess && (
                <>
                  <Divider className="bg-slate-300 h-[1px] w-3/5" />
                  <KeyObservations
                    agent2Query={agent2Query}
                    submitFeedback={submitFeedback}
                  />
                </>
              )}
              <Divider className="bg-slate-300 h-[1px] w-3/5" />
            </div>
          </ModalBody>
          <ModalFooter>
            <Button
              color="default"
              variant="flat"
              className="rounded-full"
              onPress={onClose}
            >
                Close
            </Button>
          </ModalFooter>
        </>
      )}
    </ModalContent>
  );
};

export default ClaireModal;
