import { screen, render, cleanup } from "@testing-library/react";
import { HashRouter } from "react-router-dom";
import { describe, it, expect, afterEach } from "vitest";
import SearchField from "./SearchField";

describe("SearchField component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Should render SearchField component", () => {
    render(
      <HashRouter>
        <SearchField />
      </HashRouter>,
    );
    const input = screen.getByTestId("search_input");
    expect(input).toBeInTheDocument();
  });
});
