import { useState, KeyboardEvent } from "react";
import { Input, InputProps } from "@nextui-org/react";
import { FaMagnifyingGlass , FaBan} from "react-icons/fa6";
import { useNavigate } from "react-router-dom";
import { usePostHog } from "posthog-js/react";

/**
 * Props for the SearchField component.
 */
interface SearchFieldProps extends Omit<InputProps, "children"> {
  navbar?: boolean;
  isLoading?: boolean;
}

/**
 * SearchField component.
 *
 * @component
 * @param {SearchFieldProps} props - The component props.
 * @param {boolean} [props.navbar=false] - Indicates if the search field is used in the navbar.
 * @param {string} [props.size="lg"] - The size of the search field. Possible values: "sm", "md", "lg".
 * @param {boolean} [props.isLoading=false] - Indicates if the search field is in a loading state.
 * @returns {JSX.Element} The rendered SearchField component.
 */
const SearchField = ({
  navbar = false,
  size = "lg",
  isLoading = false,
}: SearchFieldProps): JSX.Element => {
  const posthog = usePostHog();
  const [inputValue, setInputValue] = useState<string>("");
  const navigate = useNavigate();
  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && inputValue.trim()) {
      if (
        typeof inputValue === "string" &&
        /^[A-Za-z0-9]+$/.exec(inputValue)
      ) {
        navigate(`/claim-details/${inputValue}`);
        posthog.capture("search_submit", {
          claim_number: inputValue,
          placement: navbar
            ? "claim details navbar search field"
            : "homepage search field",
        });
      } else {
        setShowError(true);
      }
    }
  };

  const [showError, setShowError] = useState<boolean>(false);

  let innerPadding;

  if (size === "sm") {
    innerPadding = 2.5;
  } else if (size === "md") {
    innerPadding = 3.5;
  } else {
    innerPadding = 4;
  }

  return (
    <Input
      data-testid="search_input"
      disabled={isLoading}
      classNames={{
        inputWrapper: `h-full p-${innerPadding} font-normal rounded-full border text-gray-400 bg-gray-50 dark:bg-gray-100`,
        helperWrapper: "px-4",
        errorMessage: "text-start",
        clearButton: "hover:text-red-600",
        description: "",
      }}
      maxLength={10}
      fullWidth
      size={size}
      isClearable
      onClear={() => {
        setInputValue("");
        setShowError(false);
      }}
      placeholder="Type claim number..."
      description={!navbar && "String format: A123456789"}
      startContent={
        <>
          {showError ? (
            <FaBan color="rgb(248 113 113)" />
          ) : (
            <FaMagnifyingGlass color="inherit" />
          )}
        </>
      }
      value={inputValue}
      isInvalid={showError}
      errorMessage={!navbar && "Please, enter a valid alphanumeric string."}
      onChange={(e) => {
        setInputValue(e.target.value.toUpperCase());
        if (/^[A-Za-z0-9]*$/.test(e.target.value)) {
          setShowError(false);
        } else {
          setShowError(true);
        }
      }}
      onKeyDown={handleKeyDown}
    />
  );
};

export default SearchField;
