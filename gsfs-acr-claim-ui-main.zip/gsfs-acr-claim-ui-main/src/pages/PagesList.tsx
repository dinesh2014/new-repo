/**
 * Represents the props for a page.
 */
export interface PageProps {
  label: string;
  href: string;
  component: string;
  exact: boolean;
}

/**
 * Represents a list of pages with their corresponding properties to be used on SideNav component.
 */
export const pagesList: PageProps[] = [
  /**
   * Represents the "Claim details" page.
   */
  {
    label: "Claim details",
    href: "/claim-details",
    component: "ClaimDetails",
    exact: true,
  },
];
