export { default } from "./ClaimDetails";
