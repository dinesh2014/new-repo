import { describe, it, expect, afterEach } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import {
  QueryClient,
  QueryClientConfig,
  QueryClientProvider,
} from "@tanstack/react-query";
import { act } from "react-dom/test-utils";

import Feedback, { FeedbackProps } from "./Feedback";
import "react-toastify/dist/ReactToastify.css";

const safeReactQueryOptions: QueryClientConfig = {
  defaultOptions: {
    queries: {
      staleTime: 5 * 1000,
      retry: false,
      refetchOnMount: true,
      refetchOnReconnect: false,
      refetchOnWindowFocus: false,
    },
  },
};

const queryClient = new QueryClient(safeReactQueryOptions);

const props: FeedbackProps = {
  claimNumber: "TEST10101",
  placement: "Test placement",
  iproduct_type_id: 8,
};

describe("Feedback component", () => {
  afterEach(() => {
    cleanup();
  });

  it("Should render Feedback", () => {
    render(
      <QueryClientProvider client={queryClient}>
        <Feedback {...props} />
      </QueryClientProvider>,
    );

    const thumbsUpButton = screen.getByTestId("feedback_button_thumbsUp");
    expect(thumbsUpButton).toBeInTheDocument();

    const thumbsDownButton = screen.getByTestId("feedback_button_thumbsDown");
    expect(thumbsDownButton).toBeInTheDocument();
  });

  it("Should open feedback modal on thumbs down button click", () => {
    render(
      <QueryClientProvider client={queryClient}>
        <Feedback {...props} />
      </QueryClientProvider>,
    );

    const thumbsDownButton = screen.getByTestId("feedback_button_thumbsDown");
    act(() => {
      fireEvent.click(thumbsDownButton);
    });

    const modal = screen.getByTestId("feedback_modal__header");
    expect(modal).toBeInTheDocument();
  });
});
