import { FaCircleExclamation } from "react-icons/fa6";

/**
 * Props for the ReminderTag component.
 */
interface ReminderTagProps {
  text: string;
}

/**
 * Represents a reminder tag component.
 *
 * @param {ReminderTagProps} props - The props for the ReminderTag component.
 * @param {string} props.text - The text to be displayed in the reminder tag.
 * @returns {JSX.Element} The rendered ReminderTag component.
 */
const ReminderTag = ({ text }: ReminderTagProps) => {
  return (
    <div className="rounded-full bg-yellow-50 border-red-200 border-1 px-3 py-2 flex flex-row gap-2 items-center">
      <div className="w-4 h-4 flex items-center justify-center rounded-full text-red-500 font-extralight">
        <FaCircleExclamation />
      </div>
      <div className="text-red-600 text-xs text-nowrap tracking-wide">
        {text}
      </div>
    </div>
  );
};

export default ReminderTag;
