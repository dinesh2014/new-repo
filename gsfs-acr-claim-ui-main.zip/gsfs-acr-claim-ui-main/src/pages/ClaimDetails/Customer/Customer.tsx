import GroupedLabeledInfo from "../../../components/GroupedLabeledInfo";
import Section from "../../../layouts/Section";
import { FaCar } from "react-icons/fa6";
import { ClaimProps } from "../../../api/core/get-claim-details";
import { InfoProps } from "../../../components/LabeledInfo/LabeledInfo";

/**
 * Represents the props for the Customer component.
 */
interface CustomerProps {
  claim?: ClaimProps;
  isLoading?: boolean;
}

/**
 * Renders the customer information section of the claim details page.
 *
 * @param {CustomerProps} props - The component props.
 * @param {ClaimProps} props.claim - The claim object containing customer information.
 * @param {boolean} props.isLoading - A boolean indicating whether the data is still loading.
 * @returns {JSX.Element} The JSX element representing the customer information section.
 */


const Customer = ({ claim, isLoading }: CustomerProps) => {
  const formatNumber = (value: number, decimals: number = 2) => {
    const formatter = new Intl.NumberFormat("en-US", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
      useGrouping: true,
    });
    return formatter.format(value);
  };

  // New function to simplify data construction
  const buildGroupedLabeledInfoData = (claim:ClaimProps | undefined, fields:any) => {

    return fields.map(({ label, key, formatAsNumber = false }: { label: string, key: string, formatAsNumber?: boolean })=>{
      let value = "";
      if (formatAsNumber && claim) {
        if (claim[key]) {
          const decimalPlaces = key === "pre_tenure_period" || key === "miles_to_expiration" || key === "days_since_sales" || key === "iodometer_at_time_of_loss" ? 0 : 2;
          value = String(formatNumber(Number(claim[key]), decimalPlaces));
        }
      } else {
        value = claim?.[key] ?? "";
      }
    
      return {
        label,
        value,
      };
    });
  };

  const carDetails = [
    { label: "Make", value: claim?.smake ?? "" },
    { label: "Model", value: claim?.smodel ?? "" },
    { label: "Trim", value: claim?.strim ?? "" },
    {
      label: "Year",
      value: claim?.imodel_year ? String(claim.imodel_year) : "",
    },
    {
      label: "Customer",
      value: `${claim?.scontract_holder_fname ?? ""} ${claim?.scontract_holder_lname ?? ""}`,
    },
  ];

  const contractDetails = buildGroupedLabeledInfoData(claim, [
    { label: "Contract Exp Date", key: "dtcontract_expiration" },
    { label: "Days to Exp", key: "pre_tenure_period", formatAsNumber: true },
    { label: "Miles to Exp", key: "miles_to_expiration", formatAsNumber: true },
    { label: "Days Since Sale", key: "days_since_sales", formatAsNumber: true },
    { label: "Miles Since Sale", key: "iodometer_at_time_of_loss", formatAsNumber: true },
  ]);
  
  return (
    <Section
      id="car-customer-contract-info"
      bordered
      paddingX={6}
      paddingY={4}
    >
      {isLoading ? (
        <div className="animate-pulse">Loading...</div>
      ) : (
        <div className="flex flex-col gap-6">
          <div className="flex flex-row justify-start gap-4">
            <div className="h-100 text-gsfs-sky-900 self-center">
              <FaCar size={24} />
            </div>
            <GroupedLabeledInfo data={carDetails} />
          </div>
          <div className="flex flex-row justify-start gap-4">
            <div className="h-100 text-gsfs-sky-900 self-center">
              <FaCar
                size={24}
                color="transparent"
              />
            </div>
            {contractDetails.map((group:InfoProps, index:any) => (
              <GroupedLabeledInfo key={`${group.label}${index}`} data={[group]} />
            ))}
          </div>
        </div>
      )}
    </Section>
  );
};

export default Customer;
