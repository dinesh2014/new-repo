export { default } from "./Customer";
