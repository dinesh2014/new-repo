import clsx from "clsx";
import {
  Accordion,
  AccordionItem,
  Card,
  CircularProgress,
} from "@nextui-org/react";
import { AxiosError } from "axios";
import ClaimCard from "../../../components/ClaimCard";
import StatusCard from "../../../components/StatusCard";
import Section from "../../../layouts/Section";
import { ClaimProps } from "../../../api/core/get-claim-details";
import { colorsStatus } from "../../../utils/constants";
import React from "react";

/**
 * Props for the Review component.
 */
interface ReviewProps {
  data?: ClaimProps;
  error?: AxiosError;
  isError?: boolean;
  isLoading?: boolean;
  isFailureJobStatus?: boolean;
}

/**
 * Renders the review details section of a claim.
 *
 * @component
 * @param {ReviewProps} props - The component props.
 * @param {ClaimProps} props.claim - The claim object.
 * @param {boolean} [props.isError=false] - Indicates if the fetch returns an error.
 * @param {boolean} [props.isLoading=false] - Indicates if the data is loading.
 * @param {boolean} [props.isFailureJobStatus=false] - Indicates if the job status is a failure.
 * @returns {JSX.Element} The rendered Review component.
 */
const Review = ({
  data,
  error,
  isError = false,
  isLoading = false,
  isFailureJobStatus = false,
}: ReviewProps) => {
  const claim = data?.claim;
  const errorMsg = isError
    ? (error?.response?.data as { detail: string })?.detail
    : null;
  const jobStatusTitle = claim?.overall_recommendation
    ?.toString()
    ?.split(" - ")[0];
  const jobStatusDescription = claim?.overall_recommendation
    ?.toString()
    ?.includes(" - ")
    ? claim?.overall_recommendation?.toString()?.split(" - ")[1]
    : "";
  const productType = claim?.iproduct_type_id;
  const isTW = productType === 8;

  const renderOutdatedClaimCard = () => {
    if (claim?.is_updated === false && !isLoading && !isError) {
      return (
        <Card className="p-4 mb-4 shadow-none rounded-md border-y-4 bg-amber-50 border-amber-200">
          <div className="text-2xl font-bold text-amber-500">
            Attention! This claim has been flagged as outdated.
          </div>
          <div className="text-md">
            The recommendation model is running a new set of data.
          </div>
          <div className="text-md">
            Please review the claim details carefully and wait for the updated
            data.
          </div>
        </Card>
      );
    }
    return null;
  };

  const renderServerErrorCard = () => {
    if (isError && !isLoading) {
      return (
        <Card className="p-4 mb-4 shadow-none rounded-md border-y-4 bg-red-50 border-red-200">
          <div className="text-2xl px-2 font-bold text-red-500">
            Sorry. This request returned a server error.
          </div>
          <div className="text-md pt-2 px-2 text-red-500">
            Please, reach out support or try again later.
          </div>
          <Accordion
            isCompact
            itemClasses={{
              indicator: "text-2xl text-red-500",
            }}
          >
            <AccordionItem
              classNames={{
                subtitle: "text-red-500 text-md",
              }}
              key="1"
              aria-label="Error details"
              subtitle="Expand for more details..."
            >
              {errorMsg}
            </AccordionItem>
          </Accordion>
        </Card>
      );
    }
    return null;
  };

  const renderClaimCard = () => {
    if (!isError && !isLoading) {
      return (
        <div className={isFailureJobStatus ? "col-span-6" : "col-span-2"}>
          <ClaimCard
            claimNumber={claim?.sclaim_number?.toString() ?? ""}
            claimTitle={jobStatusTitle}
            claimSubtitle={jobStatusDescription}
            isFailureJobStatus={isFailureJobStatus}
            iproduct_type_id={claim?.iproduct_type_id || 0}
          />
        </div>
      );
    }
    return null;
  };
  // Function to render a single StatusCard based on provided configuration
  const renderStatusCard = (config: { label: string; statusKey: string; condition: undefined; } | { label: string; statusKey: string; condition: boolean; }) => {
    const { label, statusKey, condition = true } = config;
    if (!condition) return null;

    const statusValue = claim?.[statusKey]?.toString() ?? "";
    const status = colorsStatus[statusValue];

    return (
      <StatusCard
        label={label}
        status={status}
        statusText={isLoading ? "..." : statusValue}
        displayIcon={true}
      />
    );
  };


  const renderStatusCards = () => {
    if (isFailureJobStatus) return null;

    // Configuration for each StatusCard
    const statusCardConfigs = [
      { label: "Coverage Checks", statusKey: "coverage_checks" },
      { label: "Dealer & Customer Checks", statusKey: "dealer_customer_risk" },
      { label: "Breakdown Checks", statusKey: "breakdown_risk", condition: !isTW },
      { label: "Cost Checks", statusKey: "cost_checks" },
    ];

    return (
      <div className="col-span-4">
        <div className="grid grid-rows-7 auto-rows-max gap-2 h-full">
          <div className="row-span-3 font-bold content-center ps-4">
          Claim Review
          </div>
          <div className="row-span-4 content-end">
            <div
              className={clsx(
                "grid",
                isTW ? "grid-cols-3" : "grid-cols-4",
                "min-w-full gap-3 size-full",
              )}
            >
              {statusCardConfigs.map((config, index) => (
                <React.Fragment key={`${config.label}${index}`}>
                  {renderStatusCard(config)}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Section
      id="review-details"
      paddingX={0}
    >
      {isLoading && (
        <div className="flex justify-center items-center">
          <CircularProgress
            color="default"
            className="flex"
          />
          <div className="px-2 text-gray-500 font-xl animate-pulse">
            Fetching data...
          </div>
        </div>
      )}
      {renderOutdatedClaimCard()}
      {renderServerErrorCard()}
      <div className="grid grid-cols-6 min-w-full gap-6">
        {renderClaimCard()}
        {renderStatusCards()}
      </div>
    </Section>
  );
};

export default Review;
