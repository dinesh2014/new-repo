import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import { NextUIProvider } from "@nextui-org/react";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import {
  QueryClient,
  QueryClientConfig,
  QueryClientProvider,
} from "@tanstack/react-query";
import { PostHogProvider, usePostHog } from "posthog-js/react";

import "./index.css";
import Router from "./router";
import Globals from "./globals";

/**
 * Configuration options for safe React Query.
 */
const safeReactQueryOptions: QueryClientConfig = {
  defaultOptions: {
    queries: {
      staleTime: 5 * 1000,
      retry: false,
      refetchOnMount: true,
      refetchOnReconnect: false,
      refetchOnWindowFocus: false,
    },
  },
};

/**
 * The query client used for managing data fetching and caching.
 */
const queryClient = new QueryClient(safeReactQueryOptions);

/**
 * The root element for rendering the React application.
 */
const root = ReactDOM.createRoot(document.getElementById("root")!);

/**
 * The root component of the application.
 *
 * @returns The JSX element representing the application.
 */
function App() {
  // PostHog configs
  const posthog = usePostHog();

  const posthogOptions = {
    api_host: Globals.pubPostHogHost,
    session_recording: {
      maskAllInputs: false,
      maskInputOptions: {
        "password": true,
        "color": false,
        "date": false,
        "datetime-local": false,
        "email": false,
        "month": false,
        "number": false,
        "range": false,
        "search": false,
        "tel": false,
        "text": false,
        "time": false,
        "url": false,
        "week": false,
        "textarea": false,
        "select": false,
      },
    },
  };

  const postHogUserIdentify = Globals.user || "undefined@email.com";

  useEffect(() => {
    posthog.identify(postHogUserIdentify, { email: postHogUserIdentify });
  }, [posthog, postHogUserIdentify]);

  return (
    <React.StrictMode>
      <PostHogProvider
        apiKey={Globals.pubPostHogKey}
        options={posthogOptions}
      >
        <NextUIProvider>
          <QueryClientProvider client={queryClient}>
            <Router />
            <ReactQueryDevtools initialIsOpen={false} />
          </QueryClientProvider>
        </NextUIProvider>
      </PostHogProvider>
    </React.StrictMode>
  );
}

root.render(<App />);
