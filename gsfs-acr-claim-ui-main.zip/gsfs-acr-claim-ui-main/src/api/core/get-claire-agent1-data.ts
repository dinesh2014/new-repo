import axios from "axios";
import Globals from "../../globals";

/**
 * Represents the props for the full details data for a Claire request.
 */
export interface ClaimEventPartDetailsProps {
  claim_event_part_details_id: number;
  part_description: string;
  part_number: string;
  part_price: number;
  assigned_loss_category: string;
  assigned_loss_code: string;
  is_assigned_loss_code_covered: boolean;
  prediction_id: number;
  predicted_loss_category: string;
  predicted_loss_code: string;
  is_predicted_loss_code_covered: boolean;
  prediction_rationale: string;
  prediction_confidence_score: number;
  is_feedback_thumbs_up: boolean;
  user_feedback_text: string;
  is_deleted: boolean;
}

/**
 * Represents the properties and detailed array of a Claire response for agent 1.
 */
export interface Agent1Props {
  id: number;
  claim_number: string;
  claim_event_part_details: ClaimEventPartDetailsProps[];
}

/**
 * Retrieves the details of a claim.
 *
 * @param claimNumber - The claim number.
 * @returns A promise that resolves to Claire Agent 1 response.
 */
export const getClaireAgent1Data = (
  claimNumber: string,
): Promise<Agent1Props> => {
  return new Promise((resolve, reject) => {
    axios
      .get(`${Globals.apiURL}/v1/genai/agent1/${claimNumber}`)
      .then((res) => {
        resolve(res.data);
      })
      .catch((error) => {
        reject( new Error(error.message ?? error));
      });
  });
};
