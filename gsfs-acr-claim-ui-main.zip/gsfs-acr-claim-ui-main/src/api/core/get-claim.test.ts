import { describe, it, expect, vi } from "vitest";
import axios from "axios";
import { getClaims } from "./get-claims";
import Globals from "../../globals";

vi.mock("axios");

describe("getClaims API Route", () => {
  const mockResponse = {
    data: ["claim1", "claim2", "claim3"],
  };

  it("resolves with an array of claims on successful API call", async () => {
    (axios.get as jest.Mock).mockResolvedValue(mockResponse);

    const result = await getClaims();

    expect(result).toEqual(mockResponse.data);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/ids`);
  });

  it("rejects with an error message on API call failure", async () => {
    const errorMessage = "Network Error";
    (axios.get as jest.Mock).mockRejectedValue(new Error(errorMessage));

    await expect(getClaims()).rejects.toThrow(errorMessage);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/ids`);
  });

  it("handles empty response gracefully", async () => {
    (axios.get as jest.Mock).mockResolvedValue({ data: [] });

    const result = await getClaims();

    expect(result).toEqual([]);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/ids`);
  });

  it("handles unexpected response structure gracefully", async () => {
    const unexpectedResponse = { data: { unexpectedKey: "unexpectedValue" } };
    (axios.get as jest.Mock).mockResolvedValue(unexpectedResponse);

    const result = await getClaims();

    expect(result).toEqual(unexpectedResponse.data);
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/ids`);
  });

  it("handles network errors gracefully", async () => {
    const networkError = new Error("Network Error");
    (axios.get as jest.Mock).mockRejectedValue(networkError);

    await expect(getClaims()).rejects.toThrow("Network Error");
    expect(axios.get).toHaveBeenCalledWith(`${Globals.apiURL}/v1/claims/ids`);
  });
});