/**
 * Capitalizes the first letter of a string.
 *
 * @param s - The input string.
 * @returns The input string with the first letter capitalized.
 */
export const capitalizeFirstLetter = (s: string): string => {
  return s[0].toUpperCase() + s.slice(1);
};
