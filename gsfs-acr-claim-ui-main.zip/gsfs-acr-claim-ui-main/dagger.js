import { connect } from "@dagger.io/dagger";
import { fileURLToPath } from "url";

export const test = async (client, dirName) => {
  const root = client.host().directory(dirName, { exclude: ["node_modules/"] });

  return await client
    .container()
    .from("node:21")
    .withExec(["mkdir", "/app"])
    .withFile("/app/package.json", root.file("package.json"))
    .withWorkdir("/app")
    .withExec(["npm", "install"])
    .withDirectory("/app/src", root.directory("src"))
    .withExec(["npm", "run", "test:run"])
    .stdout();
};

// Allows this script to be run directly from command line, with `node dagger.js`
// Modifying `package.json` to include `type = module` is necessary.
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  connect(test);
}
