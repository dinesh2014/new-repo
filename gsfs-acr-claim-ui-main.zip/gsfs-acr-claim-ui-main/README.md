# ACR Claim UI

#### For documentation details and latest updates, check [Confluence](https://fit.atlassian.net/wiki/spaces/TGA/pages/2831777804/Front+End) page.
---
## Local Development

### Setup

Set up `.env` file:

- Make a copy of `.env.example` and name it either `.env.local` or `.env.${runtime_env}` **(runtime_env = development or production or test)**.
- Fill in the variables.

Make sure `node` version is at least 20.12.0.

Run `npm install` to install app dependencies:

```sh
npm install
```

### Running the app

Run the development application:

```sh
npm run dev
```

Navigate to `localhost:5173` to see the App.

### Running code formatter

Run the following command to apply code formatting (ESlint):

```sh
npm run lint:fix
```

### Running tests

Run the following command to run tests (Vitest):

```sh
npm run test:run
```

## With Docker

Development:

```sh
docker-compose up --build
```

Navigate to `localhost:5173` to see the App.

---