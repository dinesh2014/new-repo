import os
from pyspark.storagelevel import StorageLevel
from app.config.base_config import BaseConfig
from app.utils.utils import read_parquet
from app.config.base_config import env_variables
from datetime import datetime
import pyspark.sql.functions as F
from app.config.spark import sparkInitializer

# Loading config file
config_file = BaseConfig.KPI_REFRESHMENT_CONFIG
spark = sparkInitializer.getSparkSession()

benchmark = config_file["benchmark"]
today_date = datetime.now().strftime("%Y-%m-%d")

set_up_config = config_file["set_up_configuration"]
data_sources = set_up_config["data_sources"]
clean_cols = set_up_config["clean_master_cols"]

input_folder = data_sources["input_folder"]
raw_input_folder = data_sources["raw_input_folder"]
intermediate_input_folder = data_sources["intermediate_input_folder"]
input_tables = data_sources["input_tables"]
output_folder = data_sources["output_folder"]
output_tables = data_sources["output_tables"]

selected_cols = config_file["selected_cols"]
customer_level = selected_cols["customer_level"]
initial_cols = selected_cols["initial_cols"]
contract_cols = selected_cols["contract_cols"]
contract_precomp_cols = selected_cols["contract_precomp_cols"]
dealer_precomp_cols = selected_cols["dealer_precomp_cols"]
customer_precomp_cols = selected_cols["customer_precomp_cols"]
dealer_issue_precomp_cols = selected_cols["dealer_issue_precomp_cols"]

part_frequency_table = input_tables["part_frequency_table"]
average_loss_labor_hours = input_tables["average_loss_labor_hours"]
mileage_per_year_segment = input_tables["mileage_per_year_segment"]
geo_features = input_tables["geo_features"]
weather_features = input_tables["weather_features"]
master_clean_table = input_tables["master_clean_table"]
tier_risk_calculation = input_tables["tier_risk_calculation"]


def preload_precompute_tw():
    """Function to preload precomputed metrics for Tire and Wheel (T&W)
    products.

    This function reads various precomputed metrics from parquet files, caches them in memory,
    creates global temporary views for each dataframe, and prints confirmation messages.
    Parameters:
        None
    Returns:
        None
    """
    # Load combo contract - contract + contract level pre compute
    df_contract_car_config = read_parquet(
        input_folder + input_tables["dealer_customer_contract_combo"] + "_tw", None
    )
    df_contract_car_config.persist(StorageLevel.MEMORY_ONLY)
    df_contract_car_config.createOrReplaceGlobalTempView("df_contract_car_config_tw")

    # Force the cache by performing an action
    df_contract_car_config.count()
    print("Cached contract metrics")

    # Load customer
    df_customer = read_parquet(
        input_folder + input_tables["customer_precomp"] + "_tw", customer_precomp_cols
    )
    df_customer.persist(StorageLevel.MEMORY_ONLY)
    df_customer.createOrReplaceGlobalTempView("df_customer_tw")
    df_customer.count()

    print("Cached customer metrics")
    # Load pre-compute make + issue type benchmark/threshold information
    df_make_issue_benchmark_precomp = read_parquet(
        input_folder + input_tables["make_issue_benchmark_precomp"] + "_tw", None
    )
    df_make_issue_benchmark_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_make_issue_benchmark_precomp.createOrReplaceGlobalTempView(
        "df_make_issue_benchmark_precomp_tw"
    )
    df_make_issue_benchmark_precomp.count()

    print("Cached make issue benchmark metrics")

    # Load dealer level metrics
    df_dealer = read_parquet(
        input_folder + input_tables["dealer_precomp"] + "_tw", dealer_precomp_cols
    )
    df_dealer.persist(StorageLevel.MEMORY_ONLY)
    df_dealer.createOrReplaceGlobalTempView("df_dealer_tw")
    df_dealer.count()
    print("Cached dealer metrics")

    # Load dealer issue precompute metrics
    df_dealer_issue_precomp = read_parquet(
        input_folder + input_tables["dealer_issue_precomp"] + "_tw", None
    )
    df_dealer_issue_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_dealer_issue_precomp.createOrReplaceGlobalTempView("df_dealer_issue_precomp_tw")
    df_dealer_issue_precomp.count()

    print("Cached dealer issue metrics")
    # Bring in part + make + issue and part price variation related pre-computed metrics
    df_benchmark_part_make_issue = read_parquet(
        input_folder + input_tables["part_make_issue_benchmark_precomp"] + "_tw", None
    )
    df_benchmark_part_make_issue.persist(StorageLevel.MEMORY_ONLY)
    df_benchmark_part_make_issue.createOrReplaceGlobalTempView(
        "df_benchmark_part_make_issue_tw"
    )
    df_benchmark_part_make_issue.count()
    print("Cached benchmark part make issue metrics")

    df_part_price_deviation_precomp = read_parquet(
        input_folder + input_tables["part_price_deviation_precomp"] + "_tw", None
    )
    df_part_price_deviation_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_part_price_deviation_precomp.createOrReplaceGlobalTempView(
        "df_part_price_deviation_precomp_tw"
    )
    df_part_price_deviation_precomp.count()
    print("Cached part price deviation metrics")

    # Load pre-comp metircs tables for labor rates
    df_labor_rate_deviation_precomp = read_parquet(
        input_folder + input_tables["labor_rate_deviation_precomp"] + "_tw", None
    )
    df_labor_rate_deviation_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_labor_rate_deviation_precomp.createOrReplaceGlobalTempView(
        "df_labor_rate_deviation_precomp_tw"
    )
    df_labor_rate_deviation_precomp.count()
    print("Cached labor rate deviation metrics")

    # Read the claim history table and join in one operation
    df_claim_history = spark.read.parquet(
        input_folder + input_tables["claim_history_table"] + "_tw"
    )
    df_claim_history.persist(StorageLevel.MEMORY_ONLY)
    df_claim_history.createOrReplaceGlobalTempView("df_claim_history_tw")
    df_claim_history.count()
    print("Cached claim history metrics")

    # Load technicain found and customer complaints
    df_tech_found = read_parquet(input_folder + input_tables["tech_found"], None)
    df_tech_found.persist(StorageLevel.MEMORY_ONLY)
    df_tech_found.createOrReplaceGlobalTempView("df_tech_found_tw")
    df_tech_found.count()
    print("Cached tech found metrics")

    df_customer_comp = read_parquet(input_folder + input_tables["customer_comp"], None)
    df_customer_comp.persist(StorageLevel.MEMORY_ONLY)
    df_customer_comp.createOrReplaceGlobalTempView("df_customer_comp_tw")
    df_customer_comp.count()
    print("Cached customer compliants metrics")

    # Load DO dealer list:
    df_do = read_parquet(input_folder + input_tables["do_dealer_list"], None)
    df_do.persist(StorageLevel.MEMORY_ONLY)
    df_do.createOrReplaceGlobalTempView("df_do")
    df_do.count()
    print("Cached DO Dealers metrics")

    # Load state table:
    df_state_precomp = read_parquet(
        input_folder + input_tables["state_precomp"] + "_tw"
    )
    df_state_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_state_precomp.createOrReplaceGlobalTempView("df_state_precomp_tw")
    df_state_precomp.count()
    print("Cached state list")

    all_cols = clean_cols["contracts"] + clean_cols["vin"]
    df_master_clean = read_parquet(
        intermediate_input_folder + master_clean_table
    ).select(*all_cols)
    df_master_clean.persist(StorageLevel.MEMORY_ONLY)
    df_master_clean.createOrReplaceGlobalTempView("df_master_clean")
    df_master_clean.count()
    print("Cached final clean master table")

    # Load tables for T&W parts config for t&W model inference stacking information
    df_contract_parts_config_tw = read_parquet(
        input_folder + "contract_parts_config_tw", None
    )
    df_contract_parts_config_tw.persist(StorageLevel.MEMORY_ONLY)
    df_contract_parts_config_tw.createOrReplaceGlobalTempView(
        "df_contract_parts_config_tw"
    )
    df_contract_parts_config_tw.count()
    print("Cached contract parts config metrics for TW")

    # Load tables for T&W part no mapping
    df_part_no_mapping_tw = read_parquet(input_folder + "part_no_mapping_tw", None)
    df_part_no_mapping_tw.persist(StorageLevel.MEMORY_ONLY)
    df_part_no_mapping_tw.createOrReplaceGlobalTempView("df_part_no_mapping_tw")
    df_part_no_mapping_tw.count()
    print("Cached part code mapping metrics for TW")

    # Load tables for T&W labor rate
    df_labor_rate_deviation_precomp_tw = read_parquet(
        input_folder + "labor_rate_deviation_metrics_tw", None
    )
    df_labor_rate_deviation_precomp_tw.persist(StorageLevel.MEMORY_ONLY)
    df_labor_rate_deviation_precomp_tw.createOrReplaceGlobalTempView(
        "df_labor_rate_deviation_precomp_tw"
    )
    df_labor_rate_deviation_precomp_tw.count()
    print("Cached labor rate deviation metrics for TW")

    # Load tables for T&W fred index
    df_fred_index = read_parquet(input_folder + "fred_index.parquet", None)
    df_fred_index.persist(StorageLevel.MEMORY_ONLY)
    df_fred_index.createOrReplaceGlobalTempView("df_fred_index")
    df_fred_index.count()
    print("Cached fred index metrics for TW")


def preload_precompute():
    """Function to preload precomputed metrics for various data tables.

    This function reads precomputed metrics from parquet files, caches them in memory,
    creates global temporary views for each dataframe, and prints confirmation messages.
    Parameters:
        None
    Returns:
        None
    """
    # Load combo contract - contract + contract level pre compute

    # First remove all perviously cached tables.
    spark.catalog.clearCache()

    df_contract_car_config = read_parquet(
        input_folder + input_tables["dealer_customer_contract_combo"], None
    )
    df_contract_car_config.persist(StorageLevel.MEMORY_ONLY)

    df_contract_car_config.createOrReplaceGlobalTempView("df_contract_car_config")

    # Force the cache by performing an action
    df_contract_car_config.count()
    print("Cached contract metrics")

    # Load customer
    df_customer = read_parquet(
        input_folder + input_tables["customer_precomp"], customer_precomp_cols
    )
    df_customer.persist(StorageLevel.MEMORY_ONLY)
    df_customer.createOrReplaceGlobalTempView("df_customer")
    df_customer.count()

    print("Cached customer metrics")
    # Load pre-compute make + issue type benchmark/threshold information
    df_make_issue_benchmark_precomp = read_parquet(
        input_folder + input_tables["make_issue_benchmark_precomp"], None
    )
    df_make_issue_benchmark_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_make_issue_benchmark_precomp.createOrReplaceGlobalTempView(
        "df_make_issue_benchmark_precomp"
    )
    df_make_issue_benchmark_precomp.count()

    print("Cached make issue benchmark metrics")

    # Load dealer level metrics
    df_dealer = read_parquet(
        input_folder + input_tables["dealer_precomp"], dealer_precomp_cols
    )
    df_dealer.persist(StorageLevel.MEMORY_ONLY)
    df_dealer.createOrReplaceGlobalTempView("df_dealer")
    df_dealer.count()
    print("Cached dealer metrics")

    # Load dealer issue precompute metrics
    df_dealer_issue_precomp = read_parquet(
        input_folder + input_tables["dealer_issue_precomp"], None
    )
    df_dealer_issue_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_dealer_issue_precomp.createOrReplaceGlobalTempView("df_dealer_issue_precomp")
    df_dealer_issue_precomp.count()

    print("Cached dealer issue metrics")
    # Bring in part + make + issue and part price variation related pre-computed metrics
    df_benchmark_part_make_issue = read_parquet(
        input_folder + input_tables["part_make_issue_benchmark_precomp"], None
    )
    df_benchmark_part_make_issue.persist(StorageLevel.MEMORY_ONLY)
    df_benchmark_part_make_issue.createOrReplaceGlobalTempView(
        "df_benchmark_part_make_issue"
    )
    df_benchmark_part_make_issue.count()
    print("Cached benchmark part make issue metrics")

    df_part_price_variation_precomp = read_parquet(
        input_folder + input_tables["part_price_variation_precomp"], None
    )
    df_part_price_variation_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_part_price_variation_precomp.createOrReplaceGlobalTempView(
        "df_part_price_variation_precomp"
    )
    df_part_price_variation_precomp.count()
    print("Cached part price variation metrics")

    df_part_price_deviation_precomp = read_parquet(
        input_folder + input_tables["part_price_deviation_precomp"], None
    )
    df_part_price_deviation_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_part_price_deviation_precomp.createOrReplaceGlobalTempView(
        "df_part_price_deviation_precomp"
    )
    df_part_price_deviation_precomp.count()
    print("Cached part price deviation metrics")

    # Load pre-comp metircs tables for labor rates
    df_labor_rate_deviation_precomp = read_parquet(
        input_folder + input_tables["labor_rate_deviation_precomp"], None
    )
    df_labor_rate_deviation_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_labor_rate_deviation_precomp.createOrReplaceGlobalTempView(
        "df_labor_rate_deviation_precomp"
    )
    df_labor_rate_deviation_precomp.count()
    print("Cached labor rate deviation metrics")

    df_labor_rate_variation_precomp = read_parquet(
        input_folder + input_tables["labor_rate_variation_precomp"], None
    )
    df_labor_rate_variation_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_labor_rate_variation_precomp.createOrReplaceGlobalTempView(
        "df_labor_rate_variation_precomp"
    )
    df_labor_rate_variation_precomp.count()
    print("Cached labor rate variaiton metrics")

    # Load mapping tables
    df_loss_code_mapping = read_parquet(
        input_folder + input_tables["loss_code_mapping"], None
    )
    df_loss_code_mapping.persist(StorageLevel.MEMORY_ONLY)
    df_loss_code_mapping.createOrReplaceGlobalTempView("df_loss_code_mapping")
    df_loss_code_mapping.count()
    print("Cached loss code mapping metrics")

    df_part_no_mapping = read_parquet(
        input_folder + input_tables["part_no_mapping"], None
    )
    df_part_no_mapping.persist(StorageLevel.MEMORY_ONLY)
    df_part_no_mapping.createOrReplaceGlobalTempView("df_part_no_mapping")
    df_part_no_mapping.count()
    print("Cached part code mapping metrics")

    # Read the claim history table and join in one operation
    df_claim_history = spark.read.parquet(
        input_folder + input_tables["claim_history_table"]
    )
    df_claim_history.persist(StorageLevel.MEMORY_ONLY)
    df_claim_history.createOrReplaceGlobalTempView("df_claim_history")
    df_claim_history.count()
    print("Cached claim history metrics")

    # Load technicain found and customer complaints
    df_tech_found = read_parquet(input_folder + input_tables["tech_found"], None)
    df_tech_found.persist(StorageLevel.MEMORY_ONLY)
    df_tech_found.createOrReplaceGlobalTempView("df_tech_found")
    df_tech_found.count()
    print("Cached tech found metrics")

    df_customer_comp = read_parquet(input_folder + input_tables["customer_comp"], None)
    df_customer_comp.persist(StorageLevel.MEMORY_ONLY)
    df_customer_comp.createOrReplaceGlobalTempView("df_customer_comp")
    df_customer_comp.count()
    print("Cached customer compliants metrics")

    # Load DO dealer list:
    df_do = read_parquet(input_folder + input_tables["do_dealer_list"], None)
    df_do.persist(StorageLevel.MEMORY_ONLY)
    df_do.createOrReplaceGlobalTempView("df_do")
    df_do.count()
    print("Cached DO Dealers metrics")

    # Load state table:
    df_state_precomp = read_parquet(input_folder + input_tables["state_precomp"])
    df_state_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_state_precomp.createOrReplaceGlobalTempView("df_state_precomp")
    df_state_precomp.count()
    print("Cached state list")

    # Load average labor request dealer table:
    df_avg_labor_request_dealer = read_parquet(
        input_folder + "avg_labor_request_dealer_table"
    )
    df_avg_labor_request_dealer.persist(StorageLevel.MEMORY_ONLY)
    df_avg_labor_request_dealer.createOrReplaceGlobalTempView(
        "df_avg_labor_request_precomp"
    )
    df_avg_labor_request_dealer.count()
    print("Cached average labor request dealer table")

    # Load dealer issue make model level:
    df_dealer_issue_make_model = read_parquet(
        input_folder + "make_model_mdlyr_dealer_issue_level_metrics"
    )
    df_dealer_issue_make_model.persist(StorageLevel.MEMORY_ONLY)
    df_dealer_issue_make_model.createOrReplaceGlobalTempView(
        "df_dealer_issue_make_model"
    )
    df_dealer_issue_make_model.count()
    print("Cached dealer issue make model level table")

    # Load part frequency:
    df_part_freq = read_parquet(input_folder + part_frequency_table)
    df_part_freq.persist(StorageLevel.MEMORY_ONLY)
    df_part_freq.createOrReplaceGlobalTempView("df_part_freq")
    df_part_freq.count()
    print("Cached part frequency table")

    df_average_loss_labor_hours = read_parquet(input_folder + average_loss_labor_hours)
    df_average_loss_labor_hours.persist(StorageLevel.MEMORY_ONLY)
    df_average_loss_labor_hours.createOrReplaceGlobalTempView(
        "df_average_loss_labor_hours"
    )
    # df_average_loss_labor_hours.count()
    print("Cached average loss labor hours table")

    df_mileage_per_year_segment = read_parquet(input_folder + mileage_per_year_segment)
    df_mileage_per_year_segment.persist(StorageLevel.MEMORY_ONLY)
    df_mileage_per_year_segment.createOrReplaceGlobalTempView(
        "df_mileage_per_year_segment"
    )
    df_mileage_per_year_segment.count()
    print("Cached mielage per year segment table")

    df_weather_features = read_parquet(input_folder + weather_features)
    df_weather_features.persist(StorageLevel.MEMORY_ONLY)
    df_weather_features.createOrReplaceGlobalTempView("df_weather_features")
    df_weather_features.count()
    print("Cached weather features table")

    df_geo_features = read_parquet(input_folder + geo_features)
    df_geo_features.persist(StorageLevel.MEMORY_ONLY)
    df_geo_features.createOrReplaceGlobalTempView("df_geo_features")
    df_geo_features.count()
    print("Cached geo feature table")

    all_cols = clean_cols["contracts"] + clean_cols["vin"]
    df_master_clean = read_parquet(
        intermediate_input_folder + master_clean_table
    ).select(*all_cols)
    df_master_clean.persist(StorageLevel.MEMORY_ONLY)
    df_master_clean.createOrReplaceGlobalTempView("df_master_clean")
    df_master_clean.count()
    print("Cached final clean master table")

    df_tier_risk = read_parquet(tier_risk_calculation)
    df_tier_risk.persist(StorageLevel.MEMORY_ONLY)
    df_tier_risk.createOrReplaceGlobalTempView("df_tier_risk")
    df_tier_risk.count()
    print("Cached tier risk calculation table")

    df_anomaly_threshold = read_parquet(
        input_folder + input_tables["anomaly_threshold"], None
    )
    df_anomaly_threshold.persist(StorageLevel.MEMORY_ONLY)
    df_anomaly_threshold.createOrReplaceGlobalTempView("df_anomaly_threshold")
    df_anomaly_threshold.count()
    print("Cached anomaly threhsold table")

    df_labor_cost_model_params = spark.read.parquet(
        f'{env_variables["base_path"]}/artifacts/ml_models/latest/labor_cost_model.parquet'
    ).persist()
    df_labor_cost_model_params.createOrReplaceGlobalTempView("df_labor_cost_model")
    print("Cached Labor Cost Model Params")

    df_breakdown_model_params = (
        spark.read.parquet(
            f'{env_variables["base_path"]}/artifacts/ml_models/latest/breakdown_master_model.parquet'
        )
        .withColumnRenamed("make", "smake")
        .withColumnRenamed("model", "smodel")
        .persist()
    )
    df_breakdown_model_params.createOrReplaceGlobalTempView("df_breakdown_model")
    print("Cached Breakdown Model Params")


# Create the Dealer Master Table
def create_dealer_master_table():
    """Function to create the dealer master table by joining dealer information
    with dealer issue information.

    This function reads precomputed metrics from global temporary views, joins them, and creates a new global temporary view.
    Parameters:
        None
    Returns:
        None
    """
    # Dealer Info - Join on spayee_no
    dealer_cols = ",".join(dealer_precomp_cols)
    df_dealer = spark.sql(f"""SELECT {dealer_cols} FROM global_temp.df_dealer""")

    # Dealer Issue Info - Join on spayee_no, sloss_code
    threshold_percentile = benchmark["requestor_risk"]["dealer_issue_repair_freq"]
    filtered_cols = ",".join(
        dealer_issue_precomp_cols + [f"dealer_issue_repair_freq_{threshold_percentile}"]
    )
    df_dealer_issue_precomp = spark.sql(
        f"""SELECT {filtered_cols} FROM global_temp.df_dealer_issue_precomp"""
    )

    # Join dealer and dealer issue information
    df_dealer_master = df_dealer.join(
        df_dealer_issue_precomp, on="spayee_no", how="outer"
    )

    # Persist the dataframe in memory and create a global temporary view
    df_dealer_master.persist(StorageLevel.MEMORY_ONLY)
    df_dealer_master.createOrReplaceGlobalTempView("df_dealer_master")


def create_parts_master_table():
    """Function to create the parts master table by joining part benchmark
    information with part price variation information.

    This function reads precomputed metrics from global temporary views, joins them, and creates a new global temporary view.
    Parameters:
        None
    Returns:
        None
    """
    benchmark_qty = benchmark["financial_risk"]["part_individual_count"]

    # Load benchmark part make issue data
    df_benchmark_part_make_issue = spark.sql(
        """SELECT * FROM global_temp.df_benchmark_part_make_issue"""
    ).select(
        "sloss_code",
        "spart_no",
        "smake",
        F.col(f"part_individual_count_{int(benchmark_qty)}").alias(
            "part_individual_count_threshold"
        ),
    )

    # Load part price variation precomputed data
    df_part_price_variation_precomp = spark.sql(
        """SELECT * FROM global_temp.df_part_price_variation_precomp"""
    )

    # Join benchmark part make issue data with part price variation data
    df_parts_master = df_benchmark_part_make_issue.join(
        df_part_price_variation_precomp,
        on=["spart_no", "smake", "sloss_code"],
        how="outer",
    )

    # Persist the dataframe in memory and create a global temporary view
    df_parts_master.persist(StorageLevel.MEMORY_ONLY)
    df_parts_master.createOrReplaceGlobalTempView("df_parts_master")
    df_parts_master.count()


if __name__ == "__main__":
    print("preload for precompute started..")
    preload_precompute()
    print("preload for precompute completed..")
    print("preload for precompute_TW started..")
    preload_precompute_tw()
    print("preload for precompute_TW completed..")
    create_dealer_master_table()
    print("dealer master table created..")
    create_parts_master_table()
    print("parts master table created..")
