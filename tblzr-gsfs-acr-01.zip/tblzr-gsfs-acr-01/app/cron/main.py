from datetime import datetime
from app.cron.preload_precomp import (
    preload_precompute,
    preload_precompute_tw,
    create_dealer_master_table,
    create_parts_master_table,
)


def run_preload_precomp():
    print(f"Cron Job Started at {datetime.now()}")
    preload_precompute()
    preload_precompute_tw()
    create_dealer_master_table()
    create_parts_master_table()
    print(f"Cron Job ended at {datetime.now()}")
