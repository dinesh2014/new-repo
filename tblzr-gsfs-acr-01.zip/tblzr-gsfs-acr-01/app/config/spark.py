from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from datetime import datetime
import os
import sys

os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable
AWS_BUCKET_KEY = os.getenv("AWS_BUCKET_KEY")
AWS_BUCKET_SECRET = os.getenv("AWS_BUCKET_SECRET")
AWS_REGION_NAME = os.getenv("AWS_REGION")


def singleton(class_):
    instances = {}

    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]

    return getinstance


@singleton
class SparkInitializer:
    def __init__(self):
        self.spark = (
            SparkSession.builder.appName("core-engine")
            .config("spark.driver.memory", "64g")
            .config(
                "spark.jars.packages",
                "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262",
            )
            .config("spark.hadoop.fs.s3a.access.key", AWS_BUCKET_KEY)
            .config("spark.hadoop.fs.s3a.secret.key", AWS_BUCKET_SECRET)
            .config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2")
            .config("spark.hadoop.fs.s3a.fast.upload", "true")
            .config("spark.sql.parquet.compression.codec", "snappy")
            .getOrCreate()
        )

    def getSparkSession(self):
        if self.spark is None:
            self.spark = (
                SparkSession.builder.appName("core-engine")
                .config("spark.driver.memory", "64g")
                .config(
                    "spark.jars.packages",
                    "org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262",
                )
                .config("spark.hadoop.fs.s3a.access.key", AWS_BUCKET_KEY)
                .config("spark.hadoop.fs.s3a.secret.key", AWS_BUCKET_SECRET)
                .config(
                    "spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2"
                )
                .config("spark.hadoop.fs.s3a.fast.upload", "true")
                .config("spark.sql.parquet.compression.codec", "snappy")
                .getOrCreate()
            )
        return self.spark


sparkInitializer = SparkInitializer()
print("Config Created Time:", datetime.now().strftime("%H:%M:%S"))
