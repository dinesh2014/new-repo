import os


# TODO: Replace with IAM database access
def get_connection_string():
    username = "sa"
    password = ""
    host = "127.0.0.1"

    return os.environ.get(
        "DB_CONN_STRING", f"postgresql://{username}:{password}@{host}:5432/acr_db"
    )


#  return "postgresql://postgres:devpass@host.docker.internal:5440/acr_db"
