import logging
import os

from app.config.base_config import get_env_variables

# Define the path to save the profile report:
env_vars = get_env_variables()
base_path = f"{env_vars['base_path']}/artifacts/my_logs"


class ExecutionIDFilter(logging.Filter):
    def __init__(self, execution_id):
        super().__init__()
        self.execution_id = execution_id

    def filter(self, record):
        record.execution_id = self.execution_id
        return True


def setup_logger(execution_id: dict):
    """
    Main function to define logger set up.
    """

    # Define the log file path in dbfs:
    logger_results_path = (
        f"{base_path}/{execution_id['date_folder']}/{execution_id['job_run_id']}/"
    )
    # dbfs_log_file = os.path.join(logger_results_path, "inference_app.log")
    dbfs_log_file = logger_results_path + "/inference_app.log"

    # Ensure the directory exists
    os.makedirs(logger_results_path, exist_ok=True)

    formatter = logging.Formatter(
        fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s - execution_id=%(execution_id)s"
    )
    # Set up the logger
    logging.basicConfig(
        level=logging.DEBUG,  # Set the logging level
        handlers=[
            # logging.FileHandler(
            #     dbfs_log_file
            # ),  # Save logs to the specified file in DBFS
            logging.StreamHandler(),  # Also output logs to console
        ],
    )

    # Apply custom formatter to all handlers
    for handler in logging.getLogger().handlers:
        handler.setFormatter(formatter)

    # Add the ExecutionIDFilter to all handlers
    for handler in logging.getLogger().handlers:
        handler.addFilter(ExecutionIDFilter(execution_id))

    # Reduce logging level for third-party libraries
    logging.getLogger("py4j").setLevel(logging.WARNING)
    logging.getLogger("org.apache.spark").setLevel(logging.WARNING)
    # logging.getLogger("databricks.connect").setLevel(logging.WARNING)
    logging.getLogger("IPython").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("tornado").setLevel(logging.WARNING)
    logging.getLogger("boto3").setLevel(logging.CRITICAL)
    logging.getLogger("botocore").setLevel(logging.CRITICAL)
    logging.getLogger("s3transfer").setLevel(logging.CRITICAL)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
