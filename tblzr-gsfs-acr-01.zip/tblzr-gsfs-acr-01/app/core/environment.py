import os
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


@lru_cache
def get_env_filename():
    """
    Retrieves the environment filename based on the value of the "ENV" environment variable.
    If the "ENV" variable is not set, it defaults to "development".
    """
    runtime_env = os.getenv("ENV", "development")
    return f".env.{runtime_env}" if runtime_env else ".env"


class EnvironmentSettings(BaseSettings):
    """
    Represents the settings for the environment.
    """

    ALLOWED_ORIGINS: str = "*"

    model_config = SettingsConfigDict(env_file=get_env_filename())


@lru_cache
def get_env_variables():
    """
    Retrieves the environment variables based on the EnvironmentSettings class.
    """
    return EnvironmentSettings()
