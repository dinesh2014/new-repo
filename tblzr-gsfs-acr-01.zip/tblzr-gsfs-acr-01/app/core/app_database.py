import functools
import logging
import time
import boto3
import os

from sqlalchemy import create_engine, URL, event
from sqlalchemy.orm import Session
from urllib.parse import urlparse

from app.config.database import get_connection_string

logger = logging.getLogger("acr_backend_database")


def get_db():
    with AppDatabase() as conn:
        with conn.session as db:
            return db


class AppDatabase:
    """
    A class representing the application database.

    This class provides methods for interacting with the database.

    Attributes:
        engine: The database engine used for connecting to the database.
        session: The database session used for executing database operations.

    Usage:
        with AppDatabase() as db:
            db.get_something(...)
            db.save_something(...)

    The commands will be executed in a single transaction.

    Don't use outside a context manager, this class is designed to raise errors in this case.
    """

    @property
    def engine(self):
        """
        Returns a SQLAlchemy engine based on the environment.

        Returns:
            sqlalchemy.engine.Engine: The SQLAlchemy engine.
        """

        e = create_engine(get_connection_string())

        @event.listens_for(e, "do_connect")
        def provide_token(dialect, conn_rec, cargs, cparams):
            dburl = urlparse(get_connection_string())
            if not dburl.password and os.getenv("AWS_REGION"):
                cparams["password"] = (
                    boto3.Session()
                    .client("rds")
                    .generate_db_auth_token(dburl.hostname, dburl.port, dburl.username)
                )

        return e

    def __enter__(self):
        """
        Context manager method that is called when entering a 'with' statement.
        Initializes a database session, and begins a transaction.

        Returns:
            self: The current instance of the AppDatabase class.
        """
        self.session = Session(self.engine)
        self.session.__enter__()
        self.session.begin()

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Commits the session if no exception occurred, otherwise rolls back the session.
        """
        if exc_type is None:
            self.session.commit()
        else:
            self.session.rollback()

        self.session.__exit__(exc_type, exc_val, exc_tb)

    def __getattribute__(self, item):
        """
        Override the __getattribute__ method to log the execution time of methods.

        Args:
            item (str): The name of the attribute being accessed.

        Returns:
            The attribute value.

        """
        attr = super().__getattribute__(item)
        if callable(attr) and not item.startswith("_"):
            # If it's a method, wrap it to log execution time
            @functools.wraps(attr)
            def wrapped(*args, **kwargs):
                t0 = time.time()
                ret = attr(*args, **kwargs)
                t1 = time.time()

                logger.info(f"Function {item} took {t1 - t0:.3f} seconds")
                return ret

            return wrapped
        else:
            return attr
