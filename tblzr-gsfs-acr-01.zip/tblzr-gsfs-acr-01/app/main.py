import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Load env configs
from dotenv import load_dotenv

load_dotenv()

from app.core.environment import get_env_variables
from app.config.base_config import BaseConfig

from app.router.tblzr_gsfs_acr_router import acr_inference_router
from app.utils.read_csv import read_csv
from apscheduler.schedulers.background import BackgroundScheduler

from app.cron.preload_precomp import (
    preload_precompute,
    preload_precompute_tw,
    create_dealer_master_table,
    create_parts_master_table,
)
from app.cron.main import run_preload_precomp

# from app.cron import preload_precomp

# message = read_csv("file:///C://Projects//tblzr-gsfs-acr-new//app//dumm_file.csv")
# message.show()

config_file = BaseConfig.KPI_REFRESHMENT_CONFIG
set_up = config_file["set_up_configuration"]
data_sources = set_up["data_sources"]
output_folder = data_sources["output_folder"]
temp_input_folder = data_sources["temp_input_folder"]
output_tables = data_sources["output_tables"]
input_tables = data_sources["input_tables"]

env = get_env_variables()
root_path = os.getenv("SWAGGER_PREFIX", "")
if root_path == "" or root_path is None:
    swagger_url = None
else:
    swagger_url = "/docs"

# TO DO:
# Update the Spark code. Call the class
api = FastAPI(
    title="ACR API",
    version="0.1",
    root_path=root_path,
    redoc_url=None,
    docs_url=swagger_url,
)

api.add_middleware(
    CORSMiddleware,
    allow_origins=env.ALLOWED_ORIGINS,  # Allow requests from this origin (React app)
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

scheduler = BackgroundScheduler()
scheduler.add_job(run_preload_precomp, "cron", hour="6")
scheduler.start()

# Run only once
run_preload_precomp()


# def run_preload_precomp():
#     print("Cron Job Starts")
#     preload_precompute()
#     preload_precompute_tw()
#     create_dealer_master_table()
#     create_parts_master_table()
#     print("Cron Job ends")


def health_check():
    return {"status": "OK"}


@api.get("/")
async def root():
    return health_check()


api.include_router(acr_inference_router, prefix="/v1", tags=["acr_inference_pipeline"])
