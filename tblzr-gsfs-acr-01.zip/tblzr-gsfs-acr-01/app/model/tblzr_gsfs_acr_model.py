from datetime import datetime

from sqlalchemy import String, Integer, DateTime
from sqlalchemy.orm import mapped_column, Mapped

from app.model.base import Base


class JobStatus(Base):
    __tablename__ = "job_status"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    job_id: Mapped[str] = mapped_column(String(20))
    run_id: Mapped[str] = mapped_column(String(20))
    job_status: Mapped[str] = mapped_column(String(50))
    start_time: Mapped[datetime] = mapped_column(DateTime)
    end_time: Mapped[datetime] = mapped_column(DateTime)
    s3_path_output: Mapped[str] = mapped_column(String(300))
    sclaim_number: Mapped[str] = mapped_column(String(20))
    user_id: Mapped[str] = mapped_column(String(32))
