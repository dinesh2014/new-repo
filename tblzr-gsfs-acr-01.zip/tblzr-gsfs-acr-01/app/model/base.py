from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    def as_dict(self):
        return {
            column.name: self.get_model_attr(column)
            for column in self.__table__.columns
        }

    def get_model_attr(self, column):
        return (
            getattr(self, column.name)
            if column.name != "30days_at_selling_dealer_flag"
            else getattr(self, "days_at_selling_dealer_flag")
        )
