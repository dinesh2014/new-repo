API_RETRIES = 3
SECS_BETWEEN_RETRIES = 1
MAX_CONCURRENT_RUNS_RCHD = "maximum_concurrent_runs_reached"
SUCCESS = "success"
PROCESSING_JOB_STATUS = "Processing request for job status against current claim"
PROCESSING_JOB_STATUS_CMPLT = "Processing completed for job status request"
