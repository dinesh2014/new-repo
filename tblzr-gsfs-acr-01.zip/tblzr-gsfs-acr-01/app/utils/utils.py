from functools import wraps
import os
import boto3
import time
import glob
import logging
import pickle

from app.config.spark import sparkInitializer
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, expr, to_date, when
from pyspark.sql.utils import AnalysisException, IllegalArgumentException
from py4j.protocol import Py4JJavaError

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# ingest_aws_bucket_key = os.environ["AWS_BUCKET_KEY"]
# ingest_aws_bucket_secret = os.environ["AWS_BUCKET_SECRET"]
# aws_bucket = os.environ["AWS_BUCKET"]


def read_parquet(file_path, cols=None, value_filter=None):
    # Create SparkSession (run on Databricks):
    spark = sparkInitializer.getSparkSession()
    if (cols != None) & (value_filter != None):
        spark_df = spark.read.parquet(file_path).filter(value_filter).select(cols)
    elif (cols != None) & (value_filter == None):
        spark_df = spark.read.parquet(file_path).select(cols)
    elif (cols == None) & (value_filter != None):
        spark_df = spark.read.parquet(file_path).filter(value_filter)
    else:
        spark_df = spark.read.parquet(file_path)
    return spark_df


def loading_temporal_views(
    table_name: str,
    cols_to_pull: list,
    value_filter: str,
    spark: object,
):
    """Auxiliar function used to load a temporal table created and loaded into
    cluster to speed up computation."""

    # Define SQL query statement:

    sql_query = f"""
    SELECT DISTINCT {', '.join(cols_to_pull)}
    FROM global_temp.{table_name}
    WHERE {value_filter}
    """
    # Import table into process:
    temp_table = spark.sql(sql_query)

    return temp_table


def save_intermediate_daily_files_s3(
    df: F.DataFrame,
    s3_bucket: str,
    date_folder: str,
    job_run_id: str,
    file_name: str,
):
    """Function used to save intermediate files into S3 bucket."""
    # Construct the full path to the file
    file_path = s3_bucket + f"/{date_folder}/{job_run_id}/{file_name}"

    try:

        start_time = time.time()

        # Save dataframe into S3:
        df.write.mode("overwrite").option("compression", "snappy").parquet(file_path)
        logger.info(
            f"Elapsed time for save {file_name} intermediate file: %s seconds",
            time.time() - start_time,
        )

    except AnalysisException as e:
        # Handle file not found or incorrect path errors
        if "Path does not exist" in str(e):
            logger.warning("Error: The file %s does not exist.", file_path)
        else:
            logger.warning("AnalysisException error occurred: %s", e)

        # Re rise the error:
        raise AnalysisException

    except Py4JJavaError as e:
        if "Insufficient privileges" in str(e):
            logger.warning(
                "Error: Insufficient privileges for accessing %s. Check permissions.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise Py4JJavaError

    except IllegalArgumentException as e:
        # Handle various PySpark argument errors (possibly including S3 authentication issues)
        if "Unable to find the catalog" in str(e):
            logger.warning(
                "Error: Authentication failed for accessing %s. Check your credentials.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise IllegalArgumentException

    except Exception as e:
        # Handle other exceptions
        logger.warning("An unexpected error occurred: %s", e)

        # Re rise the error:
        raise Exception


def load_intermediate_daily_files_s3(
    s3_bucket: str, date_folder: str, job_run_id: str, file_name: str, spark: object
):
    """Function used to load intermediate files from S3 bucket."""

    # Construct the full path to the file
    file_path = s3_bucket + f"/{date_folder}/{job_run_id}/{file_name}"

    try:

        # Try to read the parquet file
        loaded_table = spark.read.parquet(file_path)

        return loaded_table

    except AnalysisException as e:
        # Handle file not found or incorrect path errors
        if "Path does not exist" in str(e):
            logger.warning("Error: The file %s does not exist.", file_path)
        else:
            logger.warning("AnalysisException error occurred: %s", e)

        # Re rise the error:
        raise AnalysisException

    except Py4JJavaError as e:
        if "Insufficient privileges" in str(e):
            logger.warning(
                "Error: Insufficient privileges for accessing %s. Check permissions.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise Py4JJavaError

    except IllegalArgumentException as e:
        # Handle various PySpark argument errors (possibly including S3 authentication issues)
        if "Unable to find the catalog" in str(e):
            logger.warning(
                "Error: Authentication failed for accessing %s. Check your credentials.",
                s3_bucket,
            )
        else:
            logger.warning("Argument Error occurred: %s", e)

        # Re rise the error:
        raise IllegalArgumentException

    except Exception as e:
        # Handle other exceptions
        logger.warning("An unexpected error occurred: %s", e)

        # Re rise the error:
        raise Exception


def format_contract_sdf(contract_sdf):
    """This function is used to clean up data format for contract sdf."""
    # Convert date string to date in sdf
    contract_sdf = contract_sdf.withColumn(
        "dtdate_loss_occurred", to_date(col("dtdate_loss_occurred"), "dd-MM-yyyy")
    )
    # contract_sdf = contract_sf.withColumn("sloss_code",
    #                                      col("sloss_code").cast("integer"))
    return contract_sdf


def generate_threshold_flag_greater(df: F.DataFrame, feat: str, threshold: float):
    df = df.withColumn(feat + "_threshold", F.lit(threshold)).withColumn(
        feat + "_flag", F.when(df[feat] > threshold, 1).otherwise(0)
    )
    return df


def generate_threshold_flag_smaller(df: F.DataFrame, feat: str, threshold: float):
    df = df.withColumn(feat + "_threshold", F.lit(threshold)).withColumn(
        feat + "_flag", F.when(df[feat] < threshold, 1).otherwise(0)
    )
    return df


def save_single_file(df, output_path, file_format="json"):
    """This function saves a single parquet file from a dataframe.

    The output path requires to have .parquet extension at the end.
    """

    # Get the output folder from full output path
    output_folder = output_path.replace(f".{file_format}", "")

    # Make sure single partition for the output file
    if file_format == "json":
        df.fillna("").repartition(1).write.format(file_format).mode("overwrite").option(
            "ignoreNullFields", False
        ).save(output_folder)
    elif file_format == "csv":
        df.repartition(1).write.format(file_format).option("delimiter", "|").option(
            "header", "true"
        ).mode("overwrite").save(output_folder)

    else:
        df.repartition(1).write.format(file_format).mode("overwrite").save(
            output_folder
        )

    # Rename the output Parquet file
    part_files = glob.glob(f"{output_folder}/part-*.{file_format}")

    if part_files:
        os.rename(part_files[0], output_path)
        logger.info("Single output file was saved.")
    else:
        logger.warning("No part files found to rename.")


def timing(f):
    @wraps(f)
    def wrap(*args, **kw):
        ts = time.time()
        result = f(*args, **kw)
        te = time.time()
        logger.debug(
            "------------------------TIME CALCULATION FOR FUNCTION:%r TOOK: %2.4f sec -----------------------",
            f.__name__,
            te - ts,
        )
        return result

    return wrap


def add_missing_columns(df, columns):
    """Adds missing columns to a DataFrame and fills them with NaN values.

    Parameters:
        df (spark.DataFrame): The DataFrame to which missing columns will be added.
        columns (list): A list of column names to be added if they are not already present.

    Returns:
        spark.DataFrame: The DataFrame with missing columns added and filled with NaN values.
    """

    existing_columns = df.columns
    columns_to_add = [col for col in columns if col not in existing_columns]

    if columns_to_add:
        for col_name in columns_to_add:
            df = df.withColumn(
                col_name, F.lit(float("nan"))
            )  # Assuming NaN values are desired

    return df.select(columns)


def create_claim_flag_computation(
    df,
    col_name: str,
    new_col_name: str,
):
    """Function used to set the maximum value (flag) across loss codes to
    capture flags at claim level."""

    # Step 1: Aggregate to check if at least one record has a 1
    max_value = df.agg(
        F.max(F.when(F.col(col_name) == 2, 0).otherwise(F.col(col_name)))
    ).collect()[0][0]

    # Step 2: Add a new column with the result
    df_with_new_column = df.withColumn(
        f"{new_col_name}", lit(1 if max_value == 1 else 0)
    )

    return df_with_new_column


# def read_s3_pickle_obj(pkl_path):
#     """Reads picke file from S3 bucket
#     Args:
#         pkl_path (String) : Pickle file path without S3 bucket name
#         Sample : acr/base/artifacts/ml_models/latest/non_tec_wheel_v2.pkl

#     Returns: Pickle object
#     """

#     session = boto3.Session(
#         aws_access_key_id=ingest_aws_bucket_key,
#         aws_secret_access_key=ingest_aws_bucket_secret,
#     )
#     s3 = session.resource("s3")
#     pickle_obj = pickle.loads(
#         s3.Bucket(aws_bucket).Object(pkl_path).get()["Body"].read()
#     )
#     return pickle_obj
