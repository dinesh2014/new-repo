from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DoubleType,
    IntegerType,
)

# Define Schema for JSON data:

claims_contract_schema = StructType(
    [
        StructField("sclaim_number", StringType(), True),
        StructField("iclaim_id", IntegerType(), True),
        StructField("irecord_id", IntegerType(), True),
        StructField("sloss_code", StringType(), True),
        StructField("dtdate_loss_occurred", StringType(), True),
        StructField("iodometer_at_time_of_loss", IntegerType(), True),
        StructField("sdetail_type", StringType(), True),
        StructField("nreq_qty", DoubleType(), True),
        StructField("creq_unit_cost", DoubleType(), True),
        StructField("cext_total_amt", DoubleType(), True),
        StructField("spart_no", StringType(), True),
        StructField("smanufacturer_code", StringType(), True),
        StructField("spayee_type", StringType(), True),
        StructField("sservice_center_type", StringType(), True),
        StructField("iclaim_det_status_id", IntegerType(), True),
        StructField("sdetail_desc", StringType(), True),
        StructField("spart_desc", StringType(), True),
    ]
)

# Define the schema for "dealer"
dealer_schema = StructType(
    [
        StructField("spayee_no", StringType(), True),
        StructField("spayee_state", StringType(), True),
        StructField("spayee_city", StringType(), True),
        StructField("spayee_zip_code", StringType(), True),
    ]
)

# Define the schema for "customer"
customer_schema = StructType(
    [
        StructField("scontract_holder_fname", StringType(), True),
        StructField("scontract_holder_lname", StringType(), True),
        StructField("scontract_holder_email", StringType(), True),
        StructField("scontract_holder_address_1", StringType(), True),
    ]
)

# Define the schema for "contract"
contract_schema = StructType(
    [
        StructField("scontract_no", StringType(), True),
        StructField("iproduct_type_id", IntegerType(), True),
    ]
)
