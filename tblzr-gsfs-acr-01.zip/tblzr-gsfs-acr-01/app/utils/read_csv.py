from app.config.spark import sparkInitializer
from pyspark.sql import SparkSession
from pyspark.storagelevel import StorageLevel


def read_csv(file_path: str):
    spark = sparkInitializer.getSparkSession()
    # spark = SparkSession.builder.appName("core-engine").getOrCreate()
    df_dealer_issue_precomp = (
        spark.read.format("csv").option("header", "true").load(file_path)
    )
    df_dealer_issue_precomp.persist(StorageLevel.MEMORY_ONLY)
    df_dealer_issue_precomp.createOrReplaceGlobalTempView("df_dealer_issue_precomp")
    return df_dealer_issue_precomp
