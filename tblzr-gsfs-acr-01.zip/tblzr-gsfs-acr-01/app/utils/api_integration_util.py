from logging import getLogger

import httpx
from fastapi import HTTPException
from pydantic import BaseModel
from typing import Any


class CustomResponseModel(BaseModel):
    field1: Any  # Replace with actual field names and types
    field2: Any


class ApiIntegrationUtil:
    def __init__(self, api_url: str):
        self.api_url = api_url
        self.logger = getLogger()

    async def call_external_api(self, payload: dict, auth: str):
        headers = {"client_id": "client_id", "client_secret": "client_secret"}
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.api_url, json=payload, headers=headers
                )
                response.raise_for_status()
                custom_response = CustomResponseModel(**response.json())
                return response.json()
        except httpx.HTTPStatusError as exc:
            self.logger.error(
                f"HTTP error: {exc.response.status_code} - {exc.response.text}"
            )
            raise HTTPException(
                status_code=exc.response.status_code,
                detail="Error calling external API",
            )
        except Exception as exc:
            self.logger.error(f"Error: {str(exc)}")
            raise HTTPException(status_code=500, detail="Internal Server Error")
