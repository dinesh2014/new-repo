import logging
import json
import uuid

# from logging import getLogger
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter
from pydantic import BaseModel
from starlette.responses import JSONResponse

from app.cron.main import run_preload_precomp
from app.service.tblzr_gsfs_acr_service import AcrAppService
from app.config.logger_config import setup_logger

from app.config.spark import sparkInitializer

acr_inference_router = APIRouter()
spark = sparkInitializer.getSparkSession()


# logger = getLogger()


class InferenceInput(BaseModel):
    claim_detail: str


@acr_inference_router.post("/process/inference/")
async def acr_inference(Inference_input: InferenceInput):
    # Define the time difference between UTC and Central Time
    ct_offset = timedelta(hours=-5)
    # Get the current date and time in Central Time
    date_folder = (datetime.now(timezone.utc) + ct_offset).strftime("%Y-%m-%d")
    # Get the job run and date folder parameter to track interim results:
    id_execution = {"job_run_id": str(uuid.uuid4()), "date_folder": date_folder}

    # Set up the logger using our configuration function
    setup_logger(id_execution)
    # Create a logger instance specific to this module
    logger = logging.getLogger(__name__)

    response = AcrAppService.inference_task_executor(
        Inference_input.claim_detail, id_execution
    )
    return response


@acr_inference_router.post("/trigger-preload-precomp")
async def trigger_preload_precomp_job():
    run_preload_precomp()
    return "preload precompute job triggered successfully"
