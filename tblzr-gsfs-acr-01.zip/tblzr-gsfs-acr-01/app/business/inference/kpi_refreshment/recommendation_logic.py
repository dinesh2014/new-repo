import logging
import pyspark.sql.functions as F
from pyspark.sql.functions import col, when, broadcast
from app.config.base_config import BaseConfig
from pyspark.sql.types import FloatType, StringType
from app.config.spark import sparkInitializer
from datetime import datetime
from app.utils.utils import create_claim_flag_computation

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.KPI_REFRESHMENT_CONFIG
set_up_config = config_file["set_up_configuration"]
data_sources = set_up_config["data_sources"]
risk_category = config_file["risk_category"]

input_folder = data_sources["input_folder"]
raw_input_folder = data_sources["raw_input_folder"]
input_tables = data_sources["input_tables"]
today_date = datetime.now().strftime("%Y-%m-%d")


# Create SparkSession
spark = sparkInitializer.getSparkSession()


def agg_claim_risk_category(df, prod):
    """This function is used to aggregate risk category with individual level
    flags.

    Args:
        df: dataframe with claim information
        prod: product type

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if prod != "tw":
        # get all the flags
        dealer_risk = risk_category["dealer_risk"]
        breakdown_risk = risk_category["breakdown_risk"]
        coverage_checks = risk_category["coverage_checks"]
        customer_risk = risk_category["customer_risk"]
        cost_checks = risk_category["cost_checks"]

        # aggregate flag at claim level
        # Create aggregation expressions
        all_risks_and_checks = (
            dealer_risk + breakdown_risk + customer_risk + coverage_checks + cost_checks
        )

        # select only necessary columns
        necessary_columns = [
            "sclaim_number",
            "breakdown_risk_tier",
            "creq_total",
        ] + all_risks_and_checks
        df = df.select(necessary_columns)

        # Create aggregation expressions
        agg_expressions = [
            F.expr(f"max(case when {x} == 1 then 1 else 0 end)").alias(x)
            for x in all_risks_and_checks
        ]
        agg_expressions.append(
            F.min(col("breakdown_risk_tier")).alias("breakdown_risk_tier")
        )
        agg_expressions.append(F.max(col("creq_total")).alias("creq_total"))
    else:
        # get all the flags
        dealer_risk = risk_category["dealer_risk_tw"]
        coverage_checks = risk_category["coverage_checks"]
        customer_risk = risk_category["customer_risk"]
        cost_checks = risk_category["cost_checks_tw"]

        # aggregate flag at claim level
        # Create aggregation expressions
        all_risks_and_checks = (
            dealer_risk + customer_risk + coverage_checks + cost_checks
        )

        # select only necessary columns
        necessary_columns = ["sclaim_number", "creq_total"] + all_risks_and_checks
        df = df.select(necessary_columns)

        # Create aggregation expressions
        agg_expressions = [
            F.expr(f"max(case when {x} == 1 then 1 else 0 end)").alias(x)
            for x in all_risks_and_checks
        ]
        agg_expressions.append(F.max(col("creq_total")).alias("creq_total"))

    # Perform the aggregation
    df_agg = df.groupBy("sclaim_number").agg(*agg_expressions)

    return df_agg


def get_category_checks(df_feature: F.DataFrame, category_check: str, prod):
    """
    This function is used to get risk category - coverage checks

    Args:
        df_feature: dataframe with claim information
        category_check: category to evaluate
        prod: product type

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if (prod == "tw") & (category_check == "cost_checks"):
        checks = risk_category[category_check + "_tw"]
    else:
        checks = risk_category[category_check]

    # Creating a more efficient sum expression
    sum_expression = F.expr(" + ".join(f"IF(ISNULL({x}), 0, {x})" for x in checks))

    df_feature = df_feature.withColumn(
        category_check, F.when(sum_expression > 0, "Fail").otherwise("Pass")
    )

    return df_feature


def get_dealer_customer_risk(df_feature: F.DataFrame, prod):
    """This function is used to get the high level risk level for dealer &
    customer risks.

    Args:
        df_feature: dataframe with claim information
        prod: product type

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Get the list of flags under dealer and customer buckets:
    if prod == "tw":
        risk_flag_ls = risk_category["dealer_risk_tw"] + risk_category["customer_risk"]
    else:
        risk_flag_ls = risk_category["dealer_risk"] + risk_category["customer_risk"]

    # Get the weights of each flag
    if prod == "tw":
        weights = spark.sparkContext.broadcast(config_file["flag_weights_tw"])
    else:
        weights = spark.sparkContext.broadcast(config_file["flag_weights"])

    # Create a single expression to calculate the weighted total
    weighted_sum_expr = F.expr(
        " + ".join(
            [f"COALESCE({weights.value.get(c, 0)} * {c}, 0)" for c in risk_flag_ls]
        )
    )
    # Calculate the weighted total directly
    df = df_feature.withColumn("weighted_total", weighted_sum_expr)

    # Calculate overall risk level
    if prod == "tw":
        df = df.withColumn(
            "dealer_customer_risk",
            when(col("weighted_total") == 0, "Low")
            .when(col("weighted_total") <= 2, "Medium")
            .otherwise("High"),
        )
    else:
        df = df.withColumn(
            "dealer_customer_risk",
            when(col("weighted_total") == 0, "Low")
            .when(col("weighted_total") <= 1, "Medium")
            .otherwise("High"),
        )

    # Show the resulting DataFrame
    return df


def get_breakdown_risk(df_feature: F.DataFrame):
    """This function is used to get the high level risk for breakdown.

    Args:
        df_feature: dataframe with claim information

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    df = df_feature

    # Get the breakdown risk tier column assigned at make + model + issue level
    risk_tier = "breakdown_risk_tier"

    # Get breakdown overall risk level
    df = df.withColumn(
        "breakdown_risk",
        when(col(risk_tier) == 1, "High").otherwise(
            when(col(risk_tier) == 2, "Medium").otherwise(
                when(col(risk_tier) == 3, "Low").otherwise("Unknown")
            )
        ),
    )

    return df


def get_overall_recommendation(df_feature: F.DataFrame, prod):
    """This function is used to get the overall recommendation.

    Args:
        df_feature: dataframe with claim information

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    if prod == "vsc":
        # Merge kpi features and breakdown
        df = df_feature.select(
            "sclaim_number",
            "breakdown_risk",
            "cost_checks",
            "dealer_customer_risk",
            "coverage_checks",
            "creq_total",
        )

        # Load anomaly thresholds
        df_anomaly_threshold = spark.sql(
            "SELECT * FROM global_temp.df_anomaly_threshold"
        )

        # Merge in anomaly threshold
        df = df.join(
            df_anomaly_threshold,
            on=["dealer_customer_risk", "breakdown_risk"],
            how="inner",
        )

        # Apply overall recommendation logic
        df_out = df.withColumn(
            "overall_recommendation",
            when(col("coverage_checks") == "Fail", "Deny").otherwise(
                when(
                    col("cost_checks") == "Fail", "Review further - parts overcost"
                ).otherwise(
                    when(
                        col("creq_total") >= col("inspection_threshold"),
                        "Send for inspection",
                    ).otherwise(
                        when(
                            col("creq_total") >= col("review_threshold"),
                            "Review further - check anomalies",
                        ).otherwise("Approve")
                    )
                )
            ),
        ).drop("creq_total", "review_threshold", "inspection_threshold")

    elif prod == "tw":
        # Merge kpi features and breakdown
        df = df_feature.select(
            "sclaim_number",
            "cost_checks",
            "dealer_customer_risk",
            "coverage_checks",
            "creq_total",
        )

        var_threshold = config_file["var_threshold"]["tw"]

        # Apply overall recommendation logic
        df_out = df.withColumn(
            "overall_recommendation",
            when(col("coverage_checks") == "Fail", "Deny").otherwise(
                when(
                    col("cost_checks") == "Fail",
                    "Review further - check cost anomalies",
                ).otherwise(
                    when(
                        (
                            (col("dealer_customer_risk") == "High")
                            & (col("creq_total") > F.lit(float(var_threshold["High"])))
                        )
                        | (
                            (col("dealer_customer_risk") == "Medium")
                            & (
                                col("creq_total")
                                > F.lit(float(var_threshold["Medium"]))
                            )
                        ),
                        "Review further - check anomalies",
                    ).otherwise("Approve")
                )
            ),
        ).drop("creq_total")

    return df_out


# Function to implement recommendation and additional logics
def apply_recommendation_logic(df_feature_output, df_breakdown, df_labor_hours, run_id):
    """This function is used to get the overall recommendation.

    Args:
        df_feature_output: dataframe with claim information
        df_breakdown: dataframe with breakdown information
        df_labor_hours: dataframe with labor information
        run_id: unique id for run execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    # Join breakdown and labor hours model output
    df = df_feature_output.join(
        df_breakdown, on=["sclaim_number", "sloss_code"], how="left"
    )
    df = df.join(df_labor_hours, on=["sclaim_number", "sloss_code"], how="left")

    # Create claim level flags (new cols) used to flag in the UI
    for individual_flag, claim_level_flag in config_file[
        "individual_to_claim_level_flags_vsc"
    ].items():
        df = create_claim_flag_computation(df, individual_flag, claim_level_flag)

    # Aggregate to claim level (to create 4 mayor risk checks)
    prod = "vsc"
    df_agg = agg_claim_risk_category(df, prod)

    # Get two coverage checks:
    checks = ["coverage_checks", "cost_checks"]
    for check in checks:
        df_agg = get_category_checks(df_agg, check, prod)
        logger.info("%s is complete", check)

    logger.info("coverage checks and cost checks are implemented.")
    # Get breakdown risk
    df_agg1 = get_breakdown_risk(df_agg)

    df_agg2 = get_dealer_customer_risk(df_agg1, prod)
    logger.info("dealer/customer risks are incorporated")

    # Get overall recommendation
    df_agg3 = get_overall_recommendation(df_agg2, prod)
    df_out = df.join(broadcast(df_agg3), on=["sclaim_number"], how="inner")

    # Save intermediate output out
    df_out.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/rec_logic",
    )


def apply_recommendation_logic_tw(df_feature_output, df_tw, run_id):
    """This function is used to get the overall recommendation.

    Args:
        df_feature_output: dataframe with claim information
        df_tw: dataframe with TW information
        run_id: unique id for run execution

    Returns:
        spark.Dataframe with the information across main dimensions
    """

    prod = "tw"
    # Populate placeholder values for breakdown and labor hours columns
    df = df_feature_output
    df = (
        df.withColumn("breakdown_risk_tier", F.lit(None).cast(StringType()))
        .withColumn("breakdown_risk", F.lit(None).cast(StringType()))
        .withColumn("breakdown_propensity_flag", F.lit(2))  # not enough information
        .withColumn("breakdown_propensity", F.lit(None).cast(FloatType()))
        .withColumn("breakdown_propensity_threshold", F.lit(None).cast(FloatType()))
        .withColumn("breakdown_part_freq", F.lit(None).cast(FloatType()))
        .withColumn("breakdown_part_freq_flag", F.lit(2))  # not enough information
    )
    df = (
        df.withColumn("labor_hours_prediction_flag", F.lit(2))  # not enough information
        .withColumn("labor_hours_prediction_threshold", F.lit(None).cast(FloatType()))
        .withColumn("labor_hours_req", F.lit(None).cast(FloatType()))
        .withColumn("labor_hours_prediction", F.lit(None).cast(FloatType()))
    )

    # Standardize upper case before join
    df = df.withColumn("smake", F.upper(F.col("smake")))
    df_tw = df_tw.withColumn("smake", F.upper(F.col("smake")))
    df = df.withColumn("sclaim_number", F.upper(F.col("sclaim_number")))
    df_tw = df_tw.withColumn("sclaim_number", F.upper(F.col("sclaim_number")))
    df = df.withColumn("spart_no", F.upper(F.col("spart_no")))
    df_tw = df_tw.withColumn("spart_no", F.upper(F.col("spart_no")))

    # Merge in tw prediction output
    df = df.join(
        df_tw, on=["sclaim_number", "smake", "spart_no", "sloss_code"], how="inner"
    )

    # Create claim level flags (new cols) used to flag in the UI
    for individual_flag, claim_level_flag in config_file[
        "individual_to_claim_level_flags_tw"
    ].items():
        df = create_claim_flag_computation(df, individual_flag, claim_level_flag)

    # Aggregate to claim level
    df_agg = agg_claim_risk_category(df, prod)

    # Get two coverage checks:
    checks = ["coverage_checks", "cost_checks"]
    for check in checks:
        df_agg = get_category_checks(df_agg, check, prod)
        logger.info("%s is complete", check)

    logger.info("coverage checks and cost checks are implemented.")

    df_agg2 = get_dealer_customer_risk(df_agg, prod)
    logger.info("dealer/customer risks are incorporated")

    # Get overall recommendation
    df_agg3 = get_overall_recommendation(df_agg2, prod)

    df_out = df.join(broadcast(df_agg3), on=["sclaim_number"], how="inner")

    # Save intermediate output out
    df_out.repartition(1).write.mode("overwrite").option(
        "compression", "snappy"
    ).parquet(
        data_sources["intermediate_output_folder"]
        + str(today_date)
        + "/"
        + str(run_id)
        + "/rec_logic",
    )
