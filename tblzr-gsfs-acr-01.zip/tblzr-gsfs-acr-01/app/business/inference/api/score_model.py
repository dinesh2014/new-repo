import pandas as pd
import requests
import pandas as pd
import json
import os

from app.business.inference.api.config import create_tw_score_model_json

def create_tf_serving_json(data):
    return {'inputs': {name: data[name].tolist() for name in data.keys()} if isinstance(data, dict) else data.tolist()}

def score_model(dataset, model_name):
    loaded_data = create_tw_score_model_json()
    json_data = json.dumps(loaded_data)
    config_data = json.loads(json_data)
    url=config_data['workspace_url']
    url = f'{url}/serving-endpoints/{os.environ["ENDPOINT"]}/served-models/{model_name}/invocations'
    headers = {
        'Authorization': f'Bearer {os.environ["DB_TOKENS"]}',
        'Content-Type': 'application/json'
    }
    ds_dict = {
        'dataframe_split': dataset.to_dict(orient='split') if isinstance(dataset, pd.DataFrame) else create_tf_serving_json(dataset),
        "params": {"model_name": model_name}
    }
    data_json = json.dumps(ds_dict, allow_nan=True)
    print("&"*100)
    print(url,data_json)
    response = requests.request(method='POST', headers=headers, url=url, data=data_json)
    if response.status_code != 200:
        raise Exception(f'Request failed with status {response.status_code}, {response.text}')

    return response.json()