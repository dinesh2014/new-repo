from app.config.base_config import get_env_variables

def create_tw_score_model_json():
    env = get_env_variables()
    # if env=="dev":
    #     workspace_url = f"https://tfg-gsfsind-{env}-01.cloud.databricks.com"
    # else:
    #     workspace_url = f"https://tfg-gsfsind-{env}.cloud.databricks.com"
    workspace_url = f"https://tfg-gsfsind-dev-01.cloud.databricks.com"

    return {
        'workspace_url':workspace_url,
        'model':{
        'techTire':'tec_tire',
        'nontechTire':'nontec_tire',
        'techWheel':'tec_wheel',
        'nontechWheel':'nontec_wheel',
        'techMB':'tec_m_and_b',
        'nontechMB':'nontec_m_and_b'
        } }