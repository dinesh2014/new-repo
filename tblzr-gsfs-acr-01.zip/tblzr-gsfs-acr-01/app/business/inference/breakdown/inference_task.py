# Native python libraries:
import logging
import numpy as np
from sklearn.linear_model import LogisticRegression
from mlflow.exceptions import RestException
from app.utils.utils import (
    loading_temporal_views,
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
    add_missing_columns,
)

# Pyspark requirements:
from pyspark.sql import Window, Row
import pyspark.sql.functions as F
import pyspark.sql.types as T
from app.config.base_config import BaseConfig

from joblib import load
from typing import List

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_BREAKDOWN_CONFIG
set_up_config = config_file["set_up_configuration"]["breakdown"]
ml_registry_config = set_up_config["model_registry"]
serving_config = set_up_config["serving"]

# Define intermediate configs:
interim_tables_config = set_up_config["intermediate_results"]
interim_bucket_path = interim_tables_config["bucket_path"]

# Model path breakdown
model_path_breakdown = set_up_config["model_path"]


@timing
def return_closest_boundary(df):
    """Identifies the closest boundary for each probability in the DataFrame.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing probability values and their respective bounds.

    Returns:
        pyspark.sql.DataFrame: DataFrame with only the rows that contain the closest boundary to each probability.
    """

    # Define a UDF to find the closest boundary
    df_with_distances = df.withColumn(
        "distance",
        F.expr(
            """
                case
                when probabilities between lower_bound and upper_bound then 0
                when abs(probabilities - lower_bound) < abs(probabilities - upper_bound) then abs(probabilities - lower_bound)
                when abs(probabilities - lower_bound) >= abs(probabilities - upper_bound) then abs(probabilities - upper_bound)
                else -1
                end
            """
        ),
    )

    # Adding a row number within each sloss_code for ordering
    window_spec = Window.partitionBy("sloss_code").orderBy(F.col("distance"))

    df_with_row_number = df_with_distances.withColumn(
        "row_number", F.row_number().over(window_spec)
    )

    # Filtering to get the minimum distance (closest boundary)
    selected_boundaries = df_with_row_number.filter(F.col("row_number") == 1)

    # Select the columns you need from the selected_boundaries DataFrame
    selected_boundaries_final = selected_boundaries

    return selected_boundaries_final


@timing
def normalize_features(df, scaler_params_dict):
    """Normalizes features in the DataFrame based on provided scaling
    parameters.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing features to be normalized.
        scaler_params_dict (dict): Dictionary containing mean and standard deviation for each feature.

    Returns:
        pyspark.sql.DataFrame: DataFrame with normalized features.
    """
    # Iterate over the keys in the dictionary
    for feature, params in scaler_params_dict.items():
        # Check if the DataFrame has this feature
        if feature in df.columns:
            logger.info("Scaling feature: %s", feature)

            # Calculate the mean and standard deviation
            mean = params.get("mean", 0)
            std_dev = params.get("std_dev", 1)

            # Replace dealer feature to average dealer to control for dealer behavior:
            if feature in set_up_config["features_to_set_to_average"]:
                logger.info("** Setting feature to average **")
                df = df.withColumn(feature, F.lit(mean))

                # Subtract the mean and divide by the standard deviation
                df = df.withColumn(feature, (F.col(feature) - mean) / std_dev)
            else:
                # Subtract the mean and divide by the standard deviation
                df = df.withColumn(feature, (F.col(feature) - mean) / std_dev)
    return df


# Define the recursive function
def row_to_dict(row):
    """Recursively converts a PySpark Row object into a nested dictionary.

    Args:
        row (Row): PySpark Row object to be converted.

    Returns:
        dict: Nested dictionary representation of the PySpark Row.
    """
    if isinstance(row, Row):
        return {k: row_to_dict(v) for k, v in row.asDict().items()}
    elif isinstance(row, list):
        return [row_to_dict(i) for i in row]
    else:
        return row


@timing
def estimate_value_at_risk(
    predictions,
    base_table,
    make: str,
    model: str,
    class_names: List[str],
    spark: object,
):
    """Estimates the value at risk based on predictions, comparing with
    baseline data and specific vehicle characteristics.

    Args:
        predictions (pyspark.sql.DataFrame): DataFrame containing the prediction probabilities.
        base_table (pyspark.sql.DataFrame): DataFrame containing the base data with original claim details.
        make (str): Vehicle make to filter data.
        model (str): Vehicle model to filter data.
        spark (pyspark.sql.SparkSession): Active Spark session.

    Returns:
        pyspark.sql.DataFrame: DataFrame containing the risk evaluated data.
    """

    # Define filter to reduce time computation:
    make_model_filter = f"smake = '{make}' AND smodel = '{model}'"

    # Read the risk tier table from S3:
    tier_risk_table_name = set_up_config["data_source"]["risk_tiers_output"][
        "table_name"
    ]
    # tier_risk_table = loading_temporal_views(
    #     table_name=set_up_config["data_source"]["risk_tiers_output"]["table_name"],
    #     cols_to_pull=set_up_config["data_source"]["risk_tiers_output"][
    #         "columns_to_pull"
    #     ],
    #     value_filter=make_model_filter,
    #     spark=spark,
    # )

    tier_risk_table = spark.sql(
        f"""
    select * from global_temp.{tier_risk_table_name}
    where {make_model_filter}
    """
    )

    # Set upper case cols to match with risk tier output:
    risk_tier_keys = ["smake", "smodel", "sloss_code"]
    tier_risk_table = tier_risk_table.select(
        *[
            F.upper(F.col(c)).alias(c) if c in risk_tier_keys else F.col(c)
            for c in tier_risk_table.columns
        ]
    )

    # Create monotonic index for base and prediction to match:
    window = Window.orderBy(F.monotonically_increasing_id())
    predictions = predictions.withColumn("index", F.row_number().over(window) - 1)
    base_table = base_table.withColumn("index", F.row_number().over(window) - 1)

    if base_table.count() == 0:
        logger.warning(
            "** Generating default UNKNOWN predictions for empty loss code-class match ***"
        )

        # Providing JSON message to simulate rest error:
        json_error = {
            "status_code ": 404,
            "error_code": "RESOURCE_NOT_FOUND",
            "message": "Empty resulting dataframe after loss code-class match.",
        }
        raise RestException(json_error)

    # Join base table with predictions to quick manipulation:
    base_table = base_table.join(
        predictions, base_table["index"] == predictions["index"], how="left"
    )
    base_table = base_table.drop("index")

    # Remove prediction columns:
    base_table = base_table.drop(*class_names)

    # Map risk tier values by loss
    base_table_risk_tiers = base_table.join(
        tier_risk_table, on=risk_tier_keys, how="left"
    )

    # Keep only risk tiers where probability is within boundaries / closest to boundaries:
    fe_output_risk_tiers_final = return_closest_boundary(base_table_risk_tiers)

    #########################################
    # Estimate Value At Risk ################
    #########################################

    # Generate the break-even for each risk tier:
    COST_PER_CLAIM = 15.38
    DENIED_RATE = 0.05

    base_table_risk_tiers = estimate_break_even_threshold(
        df=fe_output_risk_tiers_final,
        cost_per_claim=COST_PER_CLAIM,
        denied_rate=DENIED_RATE,
    )

    return base_table_risk_tiers


def estimate_break_even_threshold(df, cost_per_claim, denied_rate):
    """Calculates the break-even threshold for each risk tier based on cost per
    claim and denied rate.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing risk tier data.
        cost_per_claim (float): Cost per claim used in break-even calculation.
        denied_rate (float): Denied rate used in break-even calculation.

    Returns:
        pyspark.sql.DataFrame: DataFrame with break-even thresholds calculated.
    """
    # # Calculate break-even breakdown
    df = df.withColumn(
        "breakeven_breakdown", F.expr(f"{cost_per_claim} / (hit_rate * {denied_rate})")
    )

    risk_tier = "risk_tier"

    df = df.withColumn(
        "var_anomaly_flag_breakdown",
        F.when(F.col(risk_tier) == 1, 1).otherwise(
            F.when(F.col(risk_tier) == 2, 0).otherwise(
                F.when(F.col(risk_tier) == 3, 0).otherwise(2)
            )
        ),
    )

    return df


@timing
def filter_final_breakdown_cols(breakdown_output_df):
    """Filters and renames columns in the breakdown output DataFrame according
    to configuration.

    Args:
        breakdown_output_df (pyspark.sql.DataFrame): DataFrame containing breakdown data to be formatted.

    Returns:
        pyspark.sql.DataFrame: Formatted and filtered DataFrame.
    """
    # Rename columns
    for old_col, new_col in set_up_config["rename_final_cols"].items():
        breakdown_output_df = breakdown_output_df.withColumnRenamed(old_col, new_col)

    # Select final columns
    selected_cols = set_up_config["select_final_cols"]
    breakdown_output_df = breakdown_output_df.select(*selected_cols)

    return breakdown_output_df


@timing
def inference_task(id_execution: dict, spark: object):
    """Conducts the breakdown inference task using a hosted model in MLFlow.

    Args:
        id_execution (dict): Execution IDs for tracking purposes.
        spark (pyspark.sql.SparkSession): Active Spark session.

    Returns:
        None: The function orchestrates the inference task but does not return a value.
    """
    logger.info("** Initializing breakdown inference task **")

    # Read output from feature engineering task:
    # df_model_params = spark.sql("""select * from global_temp.df_breakdown_model""")
    model = load(f"{model_path_breakdown}breakdown_model.joblib")
    scaler = load(f"{model_path_breakdown}scaler.joblib")
    input_file_name = interim_tables_config["file_name"]["feature_engineering"]

    fe_output = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=input_file_name,
        spark=spark,
    )

    try:
        # Retrieve model signature from MLFlow:
        df_prediction_features = fe_output
        class_names = model.classes_
        df_prediction_features = df_prediction_features.filter(
            F.col("sloss_code").isin(list(class_names))
        )
        df_prediction_intermediate = df_prediction_features.toPandas()

        df_prediction_features_pandas = pd.get_dummies(
            df_prediction_intermediate.drop(columns=["sloss_code"])
        )

        smake = df_prediction_intermediate["smake"].tolist()[0].lower()
        smodel = df_prediction_intermediate["smodel"].tolist()[0].lower()

        df_prediction_features_pandas.columns = [
            name.lower() for name in df_prediction_features_pandas.columns
        ]

        for each in model.feature_names_in_:
            if each not in df_prediction_features_pandas.columns:
                df_prediction_features_pandas[each] = 0

        df_prediction_features_pandas.fillna(
            0, inplace=True
        )  # Filling NaN to give some predictions

        # Scale features using standard scaler method during training set:
        scaler_features = scaler.feature_names_in_
        df_prediction_features_pandas[scaler_features] = scaler.transform(
            df_prediction_features_pandas[scaler_features]
        )

        probability_results = model.predict_proba(
            df_prediction_features_pandas[model.feature_names_in_]
        )
        probability_results = pd.DataFrame(probability_results, columns=model.classes_)
        probability_results.index = range(len(probability_results))

        df_prediction_intermediate.index = range(len(df_prediction_intermediate))

        probability_results["sloss_code"] = df_prediction_intermediate["sloss_code"]
        probability_results["probabilities"] = probability_results.apply(
            lambda x: x[x["sloss_code"]], axis=1
        )
        probability_results.drop(columns=["sloss_code"], inplace=True)

        predictions = spark.createDataFrame(probability_results)

        # Assign probabilities, quartile cuts and risk segment:
        output_inference = estimate_value_at_risk(
            predictions=predictions,
            base_table=df_prediction_features,
            make=smake.lower(),
            model=smodel.lower(),
            class_names=model.classes_,
            spark=spark,
        )

        # Filter relevant cols for KPI module:
        output_inference = filter_final_breakdown_cols(output_inference)
        logger.info("Output_Inference Results Count: %s", output_inference.count())

        # Save output to S3:
        save_intermediate_daily_files_s3(
            df=output_inference,
            s3_bucket=interim_bucket_path,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config["file_name"]["breakdown_inference"],
        )

        logger.info("Assigning risk tier and other metrics to output...")
        logger.info("** Inference task completed **")

    except Exception as e:
        logger.warning("Exception in BreakDown Modelling: %s", e)
        output_inference = add_missing_columns(
            fe_output, set_up_config["select_final_cols"]
        )

        # Save output to S3:
        save_intermediate_daily_files_s3(
            df=output_inference,
            s3_bucket=interim_bucket_path,
            date_folder=id_execution["date_folder"],
            job_run_id=id_execution["job_run_id"],
            file_name=interim_tables_config["file_name"]["breakdown_inference"],
        )
