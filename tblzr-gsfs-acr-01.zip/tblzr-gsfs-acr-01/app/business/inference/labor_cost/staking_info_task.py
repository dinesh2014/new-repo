import logging
from app.config.base_config import BaseConfig

from app.business.inference.breakdown.staking_info_task import (
    retrieve_api_contract,
    map_contract_reference_columns,
)

from app.utils.utils import (
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

import pyspark.sql.functions as F
from pyspark.sql.functions import col

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_STAKING_INFO_CONFIG
set_up_config = config_file["set_up_configuration"]

# referential and precomputed table config:
referential_tables_config = set_up_config["referential_tables"]
pre_calc_tables_config = set_up_config["pre_computed_tables"]

interim_tables_config = set_up_config["intermediate_results"]["cost_assessment"]
interim_bucket_path = interim_tables_config["bucket_path"]


def map_referential_features(
    api_contract,
    id_execution: dict,
    spark: object,
):
    """Enhances API contract data with additional reference fields pulled from
    configured S3 sources.

    Args:
        api_contract (pyspark.sql.DataFrame): DataFrame containing API contract data.
        id_execution (dict): Dictionary with execution identifiers.
        spark (pyspark.sql.SparkSession): Active Spark session to execute data loading.
    """

    # Map contract information:
    data_w_contract_vin = map_contract_reference_columns(api_contract, spark)

    # Save interim outputs into S3:
    file_name = interim_tables_config["file_name"]["map_referential_features"]

    save_intermediate_daily_files_s3(
        df=data_w_contract_vin,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name,
    )


def extract_labor_details(
    api_contract,
):
    """Extracts labor-related details from the API contract data, specifically
    filtering for labor types.

    Args:
        api_contract (pyspark.sql.DataFrame): DataFrame containing API contract data.

    Returns:
        pyspark.sql.DataFrame: Filtered DataFrame with only labor-related details.
    """

    api_contract_flt = api_contract.filter(col("sdetail_type") == "L")

    # Assuming api_contract_flt is a PySpark DataFrame
    if api_contract_flt.count() == 0:
        raise ValueError(
            "[ERROR]: Cannot calculate Labor predictions. Labor details are missing."
        )

    else:
        # Continue with your logic or simply return the DataFrame
        return api_contract_flt


def map_historical_labor_request_dealer(
    df: F.DataFrame,
    spark: object,
):
    """Maps historical labor request data by dealer, loss type, and make from a
    pre-calculated table.

    Args:
        df (pyspark.sql.DataFrame): DataFrame to map with historical data.
        spark (pyspark.sql.SparkSession): Spark session to execute SQL queries.

    Returns:
        pyspark.sql.DataFrame: DataFrame with mapped historical labor requests.
    """

    # Load pre-computed table:

    sql_query = """
    SELECT *
    FROM global_temp.df_avg_labor_request_dealer
    """

    avg_labor_req = spark.sql(sql_query)

    avg_labor_req = avg_labor_req.withColumnRenamed(
        "nreq_qty", "labor_hours_prediction"
    )

    df = df.merge(avg_labor_req, on=["sloss_code", "spayee_no", "smake"], how="left")

    logger.info("Mapping historical labor request by dealer...")

    return df


def assign_global_vars(
    df,
):
    """Assigns several global variables based on DataFrame columns for quick
    referencing in subsequent processes.

    Args:
        df (pyspark.sql.DataFrame): DataFrame from which to extract global variable values.
    """

    # Assign make global var:
    global labor_cost_global_vars
    labor_cost_global_vars = {}
    labor_cost_global_vars["make"] = df.select("smake").first()["smake"]

    # Assign model as global var:
    labor_cost_global_vars["model"] = df.select("smodel").first()["smodel"]

    # Assign dealer as global var:
    labor_cost_global_vars["dealer"] = df.select("spayee_no").first()["spayee_no"]

    # Assign loss code as global var:
    labor_cost_global_vars["loss_codes"] = [
        row["sloss_code"] for row in df.select("sloss_code").distinct().collect()
    ]


def map_claim_to_contract_ratio(
    base_df: F.DataFrame,
    spark: object,
):
    """Maps claim to contract ratios using dealer information from a pre-
    computed table.

    Args:
        base_df (pyspark.sql.DataFrame): Base DataFrame to enhance with dealer-level ratios.
        spark (pyspark.sql.SparkSession): Spark session to execute SQL queries.

    Returns:
        pyspark.sql.DataFrame: Enhanced DataFrame with dealer-level claim to contract ratios.
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["dealer_level"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["dealer_level"]["columns_to_pull"]

    # Define filter:
    filter_str = f"spayee_no = '{labor_cost_global_vars['dealer']}'"

    # Load table from tables preloaded into memory:

    sql_query = f"""
    SELECT DISTINCT {', '.join(cols_to_pull)}
    FROM global_temp.{table_name}
    WHERE {filter_str}
    """

    dealer_level = spark.sql(sql_query)

    # Merge the dataframes:
    base_df = base_df.join(dealer_level, on="spayee_no", how="left")

    # Rename_columns:
    base_df = base_df.withColumnRenamed(
        "dealer_claim_to_contract_ratio", "dealer_claim_contract_ratio"
    )

    return base_df


def map_labor_hours_feats(
    base_df: F.DataFrame,
    spark: object,
):
    """Maps dealer-specific labor labor hours features from a pre-calculated
    table.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to map with labor cost data.
        spark (pyspark.sql.SparkSession): Spark session to execute SQL queries.

    Returns:
        pyspark.sql.DataFrame: DataFrame with mapped labor cost per claim.
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["dealer_issue_make_model_level"][
        "table_name"
    ]
    cols_to_pull = pre_calc_tables_config["tables"]["dealer_issue_make_model_level"][
        "columns_to_pull"
    ]

    # Define filter:
    filter_str = (
        f"spayee_no = '{labor_cost_global_vars['dealer']}' AND "
        f"smake = '{labor_cost_global_vars['make']}' AND "
        f"smodel = '{labor_cost_global_vars['model']}'"
    )

    # Load table from s3:
    sql_query = f"""
    SELECT DISTINCT {', '.join(cols_to_pull)}
    FROM global_temp.{table_name}
    WHERE {filter_str}
    """

    dealer_level = spark.sql(sql_query)

    # Merge the dataframes:
    base_df = base_df.join(
        dealer_level,
        on=["spayee_no", "sloss_code", "smake", "smodel", "imodel_year"],
        how="left",
    )

    return base_df


def map_pre_computed_features(
    id_execution: dict,
    spark: object,
):
    """Maps all pre-computed features to the API contract DataFrame based on
    pre-configured mappings.

    Args:
        id_execution (dict): Execution identifiers.
        spark (pyspark.sql.SparkSession): Spark session to execute data loading and mapping.

    Returns:
        pyspark.sql.DataFrame: API contract DataFrame with all pre-computed features mapped.
    """

    # Read interim parquet file from S3:
    file_name_input = interim_tables_config["file_name"]["map_referential_features"]

    api_contract_df = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_input,
        spark=spark,
    )

    # Assign global variables for quick filtering:
    assign_global_vars(api_contract_df)

    # Map dealer_claim_contract_ratio:
    api_contract_df = map_claim_to_contract_ratio(api_contract_df, spark)

    # Map issue_dealer_car_segment_ratio, avg_prev_labor_hours_ratio and issue_dealer_car_segment_ratio:
    api_contract_df = map_labor_hours_feats(api_contract_df, spark)

    # Write interim output to s3:
    file_name_output = interim_tables_config["file_name"]["map_pre_computed_features"]

    save_intermediate_daily_files_s3(
        df=api_contract_df,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )


@timing
def stack_claim_information(api_contract, id_execution, spark):
    """Coordinates the execution of data retrieval and mapping tasks for claim
    information, transforming JSON input into enriched DataFrame formats
    suitable for analysis.

    Args:
        api_contract (dict): JSON contract containing claim information.
        id_execution (dict): Dictionary with execution identifiers.
        spark (pyspark.sql.SparkSession): Active Spark session for data handling and transformations.
    """
    logger.info("** Initializing staking info task **")

    # Retrieve API contract information:
    api_contract = retrieve_api_contract(api_contract, spark)
    logger.info("API contract parse correctly...")

    # Check claim contains labor details:
    api_contract = extract_labor_details(api_contract)
    logger.info("Labor details extracted from contract...")

    # Map referential columns from S3:
    map_referential_features(api_contract, id_execution, spark)
    logger.info("Referential features included into pipeline...")

    # Map pre-computed columns from S3:
    map_pre_computed_features(id_execution, spark)
    logger.info("Pre-computed features included into pipeline...")
