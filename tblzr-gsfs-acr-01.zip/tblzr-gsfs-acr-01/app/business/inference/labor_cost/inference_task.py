import logging
from sklearn.linear_model import LinearRegression
from app.config.base_config import BaseConfig
import pyspark.sql.functions as F
import pyspark.sql.types as T
import numpy as np

# Native python libraries:
from app.utils.utils import (
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.INF_BREAKDOWN_CONFIG
set_up_config = config_file["set_up_configuration"]["cost_assessment"]
ml_registry_config = set_up_config["model_registry"]
serving_config = set_up_config["serving"]

# Define intermediate configs:
interim_tables_config = set_up_config["intermediate_results"]
interim_bucket_path = interim_tables_config["bucket_path"]


def estimate_labor_prediction_flag(
    df,
):
    """Estimates a flag for labor predictions based on a specified deviation
    threshold from the baseline prediction.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing labor hours required and predicted, used to calculate deviations.

    Returns:
        pyspark.sql.DataFrame: DataFrame with an additional column 'labor_hours_prediction_flag' indicating whether the deviation exceeds the threshold.
    """

    # Post Processing
    df = (
        df.withColumn(
            "labor_hours_prediction_threshold",
            F.lit(set_up_config["deviation_threshold"]),
        )
        .withColumn(
            "deviation_to_baseline",
            (F.col("labor_hours_req") - F.col("predictions")) / F.col("predictions"),
        )
        .withColumn(
            "labor_hours_prediction_flag",
            F.expr(
                f"case when predictions == {set_up_config['no_model_pred']} then NULL "
                "else case when deviation_to_baseline > labor_hours_prediction_threshold then 1 "
                "when deviation_to_baseline < labor_hours_prediction_threshold then 0 "
                "else 2 end end"
            ),
        )
        .withColumn(
            "predictions",
            F.expr(
                f"case when predictions == '{set_up_config['no_model_pred']}' or predictions <0 then NULL else predictions end"
            ),
        )
        .withColumnRenamed("predictions", "labor_hours_prediction")
        .select(*set_up_config["final_cols_inference"])
    )

    return df


@timing
def inference_task(id_execution: dict, spark: object):
    """Executes the inference task to estimate labor cost predictions using a
    pre-trained model hosted in MLFlow and appends prediction flags based on
    deviations from predicted values.

    Args:
        id_execution (dict): Dictionary containing identifiers and other metadata for the execution session.
        spark (pyspark.sql.SparkSession): Active Spark session to handle data retrieval and transformations.

    Returns:
        None: The function orchestrates the inference process and saves the results to an external storage system but does not return any value directly.
    """
    logger.info("** Initializing inference task **")
    logger.info(id_execution)

    df_model_params = spark.sql("""select * from global_temp.df_labor_cost_model""")
    input_file_name = interim_tables_config["file_name"]["feature_engineering"]

    fe_output = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=input_file_name,
        spark=spark,
    )

    trims = list(fe_output.select("strim").distinct().toPandas()["strim"])
    df_prediction_features = fe_output.join(
        df_model_params, on=["smake", "smodel", "sloss_code"], how="left"
    )
    for trim in trims:
        df_prediction_features = df_prediction_features.withColumn(
            f"strim_{trim}", F.expr(f"case when strim == '{trim}' then 1 else 0 END")
        )

        # TODO bring from original file
        df_prediction_features = df_prediction_features.withColumn(
            "swheel_drive_count",
            F.expr(
                "case when sdriving_type = 'FWD' OR sdriving_type = 'RWD'"
                " then 2 else 4 END"
            ),
        )

    # Pandas Spark UDF
    def linear_predict(row):
        """
        Implement a linear regression model to predict the labor hours.
        If parameters required from model are not included, lets return a default pred.
        Args:
            row:

        Returns:

        """

        try:
            x_pred = np.array(
                [[row[value] if value in row.__fields__ else 0 for value in row.feat]]
            )

            model = LinearRegression()
            model.coef_ = np.array(row.coef)
            model.intercept_ = row.intercept

            result = model.predict(x_pred)
            return float(result[0])
        except Exception:
            return -9999

    linear_predict_udf = F.udf(linear_predict, T.FloatType())
    df_prediction = df_prediction_features.withColumn(
        "predictions",
        linear_predict_udf(
            F.struct(*[F.col(name) for name in df_prediction_features.columns])
        ),
    )

    inference_output = estimate_labor_prediction_flag(df_prediction)

    # Save output to S3:
    save_intermediate_daily_files_s3(
        df=inference_output,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=interim_tables_config["file_name"]["labor_inference"],
    )
    logger.info("** Saved Results Successfully **")
