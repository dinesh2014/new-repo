import os
import logging
import pandas as pd
import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql.functions import lower, col, when
from app.business.inference.api.config import create_tw_score_model_json
from app.config.base_config import BaseConfig, env_variables
from app.business.inference.api import score_model

# Native python libraries:
from app.utils.utils import (
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
    timing,
)

# Loading config file
config_file = BaseConfig.TW_PREDICTION_CONFIG
params = config_file["params"]

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Define intermediate configs:
interim_tables_config = config_file["intermediate_results"]["tire_and_wheel"]
interim_bucket_path = interim_tables_config["bucket_path"]


def estimate_unitcost_prediction_flag(
    df,
):
    """Estimates a prediction flag for unit costs based on deviations from
    baseline predictions, applying different thresholds for various product
    types and technical specifications.

    Args:
        df (pyspark.sql.DataFrame): DataFrame containing unit cost details and predictions to compute deviations.

    Returns:
        pyspark.sql.DataFrame: DataFrame with additional columns indicating prediction flags and benchmarks.
    """
    part_price_thresholds = params["part_price_threshold"]
    # Post Processing
    df = (
        df.withColumn(
            "part_price_prediction_threshold",
            when(
                (col("is_tec") == 1) & (col("tw_prod_type") == "tire"),
                float(part_price_thresholds["tire_tec"]),
            )
            .when(
                (col("is_tec") == 0) & (col("tw_prod_type") == "tire"),
                float(part_price_thresholds["tire_nontec"]),
            )
            .when(
                (col("is_tec") == 1) & (col("tw_prod_type") == "wheel"),
                float(part_price_thresholds["wheel_tec"]),
            )
            .when(
                (col("is_tec") == 0) & (col("tw_prod_type") == "wheel"),
                float(part_price_thresholds["wheel_nontec"]),
            )
            .otherwise(
                float(0)
            ),  # assuming a default threshold of 0 if none of the conditions are met
        )
        .withColumn(
            "part_price_prediction",
            F.when(
                (F.lower(F.col("tw_prod_type")) != "m&b"),
                (F.col("creq_unit_cost") - F.col("predictions")) / F.col("predictions"),
            ).otherwise(None),
        )
        .withColumn(
            "part_price_prediction_flag",
            F.expr(
                """
                case
                    when lower(tw_prod_type) = 'm&b' then null
                    when part_price_prediction > part_price_prediction_threshold then 1
                    when part_price_prediction <= part_price_prediction_threshold then 0
                    else 2
                end
                """
            ),
        )
        .withColumn(
            "part_price_prediction_benchmark",
            F.when(
                F.lower(F.col("tw_prod_type")) != "m&b", F.col("predictions")
            ).otherwise(None),
        )
        .withColumn(
            "mb_prediction_threshold",
            F.when(
                F.lower(F.col("tw_prod_type")) == "m&b",
                F.lit(
                    float(params.get("mb_prediction_threshold", 0))
                ),  # Defaulting to 0 if key not found
            ).otherwise(None),
        )
        .withColumn(
            "mb_prediction",
            F.when(
                F.lower(F.col("tw_prod_type")) == "m&b",
                (F.col("creq_unit_cost") - F.col("predictions")) / F.col("predictions"),
            ).otherwise(None),
        )
        .withColumn(
            "mb_prediction_flag",
            F.expr(
                """
                case
                    when lower(tw_prod_type) != 'm&b' then null
                    when mb_prediction > mb_prediction_threshold then 1
                    when mb_prediction <= mb_prediction_threshold then 0
                    else 2
                end
                """
            ),
        )
        .withColumn(
            "mb_prediction_benchmark",
            F.when(
                F.lower(F.col("tw_prod_type")) == "m&b", F.col("predictions")
            ).otherwise(None),
        )
        .select(
            *config_file["final_cols_inference"]
        )  # Ensure this contains the correct final column names
    )

    return df


@timing
def inference_task(id_execution: dict, spark: object):
    """Executes the inference process for tire and wheel predictions using pre-
    trained models. It handles feature preparation, model predictions and saves
    the prediction results to an external storage system.

    Args:
        id_execution (dict): Contains execution identifiers and metadata for tracking.
        spark (pyspark.sql.SparkSession): Active Spark session to perform data transformations and to read/write interim results.

    Returns:
        None: This function orchestrates the inference process and saves results but does not return any value.
    """
    logger.info("** Initializing inference task **")
    logger.info(id_execution)

    # All models with the same features
    feature_names = config_file["model_features"]
    categorical_features = [
        "snew_used",
        "smake",
        "smodel",
        "strim",
        "spayee_no",
        "sloss_code",
    ]


    # Define the pandas U
    def predict(row):
        model_names=create_tw_score_model_json()
        row_df = pd.DataFrame([row])
        for cat_feature in categorical_features:
            row_df[cat_feature] = row_df[cat_feature].astype("category")
        for column in list(set(feature_names) - set(categorical_features)):
            row_df[column] = row_df[column].astype("float")

        # Decision logic for model prediction
        if row["is_tec"] == 1 and row["tw_prod_type"] == "tire":
            registered_model_name = model_names['model']['techTire']
            predictions=score_model(row_df[feature_names],registered_model_name)
            print("prediction:",predictions)
            return (
                float(predictions['predictions'][0])
            )
        elif row["is_tec"] == 0 and row["tw_prod_type"] == "tire":
            registered_model_name = model_names['model']['nontechTire']
            predictions=score_model(
                    row_df[feature_names],registered_model_name
                )
            return (
                float(predictions['predictions'][0]
                )
            )
        # TEC does not need prediction as it's set at 35$
        elif row["is_tec"] == 1 and row["tw_prod_type"] == "m&b":
            return float(
                #    model_mb_toyota.predict(row_df[model_mb_toyota.feature_name()])[0]
                35  # TODO to add the MB threshold here
            )
        elif row["is_tec"] == 0 and row["tw_prod_type"] == "m&b":
            registered_model_name = model_names['model']['nontechMB']
            predictions=score_model(row_df[feature_names],registered_model_name)
            return (
                float(predictions['predictions'][0])
                )
        elif row["is_tec"] == 1 and row["tw_prod_type"] == "wheel":
            registered_model_name = model_names['model']['techWheel']
            predictions=score_model(row_df[feature_names],registered_model_name)
            return (
                float(predictions['predictions'][0])
            )
        elif row["is_tec"] == 0 and row["tw_prod_type"] == "wheel":
            registered_model_name = model_names['model']['nontechWheel']
            predictions=score_model(row_df[feature_names],registered_model_name)
            return (
                float(predictions['predictions'][0])
            )
        else:
            return -9999

    # Applying the UDF on the DataFrame

    for column in fe_output.columns:
        if isinstance(fe_output.schema[column].dataType, T.StringType):
            fe_output = fe_output.withColumn(column, lower(col(column)))

    fe_output_pdf = fe_output.toPandas()
    fe_output_pdf["predictions"] = fe_output_pdf.apply(predict, axis=1)

    if fe_output_pdf.shape[0] > 0:
        fe_output_pdf = fe_output_pdf.fillna(0)
        df_prediction = spark.createDataFrame(fe_output_pdf)
    else:
        df_prediction = fe_output.withColumn("predictions", F.lit(None))

    # Get the inference output with flags
    inference_output = estimate_unitcost_prediction_flag(df_prediction)

    # Save output to S3:
    save_intermediate_daily_files_s3(
        df=inference_output,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=interim_tables_config["file_name"]["tw_inference"],
    )
    logger.info("** Saved Results Successfully **")
