import sys
import logging

from app.config.base_config import BaseConfig
from pyspark.sql import Window
from app.utils.utils import (
    loading_temporal_views,
    save_intermediate_daily_files_s3,
    load_intermediate_daily_files_s3,
)

from app.utils.data_schemas import (
    customer_schema,
    dealer_schema,
    contract_schema,
    claims_contract_schema,
)

from pyspark.sql.functions import (
    monotonically_increasing_id,
    explode,
    array,
    lit,
    when,
    row_number,
    col,
    max,
    upper,
    lower,
)

import time

# Create a logger instance specific to this module
logger = logging.getLogger(__name__)

# Loading config file
config_file = BaseConfig.TW_PREDICTION_CONFIG
set_up_config = config_file["set_up_configuration"]

# referential and precomputed table config:
referential_tables_config = config_file["referential_tables"]
pre_calc_tables_config = config_file["pre_computed_tables"]
interim_tables_config = config_file["intermediate_results"]["tire_and_wheel"]
interim_bucket_path = interim_tables_config["bucket_path"]


def flatten_json(json_data, spark):
    """Converts JSON data into a flattened Spark DataFrame by extracting nested
    fields and combining related datasets.

    Args:
        json_data (dict): The JSON data containing nested structures to be flattened.
        spark (pyspark.sql.SparkSession): The Spark session used to perform data transformations and create DataFrames.
    """

    # Extract claims
    claims_data = json_data["claims"]
    num_claims = len(claims_data)

    # Create DataFrame for claims
    window = Window.orderBy(monotonically_increasing_id())
    df_claims = spark.createDataFrame(
        claims_data, schema=claims_contract_schema
    ).withColumn("index", row_number().over(window) - 1)

    # Create independent dataframes for dealer:
    df_dealer = spark.createDataFrame(
        [json_data["dealer"]], schema=dealer_schema
    ).withColumn("index", explode(array([lit(x) for x in range(num_claims)])))

    # Create independent dataframes for customer:
    df_customer = spark.createDataFrame(
        [json_data["customer"]], schema=customer_schema
    ).withColumn("index", explode(array([lit(x) for x in range(num_claims)])))

    # Create independent dataframes for contract:
    df_contract = spark.createDataFrame(
        [json_data["contract"]], schema=contract_schema
    ).withColumn("index", explode(array([lit(x) for x in range(num_claims)])))

    # Join all dataframes:
    api_contract_df = (
        df_claims.join(df_dealer, on="index", how="left")
        .join(df_customer, on="index", how="left")
        .join(df_contract, on="index", how="left")
    )

    # remove index column:
    api_contract_df = api_contract_df.drop("index")

    return api_contract_df


# def extract_global_vars(json_contract):
#     """Extracts global variables from the JSON contract."""
#     global_vars = {
#         "sloss_code": list(set([json_contract["claims"][x]["sloss_code"] for x in range(len(json_contract["claims"]))])),
#         "spart_no": list(set([json_contract["claims"][x]["spart_no"] for x in range(len(json_contract["claims"]))])),
#         "spayee_no": list(json_contract["dealer"]["spayee_no"])
#     }
#     return global_vars


def retrieve_api_contract(json_contract: dict, spark: object):
    """Transforms a JSON-based API contract into a structured Spark DataFrame
    for further processing.

    Args:
        json_contract (dict): JSON data representing the contract and associated details.
        spark (pyspark.sql.SparkSession): Spark session to handle data operations.
    """

    # Convert JSON into pyspark dataframe:
    contract_df = flatten_json(json_contract, spark)

    return contract_df


def map_contract_reference_columns(
    api_contract,
    spark,
):
    """Maps additional contract information from external references to the
    existing DataFrame.

    Args:
        api_contract (pyspark.sql.DataFrame): DataFrame containing initial contract data.
        spark (pyspark.sql.SparkSession): Spark session to execute data retrieval.
    """

    # Define column used for filtering:
    contract_column = "scontract_no"

    # Define filter to reduce time computation:
    contract_no = api_contract.select(contract_column).first()[contract_column]
    contract_filter = f"{contract_column} = '{contract_no}'"

    # Read contract form temp view clean master table:
    referential_table = loading_temporal_views(
        table_name=referential_tables_config["tables"]["contracts"],
        cols_to_pull=referential_tables_config["columns"]["contracts"],
        value_filter=contract_filter,
        spark=spark,
    )

    # Extract required columns:
    data_w_contract = api_contract.join(
        referential_table, on=contract_column, how="left"
    )

    # Add is_tec column based on icontract_type
    tec_contract_ls = [
        int(x) for x in referential_tables_config["identification"]["is_tec"]
    ]
    data_w_contract = data_w_contract.withColumn(
        "is_tec", when(col("icontract_type").isin(tec_contract_ls), 1).otherwise(0)
    )

    return data_w_contract


def map_referential_features(
    api_contract,
    id_execution,
    spark: object,
):
    """Enhances an API contract DataFrame with referential data pulled from
    external data sources based on configured mappings.

    Args:
        api_contract (pyspark.sql.DataFrame): DataFrame to enrich with referential data.
        id_execution (dict): Execution identifiers for tracking purposes.
        spark (pyspark.sql.SparkSession): Spark session to manage data retrieval and transformations.
    """

    # Map contract information:
    data_w_contract_vin = map_contract_reference_columns(api_contract, spark)

    # Save interim outputs into S3:
    file_name = interim_tables_config["file_name"]["map_referential_features"]

    save_intermediate_daily_files_s3(
        df=data_w_contract_vin,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name,
    )


def assign_global_vars(
    json_contract: dict,
):
    """Assigns global variables based on specific values extracted from a JSON
    contract for quick access throughout the application.

    Args:
        json_contract (dict): JSON data from which to extract and set global variables.
    """
    """Extracts global variables from the JSON contract."""

    global tw_global_variables
    tw_global_variables = {}
    tw_global_variables = {
        "sloss_code": list(
            set(
                [
                    json_contract["claims"][x]["sloss_code"]
                    for x in range(len(json_contract["claims"]))
                ]
            )
        ),
        "spart_no": list(
            set(
                [
                    json_contract["claims"][x]["spart_no"]
                    for x in range(len(json_contract["claims"]))
                ]
            )
        ),
        "spayee_no": list(json_contract["dealer"]["spayee_no"]),
    }
    return tw_global_variables


def map_tw_part_attributes(
    base_df,
    spark: object,
):
    """Maps part attributes related to tires and wheels from precomputed tables
    to the base DataFrame.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to which part attributes will be mapped.
        spark (pyspark.sql.SparkSession): Spark session to execute data queries.
    """

    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["part_no_mapping"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["part_no_mapping"][
        "columns_to_pull"
    ]

    # Get the list of loss codes and part nos
    sloss_code_str = ",".join(
        ["'" + str(x) + "'" for x in tw_global_variables["sloss_code"]]
    )
    spart_no_str = ",".join(
        ["'" + str(x) + "'" for x in tw_global_variables["spart_no"]]
    )

    # Define filter:
    filter_str = (
        f"sloss_code in ({sloss_code_str}) OR " f"spart_no in ({spart_no_str}) "
    )

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Merge the dataframes:
    # Change to upper, merge and then leave as it was
    base_df = base_df.withColumn("spart_no", upper(col("spart_no")))
    base_df = base_df.join(table, on=["sloss_code", "spart_no"], how="left")
    base_df = base_df.withColumn("spart_no", lower(col("spart_no")))

    # Create the tw_prod_type to only consider TW replacements:
    base_df = base_df.withColumn(
        "tw_prod_type",
        when(lower(col("sdetail_desc")).contains("wheel replace"), "wheel").otherwise(
            when(lower(col("sdetail_desc")).contains("tire replace"), "tire").otherwise(
                "other_prod"
            )
        ),
    )

    # Filter only for tire or wheel replacements (tool scope):
    base_df = base_df.filter(col("tw_prod_type").isin({"tire", "wheel"}))

    # Filter out disposal fees
    base_df = base_df.filter(
        ~((col("creq_unit_cost") <= 10) | (col("spart_no").like("%disp%")))
    )

    # Capture following scenarios for gracefully error execution:
    #  1. Only labor details included on claim records
    #  2. Non TW replacement under claim records

    contains_only_labor = (
        base_df.filter(base_df.sdetail_type.contains("P")).count() == 0
    )
    contains_only_tw_replaces = (
        base_df.filter(~col("tw_prod_type").contains("other_prod")).count() == 0
    )

    # Using the corrected and simplified logic
    if contains_only_labor and contains_only_tw_replaces:
        logger.warning(
            "Only labor details and non TW replacement records included under claim - Exit Engine..."
        )
        spark.stop()
        sys.exit(0)

    elif contains_only_labor and not contains_only_tw_replaces:
        logger.warning("Only labor records included under claim - Exit Engine...")
        spark.stop()
        sys.exit(0)

    elif not contains_only_labor and contains_only_tw_replaces:
        logger.warning(
            "Only TW repairs and non replacements records included under claim - Exit Engine..."
        )
        spark.stop()
        sys.exit(0)

    else:
        logger.info("TW validation on staking went successfully")

    # Get tw_prod_type for M&B at labor by text extraction from spart_desc
    base_df = base_df.withColumn(
        "tw_prod_type",
        when(
            # (lower(col("spart_desc")).rlike(regex_pattern)) |
            (lower(col("sdetail_type")) == "l"),
            "m&b",
        ).otherwise(col("tw_prod_type")),
    )

    return base_df


def map_labor_rate(
    base_df,
    spark: object,
):
    """Maps labor rate information from a precomputed table to the base
    DataFrame based on dealer and other criteria.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to enhance with labor rate data.
        spark (pyspark.sql.SparkSession): Spark session to manage data retrieval.
    """
    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["labor_rate"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["labor_rate"]["columns_to_pull"]

    # Get the list of loss codes and part nos
    spayee_no_str = ",".join(["'" + x + "'" for x in tw_global_variables["spayee_no"]])

    base_df = base_df.withColumn(
        "sparent_type_code",
        when(
            col("sservice_center_type").contains("D"),
            "SLR",
        ).otherwise("SVC"),
    )

    # Define filter:
    filter_str = f"spayee_no in ({spayee_no_str})"

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Merge the dataframes:
    base_df = base_df.join(table, on=["sparent_type_code", "spayee_no"], how="left")

    base_df = base_df.drop("sparent_type_code")

    return base_df


def map_fred_index(
    base_df,
    spark: object,
):
    """Integrates financial index data from a precomputed source into the base
    DataFrame for enriched analysis capabilities.

    Args:
        base_df (pyspark.sql.DataFrame): DataFrame to enhance with financial index data.
        spark (pyspark.sql.SparkSession): Spark session to execute data queries.
    """
    # Construct the filtering string:
    table_name = pre_calc_tables_config["tables"]["fred_index"]["table_name"]
    cols_to_pull = pre_calc_tables_config["tables"]["fred_index"]["columns_to_pull"]

    # Define filter:
    filter_str = "date > add_months(current_date(), -3)"

    # Load table from s3:
    table = loading_temporal_views(
        table_name=table_name,
        cols_to_pull=cols_to_pull,
        value_filter=filter_str,
        spark=spark,
    )

    # Find the maximum date
    max_date = table.select(max("date")).first()[0]

    # Filter the DataFrame to get rows with the maximum date
    df_max_date = table.filter(col("date") == max_date).select("fred_index_price")

    # Merge the dataframes:
    base_df = base_df.join(df_max_date, how="left")

    return base_df


def map_pre_computed_features(
    id_execution,
    spark: object,
):
    """Retrieves and integrates multiple pre-computed features into the API
    contract data for enhanced analytical capabilities.

    Args:
        id_execution (dict): Identifiers related to the execution context.
        spark (pyspark.sql.SparkSession): Active Spark session to handle data transformations.
    """

    # Read interim parquet file from S3:
    file_name_input = interim_tables_config["file_name"]["map_referential_features"]

    api_contract_df = load_intermediate_daily_files_s3(
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_input,
        spark=spark,
    )

    # Map product type and additional tire metrics:
    api_contract_df = map_tw_part_attributes(api_contract_df, spark)
    logger.info("Mapping pre-compute dealer features...")

    # Write interim output to s3:
    file_name_output = interim_tables_config["file_name"]["staking_info"]

    save_intermediate_daily_files_s3(
        df=api_contract_df,
        s3_bucket=interim_bucket_path,
        date_folder=id_execution["date_folder"],
        job_run_id=id_execution["job_run_id"],
        file_name=file_name_output,
    )

    return api_contract_df


def stack_claim_information(json_contract, id_execution, spark):
    """Orchestrate tasks related to staking claim information including data
    retrieval, feature mapping, and data transformation.

    Args:
        json_contract (dict): JSON contract containing detailed claims information.
        id_execution (dict): Dictionary containing identifiers for the job run.
        spark (pyspark.sql.SparkSession): Spark session to handle data operations.
    """
    logger.info("** Initializing staking info task **")

    # define global variables:
    assign_global_vars(json_contract)
    logger.info("Global variables assigned...")

    # Retrieve API contract information:
    start_time = time.time()
    api_contract = retrieve_api_contract(json_contract, spark)
    logger.info(
        "Elapsed time for task retrieve_api_contract: %s seconds",
        time.time() - start_time,
    )
    logger.info("API contract parse correctly...")

    # Map referential columns from S3:
    start_time = time.time()
    map_referential_features(api_contract, id_execution, spark)
    logger.info(
        "Elapsed time for task data_w_referential: %s seconds",
        time.time() - start_time,
    )
    logger.info("Referential features included into pipeline...")

    # Map pre-computed columns from S3:
    start_time = time.time()
    map_pre_computed_features(id_execution, spark)
    logger.info(
        "Elapsed time for task data_w_ref_comp: : %s seconds", time.time() - start_time
    )
    logger.info("Pre-computed features included into pipeline...")
